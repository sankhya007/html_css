var ConvertKitCommerce = function(t) {
    var e = {};

    function r(n) {
        if (e[n]) return e[n].exports;
        var i = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(i.exports, i, i.exports, r), i.l = !0, i.exports
    }
    return r.m = t, r.c = e, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function(t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var i in t) r.d(n, i, function(e) {
                return t[e]
            }.bind(null, i));
        return n
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "", r(r.s = 0)
}([function(t, e, r) {
    "use strict";
    r.r(e);
    var n = function(t, e) {
        var r = document.createElement(t);
        for (var n in e)
            if ("style" == n)
                for (var i in e[n]) r.style[i] = e[n][i];
            else r.setAttribute(n, e[n]);
        return r
    };
    var i = function(t) {
        var e = t.src,
            r = t.title,
            i = n("iframe", {
                src: e,
                title: r,
                style: {
                    position: "fixed",
                    overflow: "hidden",
                    zIndex: 99999,
                    top: 0,
                    right: 0,
                    border: "none",
                    width: "0%",
                    height: "0%"
                }
            }),
            o = function(t) {
                try {
                    switch (JSON.parse(t.data).type) {
                        case "hide-modal":
                            return a()
                    }
                } catch (t) {}
            },
            a = function() {
                i.style.height = "0%", i.style.width = "0%", i.remoteAttr("data-active")
            };
        return window.iframe = i, {
            show: function() {
                var t, e;
                i.style.height = "100%", i.style.width = "100%", i.dataset.active = "", t = i.contentWindow, e = {
                    type: "show-modal"
                }, t.postMessage(JSON.stringify(e), "*"), window.addEventListener("message", o, !1)
            },
            hide: a,
            init: function() {
                document.body.appendChild(i)
            },
            remove: function() {
                i.remove()
            }
        }
    };
    var o = function(t) {
        var e = "https://".concat(t.href.split("/")[2]);
        t.hasAttribute("data-initialized") || function() {
            var r = new URL(t.href);
            r.searchParams.append("embed", !0);
            var o = i({
                src: r.toString(),
                title: t.innerText
            });
            if (o.init(), t.classList.contains("convertkit-button")) {
                var a = n("link", {
                    rel: "stylesheet",
                    href: "".concat(e, "/commerce.css")
                });
                document.head.appendChild(a)
            }
            t.addEventListener("click", (function(t) {
                t.preventDefault(), o.show()
            })), t.dataset.initialized = ""
        }()
    };

    function a(t) {
        return function(t) {
            if (Array.isArray(t)) {
                for (var e = 0, r = new Array(t.length); e < t.length; e++) r[e] = t[e];
                return r
            }
        }(t) || function(t) {
            if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        }()
    }
    a(document.querySelectorAll("[data-commerce]")).map((function(t) {
        return o(t)
    }))
}]).default;