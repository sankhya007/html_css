(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        fa = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        r = {},
        ha = {},
        t = function(a, b, c) {
            if (!c || null != a) {
                c = ha[b];
                if (null == c) return a[b];
                c = a[c];
                return void 0 !== c ? c : a[b]
            }
        },
        u = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = 1 === d.length;
                var e = d[0],
                    f;!a && e in r ? f = r : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = fa && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? ba(r, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (void 0 === ha[d] && (a = 1E9 * Math.random() >>> 0, ha[d] = fa ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, ha[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        };
    u("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    u("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, r.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ja(aa(this))
                }
            })
        }
        return a
    }, "es6");
    var ja = function(a) {
            a = {
                next: a
            };
            a[t(r.Symbol, "iterator")] = function() {
                return this
            };
            return a
        },
        ka = function(a) {
            return a.raw = a
        },
        v = function(a) {
            var b = "undefined" != typeof r.Symbol && t(r.Symbol, "iterator") && a[t(r.Symbol, "iterator")];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        w = function(a) {
            if (!(a instanceof Array)) {
                a = v(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        la = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ma = fa && "function" == typeof t(Object, "assign") ? t(Object, "assign") : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) la(d, e) && (a[e] = d[e])
            }
            return a
        };
    u("Object.assign", function(a) {
        return a || ma
    }, "es6");
    var na = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        oa;
    if (fa && "function" == typeof Object.setPrototypeOf) oa = Object.setPrototypeOf;
    else {
        var pa;
        a: {
            var qa = {
                    a: !0
                },
                ra = {};
            try {
                ra.__proto__ = qa;
                pa = ra.a;
                break a
            } catch (a) {}
            pa = !1
        }
        oa = pa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var sa = oa,
        x = function(a, b) {
            a.prototype = na(b.prototype);
            a.prototype.constructor = a;
            if (sa) sa(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Va = b.prototype
        },
        ta = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    u("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    }, "es6");
    u("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = v(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!la(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!la(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && la(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && la(g, d) && la(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && la(g, d) && la(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    u("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(v([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (p) {
                    return !1
                }
            }()) return a;
        var b = new r.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = v(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.s ? l.s.value = k : (l.s = {
                next: this[1],
                B: this[1].B,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.s), this[1].B.next = l.s, this[1].B = l.s, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.s && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.s.B.next = h.s.next, h.s.next.B = h.s.B, h.s.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].B = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).s
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).s) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[t(r.Symbol, "iterator")] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && la(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var p = m[h];
                        if (k !== k && p.key !== p.key || k === p.key) return {
                            id: l,
                            list: m,
                            index: h,
                            s: p
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    s: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return ja(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.B;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.B = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    u("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) la(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    u("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    u("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || t(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    var va = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    u("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== va(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    var wa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[t(r.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    u("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof r.Symbol && t(r.Symbol, "iterator") && b[t(r.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    u("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return wa(this, function(b) {
                return b
            })
        }
    }, "es6");
    u("Array.prototype.values", function(a) {
        return a ? a : function() {
            return wa(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    u("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(v([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new r.Map;
            if (c) {
                c = v(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return this.g.entries()
        };
        b.prototype.values = function() {
            return t(this.g, "values").call(this.g)
        };
        b.prototype.keys = t(b.prototype, "values");
        b.prototype[t(r.Symbol, "iterator")] = t(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    u("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = va(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    u("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = va(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    u("globalThis", function(a) {
        return a || da
    }, "es_2020");
    u("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = va(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? t(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    var y = this || self,
        xa = function(a) {
            a = a.split(".");
            for (var b = y, c = 0; c < a.length; c++)
                if (b = b[a[c]], null == b) return null;
            return b
        },
        ya = function(a, b) {
            a = a.split(".");
            var c = y;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };
    var za = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Ha = function(a) {
            if (!Aa.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Ba, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Ca, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Da, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Ea, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Fa, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ga, "&#0;"));
            return a
        },
        Ba = /&/g,
        Ca = /</g,
        Da = />/g,
        Ea = /"/g,
        Fa = /'/g,
        Ga = /\x00/g,
        Aa = /[\x00&<>"']/,
        Ja = function(a, b) {
            var c = 0;
            a = za(String(a)).split(".");
            b = za(String(b)).split(".");
            for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
                var f = a[e] || "",
                    g = b[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    c = Ia(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Ia(0 == f[2].length, 0 == g[2].length) || Ia(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == c)
            }
            return c
        },
        Ia = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var Ka, La = xa("CLOSURE_FLAGS"),
        Ma = La && La[610401301];
    Ka = null != Ma ? Ma : !1;

    function Na() {
        var a = y.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Oa, Pa = y.navigator;
    Oa = Pa ? Pa.userAgentData || null : null;

    function Qa(a) {
        return Ka ? Oa ? Oa.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function A(a) {
        return -1 != Na().indexOf(a)
    };

    function Ra() {
        return Ka ? !!Oa && 0 < Oa.brands.length : !1
    }

    function Sa() {
        return Ra() ? Qa("Chromium") : (A("Chrome") || A("CriOS")) && !(Ra() ? 0 : A("Edge")) || A("Silk")
    };
    var Ta = function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        },
        Ua = function(a, b) {
            return Array.prototype.filter.call(a, b, void 0)
        },
        Va = function(a, b) {
            return Array.prototype.map.call(a, b, void 0)
        };

    function Wa(a, b) {
        a: {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Xa(a, b) {
        a: {
            for (var c = "string" === typeof a ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ya(a, b) {
        return 0 <= Array.prototype.indexOf.call(a, b, void 0)
    };
    var Za = function(a) {
        Za[" "](a);
        return a
    };
    Za[" "] = function() {};
    var $a = Ra() ? !1 : A("Trident") || A("MSIE");
    !A("Android") || Sa();
    Sa();
    A("Safari") && (Sa() || (Ra() ? 0 : A("Coast")) || (Ra() ? 0 : A("Opera")) || (Ra() ? 0 : A("Edge")) || (Ra() ? Qa("Microsoft Edge") : A("Edg/")) || Ra() && Qa("Opera"));
    var ab = {},
        bb = null,
        db = function(a) {
            var b = [];
            cb(a, function(c) {
                b.push(c)
            });
            return b
        },
        cb = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = bb[l];
                    if (null != m) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            eb();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        eb = function() {
            if (!bb) {
                bb = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    ab[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === bb[f] && (bb[f] = e)
                    }
                }
            }
        };
    var fb = "undefined" !== typeof Uint8Array,
        gb = !$a && "function" === typeof btoa;

    function hb(a) {
        return Array.prototype.slice.call(a)
    };
    var B = "function" === typeof r.Symbol && "symbol" === typeof(0, r.Symbol)() ? (0, r.Symbol)() : void 0,
        ib = B ? function(a, b) {
            a[B] |= b
        } : function(a, b) {
            void 0 !== a.g ? a.g |= b : Object.defineProperties(a, {
                g: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function kb(a) {
        var b = C(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = hb(a)), D(a, b | 1))
    }
    var lb = B ? function(a, b) {
            a[B] &= ~b
        } : function(a, b) {
            void 0 !== a.g && (a.g &= ~b)
        },
        C = B ? function(a) {
            return a[B] | 0
        } : function(a) {
            return a.g | 0
        },
        E = B ? function(a) {
            return a[B]
        } : function(a) {
            return a.g
        },
        D = B ? function(a, b) {
            a[B] = b
        } : function(a, b) {
            void 0 !== a.g ? a.g = b : Object.defineProperties(a, {
                g: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function mb(a, b) {
        Object.isFrozen(a) && (a = hb(a));
        D(a, b);
        return a
    }

    function nb(a) {
        ib(a, 1);
        return a
    }

    function ob(a, b) {
        D(b, (a | 0) & -51)
    }

    function pb(a, b) {
        D(b, (a | 18) & -41)
    }

    function qb(a) {
        a = a >> 10 & 1023;
        return 0 === a ? 536870912 : a
    };
    var rb = {};

    function sb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var tb, ub, vb = [];
    D(vb, 23);
    ub = Object.freeze(vb);

    function wb(a) {
        if (a & 2) throw Error();
    };

    function xb(a) {
        if ("boolean" !== typeof a) {
            var b = typeof a;
            throw Error("Expected boolean but got " + ("object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null") + ": " + a);
        }
        return !!a
    }

    function yb(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    }

    function zb(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    }

    function Ab(a) {
        return null == a ? a : a
    }

    function Bb(a) {
        return a
    }

    function Cb(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function F(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function G(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Db(a, b, c) {
        var d = !1;
        if (null != a && "object" === typeof a && !(d = Array.isArray(a)) && a.O === rb) return a;
        if (d) {
            var e = d = C(a);
            0 === e && (e |= c & 16);
            e |= c & 2;
            e !== d && D(a, e);
            return new b(a)
        }
    }
    var Eb = "function" === typeof r.Symbol && "symbol" === typeof(0, r.Symbol)() ? (0, r.Symbol)() : "di";
    var H = function(a, b) {
            a = a.h;
            return Fb(a, E(a), b)
        },
        Fb = function(a, b, c, d) {
            if (-1 === c) return null;
            if (c >= qb(b)) {
                if (b & 128) return a[a.length - 1][c]
            } else {
                var e = a.length;
                if (d && b & 128 && (d = a[e - 1][c], null != d)) return d;
                b = c + ((b >> 8 & 1) - 1);
                if (b < e) return a[b]
            }
        },
        J = function(a, b, c) {
            var d = a.h,
                e = E(d);
            wb(e);
            I(d, e, b, c);
            return a
        };

    function I(a, b, c, d, e) {
        var f = qb(b);
        if (c >= f || e) {
            e = b;
            if (b & 128) f = a[a.length - 1];
            else {
                if (null == d) return;
                f = a[f + ((b >> 8 & 1) - 1)] = {};
                e |= 128
            }
            f[c] = d;
            e &= -513;
            e !== b && D(a, e)
        } else a[c + ((b >> 8 & 1) - 1)] = d, b & 128 && (d = a[a.length - 1], c in d && delete d[c]), b & 512 && D(a, b & -513)
    }

    function Gb(a, b, c) {
        var d = b & 2;
        a = Fb(a, b, c);
        Array.isArray(a) || (a = ub);
        b = C(a);
        b & 1 || nb(a);
        d ? b & 2 || ib(a, 18) : b & 16 && !(b & 2) && lb(a, 16);
        return a
    }

    function Hb(a, b, c) {
        a = a.h;
        var d = E(a),
            e = d & 2,
            f = Gb(a, d, b),
            g = C(f);
        if (!(g & 4)) {
            Object.isFrozen(f) && (f = nb(hb(f)), I(a, d, b, f));
            for (var h = 0, k = 0; h < f.length; h++) {
                var l = c(f[h]);
                null != l && (f[k++] = l)
            }
            k < h && (f.length = k);
            g |= 5;
            e && (g |= 18);
            D(f, g);
            g & 2 && Object.freeze(f)
        }!e && (g & 2 || Object.isFrozen(f)) && (f = hb(f), ib(f, 5), I(a, d, b, f));
        return f
    }

    function Ib(a, b, c, d) {
        var e = a.h,
            f = E(e);
        wb(f);
        if (null == c) return I(e, f, b), a;
        var g = C(c);
        if (!(g & 4)) {
            if (g & 2 || Object.isFrozen(c)) c = hb(c);
            for (var h = 0; h < c.length; h++) c[h] = d(c[h]);
            D(c, g | 5)
        }
        I(e, f, b, c);
        return a
    }

    function K(a, b, c, d) {
        var e = a.h,
            f = E(e);
        wb(f);
        I(e, f, b, c !== d ? c : void 0);
        return a
    }
    var Kb = function(a, b, c, d) {
            var e = a.h,
                f = E(e);
            wb(f);
            (c = Jb(e, f, c)) && c !== b && null != d && I(e, f, c);
            I(e, f, b, d);
            return a
        },
        Lb = function(a, b, c) {
            a = a.h;
            return Jb(a, E(a), b) === c ? c : -1
        },
        Mb = function(a, b) {
            a = a.h;
            return Jb(a, E(a), b)
        };

    function Jb(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != Fb(a, b, f) && (0 !== d && I(a, b, d), d = f)
        }
        return d
    }
    var Nb = function(a, b, c, d) {
            a = a.h;
            var e = E(a),
                f = Fb(a, e, c, d);
            b = Db(f, b, e);
            b !== f && null != b && I(a, e, c, b, d);
            return b
        },
        Pb = function(a, b) {
            (a = Nb(a, b, 1, !1)) ? b = a: (a = b[Eb]) ? b = a : (a = new b, ib(a.h, 18), b = b[Eb] = a);
            return b
        },
        L = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            b = Nb(a, b, c, d);
            if (null == b) return b;
            a = a.h;
            var e = E(a);
            if (!(e & 2)) {
                var f = Qb(b);
                f !== b && (b = f, I(a, e, c, b, d))
            }
            return b
        },
        M = function(a, b, c) {
            var d = a.h,
                e = E(d);
            a = !!(e & 2);
            var f = a ? 1 : 2,
                g = !!(e & 2),
                h = Gb(d, e, c);
            if (h !== ub && C(h) & 4) 3 === f || g || (g = Object.isFrozen(h), 1 === f ? g || Object.freeze(h) : (f = C(h), b = f & -19, g && (h = hb(h), f = 0, I(d, e, c, h)), f !== b && D(h, b))), c = h;
            else {
                var k = h;
                h = !!(e & 2);
                var l = !!(C(k) & 2);
                g = k;
                !h && l && (k = hb(k));
                var m = e | (l ? 2 : 0);
                l = l || void 0;
                for (var p = 0, n = 0; p < k.length; p++) {
                    var z = Db(k[p], b, m);
                    void 0 !== z && (l = l || E(z.h) & 2, k[n++] = z)
                }
                n < p && (k.length = n);
                b = k;
                k = C(b);
                m = k | 5;
                l = l ? m & -9 : m | 8;
                k != l && (b = mb(b, l));
                k = b;
                g !== k && I(d, e, c, k);
                (h && 2 !== f || 1 === f) && Object.freeze(k);
                c = k
            }
            if (!(a || C(c) & 8)) {
                for (a = 0; a < c.length; a++) d = c[a], e = Qb(d), d !== e && (c[a] = e);
                ib(c, 8)
            }
            return c
        },
        Rb = function(a, b, c) {
            null == c && (c = void 0);
            return J(a, b, c)
        },
        Sb = function(a, b, c, d) {
            null == d && (d = void 0);
            return Kb(a, b, c, d)
        },
        Tb = function(a, b, c) {
            var d = a.h,
                e = E(d);
            wb(e);
            if (null != c) {
                for (var f = !!c.length, g = 0; g < c.length; g++) {
                    var h = c[g];
                    f = f && !(C(h.h) & 2)
                }
                g = C(c);
                h = g | 1;
                h = (f ? h | 8 : h & -9) | 4;
                h != g && (c = mb(c, h))
            }
            null == c && (c = void 0);
            I(d, e, b, c);
            return a
        },
        N = function(a, b, c) {
            return K(a, b, Ab(c), 0)
        };

    function O(a, b) {
        return null != a ? a : b
    }
    var Ub = function(a, b) {
            a = H(a, b);
            return O(null == a ? a : "boolean" === typeof a || "number" === typeof a ? !!a : void 0, !1)
        },
        Vb = function(a, b) {
            return O(yb(H(a, b)), 0)
        },
        Wb = function(a, b) {
            var c = void 0 === c ? 0 : c;
            a = a.h;
            var d = E(a),
                e = Fb(a, d, b);
            var f = null == e ? e : "number" === typeof e || "NaN" === e || "Infinity" === e || "-Infinity" === e ? Number(e) : void 0;
            null != f && f !== e && I(a, d, b, f);
            return O(f, c)
        },
        P = function(a, b) {
            return O(G(H(a, b)), "")
        },
        Q = function(a, b) {
            a = H(a, b);
            return O(null == a ? a : a, 0)
        };
    var Xb;

    function Yb(a, b) {
        Xb = b;
        a = new a(b);
        Xb = void 0;
        return a
    }

    function R(a, b, c) {
        null == a && (a = Xb);
        Xb = void 0;
        if (null == a) {
            var d = 48;
            c ? (a = [c], d |= 256) : a = [];
            b && (d = d & -1047553 | (b & 1023) << 10)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = C(a);
            if (d & 32) return a;
            d |= 32;
            if (c && (d |= 256, c !== a[0])) throw Error();
            a: {
                c = a;
                var e = c.length;
                if (e) {
                    var f = e - 1,
                        g = c[f];
                    if (sb(g)) {
                        d |= 128;
                        b = (d >> 8 & 1) - 1;
                        e = f - b;
                        1024 <= e && (Zb(c, b, g), e = 1023);
                        d = d & -1047553 | (e & 1023) << 10;
                        break a
                    }
                }
                b && (g = (d >> 8 & 1) - 1, b = Math.max(b, e - g), 1024 < b && (Zb(c, g, {}), d |= 128, b = 1023), d = d & -1047553 | (b & 1023) << 10)
            }
        }
        D(a, d);
        return a
    }

    function Zb(a, b, c) {
        for (var d = 1023 + b, e = a.length, f = d; f < e; f++) {
            var g = a[f];
            null != g && g !== c && (c[f - b] = g)
        }
        a.length = d + 1;
        a[d] = c
    };

    function $b(a, b) {
        return ac(b)
    }

    function ac(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a && !Array.isArray(a) && fb && null != a && a instanceof Uint8Array) {
                    if (gb) {
                        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        a = btoa(b)
                    } else {
                        void 0 === b && (b = 0);
                        eb();
                        b = ab[b];
                        c = Array(Math.floor(a.length / 3));
                        d = b[64] || "";
                        for (var e = 0, f = 0; e < a.length - 2; e += 3) {
                            var g = a[e],
                                h = a[e + 1],
                                k = a[e + 2],
                                l = b[g >> 2];
                            g = b[(g & 3) << 4 | h >> 4];
                            h = b[(h & 15) << 2 | k >> 6];
                            k = b[k & 63];
                            c[f++] = l + g + h + k
                        }
                        l = 0;
                        k = d;
                        switch (a.length - e) {
                            case 2:
                                l = a[e + 1], k = b[(l & 15) << 2] || d;
                            case 1:
                                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
                        }
                        a = c.join("")
                    }
                    return a
                }
        }
        return a
    };

    function bc(a, b, c) {
        a = hb(a);
        var d = a.length,
            e = b & 128 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 256 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function cc(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && C(a) & 1 ? void 0 : f && C(a) & 2 ? a : dc(a, b, c, void 0 !== d, e, f);
            else if (sb(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = cc(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function dc(a, b, c, d, e, f) {
        var g = d || c ? C(a) : 0;
        d = d ? !!(g & 16) : void 0;
        a = hb(a);
        for (var h = 0; h < a.length; h++) a[h] = cc(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function ec(a) {
        return a.O === rb ? a.toJSON() : ac(a)
    };

    function fc(a, b, c) {
        c = void 0 === c ? pb : c;
        if (null != a) {
            if (fb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = C(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return D(a, d | 18), a;
                a = dc(a, fc, d & 4 ? pb : c, !0, !1, !0);
                b = C(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            a.O === rb && (b = a.h, c = E(b), a = c & 2 ? a : gc(a, b, c, !0));
            return a
        }
    }

    function gc(a, b, c, d) {
        var e = d || c & 2 ? pb : ob,
            f = !!(c & 16);
        b = bc(b, c, function(g) {
            return fc(g, f, e)
        });
        ib(b, 16 | (d ? 2 : 0));
        return Yb(a.constructor, b)
    }

    function Qb(a) {
        var b = a.h,
            c = E(b);
        if (!(c & 2)) return a;
        b = gc(a, b, c, !1);
        b.g = a;
        ib(b.h, 512);
        return b
    };
    var S = function(a, b, c) {
        this.h = R(a, b, c)
    };
    S.prototype.toJSON = function() {
        if (tb) var a = hc(this, this.h, !1);
        else a = dc(this.h, ec, void 0, void 0, !1, !1), a = hc(this, a, !0);
        return a
    };
    var ic = function(a) {
        tb = !0;
        try {
            return JSON.stringify(a.toJSON(), $b)
        } finally {
            tb = !1
        }
    };
    S.prototype.O = rb;

    function hc(a, b, c) {
        var d = a.constructor.m,
            e = qb(E(c ? a.h : b)),
            f = !1;
        if (d) {
            if (!c) {
                b = hb(b);
                var g;
                if (b.length && sb(g = b[b.length - 1]))
                    for (f = 0; f < d.length; f++)
                        if (d[f] >= e) {
                            t(Object, "assign").call(Object, b[b.length - 1] = {}, g);
                            break
                        }
                f = !0
            }
            e = b;
            c = !c;
            g = E(a.h);
            a = qb(g);
            g = (g >> 8 & 1) - 1;
            for (var h, k, l = 0; l < d.length; l++)
                if (k = d[l], k < a) {
                    k += g;
                    var m = e[k];
                    null == m ? e[k] = c ? ub : nb([]) : c && m !== ub && kb(m)
                } else h || (m = void 0, e.length && sb(m = e[e.length - 1]) ? h = m : e.push(h = {})), m = h[k], null == h[k] ? h[k] = c ? ub : nb([]) : c && m !== ub && kb(m)
        }
        d = b.length;
        if (!d) return b;
        var p;
        if (sb(h = b[d - 1])) {
            a: {
                var n = h;e = {};c = !1;
                for (var z in n) Object.prototype.hasOwnProperty.call(n, z) && (a = n[z], Array.isArray(a) && a != a && (c = !0), null != a ? e[z] = a : c = !0);
                if (c) {
                    for (var ea in e) {
                        n = e;
                        break a
                    }
                    n = null
                }
            }
            n != h && (p = !0);d--
        }
        for (; 0 < d; d--) {
            h = b[d - 1];
            if (null != h) break;
            var ua = !0
        }
        if (!p && !ua) return b;
        var W;
        f ? W = b : W = Array.prototype.slice.call(b, 0, d);
        b = W;
        f && (b.length = d);
        n && b.push(n);
        return b
    };
    var jc = void 0;

    function kc() {
        var a = jc;
        jc = void 0;
        return a
    };

    function lc(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                ib(b, 16);
                b = Yb(a, b)
            }
            return b
        }
    };
    var mc = function(a) {
        this.h = R(a)
    };
    x(mc, S);
    mc.m = [6, 4];
    var nc = function(a) {
        this.h = R(a)
    };
    x(nc, S);
    var oc = lc(nc);
    nc.m = [4, 5, 6];
    var rc = function(a, b) {
        this.i = a === pc && b || "";
        this.j = qc
    };
    rc.prototype.D = !0;
    rc.prototype.g = function() {
        return this.i
    };
    var sc = function(a) {
            return a instanceof rc && a.constructor === rc && a.j === qc ? a.i : "type_error:Const"
        },
        qc = {},
        pc = {};
    var tc = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var uc = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };

    function vc(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var wc = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var T = function(a) {
        this.i = a
    };
    T.prototype.toString = function() {
        return this.i + ""
    };
    T.prototype.D = !0;
    T.prototype.g = function() {
        return this.i.toString()
    };
    var xc = function(a) {
            return a instanceof T && a.constructor === T ? a.i : "type_error:TrustedResourceUrl"
        },
        yc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        zc = {},
        Ac = function(a, b, c) {
            if (null == c) return b;
            if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
            for (var d in c)
                if (Object.prototype.hasOwnProperty.call(c, d)) {
                    var e = c[d];
                    e = Array.isArray(e) ? e : [e];
                    for (var f = 0; f < e.length; f++) {
                        var g = e[f];
                        null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                    }
                }
            return b
        };
    var Bc = function(a) {
        this.i = a
    };
    Bc.prototype.toString = function() {
        return this.i.toString()
    };
    Bc.prototype.D = !0;
    Bc.prototype.g = function() {
        return this.i.toString()
    };
    var Cc = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        Dc = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        Ec = {},
        Fc = new Bc("about:invalid#zClosurez", Ec);
    var Gc = {},
        Hc = function(a) {
            this.i = a;
            this.D = !0
        };
    Hc.prototype.g = function() {
        return this.i.toString()
    };
    Hc.prototype.toString = function() {
        return this.i.toString()
    };
    var Ic = function(a) {
            return a instanceof Hc && a.constructor === Hc ? a.i : "type_error:SafeHtml"
        },
        Jc = function(a) {
            return a instanceof Hc ? a : new Hc(Ha("object" == typeof a && a.D ? a.g() : String(a)), Gc)
        },
        Nc = function(a, b) {
            var c = {
                    src: a
                },
                d = {};
            a = {};
            for (var e in c) Object.prototype.hasOwnProperty.call(c, e) && (a[e] = c[e]);
            for (var f in d) Object.prototype.hasOwnProperty.call(d, f) && (a[f] = d[f]);
            if (b)
                for (var g in b)
                    if (Object.prototype.hasOwnProperty.call(b, g)) {
                        e = g.toLowerCase();
                        if (e in c) throw Error("");
                        e in d && delete a[e];
                        a[g] = b[g]
                    }
            var h;
            b = "";
            if (a)
                for (k in a)
                    if (Object.prototype.hasOwnProperty.call(a, k)) {
                        if (!Kc.test(k)) throw Error("");
                        c = a[k];
                        if (null != c) {
                            g = k;
                            if (c instanceof rc) c = sc(c);
                            else {
                                if ("style" == g.toLowerCase()) throw Error("");
                                if (/^on/i.test(g)) throw Error("");
                                if (g.toLowerCase() in Lc)
                                    if (c instanceof T) c = xc(c).toString();
                                    else if (c instanceof Bc) c = c instanceof Bc && c.constructor === Bc ? c.i : "type_error:SafeUrl";
                                else if ("string" === typeof c) c instanceof Bc || (c = "object" == typeof c && c.D ? c.g() : String(c), Dc.test(c) ? c = new Bc(c, Ec) : (c = String(c), c = c.replace(/(%0A|%0D)/g, ""), c = c.match(Cc) ? new Bc(c, Ec) : null)), c = (c || Fc).g();
                                else throw Error("");
                            }
                            c.D && (c = c.g());
                            g = g + '="' + Ha(String(c)) + '"';
                            b += " " + g
                        }
                    }
            var k = "<script" + b;
            null == h ? h = [] : Array.isArray(h) || (h = [h]);
            !0 === wc.script ? k += ">" : (h = Mc(h), k += ">" + Ic(h).toString() + "\x3c/script>");
            return new Hc(k, Gc)
        },
        Pc = function(a) {
            var b = Jc(Oc),
                c = [],
                d = function(e) {
                    Array.isArray(e) ? e.forEach(d) : (e = Jc(e), c.push(Ic(e).toString()))
                };
            a.forEach(d);
            return new Hc(c.join(Ic(b).toString()), Gc)
        },
        Mc = function(a) {
            return Pc(Array.prototype.slice.call(arguments))
        },
        Kc = /^[a-zA-Z0-9-]+$/,
        Lc = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Oc = new Hc(y.trustedTypes && y.trustedTypes.emptyHTML || "", Gc);
    var Rc = function() {
            a: {
                var a = y.document;
                if (a.querySelector && (a = a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && Qc.test(a)) break a;a = ""
            }
            return a
        },
        Qc = /^[\w+/_-]+[=]{0,2}$/;
    var Sc = function() {
        return Ka && Oa ? !Oa.mobile && (A("iPad") || A("Android") || A("Silk")) : A("iPad") || A("Android") && !A("Mobile") || A("Silk")
    };
    var Tc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Uc = function(a) {
            return a ? decodeURI(a) : a
        },
        Vc = /#|$/,
        Wc = function(a, b) {
            var c = a.search(Vc);
            a: {
                var d = 0;
                for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                    var f = a.charCodeAt(d - 1);
                    if (38 == f || 63 == f)
                        if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                    d += e + 1
                }
                d = -1
            }
            if (0 > d) return null;
            e = a.indexOf("&", d);
            if (0 > e || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
        };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Xc(a, b) {
        a.src = xc(b);
        var c, d;
        (c = (b = null == (d = (c = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : d.call(c, "script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };

    function Yc(a, b) {
        a.write(Ic(b))
    };
    var Zc = function(a) {
            try {
                var b;
                if (b = !!a && null != a.location.href) a: {
                    try {
                        Za(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        $c = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = void 0 === c ? y : c;
            for (var d = 0; c && 40 > d++ && (!b && !Zc(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e != c) {
                        c = e;
                        break a
                    }
                } catch (f) {}
                c = null
            }
        },
        ad = function(a) {
            var b = a;
            $c(function(c) {
                b = c;
                return !1
            });
            return b
        },
        bd = function(a) {
            return Zc(a.top) ? a.top : null
        },
        fd = function(a, b) {
            if (!cd() && !dd()) {
                var c = Math.random();
                if (c < b) return c = ed(), a[Math.floor(c * a.length)]
            }
            return null
        },
        ed = function() {
            if (!r.globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                r.globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        },
        gd = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        hd = function(a) {
            var b = a.length;
            if (0 == b) return 0;
            for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
            return 0 < c ? c : 4294967296 + c
        },
        dd = tc(function() {
            return Array.prototype.some.call(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], id, void 0) || 1E-4 > Math.random()
        }),
        cd = tc(function() {
            return id("MSIE")
        }),
        id = function(a) {
            return -1 != Na().indexOf(a)
        },
        jd = /^(-?[0-9.]{1,30})$/,
        kd = function() {
            return /^true$/.test("false")
        },
        ld = tc(function() {
            return (Ka && Oa ? Oa.mobile : !Sc() && (A("iPod") || A("iPhone") || A("Android") || A("IEMobile"))) ? 2 : Sc() ? 1 : 0
        }),
        md = function(a) {
            if ("number" !== typeof a.goog_pvsid) try {
                var b = Object,
                    c = b.defineProperty,
                    d = void 0;
                d = void 0 === d ? Math.random : d;
                var e = Math.floor(d() * Math.pow(2, 52));
                c.call(b, a, "goog_pvsid", {
                    value: e,
                    configurable: !1
                })
            } catch (f) {}
            return Number(a.goog_pvsid) || -1
        },
        nd = function(a, b) {
            b = void 0 === b ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function od(a) {
        var b = ta.apply(1, arguments);
        if (0 === b.length) return new T(a[0], zc);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return new T(c, zc)
    }

    function pd(a, b) {
        var c = xc(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return new T(c, zc)
    };
    var qd = {
        Ja: 0,
        Ia: 1,
        Fa: 2,
        Aa: 3,
        Ga: 4,
        Ba: 5,
        Ha: 6,
        Da: 7,
        Ea: 8,
        za: 9,
        Ca: 10,
        Ka: 11
    };
    var rd = {
        Ma: 0,
        Na: 1,
        La: 2
    };
    var sd = function(a) {
        this.h = R(a)
    };
    x(sd, S);
    var td = {
            "-": 0,
            Y: 2,
            N: 1
        },
        ud = {},
        vd = (ud[0] = "-", ud[2] = "Y", ud[1] = "N", ud);
    var wd = function(a) {
        this.h = R(a)
    };
    x(wd, S);
    wd.prototype.getVersion = function() {
        return Vb(this, 2)
    };
    wd.m = [3];

    function xd(a) {
        return db(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (q = b.toString(2), t(q, "padStart")).call(q, 8, "0")
        }).join("")
    }

    function yd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }

    function zd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Ad(a) {
        var b = xd(a + "A"),
            c = yd(b.slice(0, 6));
        a = yd(b.slice(6, 12));
        var d = new wd;
        c = K(d, 1, c, 0);
        a = K(c, 2, a, 0);
        b = b.slice(12);
        c = yd(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (0 === e.length) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = 0 === yd(e[0]);
            e = e.slice(1);
            var h = Bd(e, b),
                k = 0 === d.length ? 0 : d[d.length - 1];
            k = zd(h) + k;
            e = e.slice(h.length);
            if (g) d.push(k);
            else {
                g = Bd(e, b);
                h = zd(g);
                for (var l = 0; l <= h; l++) d.push(k + l);
                e = e.slice(g.length)
            }
        }
        if (0 < e.length) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return Ib(a, 3, d, Bb)
    }

    function Bd(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    var Cd = function(a) {
        this.h = R(a)
    };
    x(Cd, S);
    var Dd = function(a) {
        this.h = R(a)
    };
    x(Dd, S);
    var Ed = function(a) {
        this.h = R(a)
    };
    x(Ed, S);
    Ed.prototype.getVersion = function() {
        return Vb(this, 1)
    };
    var Fd = function(a) {
        var b = new Ed;
        return K(b, 1, a, 0)
    };
    var Gd = function(a) {
        this.h = R(a)
    };
    x(Gd, S);
    var Hd = function(a) {
        this.h = R(a)
    };
    x(Hd, S);
    var Id = function(a) {
        var b = new Hd;
        return Rb(b, 1, a)
    };
    var Jd = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        Kd = Jd.reduce(function(a, b) {
            return a + b
        });
    var Ld = "a".charCodeAt(),
        Md = vc(qd),
        Nd = vc(rd);
    var Od = function(a) {
        this.h = R(a)
    };
    x(Od, S);
    var Pd = function() {
        var a = new Od;
        return K(a, 1, 0, 0)
    };
    var Qd = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.i = a;
            this.g = 0
        },
        Td = function(a) {
            var b = U(a, 16);
            return !0 === !!U(a, 1) ? (a = Rd(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : Sd(a, b)
        },
        Rd = function(a) {
            for (var b = U(a, 12), c = []; b--;) {
                var d = !0 === !!U(a, 1),
                    e = U(a, 16);
                if (d)
                    for (d = U(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        Sd = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (U(a, 1)) {
                    var f = e + 1;
                    if (c && -1 === c.indexOf(f)) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        U = function(a, b) {
            if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.i.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    var Vd = function(a, b) {
            try {
                var c = db(a.split(".")[0]).map(function(e) {
                        return (q = e.toString(2), t(q, "padStart")).call(q, 8, "0")
                    }).join(""),
                    d = new Qd(c);
                c = {};
                c.tcString = a;
                c.gdprApplies = !0;
                d.g += 78;
                c.cmpId = U(d, 12);
                c.cmpVersion = U(d, 12);
                d.g += 30;
                c.tcfPolicyVersion = U(d, 6);
                c.isServiceSpecific = !!U(d, 1);
                c.useNonStandardStacks = !!U(d, 1);
                c.specialFeatureOptins = Ud(Sd(d, 12, Nd), Nd);
                c.purpose = {
                    consents: Ud(Sd(d, 24, Md), Md),
                    legitimateInterests: Ud(Sd(d, 24, Md), Md)
                };
                c.purposeOneTreatment = !!U(d, 1);
                c.publisherCC = String.fromCharCode(Ld + U(d, 6)) + String.fromCharCode(Ld + U(d, 6));
                c.vendor = {
                    consents: Ud(Td(d), b),
                    legitimateInterests: Ud(Td(d), b)
                };
                return c
            } catch (e) {
                return null
            }
        },
        Ud = function(a, b) {
            var c = {};
            if (Array.isArray(b) && 0 !== b.length) {
                b = v(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = -1 !== a.indexOf(d)
            } else
                for (a = v(a), d = a.next(); !d.done; d = a.next()) c[d.value] = !0;
            delete c[0];
            return c
        };

    function Wd(a) {
        return JSON.stringify([a.map(function(b) {
            var c = {};
            return [(c[b.ka] = b.ia, c)]
        })])
    };
    var Xd = function(a, b) {
        if (r.globalThis.fetch) r.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var Yd = function(a) {
        this.h = R(a)
    };
    x(Yd, S);
    var Zd = function(a) {
        this.h = R(a)
    };
    x(Zd, S);
    var $d = function(a, b) {
            return N(a, 1, b)
        },
        ae = function(a, b) {
            return N(a, 2, b)
        };
    var be = function(a) {
        this.h = R(a)
    };
    x(be, S);
    var ce = [1, 2];
    var de = function(a) {
        this.h = R(a)
    };
    x(de, S);
    var ee = function(a, b) {
            return Rb(a, 1, b)
        },
        fe = function(a, b) {
            return Tb(a, 2, b)
        },
        ge = function(a, b) {
            return Ib(a, 4, b, Bb)
        },
        he = function(a, b) {
            return Tb(a, 5, b)
        },
        ie = function(a, b) {
            return N(a, 6, b)
        };
    de.m = [2, 4, 5];
    var je = function(a) {
        this.h = R(a)
    };
    x(je, S);
    je.m = [5];
    var ke = [1, 2, 3, 4];
    var le = function(a) {
        this.h = R(a)
    };
    x(le, S);
    le.m = [2, 3];
    var me = function(a) {
        this.h = R(a)
    };
    x(me, S);
    me.prototype.getTagSessionCorrelator = function() {
        return O(H(this, 2), 0)
    };
    var oe = function(a) {
            var b = new me;
            return Sb(b, 4, ne, a)
        },
        ne = [4, 5, 7, 8];
    var pe = function(a) {
        this.h = R(a)
    };
    x(pe, S);
    pe.m = [3];
    var qe = function(a) {
        this.h = R(a)
    };
    x(qe, S);
    qe.m = [4, 5];
    var re = function(a) {
        this.h = R(a)
    };
    x(re, S);
    re.prototype.getTagSessionCorrelator = function() {
        return O(H(this, 1), 0)
    };
    re.m = [2];
    var se = function(a) {
        this.h = R(a)
    };
    x(se, S);
    var te = [4, 6];

    function ue(a) {
        a.ja.apply(a, w(ta.apply(1, arguments).map(function(b) {
            return {
                ka: 2,
                ia: b.toJSON()
            }
        })))
    }

    function ve(a) {
        a.ja.apply(a, w(ta.apply(1, arguments).map(function(b) {
            return {
                ka: 4,
                ia: b.toJSON()
            }
        })))
    };
    var we = function(a, b, c, d, e) {
            this.C = a;
            this.o = b;
            this.G = c;
            this.j = d;
            this.l = e;
            this.g = [];
            this.i = null
        },
        xe = function(a) {
            null !== a.i && (clearTimeout(a.i), a.i = null);
            if (a.g.length) {
                var b = Wd(a.g);
                a.o(a.C + "?e=1", b);
                a.g = []
            }
        };
    we.prototype.ja = function() {
        var a = ta.apply(0, arguments),
            b = this;
        this.l && 65536 <= Wd(this.g.concat(a)).length && xe(this);
        this.g.push.apply(this.g, w(a));
        this.g.length >= this.j && xe(this);
        this.g.length && null === this.i && (this.i = setTimeout(function() {
            xe(b)
        }, this.G))
    };
    var ye = function(a, b, c) {
        we.call(this, "https://pagead2.googlesyndication.com/pagead/ping", Xd, void 0 === a ? 1E3 : a, void 0 === b ? 100 : b, (void 0 === c ? !1 : c) && !!r.globalThis.fetch)
    };
    x(ye, we);
    var ze = function(a, b) {
            this.g = a;
            this.defaultValue = void 0 === b ? !1 : b
        },
        Ae = function(a) {
            this.g = a;
            this.defaultValue = 0
        };
    var Be = new ze(501898423),
        Ce = new ze(542573660),
        De = new ze(537116804),
        Ee = new Ae(523264412),
        Ie = new ze(523253321, !0),
        Je = new Ae(24),
        Ke = new function(a, b) {
            b = void 0 === b ? [] : b;
            this.g = a;
            this.defaultValue = b
        }(1934, ["A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A4A26Ymj79UVY7C7JGUS4BG1s7MdcDokAQf/RP0paks+RoTYbXHxceT/5L4iKcsleFCngi75YfNRGW2+SpVv1ggAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ=="]),
        Le = new ze(203);
    var Me = function(a) {
        this.h = R(a)
    };
    x(Me, S);
    var Ne = function(a) {
        this.h = R(a)
    };
    x(Ne, S);
    var Oe = function(a) {
        this.h = R(a)
    };
    x(Oe, S);
    var Pe = function(a) {
        this.h = R(a)
    };
    x(Pe, S);
    var Qe = lc(Pe);
    Pe.m = [7];
    var Re = function(a) {
        this.g = a || {
            cookie: ""
        }
    };
    Re.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Ta;
            d = c.Ua || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.ta
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    Re.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = za(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    Re.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    Re.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = za(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) c = b[a], this.get(c), this.set(c, "", {
            ta: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Se(a) {
        return (a = Te(a)) ? L(a, Oe, 4) : null
    }

    function Te(a) {
        if (a = (new Re(a)).get("FCCDCF", ""))
            if (t(a, "startsWith").call(a, "%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        try {
            return b ? Qe(b) : null
        } catch (c) {
            return null
        }
    }

    function Ue(a) {
        var b, c;
        return null != (c = null == (b = Te(a)) ? void 0 : M(b, Me, 7)) ? c : []
    };
    [].concat(w(new r.Map([
        [8, "usca"],
        [9, "usva"],
        [10, "usco"],
        [12, "usct"]
    ]))).sort(function(a, b) {
        return a[0] - b[0]
    }).map(function(a) {
        return a[1]
    });
    var Ve = Id(Fd(1)),
        We = function(a, b) {
            a = void 0 === a ? Ve : a;
            b = void 0 === b ? new Od : b;
            this.g = a;
            this.timestamp = b
        },
        Xe = function(a, b) {
            var c;
            try {
                if (0 === a.length) throw Error("Cannot decode empty USCA section string");
                var d = a.split(".");
                if (2 < d.length) throw Error("Expected at most 1 sub-section but got " + (d.length - 1) + " when decoding " + a);
                var e = xd(d[0]),
                    f = yd(e.slice(0, 6));
                e = e.slice(6);
                if (1 !== f) throw Error("Unable to decode unsupported USCA Section specification version " + f + " - only version 1 is supported.");
                if (e.length < Kd)
                    if (e.length + 8 >= Kd) e += "00000000";
                    else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + Kd + " but was " + (e.length + 8));
                a = 0;
                for (var g = [], h = 0; h < Jd.length; h++) {
                    var k = Jd[h];
                    g.push(yd(e.slice(a, a + k)));
                    a += k
                }
                var l = Fd(f),
                    m = g.shift();
                var p = N(l, 2, m);
                var n = g.shift();
                var z = N(p, 3, n);
                var ea = g.shift();
                var ua = N(z, 4, ea);
                var W = g.shift();
                var ia = N(ua, 5, W);
                var Og = g.shift();
                var Pg = N(ia, 6, Og);
                var Qg = new Dd,
                    Rg = g.shift();
                var Sg = N(Qg, 1, Rg);
                var Tg = g.shift();
                var Ug = N(Sg, 2, Tg);
                var Vg = g.shift();
                var Wg = N(Ug, 3, Vg);
                var Xg = g.shift();
                var Yg = N(Wg, 4, Xg);
                var Zg = g.shift();
                var $g = N(Yg, 5, Zg);
                var ah = g.shift();
                var bh = N($g, 6, ah);
                var ch = g.shift();
                var dh = N(bh, 7, ch);
                var eh = g.shift();
                var fh = N(dh, 8, eh);
                var gh = g.shift();
                var hh = N(fh, 9, gh);
                var ih = Rb(Pg, 7, hh);
                var jh = new Cd,
                    kh = g.shift();
                var lh = N(jh, 1, kh);
                var mh = g.shift();
                var nh = N(lh, 2, mh);
                var oh = Rb(ih, 8, nh);
                var ph = g.shift();
                var qh = N(oh, 9, ph);
                var rh = g.shift();
                var sh = N(qh, 10, rh);
                var th = g.shift();
                var uh = N(sh, 11, th);
                var vh = g.shift();
                var Fe = N(uh, 12, vh);
                if (1 === d.length) var Ge = Id(Fe);
                else {
                    var wh = Id(Fe),
                        jb = xd(d[1]);
                    if (3 > jb.length) throw Error("Invalid GPC Segment [" + jb + "]. Expected length 3, but was " + jb.length + ".");
                    var Ob = yd(jb.slice(0, 2));
                    if (0 > Ob || 1 < Ob) throw Error("Attempting to decode unknown GPC segment subsection type " + Ob + ".");
                    var xh = Ob + 1;
                    var yh = yd(jb.charAt(2)),
                        zh = new Gd;
                    var Ah = N(zh, 2, xh);
                    d = !!yh;
                    var Bh = K(Ah, 1, null == d ? d : xb(d), !1);
                    Ge = Rb(wh, 2, Bh)
                }
                var He = Ge
            } catch (sj) {
                He = null
            }
            return new We(null != (c = He) ? c : Ve, b)
        };
    We.prototype.getTimestamp = function() {
        return this.timestamp
    };
    var Ye = function(a) {
        var b = new sd;
        b = K(b, 1, 1, 0);
        var c = Q(L(a.g, Ed, 1), 2),
            d = Q(L(a.g, Ed, 1), 3);
        0 === c && 0 === d ? N(b, 2, 0) : 2 === c || 2 === d ? N(b, 2, 1) : N(b, 2, 2);
        c = Q(L(a.g, Ed, 1), 5);
        a = Q(L(a.g, Ed, 1), 6);
        0 === c && 0 === a ? N(b, 3, 0) : 1 === c || 1 === a ? N(b, 3, 2) : N(b, 3, 1);
        N(b, 4, 1);
        a = [Vb(b, 1), vd[Q(b, 2)], vd[Q(b, 3)], vd[Q(b, 4)]].join("");
        return 4 === a.length && (-1 === a.indexOf("-") || "---" === a.substring(1)) && "1" <= a[0] && "9" >= a[0] && td.hasOwnProperty(a[1]) && td.hasOwnProperty(a[2]) && td.hasOwnProperty(a[3]) ? a : null
    };
    vc(qd).map(function(a) {
        return Number(a)
    });
    vc(rd).map(function(a) {
        return Number(a)
    });
    var Ze = function(a) {
            this.g = a;
            this.i = null
        },
        af = function(a) {
            a.__tcfapiPostMessageReady || $e(new Ze(a))
        },
        $e = function(a) {
            a.i = function(b) {
                var c = "string" == typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = "removeEventListener" === e.command ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.g.addEventListener("message", a.i);
            a.g.__tcfapiPostMessageReady = !0
        };
    var bf = function(a) {
        this.h = R(a)
    };
    x(bf, S);
    var cf = function(a) {
        this.h = R(a)
    };
    x(cf, S);
    var df = lc(cf);
    cf.m = [2];
    var ef = function(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = nd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var hf = function(a, b) {
            this.g = a;
            var c = (c = Te(a.document)) ? L(c, Ne, 5) || null : null;
            if (b) {
                b = ff(this);
                b = gf(b);
                if (null != c && null != G(H(c, 2)) && 0 !== P(c, 2).length) {
                    var d = void 0 !== Nb(c, Od, 1, !1) ? L(c, Od, 1) : Pd();
                    c = {
                        H: P(c, 2),
                        J: new Date(1E3 * O(H(d, 1), 0) + Vb(d, 2) / 1E6)
                    }
                } else c = null;
                c = c && b ? b.J > c.J ? b.H : c.H : c ? c.H : b ? b.H : null
            } else c = c ? G(H(c, 2)) : null;
            this.l = c;
            this.i = (c = Se(a.document)) && null != G(H(c, 1)) ? G(H(c, 1)) : null;
            this.j = (a = Se(a.document)) && null != G(H(a, 2)) ? G(H(a, 2)) : null
        },
        mf = function(a) {
            var b = jf(Ce);
            a.__uspapi || a.frames.__uspapiLocator || (a = new hf(a, b), kf(a), lf(a))
        },
        kf = function(a) {
            !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", ef(a.g, "__uspapiLocator"), ya("__uspapi", function() {
                return a.C.apply(a, w(ta.apply(0, arguments)))
            }))
        };
    hf.prototype.C = function(a, b, c) {
        "function" === typeof c && "getUSPData" === a && c({
            version: 1,
            uspString: this.l
        }, !0)
    };
    var ff = function(a) {
            a = (q = Ue(a.g.document), t(q, "find")).call(q, function(b) {
                return 13 === Q(b, 1)
            });
            if (null == a ? 0 : null != G(H(a, 2))) try {
                return df(P(a, 2))
            } catch (b) {}
            return null
        },
        gf = function(a) {
            if (null == a || null == G(H(a, 1)) || 0 === P(a, 1).length) return null;
            var b = (q = M(a, bf, 2), t(q, "find")).call(q, function(f) {
                return 8 === Vb(f, 1)
            });
            b = (null == b ? 0 : void 0 !== Nb(b, Od, 2, !1)) ? L(b, Od, 2) : Pd();
            a = P(a, 1);
            try {
                if (!t(a, "includes").call(a, "~")) throw Error("GPP String [" + a + "] contains no sections");
                var c = Ad(a.split("~")[0]);
                if (!t(a, "includes").call(a, "~")) throw Error("GPP String [" + a + "] contains no sections");
                var d = a.split("~").slice(1);
                var e = Hb(c, 3, yb).indexOf(8);
                return -1 === e ? null : {
                    H: Ye(Xe(d[e], b)),
                    J: new Date(1E3 * O(H(b, 1), 0) + Vb(b, 2) / 1E6)
                }
            } catch (f) {
                return null
            }
        },
        lf = function(a) {
            !a.i || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", ef(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], ya("__tcfapi", function() {
                return a.o.apply(a, w(ta.apply(0, arguments)))
            }), af(a.g))
        };
    hf.prototype.o = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("function" === typeof c)
            if (b && (2.1 < b || 1 >= b)) c(null, !1);
            else switch (b = this.g.__tcfapiEventListeners, a) {
                case "getTCData":
                    !d || Array.isArray(d) && d.every(function(e) {
                        return "number" === typeof e
                    }) ? c(nf(this, d, null), !0) : c(null, !1);
                    break;
                case "ping":
                    c({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    a = b.push(c);
                    c(nf(this, null, a - 1), !0);
                    break;
                case "removeEventListener":
                    b[d] ? (b[d] = null, c(!0)) : c(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    c(null, !1)
            }
    };
    var nf = function(a, b, c) {
        if (!a.i) return null;
        b = Vd(a.i, b);
        b.addtlConsent = null != a.j ? a.j : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    };
    var of = function(a) {
        return "string" === typeof a
    };
    var pf = function(a, b) {
        var c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var qf = null,
        rf = function() {
            if (null === qf) {
                qf = "";
                try {
                    var a = "";
                    try {
                        a = y.top.location.hash
                    } catch (c) {
                        a = y.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        qf = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return qf
        };
    var sf = function(a) {
        this.h = R(a)
    };
    x(sf, S);
    sf.m = [2, 8];
    var tf = [3, 4, 5],
        uf = [6, 7];

    function vf(a) {
        return null != a ? !a : a
    }

    function wf(a, b) {
        for (var c = !1, d = 0; d < a.length; d++) {
            var e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function xf(a, b) {
        var c = M(a, sf, 2);
        if (!c.length) return yf(a, b);
        a = Q(a, 1);
        if (1 === a) return vf(xf(c[0], b));
        c = Va(c, function(d) {
            return function() {
                return xf(d, b)
            }
        });
        switch (a) {
            case 2:
                return wf(c, !1);
            case 3:
                return wf(c, !0)
        }
    }

    function yf(a, b) {
        var c = Mb(a, tf);
        a: {
            switch (c) {
                case 3:
                    var d = Q(a, Lb(a, tf, 3));
                    break a;
                case 4:
                    d = Q(a, Lb(a, tf, 4));
                    break a;
                case 5:
                    d = Q(a, Lb(a, tf, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b.apply(null, w(Hb(a, 8, G)))
            } catch (f) {
                return
            }
            b = Q(a, 1);
            if (4 === b) return !!e;
            if (5 === b) return null != e;
            if (12 === b) a = P(a, Lb(a, uf, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = Wb(a, Lb(a, uf, 6));
                        break a;
                    case 5:
                        a = P(a, Lb(a, uf, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === b) return e === a;
                if (9 === b) return null != e && 0 === Ja(String(e), a);
                if (null != e) switch (b) {
                    case 7:
                        return e < a;
                    case 8:
                        return e > a;
                    case 12:
                        return of(a) && of (e) && (new RegExp(a)).test(e);
                    case 10:
                        return null != e && -1 === Ja(String(e), a);
                    case 11:
                        return null != e && 1 === Ja(String(e), a)
                }
            }
        }
    }

    function zf(a, b) {
        return !a || !(!b || !xf(a, b))
    };
    var Af = function(a) {
        this.h = R(a)
    };
    x(Af, S);
    Af.m = [4];
    var Bf = function(a) {
        this.h = R(a)
    };
    x(Bf, S);
    var Cf = function(a) {
        this.h = R(a)
    };
    x(Cf, S);
    var Df = lc(Cf);
    Cf.m = [5];
    var Ef = [1, 2, 3, 6, 7];
    var Ff = function(a, b, c) {
            var d = void 0 === d ? new ye(b) : d;
            this.o = a;
            this.l = c;
            this.i = d;
            this.g = [];
            this.j = 0 < a && ed() < 1 / a
        },
        Hf = function(a, b, c, d, e, f) {
            if (a.j) {
                var g = ae($d(new Zd, b), c);
                b = ie(fe(ee(he(ge(new de, d), e), g), a.g.slice()), f);
                b = oe(b);
                ve(a.i, Gf(a, b));
                if (1 === f || 3 === f || 4 === f && !a.g.some(function(h) {
                        return Q(h, 1) === Q(g, 1) && Q(h, 2) === c
                    })) a.g.push(g), 100 < a.g.length && a.g.shift()
            }
        },
        If = function(a, b, c, d) {
            if (a.j && a.l) {
                var e = new le;
                b = Tb(e, 2, b);
                c = Tb(b, 3, c);
                d && K(c, 1, d, 0);
                d = new me;
                d = Sb(d, 7, ne, c);
                ve(a.i, Gf(a, d))
            }
        },
        Gf = function(a, b) {
            b = K(b, 1, Date.now(), 0);
            var c = md(window);
            b = K(b, 2, c, 0);
            return K(b, 6, a.o, 0)
        };
    var V = function(a) {
        var b = "L";
        if (a.L && a.hasOwnProperty(b)) return a.L;
        b = new a;
        return a.L = b
    };
    var Jf = function() {
        var a = {};
        this.u = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var Kf = kd();

    function Lf(a, b) {
        switch (b) {
            case 1:
                return Q(a, Lb(a, Ef, 1));
            case 2:
                return Q(a, Lb(a, Ef, 2));
            case 3:
                return Q(a, Lb(a, Ef, 3));
            case 6:
                return Q(a, Lb(a, Ef, 6));
            default:
                return null
        }
    }

    function Mf(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return Ub(a, 1);
            case 7:
                return P(a, 3);
            case 2:
                return Wb(a, 2);
            case 3:
                return P(a, 3);
            case 6:
                return Hb(a, 4, G);
            default:
                return null
        }
    }
    var Nf = tc(function() {
        if (!Kf) return {};
        try {
            var a = window.sessionStorage && window.sessionStorage.getItem("GGDFSSK");
            if (a) return JSON.parse(a)
        } catch (b) {}
        return {}
    });

    function Of(a, b, c, d) {
        var e = d = void 0 === d ? 0 : d,
            f, g;
        V(Pf).j[e] = null != (g = null == (f = V(Pf).j[e]) ? void 0 : f.add(b)) ? g : (new r.Set).add(b);
        e = Nf();
        if (null != e[b]) return e[b];
        b = Qf(d)[b];
        if (!b) return c;
        b = Df(JSON.stringify(b));
        b = Rf(b);
        a = Mf(b, a);
        return null != a ? a : c
    }

    function Rf(a) {
        var b = V(Jf).u;
        if (b) {
            var c = Xa(M(a, Bf, 5), function(f) {
                return zf(L(f, sf, 1), b)
            });
            if (c) {
                var d;
                return null != (d = L(c, Af, 2)) ? d : null
            }
        }
        var e;
        return null != (e = L(a, Af, 4)) ? e : null
    }
    var Pf = function() {
        this.i = {};
        this.l = [];
        this.j = {};
        this.g = new r.Map
    };

    function Sf(a, b, c) {
        return !!Of(1, a, void 0 === b ? !1 : b, c)
    }

    function Tf(a, b, c) {
        b = void 0 === b ? 0 : b;
        a = Number(Of(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Uf(a, b, c) {
        b = void 0 === b ? "" : b;
        a = Of(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function Vf(a, b, c) {
        b = void 0 === b ? [] : b;
        a = Of(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Qf(a) {
        return V(Pf).i[a] || (V(Pf).i[a] = {})
    }

    function Wf(a, b) {
        var c = Qf(b);
        gd(a, function(d, e) {
            return c[e] = d
        })
    }

    function Xf(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = [],
            g = [];
        Ta(b, function(h) {
            var k = Qf(h);
            Ta(a, function(l) {
                var m = Mb(l, Ef),
                    p = Lf(l, m);
                if (p) {
                    var n, z, ea;
                    var ua = null != (ea = null == (n = V(Pf).g.get(h)) ? void 0 : null == (z = n.get(p)) ? void 0 : z.slice(0)) ? ea : [];
                    a: {
                        n = new je;
                        switch (m) {
                            case 1:
                                Kb(n, 1, ke, Ab(p));
                                break;
                            case 2:
                                Kb(n, 2, ke, Ab(p));
                                break;
                            case 3:
                                Kb(n, 3, ke, Ab(p));
                                break;
                            case 6:
                                Kb(n, 4, ke, Ab(p));
                                break;
                            default:
                                m = void 0;
                                break a
                        }
                        Ib(n, 5, ua, Bb);m = n
                    }
                    if (ua = m) {
                        var W;
                        ua = !(null == (W = V(Pf).j[h]) || !W.has(p))
                    }
                    ua && f.push(m);
                    if (W = m) {
                        var ia;
                        W = !(null == (ia = V(Pf).g.get(h)) || !ia.has(p))
                    }
                    W && g.push(m);
                    e || (ia = V(Pf), ia.g.has(h) || ia.g.set(h, new r.Map), ia.g.get(h).has(p) || ia.g.get(h).set(p, []), d && ia.g.get(h).get(p).push(d));
                    k[p] = l.toJSON()
                }
            })
        });
        (f.length || g.length) && If(c, f, g, null != d ? d : void 0)
    }

    function Yf(a, b) {
        var c = Qf(b);
        Ta(a, function(d) {
            var e = Df(JSON.stringify(d)),
                f = Mb(e, Ef);
            (e = Lf(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function Zf() {
        return Va(t(Object, "keys").call(Object, V(Pf).i), function(a) {
            return Number(a)
        })
    }

    function $f(a) {
        Ya(V(Pf).l, a) || Wf(Qf(4), a)
    };

    function X(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Y(a, b, c) {
        return b[a] || c
    }

    function ag(a) {
        X(5, Sf, a);
        X(6, Tf, a);
        X(7, Uf, a);
        X(8, Vf, a);
        X(13, Yf, a);
        X(15, $f, a)
    }

    function bg(a) {
        X(4, function(b) {
            V(Jf).u = b
        }, a);
        X(9, function(b, c) {
            var d = V(Jf);
            null == d.u[3][b] && (d.u[3][b] = c)
        }, a);
        X(10, function(b, c) {
            var d = V(Jf);
            null == d.u[4][b] && (d.u[4][b] = c)
        }, a);
        X(11, function(b, c) {
            var d = V(Jf);
            null == d.u[5][b] && (d.u[5][b] = c)
        }, a);
        X(14, function(b) {
            for (var c = V(Jf), d = v([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, t(Object, "assign").call(Object, c.u[e], b[e])
        }, a)
    }

    function cg(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var dg = function() {};
    dg.prototype.i = function() {};
    dg.prototype.g = function() {
        return []
    };
    var eg = function(a, b, c) {
        a.i = function(d, e) {
            Y(2, b, function() {
                return []
            })(d, c, e)
        };
        a.g = function() {
            return Y(3, b, function() {
                return []
            })(c)
        }
    };

    function fg(a, b) {
        if (a.length && b.head) {
            a = v(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = nd("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    };

    function gg(a, b) {
        try {
            var c = a.split(".");
            a = y;
            for (var d = 0, e; null != a && d < c.length; d++) e = a, a = a[c[d]], "function" === typeof a && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var hg = {},
        ig = {},
        jg = {},
        kg = {},
        lg = (kg[3] = (hg[8] = function(a) {
            try {
                return null != xa(a)
            } catch (b) {}
        }, hg[9] = function(a) {
            try {
                var b = xa(a)
            } catch (c) {
                return
            }
            if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
            return a
        }, hg[10] = function() {
            return window === window.top
        }, hg[6] = function(a) {
            return Ya(V(dg).g(), Number(a))
        }, hg[27] = function(a) {
            a = gg(a, "boolean");
            return void 0 !== a ? a : void 0
        }, hg[60] = function(a) {
            try {
                return !!y.document.querySelector(a)
            } catch (b) {}
        }, hg[69] = function(a) {
            var b = y.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(q = c.features(), t(q, "includes")).call(q, a))
        }, hg[70] = function(a) {
            var b = y.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(q = c.allowedFeatures(), t(q, "includes")).call(q, a))
        }, hg), kg[4] = (ig[3] = function() {
            return ld()
        }, ig[6] = function(a) {
            a = gg(a, "number");
            return void 0 !== a ? a : void 0
        }, ig), kg[5] = (jg[2] = function() {
            return window.location.href
        }, jg[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, jg[4] = function(a) {
            a = gg(a, "string");
            return void 0 !== a ? a : void 0
        }, jg), kg);

    function mg() {
        var a = void 0 === a ? y : a;
        return a.ggeac || (a.ggeac = {})
    };
    var ng = function(a) {
        this.h = R(a)
    };
    x(ng, S);
    ng.prototype.getId = function() {
        return Vb(this, 1)
    };
    ng.m = [2];
    var og = function(a) {
        this.h = R(a)
    };
    x(og, S);
    og.m = [2];
    var pg = function(a) {
        this.h = R(a)
    };
    x(pg, S);
    pg.m = [2];
    var qg = function(a) {
        this.h = R(a)
    };
    x(qg, S);
    var rg = function(a) {
        this.h = R(a)
    };
    x(rg, S);
    rg.m = [1, 4, 2, 3];
    var sg = [12, 13, 20],
        tg = function(a, b, c, d) {
            var e = this,
                f = void 0 === d ? {} : d,
                g = void 0 === f.K ? !1 : f.K;
            d = void 0 === f.wa ? [] : f.wa;
            f = void 0 === f.F ? {} : f.F;
            this.A = c;
            this.j = a.slice();
            this.o = {};
            this.K = g;
            this.F = f;
            a = {};
            this.g = (a[b] = [], a[4] = [], a);
            this.i = {};
            this.l = {};
            (b = rf()) && Ta(b.split(",") || [], function(h) {
                (h = Number(h)) && (e.i[h] = !0)
            });
            Ta(d, function(h) {
                e.i[h] = !0
            })
        },
        xg = function(a, b, c) {
            var d = [],
                e = ug(a.j, b),
                f;
            if (f = 9 !== b) a.o[b] ? f = !0 : (a.o[b] = !0, f = !1);
            if (f) return Hf(a.A, b, c, d, [], 4), d;
            if (!e.length) return Hf(a.A, b, c, d, [], 3), d;
            var g = Ya(sg, b),
                h = [];
            Ta(e, function(k) {
                var l = new be,
                    m = vg(a, k, c, l);
                if (m) {
                    0 !== Mb(l, ce) && h.push(l);
                    l = m.getId();
                    d.push(l);
                    wg(a, l, g ? 4 : c);
                    if (0 !== Q(k, 13)) {
                        var p = a.l[String(Q(k, 13))] || void 0;
                        if (void 0 !== p && p !== l) {
                            p = a.A;
                            var n = a.l[String(Q(k, 13))];
                            k = Q(k, 13);
                            if (p.j) {
                                var z = new Yd;
                                n = J(z, 1, n);
                                n = J(n, 2, l);
                                k = J(n, 3, Ab(k));
                                n = new me;
                                k = Sb(n, 8, ne, k);
                                ve(p.i, Gf(p, k))
                            }
                        } else a.l[String(Q(k, 13))] = l
                    }(m = M(m, Cf, 2)) && (g ? Xf(m, Zf(), a.A, l) : Xf(m, [c], a.A, l))
                }
            });
            Hf(a.A, b, c, d, h, 1);
            return d
        },
        wg = function(a, b, c) {
            a.g[c] || (a.g[c] = []);
            a = a.g[c];
            Ya(a, b) || a.push(b)
        },
        yg = function(a, b) {
            a.j.push.apply(a.j, w(Ua(Va(b, function(c) {
                return new pg(c)
            }), function(c) {
                return !Ya(sg, Q(c, 1))
            })))
        },
        vg = function(a, b, c, d) {
            var e = V(Jf).u;
            if (!zf(L(b, sf, 3), e)) return null;
            var f = M(b, ng, 2),
                g = Q(b, 6);
            if (g) {
                Kb(d, 1, ce, Ab(g));
                f = e[4];
                switch (c) {
                    case 2:
                        var h = f[8];
                        break;
                    case 1:
                        h = f[7]
                }
                c = void 0;
                if (h) try {
                    c = h(g), K(d, 3, c, 0)
                } catch (k) {}
                return (b = zg(b, c)) ? Ag(a, [b], 1) : null
            }
            if (g = Q(b, 10)) {
                Kb(d, 2, ce, Ab(g));
                h = null;
                switch (c) {
                    case 1:
                        h = e[4][9];
                        break;
                    case 2:
                        h = e[4][10];
                        break;
                    default:
                        return null
                }
                c = h ? h(String(g)) : void 0;
                if (void 0 === c && 1 === Q(b, 11)) return null;
                void 0 !== c && K(d, 3, c, 0);
                return (b = zg(b, c)) ? Ag(a, [b], 1) : null
            }
            d = e ? Ua(f, function(k) {
                return zf(L(k, sf, 3), e)
            }) : f;
            if (!d.length) return null;
            c = d.length * O(zb(H(b, 1)), 0);
            return (b = Q(b, 4)) ? Bg(a, b, c, d) : Ag(a, d, c / 1E3)
        },
        Bg = function(a, b, c, d) {
            var e = null != a.F[b] ? a.F[b] : 1E3;
            if (0 >= e) return null;
            d = Ag(a, d, c / e);
            a.F[b] = d ? 0 : e - c;
            return d
        },
        Ag = function(a, b, c) {
            var d = a.i,
                e = Wa(b, function(f) {
                    return !!d[f.getId()]
                });
            return e ? e : a.K ? null : fd(b, c)
        },
        Cg = function(a, b) {
            X(1, function(c) {
                a.i[c] = !0
            }, b);
            X(2, function(c, d) {
                return xg(a, c, d)
            }, b);
            X(3, function(c) {
                return (a.g[c] || []).concat(a.g[4])
            }, b);
            X(12, function(c) {
                return void yg(a, c)
            }, b);
            X(16, function(c, d) {
                return void wg(a, c, d)
            }, b)
        };

    function ug(a, b) {
        return (a = Wa(a, function(c) {
            return Q(c, 1) === b
        })) && M(a, og, 2) || []
    }

    function zg(a, b) {
        var c = M(a, ng, 2),
            d = c.length,
            e = O(zb(H(a, 8)), 0);
        a = d * O(zb(H(a, 1)), 0);
        b = void 0 !== b ? b : Math.floor(1E3 * ed());
        if (b < e || b - e >= a) return null;
        c = c[(b - e) % d];
        d = V(Jf).u;
        return !c || d && !zf(L(c, sf, 3), d) ? null : c
    };
    var Dg = function() {
        var a = {};
        this.i = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.g = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.l = function() {}
    };

    function jf(a) {
        return V(Dg).i(a.g, a.defaultValue)
    };
    var Eg = function() {
            this.g = function() {}
        },
        Fg = function(a, b) {
            a.g = Y(14, b, function() {})
        };

    function Gg(a) {
        V(Eg).g(a)
    };
    var Hg, Ig, Jg, Kg, Lg, Mg;

    function Ng(a) {
        var b = a.oa,
            c = a.u,
            d = a.Oa,
            e = void 0 === a.la ? mg() : a.la,
            f = void 0 === a.fa ? 0 : a.fa;
        a = void 0 === a.A ? new Ff(null != (Kg = null == (Hg = L(b, qg, 5)) ? void 0 : O(H(Hg, 2), 0)) ? Kg : 0, null != (Lg = null == (Ig = L(b, qg, 5)) ? void 0 : O(H(Ig, 4), 0)) ? Lg : 0, null != (Mg = null == (Jg = L(b, qg, 5)) ? void 0 : Ub(Jg, 3)) ? Mg : !1) : a.A;
        e.hasOwnProperty("init-done") ? (Y(12, e, function() {})(Va(M(b, pg, 2), function(g) {
            return g.toJSON()
        })), Y(13, e, function() {})(Va(M(b, Cf, 1), function(g) {
            return g.toJSON()
        }), f), c && Y(14, e, function() {})(c), Ch(f, e)) : (Cg(new tg(M(b, pg, 2), f, a, d), e), ag(e), bg(e), cg(e), Ch(f, e), Xf(M(b, Cf, 1), [f], a, void 0, !0), Kf = Kf || !(!d || !d.Qa), Gg(lg), c && Gg(c))
    }

    function Ch(a, b) {
        var c = b = void 0 === b ? mg() : b;
        eg(V(dg), c, a);
        Dh(b, a);
        a = b;
        Fg(V(Eg), a);
        V(Dg).l()
    }

    function Dh(a, b) {
        var c = V(Dg);
        c.i = function(d, e) {
            return Y(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.g = function(d, e) {
            return Y(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.o = function(d, e) {
            return Y(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.j = function(d, e) {
            return Y(8, a, function() {
                return []
            })(d, e, b)
        };
        c.l = function() {
            Y(15, a, function() {})(b)
        }
    };

    function Eh(a) {
        a = void 0 === a ? ed() : a;
        return function(b) {
            return hd(a + "." + b) % 1E3
        }
    };
    var Fh = ka(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        Gh = function() {
            var a = void 0 === a ? "jserror" : a;
            var b = void 0 === b ? .01 : b;
            var c = void 0 === c ? od(Fh) : c;
            this.j = a;
            this.i = b;
            this.g = c
        };

    function Hh(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = nd("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            uc(e, "load", f);
            uc(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }
    var Jh = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=gpt_inv_ver";
            gd(a, function(d, e) {
                if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
            });
            Ih(c, b)
        },
        Ih = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : Hh(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
        };

    function Kh(a) {
        a = void 0 === a ? y : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var Lh = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        Mh = function(a, b) {
            var c = Kh(b);
            c && Lh({
                label: a,
                type: 9,
                value: c
            }, b)
        },
        Nh = function(a, b, c) {
            var d = !1;
            d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = Kh(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && Lh(t(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (Kh() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        },
        Oh = function(a, b) {
            return Nh(a, b, function(c, d) {
                var e = new Gh;
                var f = void 0 === f ? e.i : f;
                var g = void 0 === g ? e.j : g;
                Math.random() > f || (d.error && d.meta && d.id || (d = new pf(d, {
                    context: c,
                    id: g
                })), y.google_js_errors = y.google_js_errors || [], y.google_js_errors.push(d), y.error_rep_loaded || (f = y.document, c = nd("SCRIPT", f), Xc(c, e.g), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), y.error_rep_loaded = !0))
            })
        };

    function Z(a, b) {
        return null == b ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function Ph(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function Qh() {
        var a = new r.Set;
        var b = window.googletag;
        b = (null == b ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = v(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function Rh(a) {
        a = a.id;
        return null != a && (Qh().has(a) || t(a, "startsWith").call(a, "google_ads_iframe_") || t(a, "startsWith").call(a, "aswift"))
    }

    function Sh(a, b, c) {
        if (!a.sources) return !1;
        switch (Th(a)) {
            case 2:
                var d = Uh(a);
                if (d) return c.some(function(f) {
                    return Vh(d, f)
                });
                break;
            case 1:
                var e = Wh(a);
                if (e) return b.some(function(f) {
                    return Vh(e, f)
                })
        }
        return !1
    }

    function Th(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function Wh(a) {
        return Xh(a, function(b) {
            return b.currentRect
        })
    }

    function Uh(a) {
        return Xh(a, function(b) {
            return b.previousRect
        })
    }

    function Xh(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function Vh(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }
    var Yh = function() {
            this.i = this.g = this.P = this.G = this.o = 0;
            this.ba = this.X = Number.NEGATIVE_INFINITY;
            this.T = this.V = this.W = this.Z = this.ea = this.j = this.da = this.I = 0;
            this.U = !1;
            this.R = this.C = this.l = 0;
            this.A = null;
            this.aa = !1;
            this.S = function() {};
            var a = document.querySelector("[data-google-query-id]");
            this.ca = a ? a.getAttribute("data-google-query-id") : null
        },
        Zh, $h, ci = function() {
            var a = new Yh;
            if (jf(Le)) {
                var b = window;
                if (!b.google_plmetrics && window.PerformanceObserver) {
                    b.google_plmetrics = !0;
                    b = v(["layout-shift", "largest-contentful-paint", "first-input", "longtask"]);
                    for (var c = b.next(); !c.done; c = b.next()) c = c.value, ai(a).observe({
                        type: c,
                        buffered: !0
                    });
                    bi(a)
                }
            }
        },
        ai = function(a) {
            a.A || (a.A = new PerformanceObserver(Oh(640, function(b) {
                var c = Zh !== window.scrollX || $h !== window.scrollY ? [] : di,
                    d = ei();
                b = v(b.getEntries());
                for (var e = b.next(); !e.done; e = b.next()) switch (e = e.value, e.entryType) {
                    case "layout-shift":
                        var f = a;
                        if (!e.hadRecentInput) {
                            f.o += Number(e.value);
                            Number(e.value) > f.G && (f.G = Number(e.value));
                            f.P += 1;
                            var g = Sh(e, c, d);
                            g && (f.j += e.value, f.Z++);
                            if (5E3 < e.startTime - f.X || 1E3 < e.startTime - f.ba) f.X = e.startTime, f.g = 0, f.i = 0;
                            f.ba = e.startTime;
                            f.g += e.value;
                            g && (f.i += e.value);
                            f.g > f.I && (f.I = f.g, f.ea = f.i, f.da = e.startTime + e.duration)
                        }
                        break;
                    case "largest-contentful-paint":
                        a.W = Math.floor(e.renderTime || e.loadTime);
                        a.V = e.size;
                        break;
                    case "first-input":
                        a.T = Number((e.processingStart - e.startTime).toFixed(3));
                        a.U = !0;
                        break;
                    case "longtask":
                        e = Math.max(0, e.duration - 50), a.l += e, a.C = Math.max(a.C, e), a.R += 1
                }
            })));
            return a.A
        },
        bi = function(a) {
            var b = Oh(641, function() {
                    var d = document;
                    2 === (d.prerendering ? 3 : {
                        visible: 1,
                        hidden: 2,
                        prerender: 3,
                        preview: 4,
                        unloaded: 5
                    }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && fi(a)
                }),
                c = Oh(641, function() {
                    return void fi(a)
                });
            document.addEventListener("visibilitychange", b);
            document.addEventListener("pagehide", c);
            a.S = function() {
                document.removeEventListener("visibilitychange", b);
                document.removeEventListener("pagehide", c);
                ai(a).disconnect()
            }
        },
        fi = function(a) {
            if (!a.aa) {
                a.aa = !0;
                ai(a).takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += Ph("cls", a.o), b += Ph("mls", a.G), b += Z("nls", a.P), window.LayoutShiftAttribution && (b += Ph("cas", a.j), b += Z("nas", a.Z), b += Ph("was", a.ea)), b += Ph("wls", a.I), b += Ph("tls", a.da));
                window.LargestContentfulPaint && (b += Z("lcp", a.W), b += Z("lcps", a.V));
                window.PerformanceEventTiming && a.U && (b += Z("fid", a.T));
                window.PerformanceLongTaskTiming && (b += Z("cbt", a.l), b += Z("mbt", a.C), b += Z("nlt", a.R));
                for (var c = 0, d = v(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) Rh(e.value) && c++;
                b += Z("nif", c);
                c = window.google_unique_id;
                b += Z("ifi", "number" === typeof c ? c : 0);
                c = V(dg).g();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (y === y.top ? 1 : 0);
                b += a.ca ? "&qqid=" + encodeURIComponent(a.ca) : Z("pvsid", md(y));
                window.googletag && (b += "&gpt=1");
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.S()
            }
        },
        ei = function() {
            var a = t(Array, "from").call(Array, document.getElementsByTagName("iframe")).filter(Rh),
                b = [].concat(w(Qh())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return null !== c
                });
            Zh = window.scrollX;
            $h = window.scrollY;
            return di = [].concat(w(a), w(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        di = [];
    var gi = function(a) {
        this.h = R(a)
    };
    x(gi, S);
    gi.prototype.getVersion = function() {
        return P(this, 2)
    };
    var hi = function(a) {
        this.h = R(a)
    };
    x(hi, S);
    var ii = function(a, b) {
            return J(a, 2, F(b))
        },
        ji = function(a, b) {
            return J(a, 3, F(b))
        },
        ki = function(a, b) {
            return J(a, 4, F(b))
        },
        li = function(a, b) {
            return J(a, 5, F(b))
        },
        mi = function(a, b) {
            return J(a, 9, F(b))
        },
        ni = function(a, b) {
            return Tb(a, 10, b)
        },
        oi = function(a, b) {
            return J(a, 11, null == b ? b : xb(b))
        },
        pi = function(a, b) {
            return J(a, 1, F(b))
        },
        qi = function(a, b) {
            return J(a, 7, null == b ? b : xb(b))
        };
    hi.m = [10, 6];
    var ri = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function si(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function ti(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function ui(a) {
        if (!ti(a)) return null;
        var b = si(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(ri).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function vi(a) {
        var b;
        return oi(ni(li(ii(pi(ki(qi(mi(ji(new hi, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new gi;
            d = J(d, 1, F(c.brand));
            return J(d, 2, F(c.version))
        })) || []), a.wow64 || !1)
    }

    function wi(a) {
        var b, c;
        return null != (c = null == (b = ui(a)) ? void 0 : b.then(function(d) {
            return vi(d)
        })) ? c : null
    };

    function xi(a, b) {
        var c = {};
        b = (c[0] = Eh(b.ua), c);
        V(dg).i(a, b)
    };
    var yi = {},
        zi = (yi[23] = .001, yi[253] = !1, yi[246] = [], yi[150] = "", yi[221] = kd(), yi[36] = kd(), yi[172] = null, yi[260] = void 0, yi[251] = null, yi),
        Ai = function() {
            this.g = !1
        };

    function Bi(a) {
        V(Ai).g = !0;
        return zi[a]
    }

    function Ci(a, b) {
        V(Ai).g = !0;
        zi[a] = b
    };
    var Di = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;

    function Ei(a) {
        return a ? !Di.test(a.src) : !0
    };

    function Fi(a) {
        var b = a.sa,
            c = a.ya,
            d = a.ra,
            e = a.na,
            f = a.pa,
            g = Ei(a.ga);
        a = {};
        var h = {},
            k = {};
        return k[3] = (a[3] = function() {
            return !g
        }, a[59] = function() {
            var l = ta.apply(0, arguments),
                m = t(l, "includes"),
                p = String,
                n;
            var z = void 0 === z ? window : z;
            var ea;
            z = null != (ea = null == (n = Uc(z.location.href.match(Tc)[3] || null)) ? void 0 : n.split(".")) ? ea : [];
            n = 2 > z.length ? null : "uk" === z[z.length - 1] ? 3 > z.length ? null : hd(z.splice(z.length - 3).join(".")) : hd(z.splice(z.length - 2).join("."));
            return m.call(l, p(n))
        }, a[61] = function() {
            return d
        }, a[63] = function() {
            return d || ".google.ch" === f
        }, a[73] = function(l) {
            return t(c, "includes").call(c, Number(l))
        }, a), k[4] = (h[1] = function() {
            return e
        }, h[4] = function() {
            if (jd.test("0")) {
                var l = Number("0");
                l = isNaN(l) ? null : l
            } else l = null;
            return l || 0
        }, h[13] = function() {
            return b || 0
        }, h), k[5] = {}, k
    };

    function Gi(a, b) {
        var c = new rg(Bi(246));
        if (!M(c, Cf, 1).length && M(a, Cf, 1).length) {
            var d = M(a, Cf, 1);
            Tb(c, 1, d)
        }!M(c, pg, 2).length && M(a, pg, 2).length && (d = M(a, pg, 2), Tb(c, 2, d));
        void 0 === Nb(c, qg, 5, !1) && void 0 !== Nb(a, qg, 5, !1) && (a = L(a, qg, 5), Rb(c, 5, a));
        Ng({
            oa: c,
            u: Fi(b),
            fa: 2
        })
    };

    function Hi(a, b, c, d, e) {
        a = a.location.host;
        var f = Wc(b.src, "domain");
        b = Wc(b.src, "network-code");
        if (a || f || b) {
            var g = {};
            a && (g.ippd = a);
            f && (g.pppd = f);
            b && (g.pppnc = b);
            V(Dg).g(Ee.g, Ee.defaultValue) && (g.ppc_eid = V(Dg).g(Ee.g, Ee.defaultValue).toString());
            a = g
        } else a = void 0;
        if (a) {
            c = [c ? new rc(pc, "https://pagead2.googlesyndication.com") : new rc(pc, "https://securepubads.g.doubleclick.net"), new rc(pc, "/pagead/ppub_config")];
            f = "";
            for (b = 0; b < c.length; b++) f += sc(c[b]);
            c = yc.exec(xc(new T(f, zc)).toString());
            f = c[3] || "";
            c = new T(c[1] + Ac("?", c[2] || "", a) + Ac("#", f), zc);
            Ii(c, d, e)
        } else e(new r.globalThis.Error("no provided or inferred data"))
    }

    function Ii(a, b, c) {
        var d = new r.globalThis.XMLHttpRequest;
        d.open("GET", a.toString(), !0);
        d.withCredentials = !1;
        d.onload = function() {
            300 > d.status ? (Mh("13", window), b(204 === d.status ? "" : d.responseText)) : c(new r.globalThis.Error("resp:" + d.status))
        };
        d.onerror = function() {
            return void c(new r.globalThis.Error("s:" + d.status + " rs:" + d.readyState))
        };
        d.send()
    };
    var Ji = function() {
            this.l = [];
            this.j = []
        },
        Mi = function(a, b, c, d, e) {
            if (ad(b) === bd(b) && c) {
                Ki(a);
                var f = null == e ? void 0 : P(Pb(e, mc), 1);
                jf(Ie) && f && f.length && t(b.location.hostname, "includes").call(b.location.hostname, f) ? Li(a, void 0, e) : Hi(b.top, c, d, function(g) {
                    return void Li(a, g)
                }, function(g) {
                    Li(a, void 0, void 0, g)
                })
            }
        },
        Ki = function(a) {
            Bi(260);
            Ci(260, function(b) {
                void 0 !== a.g || a.i ? b(a.g, a.i) : a.l.push(b)
            })
        },
        Li = function(a, b, c, d) {
            a.g = null != b ? b : null == c ? void 0 : ic(c);
            a.o = c;
            !a.o && a.g && a.j.length && (a.o = oc(a.g));
            a.i = d;
            b = v(a.l);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.g, a.i);
            b = v(a.j);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.o, a.i);
            a.l.length = 0;
            a.j.length = 0
        };

    function Ni() {
        var a;
        return null != (a = y.googletag) ? a : y.googletag = {
            cmd: []
        }
    }

    function Oi(a, b) {
        var c = Ni();
        c.hasOwnProperty(a) || (c[a] = b)
    };
    var Qi = function() {
            return [].concat(w(t(Pi, "values").call(Pi))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        Pi = new r.Map;

    function Ri(a, b, c) {
        if (a.xa) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new se,
                e = new re;
            try {
                var f = md(window);
                K(e, 1, f, 0)
            } catch (n) {}
            try {
                var g = V(dg).g();
                Ib(e, 2, g, Bb)
            } catch (n) {}
            try {
                K(e, 3, F(window.document.URL), "")
            } catch (n) {}
            f = Rb(d, 2, e);
            g = new qe;
            b = N(g, 1, b);
            try {
                var h = of (null == c ? void 0 : c.name) ? c.name : "Unknown error";
                K(b, 2, F(h), "")
            } catch (n) {}
            try {
                var k = of (null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                K(b, 3, F(k), "")
            } catch (n) {}
            try {
                var l = of (null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && Ib(b, 4, l.split(/\n\s*/), Cb)
            } catch (n) {}
            h = Rb(f, 1, b);
            k = new pe;
            try {
                K(k, 1, F(a.M || a.ha), "")
            } catch (n) {}
            try {
                var m = Qi();
                K(k, 2, m, 0)
            } catch (n) {}
            try {
                var p = [].concat(w(t(Pi, "keys").call(Pi)));
                Ib(k, 3, p, Cb)
            } catch (n) {}
            Sb(h, 4, te, k);
            K(h, 5, a.ma, 0);
            ue(a.va, h)
        }
    };
    var Si = ka(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl", ".js"]),
        Ti = ka(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", ".js"]),
        Ui = ka(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl", ".js"]),
        Vi = ka(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", ".js"]);

    function Wi() {
        var a = Xi,
            b = Pb(Yi, rg),
            c = Zi,
            d = {
                ra: Ub(Yi, 5),
                sa: Vb(Yi, 2),
                ya: Hb(Yi, 10, yb),
                na: Vb(Yi, 7),
                pa: P(Yi, 6)
            },
            e = L(Yi, nc, 9),
            f = Vb(Yi, 8),
            g, h = null != (g = a.fifWin) ? g : window,
            k = h.document;
        g = a.fifWin ? window : h;
        Oi("_loaded_", !0);
        f = $i(c, f);
        Oi("cmd", []);
        var l;
        c = null != (l = aj(k)) ? l : bj(k);
        cj(b, h, t(Object, "assign").call(Object, {}, {
            ga: c
        }, d), f);
        try {
            ci()
        } catch (ea) {}
        Mh("1", h);
        b = dj(f, c);
        d = !1;
        if (!ej(k)) {
            h = "gpt-impl-" + Math.random();
            try {
                Yc(k, Nc(b, {
                    id: h,
                    nonce: Rc()
                }))
            } catch (ea) {}
            k.getElementById(h) && (jf(Be) ? d = !0 : a._loadStarted_ = !0)
        }
        if (jf(Be) ? !d : !a._loadStarted_) {
            var m = nd("SCRIPT");
            Xc(m, b);
            m.async = !0;
            k = a.fifWin ? g.document : k;
            b = k.body;
            d = k.documentElement;
            var p, n, z = null != (n = null != (p = k.head) ? p : b) ? n : d;
            "complete" !== g.document.readyState && a.fifWin ? uc(g, "load", function() {
                return void z.appendChild(m)
            }) : z.appendChild(m);
            jf(Be) || (a._loadStarted_ = !0)
        }
        g === g.top && mf(g);
        Mi(new Ji, g, c, fj(c), e)
    }

    function gj() {
        var a = Number("2019072601");
        1 > a || Math.floor(a) !== a ? (Jh({
            v: "2019072601"
        }), a = "1") : a = "2019072601";
        return {
            ha: a,
            M: "m202307100101",
            ua: md(window),
            va: new ye,
            xa: .01 > ed(),
            ma: 100
        }
    }

    function $i(a, b) {
        var c = new rc(pc, "2019072601");
        var d = a.M;
        /m\d+/.test(d) ? d = Number(d.substring(1)) : (d && Jh({
            mjsv: d
        }), d = void 0);
        return t(Object, "assign").call(Object, {}, a, {
            Pa: c,
            Ra: d,
            Sa: new rc(pc, "m202307100101"),
            qa: b
        })
    }

    function aj(a) {
        return (a = a.currentScript) ? a : null
    }

    function bj(a) {
        var b;
        a = v(null != (b = a.scripts) ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, t(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function dj(a, b) {
        var c = a.ha,
            d = a.M;
        a = a.qa;
        var e = "";
        jf(De) && (e = "", a && 2012 < a && (e = "_fy" + a));
        b = fj(b) ? d ? od(Si, d, e) : od(Ti, c) : d ? od(Ui, d, e) : od(Vi, c);
        return (c = V(Dg).g(Je.g, Je.defaultValue)) ? pd(b, new r.Map([
            ["cb", c]
        ])) : b
    }

    function cj(a, b, c, d) {
        Ci(172, c.ga);
        Gi(a, c);
        xi(12, d);
        xi(5, d);
        (a = wi(b)) && a.then(function(e) {
            return void Ci(251, ic(e))
        });
        fg(V(Dg).j(Ke.g, Ke.defaultValue), b.document)
    }

    function ej(a) {
        var b = aj(a);
        return "complete" === a.readyState || "loaded" === a.readyState || !(null == b || !b.async)
    }

    function fj(a) {
        return !(null == a || !a.src) && "pagead2.googlesyndication.com" === Uc(a.src.match(Tc)[3] || null)
    };
    var hj = function(a) {
        this.h = R(a)
    };
    x(hj, S);
    var ij = lc(hj);
    hj.m = [10];
    var jj = "undefined" === typeof sttc ? void 0 : sttc;
    try {
        var Xi = Ni(),
            Zi = gj(),
            kj;
        var lj = Zi;
        try {
            var mj = kc();
            if (! of (jj)) {
                var nj = mj ? mj() + "\n" : "";
                throw Error(nj + String(jj));
            }
            kj = ij(jj)
        } catch (a) {
            Ri(lj, 838, a), kj = new hj
        }
        var Yi = kj,
            oj = Xi,
            pj = Yi,
            qj = !V(Ai).g,
            rj = kc();
        if (!qj) throw Error(rj && rj() || String(qj));
        t(Object, "assign").call(Object, zi, oj._vars_);
        oj._vars_ = zi;
        pj && (Ub(pj, 3) && Ci(36, !0), Ub(pj, 5) && Ci(221, !0), P(pj, 6) && Ci(150, P(pj, 6)));
        Wi()
    } catch (a) {
        try {
            Ri(gj(), 420, a)
        } catch (b) {}
    };
}).call(this.googletag && googletag.fifWin ? googletag.fifWin.parent : this, "[[[[null,472785970,null,[null,500]],[45412007,null,null,[1]],[null,7,null,[null,0.1]],[514499457,null,null,[1]],[null,448338836,null,[null,0.01]],[null,427198696,null,[null,1]],[null,408380992,null,[null,0.01]],[null,377289019,null,[null,10000]],[45414566,null,null,[1]],[null,529,null,[null,20]],[542573660,null,null,[]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[543738408,null,null,[1]],[537888660,null,null,[1]],[539097417,null,null,[1]],[45401685,null,null,[1]],[200,null,null,[1]],[null,492,null,[null,0.01]],[437061931,null,null,[1]],[null,532520346,null,[null,120]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,376149757,null,[null,0.0025]],[523253321,null,null,[1]],[377936516,null,null,[1]],[503519166,null,null,[1]],[null,null,2,[null,null,\"1-0-40\"]],[539719744,null,null,[1]],[543564725,null,null,[1]],[null,506394061,null,[null,100]],[526684968,null,null,[1]],[null,null,null,[],null,489],[392065905,null,null,null,[[[4,null,68],[1]]]],[null,360245595,null,[null,500]],[45397804,null,null,[1]],[45398607,null,null,[1]],[516301089,null,null,[1]],[null,397316938,null,[null,1000]],[507033477,null,null,[1]],[null,514795754,null,[null,2]],[45415915,null,null,[1]],[529748032,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[0123])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[523169149,null,null,[1]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,1917,null,[null,300]],[null,1916,null,[null,0.001]],[null,null,null,[null,null,null,[\"A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo\/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8\/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A4A26Ymj79UVY7C7JGUS4BG1s7MdcDokAQf\/RP0paks+RoTYbXHxceT\/5L4iKcsleFCngi75YfNRGW2+SpVv1ggAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\"]],null,1934],[1957,null,null,[1]],[null,1972,null,[]],[485990406,null,null,[]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[1,[[31070955],[31070956]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[01])\\\\d{3,})\",[\"navigator.userAgent\"]],[1,[[4,null,63]]]]],59],[1000,[[31072561]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"FLEDGE_GAM_EXTERNAL_TESTER\",[\"navigator.userAgent\"]]]]],[50,[[31075028],[31075029,[[531493729,null,null,[1]]]]]],[1,[[31075263],[31075264,[[501,null,null,[1]]]],[31075265,[[501,null,null,[1]]]]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[01])\\\\d{3,})\",[\"navigator.userAgent\"]],[1,[[4,null,63]]]]],59],[10,[[31075593],[31075594]]],[null,[[676982960],[676982998]]]]],[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[10,[[44769661],[44769662,[[1973,null,null,[1]]]]]]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[200,[[44783616,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44791426,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]],null,77],[200,[[44790623,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[44791427,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]],null,77]]],[5,[[50,[[31067420],[31067421,[[360245597,null,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[100,[[31072019],[31072020,[[471855283,null,null,[1]]]]]],[1,[[31074605],[31074606,[[479390945,null,null,[1]],[518650310,null,null,[1]]]]]],[50,[[31074947],[31074948,[[489217043,null,null,[1]]]],[31074949,[[495013820,null,null,[1]]]]],null,59],[10,[[31075227,[[360245597,null,null,[]]]],[31075228,[[null,null,null,[null,null,null,[\"scar\"]],null,489]]],[31075229],[31075230],[31075231],[31075383],[31075384],[44776366],[44776367],[44779256],[44784467]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[31075409]],[2,[[4,null,3],[6,null,null,13,null,0]]],1,null,null,null,null,null,null,null,null,3],[10,[[31075410,[[null,24,null,[null,31075410]]]]],[2,[[4,null,3],[6,null,null,13,null,0]]],1,null,null,null,100,null,null,null,null,3],[10,[[31075411,[[null,24,null,[null,31075411]],[537116804,null,null,[1]]]]],[2,[[4,null,3],[6,null,null,13,null,0]]],1,null,null,null,200,null,null,null,null,3],[1000,[[31075591,null,[2,[[2,[[8,null,null,1,null,-1],[7,null,null,1,null,10]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31075592,null,[2,[[2,[[8,null,null,1,null,9],[7,null,null,1,null,20]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[50,[[31075755],[31075756]],[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],69],[1000,[[31076034,[[null,24,null,[null,31076034]]],[6,null,null,13,null,31076034]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31076035,[[null,24,null,[null,31076035]]],[6,null,null,13,null,31076035]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[100,[[31076048],[31076049,[[543536815,null,null,[1]]]]]],[1000,[[31076055,[[null,24,null,[null,31076055]]],[6,null,null,13,null,31076055]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31076056,[[null,24,null,[null,31076056]]],[6,null,null,13,null,31076056]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31076101,[[null,24,null,[null,31076101]]],[6,null,null,13,null,31076101]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31076102,[[null,24,null,[null,31076102]]],[6,null,null,13,null,31076102]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[100,[[31076167],[31076168,[[542573660,null,null,[1]]]]]],[10,[[31076169],[31076170,[[539488524,null,null,[1]]]]]]]],[25,[[50,[[31068366],[31068367,[[null,455645877,null,[null,0.1]]]]]],[10,[[31068825],[31068826,[[null,462420536,null,[null,0.1]]]]]],[50,[[31070232],[31070233,[[476475256,null,null,[1]]]]]]]],[2,[[1000,[[31075055,null,[4,null,6,null,null,null,null,[\"31075028\"]]]],[4,null,70,null,null,null,null,[\"browsing-topics\"]],84,null,null,null,null,null,null,null,null,6],[1000,[[31075056,null,[4,null,6,null,null,null,null,[\"31075029\"]]]],[4,null,70,null,null,null,null,[\"browsing-topics\"]],84,null,null,null,null,null,null,null,null,6],[1,[[31075124,[[null,514795754,null,[null,4]],[489217043,null,null,[1]]]]],[2,[[4,null,15,null,null,null,null,[\"22657645226\"]],[4,null,8,null,null,null,null,[\"enableRemoteAuction\"]]]],59],[50,[[31075148],[31075149,[[531615531,null,null,[1]]]]],null,null,null,null,null,100,null,102],[1000,[[31075338,null,[2,[[4,null,6,null,null,null,null,[\"31074947\"]],[4,null,8,null,null,null,null,[\"fetch\"]]]]]],null,85,null,null,null,null,null,null,null,null,7],[1000,[[31075339,null,[2,[[4,null,6,null,null,null,null,[\"31074948\"]],[4,null,8,null,null,null,null,[\"fetch\"]]]]]],null,85,null,null,null,null,null,null,null,null,7],[1000,[[31075340,null,[2,[[4,null,6,null,null,null,null,[\"31074947\"]],[4,null,9,null,null,null,null,[\"fetch\"]]]]]],null,86,null,null,null,null,null,null,null,null,8],[1000,[[31075341,null,[2,[[4,null,6,null,null,null,null,[\"31074949\"]],[4,null,9,null,null,null,null,[\"fetch\"]]]]]],null,86,null,null,null,null,null,null,null,null,8]]],[4,[[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]],null,78]]]],null,null,[null,\"1000\",1,\"1000\"]],31076034,null,null,null,\".google.co.in\",337,2021,[[\"pinchofyum.com\",null,\"https:\/\/pinchofyum.com\/\",null,null,[\"18190176\"]],[],[[[\"18190176\",null,1]]],null,null,[[\"18190176\",[[\"pubmatic\"],[\"parrable.com\"],[\"index\"],[\"liveintent.com\"],[\"33across.com\"],[\"liveramp.com\"],[\"uidapi.com\",null,1],[\"esp.criteo.com\"],[\"pubcid.org\",null,1],[\"id5-sync.com\",null,1]]]]]]")