(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var q, ba, da, ea, fa, ma, pa, ra, wa, ua, ya, za, Aa, Ba, Ca, Ea, Fa, Ja, Ka, La, Ma, Na, Qa, Ra, Sa, Va, Ta, Wa, Xa, Ya, Za, eb, fb, hb, jb, lb, nb, tb, vb, Ab, Db, Gb, Jb, Lb, Ob, Qb, Ub, Xb, Rb, Yb, dc, ec, gc, hc, ic, jc, kc, lc, mc, pc, qc, wc, xc, yc, zc, Bc, Cc, Dc, Fc, Gc, Jc, Ic, Mc, Nc, Pc, Qc, Rc, Sc, Wc, Yc, Zc, $c, dd, fd, gd, hd, md, nd, od, pd, sd, ud, vd, xd, wd, Ad, Cd, Bd, Ed, Dd, Fd, Gd, Oc, Jd, Kd, Nd, Rd, Sd, Td, Pd, Ud, Qd, Wd, ae, ce, fe, ge, he, ie, le, qe, re, te, ue, ve, we, ze, Ce, Ee, Ge, Ve, Me, Xe, Ye, Ze, $e, df, hf, kf, nf, pf, sf, uf, zf, xf, Bf, Ff, Kf, Of, Pf, Qf, Mf, Nf, Rf, Uf, Wf, ag, gg, kg, ng, pg, qg, rg, wg, Ag, H, Bg, Hg, Fg, Ug, Yg, $g, ah, ch, hh, kh, ph, rh, th, sh, Ah, Bh, Ch, Dh, uh, Eh, vh, Gh, Ih, Kh, Lh, Nh, Mh, Ph, Uh, Sh, Vh, ci, fi, Yh, Zh, gi, ii, ki, li, mi, ri, si, Ei, Ki, Ii, Ji, Pi, Ti, Ui, Wi, Xi, Yi, $i, dj, kj, gj, sj, aj, vj, tj, uj, xj, Aj, Cj, L, Ej, Fj, Gj, Ij, Kj, Lj, Oj, Nj, Mj, Wj, Zj, hk, ik, jk, lk, mk, qk, rk, tk, uk, wk, Ak, Fk, Hk, Jk, Kk, Lk, Mk, Pk, Rk, Tk, Uk, Wk, Yk, Zk, Xk, qa, bl, cl, fl, gl, il, ql, rl, sl, xl, zl, Al, Bl, Dl, El, Gl, Ml, Nl, Pl, bm, $l, cm, fm, Tl, om, pm, sm, rm, vm, xm, zm, Am, Bm, Cm, Dm, Em, Im, Jm, Km, Lm, Mm, Pm, Nm, Qm, Rm, Sm, Tm, Um, Vm, Ym, Zm, cn, dn, fn, hn, nn, rn, sn, vn, yn, wn, xn, In, Bn, Jn, Mn, On, Vn, Pn, Qn, Ln, Yn, Zn, ao, ho, ko, lo, mo, so, uo, wo, yo, Ao, Co, Do, Eo, Lo, Mo, No, Oo, Ro, So, Qo, To, Uo, Wo, $o, Xo, ap, gp, lp, np, op, pp, sp, Jp, Lp, Tp, Up, Vp, Pq, Sq, $q, Vq, Xq, br, jr, lr, nr, qr, sr, tr, ur, wr, xr, yr, zr, Br, Cr, Dr, Kr, Lr, Mr, xb, zb, Or, Rr, Pr, Qr, Sr, Tr, vc, sa, ka, la, Yr, Zr, ef;
    ba = function(a) {
        return a ? a.passive && aa() ? a : a.capture || !1 : !1
    };
    da = function(a, b) {
        b = _.ca(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    ea = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    fa = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    ma = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.ha(e) ? "o" + (Object.prototype.hasOwnProperty.call(e, ka) && e[ka] || (e[ka] = ++la)) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    pa = function(a, b) {
        a.sort(b || _.oa)
    };
    ra = function(a) {
        for (var b = qa, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.oa;
        pa(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    wa = function(a, b) {
        if (!sa(a) || !sa(b) || a.length != b.length) return !1;
        for (var c = a.length, d = ua, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.oa = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    ua = function(a, b) {
        return a === b
    };
    ya = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    za = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = za.apply(null, fa(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    Aa = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Ba = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ca = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ea = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Da.length; f++) c = Da[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Fa = function() {
        var a = _.t.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Ja = function(a) {
        return Ga ? Ha ? Ha.brands.some(function(b) {
            return (b = b.brand) && Ia(b, a)
        }) : !1 : !1
    };
    Ka = function(a) {
        return Ia(Fa(), a)
    };
    La = function(a) {
        for (var b = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
        return c
    };
    Ma = function() {
        return Ga ? !!Ha && 0 < Ha.brands.length : !1
    };
    Na = function() {
        return Ma() ? !1 : Ka("Opera")
    };
    Qa = function() {
        return Ma() ? !1 : Ka("Trident") || Ka("MSIE")
    };
    Ra = function() {
        return Ma() ? Ja("Microsoft Edge") : Ka("Edg/")
    };
    Sa = function() {
        return Ka("Firefox") || Ka("FxiOS")
    };
    Va = function() {
        return Ka("Safari") && !(Ta() || (Ma() ? 0 : Ka("Coast")) || Na() || (Ma() ? 0 : Ka("Edge")) || Ra() || (Ma() ? Ja("Opera") : Ka("OPR")) || Sa() || Ka("Silk") || Ka("Android"))
    };
    Ta = function() {
        return Ma() ? Ja("Chromium") : (Ka("Chrome") || Ka("CriOS")) && !(Ma() ? 0 : Ka("Edge")) || Ka("Silk")
    };
    Wa = function(a) {
        var b = {};
        a.forEach(function(c) {
            b[c[0]] = c[1]
        });
        return function(c) {
            return b[_.v(c, "find").call(c, function(d) {
                return d in b
            })] || ""
        }
    };
    Xa = function() {
        var a = Fa();
        if (Qa()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        a = La(a);
        b = Wa(a);
        return Na() ? b(["Version", "Opera"]) : (Ma() ? 0 : Ka("Edge")) ? b(["Edge"]) : Ra() ? b(["Edg"]) : Ka("Silk") ? b(["Silk"]) : Ta() ? b(["Chrome", "CriOS", "HeadlessChrome"]) : (a = a[2]) && a[1] || ""
    };
    Ya = function() {
        var a = La(Fa());
        Wa(a);
        return Sa() ? (a = a[2]) && a[1] || "" : ""
    };
    Za = function() {
        if (Ma()) {
            var a = _.v(Ha.brands, "find").call(Ha.brands, function(b) {
                return "Firefox" === b.brand
            });
            if (!a || !a.version) return NaN;
            a = a.version.split(".")
        } else {
            a = Ya();
            if ("" === a) return NaN;
            a = a.split(".")
        }
        return 0 === a.length ? NaN : Number(a[0])
    };
    _.db = function(a) {
        if (a instanceof _.$a) a = _.ab(a);
        else {
            b: if (cb) {
                try {
                    var b = new URL(a)
                } catch (c) {
                    b = "https:";
                    break b
                }
                b = b.protocol
            } else c: {
                b = document.createElement("a");
                try {
                    b.href = a
                } catch (c) {
                    b = void 0;
                    break c
                }
                b = b.protocol;b = ":" === b || "" === b ? "https:" : b
            }
            a = "javascript:" !== b ? a : void 0
        }
        return a
    };
    eb = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    fb = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    hb = function(a, b) {
        a.textContent = _.gb(b);
        fb(a)
    };
    jb = function(a, b) {
        a.src = _.ib(b);
        fb(a)
    };
    lb = function(a, b) {
        a.write(_.kb(b))
    };
    nb = function(a) {
        return new mb(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.rb = function(a) {
        var b = void 0 === b ? ob : b;
        a: {
            b = void 0 === b ? ob : b;
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof mb && d.Ji(a)) {
                    a = pb(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.qb
    };
    tb = function(a) {
        for (var b = _.sb.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return pb(c.join(""))
    };
    vb = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.x.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            jb(g, a);
            c && "complete" !== b.document.readyState ? _.ub(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    Ab = function(a) {
        var b, c, d, e, f, g;
        return _.wb(function(h) {
            switch (h.j) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.j + ("&tv=" + a.o + "&st=") + a.yc, c = void 0, h.F = 2, xb(h, yb(b), 4);
                case 4:
                    c = h.o;
                    h.j = 3;
                    h.F = 0;
                    break;
                case 2:
                    zb(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.Zc || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.F ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.B,
                        Nh: c.bg_hash_basename,
                        Mh: c.bg_binary,
                        Qi: a.j + "_" + a.o,
                        Zc: d,
                        yc: a.yc,
                        Sd: e,
                        je: f,
                        Rd: g
                    }) : h.return(void 0)
            }
        })
    };
    Db = function(a) {
        var b;
        return _.wb(function(c) {
            if (1 == c.j) return xb(c, Ab(a), 2);
            if (b = c.o) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.Nh, g._bgp_ = b.Mh, g._li_ = b.Qi, g._jk_ = b.Zc, g._st_ = b.yc, g._rc_ = b.Sd, g._dl_ = b.je, g._g2_ = b.Rd, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = _.Bb(Cb, {
                    basename: d
                });
                vb(d)
            }
            return c.return(b)
        })
    };
    Gb = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (Eb) {
            if (b && /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a)) throw Error("Found an unpaired surrogate");
            a = (Fb || (Fb = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    Jb = function(a) {
        if (!Hb) return Ib(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Lb = function(a) {
        return Kb[a] || ""
    };
    Ob = function(a) {
        return Nb && null != a && a instanceof Uint8Array
    };
    Qb = function(a) {
        if (a !== Pb) throw Error("illegal external caller");
    };
    Ub = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.y(Rb(c, a)), b = c.next().value, a = c.next().value, c = b);
        Sb = c >>> 0;
        Tb = a >>> 0
    };
    Xb = function(a) {
        if (16 > a.length) Ub(Number(a));
        else if (Wb) a = BigInt(a), Sb = Number(a & BigInt(4294967295)) >>> 0, Tb = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            Tb = Sb = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), Tb *= 1E6, Sb = 1E6 * Sb + d, 4294967296 <= Sb && (Tb += Sb / 4294967296 | 0, Sb %= 4294967296);
            b && (b = _.y(Rb(Sb, Tb)), a = b.next().value, b = b.next().value, Sb = a, Tb = b)
        }
    };
    Rb = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    Yb = function(a) {
        return Array.prototype.slice.call(a)
    };
    dc = function(a) {
        var b = Zb(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Yb(a)), cc(a, b | 1))
    };
    ec = function(a, b) {
        Object.isFrozen(a) && (a = Yb(a));
        cc(a, b);
        return a
    };
    gc = function(a) {
        fc(a, 1);
        return a
    };
    hc = function(a) {
        fc(a, 18);
        return a
    };
    ic = function(a) {
        fc(a, 16);
        return a
    };
    jc = function(a, b) {
        cc(b, (a | 0) & -51)
    };
    kc = function(a, b) {
        cc(b, (a | 18) & -41)
    };
    lc = function(a) {
        a = a >> 10 & 1023;
        return 0 === a ? 536870912 : a
    };
    mc = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    pc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new nc(a, Pb) : oc();
            else if (a.constructor !== nc)
            if (Ob(a)) {
                var d;
                c ? d = 0 == a.length ? oc() : new nc(a, Pb) : d = a.length ? new nc(new Uint8Array(a), Pb) : oc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    qc = function(a) {
        if (a & 2) throw Error();
    };
    _.uc = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number|null|undefined, found " + typeof a + ": " + a);
        return a
    };
    wc = function(a) {
        if ("boolean" !== typeof a) throw Error("Expected boolean but got " + vc(a) + ": " + a);
        return !!a
    };
    xc = function(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    };
    yc = function(a) {
        return null == a ? a : a
    };
    zc = function(a) {
        return a
    };
    _.Ac = function(a) {
        return a
    };
    Bc = function(a) {
        return a
    };
    Cc = function(a) {
        return a
    };
    Dc = function(a) {
        return a
    };
    _.Ec = function(a) {
        if ("string" !== typeof a) throw Error();
        return a
    };
    Fc = function(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    };
    Gc = function(a) {
        return null == a || "string" === typeof a ? a : void 0
    };
    Jc = function(a, b, c, d) {
        var e = !1;
        if (null != a && "object" === typeof a && !(e = Array.isArray(a)) && a.ff === Hc) return a;
        if (!e) return c ? d & 2 ? Ic(b) : new b : void 0;
        e = c = Zb(a);
        0 === e && (e |= d & 16);
        e |= d & 2;
        e !== c && cc(a, e);
        return new b(a)
    };
    Ic = function(a) {
        var b = a[Kc];
        if (b) return b;
        b = new a;
        hc(b.K);
        return a[Kc] = b
    };
    Mc = function(a) {
        return a
    };
    Nc = function(a, b, c) {
        return "string" === typeof a ? a : c ? "" : void 0
    };
    Pc = function(a, b, c, d, e, f) {
        a = Jc(a, d, c, f);
        e && (a = Oc(a));
        return a
    };
    Qc = function(a) {
        return a
    };
    Rc = function(a) {
        return [a, this.get(a)]
    };
    Sc = function(a, b, c, d, e) {
        var f = lc(b);
        if (c >= f || e) {
            e = b;
            if (b & 128) f = a[a.length - 1];
            else {
                if (null == d) return;
                f = a[f + ((b >> 8 & 1) - 1)] = {};
                e |= 128
            }
            f[c] = d;
            e &= -513;
            e !== b && cc(a, e)
        } else a[c + ((b >> 8 & 1) - 1)] = d, b & 128 && (d = a[a.length - 1], c in d && delete d[c]), b & 512 && cc(a, b & -513)
    };
    Wc = function(a, b, c, d, e) {
        var f = b & 2,
            g = Tc(a, b, c, e);
        Array.isArray(g) || (g = Uc);
        var h = Zb(g);
        h & 1 || gc(g);
        if (f) h & 2 || hc(g), d & 1 || Object.freeze(g);
        else {
            f = !(d & 2);
            var k = h & 2;
            d & 1 || !k ? f && h & 16 && !k && Vc(g, 16) : (g = gc(Yb(g)), Sc(a, b, c, g, e))
        }
        return g
    };
    Yc = function(a, b, c, d, e) {
        a = a.K;
        var f = Xc(a),
            g = f & 2,
            h = Wc(a, f, b, e || 1, d),
            k = Zb(h);
        if (!(k & 4)) {
            Object.isFrozen(h) && (h = gc(Yb(h)), Sc(a, f, b, h, d));
            for (var l = 0, m = 0; l < h.length; l++) {
                var n = c(h[l]);
                null != n && (h[m++] = n)
            }
            m < l && (h.length = m);
            k |= 5;
            g && (k |= 18);
            cc(h, k);
            k & 2 && Object.freeze(h)
        }
        if (2 === e) return h;
        !g && (k & 2 || Object.isFrozen(h)) && (h = Yb(h), fc(h, 5), Sc(a, f, b, h, d));
        return h
    };
    Zc = function(a) {
        return pc(a, !0, !0)
    };
    $c = function(a) {
        return pc(a, !0, !1)
    };
    dd = function() {
        var a;
        return null != (a = ad) ? a : ad = new bd(hc([]), void 0, void 0, void 0, cd)
    };
    fd = function(a, b, c, d, e, f) {
        var g = b & 2;
        a: {
            var h = c,
                k = b & 2;c = !1;
            if (null == h) {
                if (k) {
                    a = dd();
                    break a
                }
                h = []
            } else if (h.constructor === bd) {
                if (0 == (h.j & 2) || k) {
                    a = h;
                    break a
                }
                h = ed(h)
            } else Array.isArray(h) ? c = !!(Zb(h) & 2) : h = [];
            if (k) {
                if (!h.length) {
                    a = dd();
                    break a
                }
                c || (c = !0, hc(h))
            } else if (c)
                for (c = !1, h = Yb(h), k = 0; k < h.length; k++) {
                    var l = h[k] = Yb(h[k]);
                    Array.isArray(l[1]) && (l[1] = hc(l[1]))
                }
            c || (Zb(h) & 32 ? Vc(h, 16) : 16 & b && ic(h));f = new bd(h, e, Nc, f);Sc(a, b, d, f, !1);a = f
        }
        if (null == a) return a;
        !g && e && (a.N = !0);
        return a
    };
    gd = function(a, b) {
        a = a.K;
        var c = Xc(a);
        return fd(a, c, Tc(a, c, b), b, void 0, Nc)
    };
    hd = function(a, b, c) {
        a = a.K;
        var d = Xc(a);
        return fd(a, d, Tc(a, d, b), b, c)
    };
    _.id = function(a, b, c, d) {
        var e = a.K,
            f = Xc(e);
        qc(f);
        if (null == c) return Sc(e, f, b), a;
        var g = Zb(c);
        if (!(g & 4)) {
            if (g & 2 || Object.isFrozen(c)) c = Yb(c);
            for (var h = 0; h < c.length; h++) c[h] = d(c[h]);
            cc(c, g | 5)
        }
        Sc(e, f, b, c);
        return a
    };
    _.ld = function(a, b, c, d) {
        var e = a.K,
            f = Xc(e);
        qc(f);
        Sc(e, f, b, c !== d ? c : void 0);
        return a
    };
    md = function(a, b, c) {
        var d = a.K,
            e = Xc(d);
        qc(e);
        Wc(d, e, b, 2, !1).push(c);
        e & 512 && cc(d, e & -513);
        return a
    };
    nd = function(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != Tc(a, b, f) && (0 !== d && Sc(a, b, d), d = f)
        }
        return d
    };
    od = function(a, b, c, d, e) {
        var f = !!(b & 2),
            g = Wc(a, b, d, 1);
        if (g === Uc || !(Zb(g) & 4)) {
            var h = g;
            g = !!(b & 2);
            var k = !!(Zb(h) & 2);
            f = h;
            !g && k && (h = Yb(h));
            var l = b | (k ? 2 : 0);
            k = k || void 0;
            for (var m = 0, n = 0; m < h.length; m++) {
                var p = Jc(h[m], c, !1, l);
                void 0 !== p && (k = k || Xc(p.K) & 2, h[n++] = p)
            }
            n < m && (h.length = n);
            c = h;
            h = Zb(c);
            l = h | 5;
            k = k ? l & -9 : l | 8;
            h != k && (c = ec(c, k));
            h = c;
            f !== h && Sc(a, b, d, h);
            (g && 2 !== e || 1 === e) && Object.freeze(h);
            return h
        }
        if (3 === e) return g;
        f || (f = Object.isFrozen(g), 1 === e ? f || Object.freeze(g) : (e = Zb(g), c = e & -19, f && (g = Yb(g), e = 0, Sc(a, b, d, g)), e !== c && cc(g, c)));
        return g
    };
    pd = function(a, b, c, d) {
        a = a.K;
        var e = Xc(a);
        qc(e);
        b = od(a, e, c, b, 2);
        c = null != d ? d : new c;
        b.push(c);
        Zb(c.K) & 2 && Vc(b, 8);
        e & 512 && cc(a, e & -513);
        return c
    };
    _.qd = function(a, b, c) {
        return _.ld(a, b, null == c ? c : wc(c), !1)
    };
    _.rd = function(a, b, c) {
        return _.ld(a, b, c, 0)
    };
    sd = function(a, b) {
        return null != a ? a : b
    };
    ud = function(a, b) {
        td = b;
        a = new a(b);
        td = void 0;
        return a
    };
    _.z = function(a, b, c) {
        null == a && (a = td);
        td = void 0;
        if (null == a) {
            var d = 48;
            c ? (a = [c], d |= 256) : a = [];
            b && (d = d & -1047553 | (b & 1023) << 10)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = Zb(a);
            if (d & 32) return a;
            d |= 32;
            if (c && (d |= 256, c !== a[0])) throw Error();
            a: {
                c = a;
                var e = c.length;
                if (e) {
                    var f = e - 1,
                        g = c[f];
                    if (mc(g)) {
                        d |= 128;
                        b = (d >> 8 & 1) - 1;
                        e = f - b;
                        1024 <= e && (vd(c, b, g), e = 1023);
                        d = d & -1047553 | (e & 1023) << 10;
                        break a
                    }
                }
                b && (g = (d >> 8 & 1) - 1, b = Math.max(b, e - g), 1024 < b && (vd(c, g, {}), d |= 128, b = 1023), d = d & -1047553 | (b & 1023) << 10)
            }
        }
        cc(a, d);
        return a
    };
    vd = function(a, b, c) {
        for (var d = 1023 + b, e = a.length, f = d; f < e; f++) {
            var g = a[f];
            null != g && g !== c && (c[f - b] = g)
        }
        a.length = d + 1;
        a[d] = c
    };
    xd = function(a, b) {
        return wd(b)
    };
    wd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a && !Array.isArray(a)) {
                    if (Ob(a)) return Jb(a);
                    if (a instanceof nc) return yd(a);
                    if (a instanceof bd) return zd(a)
                }
        }
        return a
    };
    Ad = function(a, b, c) {
        a = Yb(a);
        var d = a.length,
            e = b & 128 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 256 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    };
    Cd = function(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Zb(a) & 1 ? void 0 : f && Zb(a) & 2 ? a : Bd(a, b, c, void 0 !== d, e, f);
            else if (mc(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Cd(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    };
    Bd = function(a, b, c, d, e, f) {
        var g = d || c ? Zb(a) : 0;
        d = d ? !!(g & 16) : void 0;
        a = Yb(a);
        for (var h = 0; h < a.length; h++) a[h] = Cd(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    };
    Ed = function(a) {
        return Cd(a, Dd, void 0, void 0, !1, !1)
    };
    Dd = function(a) {
        return a.ff === Hc ? a.toJSON() : a instanceof bd ? zd(a, Ed) : wd(a)
    };
    Fd = function(a, b, c) {
        c = void 0 === c ? kc : c;
        if (null != a) {
            if (Nb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Zb(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return cc(a, d | 18), a;
                a = Bd(a, Fd, d & 4 ? kc : c, !0, !1, !0);
                b = Zb(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            a.ff === Hc ? (b = a.K, c = Xc(b), a = c & 2 ? a : Gd(a, b, c, !0)) : a instanceof bd && (b = hc(ed(a, Fd)), a = new bd(b, a.F, a.o, a.B));
            return a
        }
    };
    Gd = function(a, b, c, d) {
        var e = d || c & 2 ? kc : jc,
            f = !!(c & 16);
        b = Ad(b, c, function(g) {
            return Fd(g, f, e)
        });
        fc(b, 16 | (d ? 2 : 0));
        return ud(a.constructor, b)
    };
    Oc = function(a) {
        var b = a.K,
            c = Xc(b);
        if (!(c & 2)) return a;
        b = Gd(a, b, c, !1);
        b.o = a;
        fc(b.K, 512);
        return b
    };
    Jd = function(a, b, c) {
        var d = a.constructor.fa,
            e = lc(Xc(c ? a.K : b)),
            f = !1;
        if (d) {
            if (!c) {
                b = Yb(b);
                var g;
                if (b.length && mc(g = b[b.length - 1]))
                    for (f = 0; f < d.length; f++)
                        if (d[f] >= e) {
                            _.v(Object, "assign").call(Object, b[b.length - 1] = {}, g);
                            break
                        }
                f = !0
            }
            e = b;
            c = !c;
            g = Xc(a.K);
            a = lc(g);
            g = (g >> 8 & 1) - 1;
            for (var h, k, l = 0; l < d.length; l++)
                if (k = d[l], k < a) {
                    k += g;
                    var m = e[k];
                    null == m ? e[k] = c ? Uc : gc([]) : c && m !== Uc && dc(m)
                } else h || (m = void 0, e.length && mc(m = e[e.length - 1]) ? h = m : e.push(h = {})), m = h[k], null == h[k] ? h[k] = c ? Uc : gc([]) : c && m !== Uc && dc(m)
        }
        d = b.length;
        if (!d) return b;
        var n;
        if (mc(h = b[d - 1])) {
            a: {
                var p = h;e = {};c = !1;
                for (var r in p) Object.prototype.hasOwnProperty.call(p, r) && (a = p[r], Array.isArray(a) && a != a && (c = !0), null != a ? e[r] = a : c = !0);
                if (c) {
                    for (var u in e) {
                        p = e;
                        break a
                    }
                    p = null
                }
            }
            p != h && (n = !0);d--
        }
        for (; 0 < d; d--) {
            h = b[d - 1];
            if (null != h) break;
            var w = !0
        }
        if (!n && !w) return b;
        var A;
        f ? A = b : A = Array.prototype.slice.call(b, 0, d);
        b = A;
        f && (b.length = d);
        p && b.push(p);
        return b
    };
    Kd = function(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        fc(b, 64);
        return ud(a, ic(b))
    };
    Nd = function(a, b) {
        var c = a[b];
        "function" == typeof c && 0 === c.length && (c = c(), a[b] = c);
        return Array.isArray(c) && (Ld in c || Md in c || 0 < c.length && "function" == typeof c[0]) ? c : void 0
    };
    Rd = function(a) {
        var b = a[Od];
        if (!b) {
            var c = Pd(a);
            b = function(d, e) {
                return Qd(d, e, c)
            };
            a[Od] = b
        }
        return b
    };
    Sd = function(a) {
        return a.j
    };
    Td = function(a, b) {
        var c = Rd(b),
            d = Pd(b).j,
            e = a.j;
        return function(f, g, h) {
            return e(f, g, h, d, c)
        }
    };
    Pd = function(a) {
        var b = a[Md];
        if (b) return b;
        a: {
            b = a[Md] = {};
            var c = Sd,
                d = Td;b.j = a[0];
            var e = 1;
            if (a.length > e && "number" !== typeof a[e]) {
                var f = a[e++];
                if (Array.isArray(f)) {
                    b.F = f[0];
                    b.o = f[1];
                    break a
                }
                b.o = f
            }
            for (; e < a.length;) {
                f = a[e++];
                for (var g = e + 1; g < a.length && "number" !== typeof a[g];) g++;
                var h = a[e++];
                g -= e;
                switch (g) {
                    case 0:
                        b[f] = c(h);
                        break;
                    case 1:
                        (g = Nd(a, e)) ? (e++, b[f] = d(h, g)) : b[f] = c(h, a[e++]);
                        break;
                    case 2:
                        g = b;
                        var k = e++;
                        k = Nd(a, k);
                        g[f] = d(h, k, a[e++]);
                        break;
                    default:
                        throw Error("unexpected number of binary field arguments: " + g);
                }
            }
        }
        Ld in a && Md in a && (a.length = 0);
        return b
    };
    Ud = function(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.o)
            if (c = c[b]) {
                var d = c.Xk,
                    e = c.bl.j;
                if (d) {
                    var f = Rd(d),
                        g = Pd(d).j;
                    c = function(h, k, l) {
                        return e(h, k, l, g, f)
                    }
                } else c = e;
                return a[b] = c
            }
    };
    Qd = function(a, b, c) {
        for (var d = a.K, e = Xc(d), f = (e >> 8 & 1) - 1, g = d.length, h = g + (e & 128 ? -1 : 0), k = e & 256 ? 1 : 0; k < h; k++)
            if (null != d[k]) {
                var l = k - f,
                    m = Ud(c, l);
                m && m(b, a, l)
            }
        if (e & 128) {
            d = d[g - 1];
            for (var n in d) Object.prototype.hasOwnProperty.call(d, n) && (e = +n, _.v(Number, "isNaN").call(Number, e) || null == d[n] || (f = Ud(c, e)) && f(b, a, e))
        }
    };
    Wd = function(a) {
        return new Vd(a)
    };
    ae = function(a, b, c) {
        b = Xd(b, c);
        null != b && ("string" === typeof b && Yd(b), null != b && (Zd(a.j, 8 * c), "number" === typeof b ? (a = a.j, Ub(b), $d(a, Sb, Tb)) : (c = Yd(b), $d(a.j, c.o, c.j))))
    };
    ce = function(a) {
        var b = be;
        be = void 0;
        if (!a) throw Error(b && b() || String(a));
    };
    fe = function(a) {
        return function() {
            var b = new de;
            Qd(this, b, Pd(a));
            ee(b, b.j.end());
            for (var c = new Uint8Array(b.o), d = b.F, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.F = [c];
            return c
        }
    };
    ge = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = ud(a, ic(b))
            }
            return b
        }
    };
    he = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    ie = function(a) {
        a = void 0 === a ? _.t : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    _.ke = function(a) {
        var b = _.sb.apply(1, arguments);
        if (0 === b.length) return je(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return je(c)
    };
    le = function(a, b) {
        var c = _.ib(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return je(c)
    };
    qe = function(a) {
        return new _.oe(JSON.stringify(a).replace(/</g, "\\u003C"), pe)
    };
    re = function(a) {
        return JSON.stringify([a.map(function(b) {
            var c = {};
            return [(c[b.Kf] = b.ef, c)]
        })])
    };
    te = function(a) {
        a.Ef.apply(a, _.se(_.sb.apply(1, arguments).map(function(b) {
            return {
                Kf: 2,
                ef: b.toJSON()
            }
        })))
    };
    ue = function(a) {
        a.Ef.apply(a, _.se(_.sb.apply(1, arguments).map(function(b) {
            return {
                Kf: 5,
                ef: b.toJSON()
            }
        })))
    };
    ve = function(a) {
        a && "function" == typeof a.wa && a.wa()
    };
    we = function(a) {
        return a[_.v(_.x.Symbol, "iterator")]()
    };
    ze = function(a) {
        a = xe(a.data.__fciReturn);
        return {
            payload: a,
            vf: _.ye(a, 1)
        }
    };
    Ce = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.Ae("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && da(a.google_image_requests, f);
                _.Be(f, "load", g);
                _.Be(f, "error", g)
            };
            _.ub(f, "load", g);
            _.ub(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    Ee = function() {
        var a = De;
        return function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    Ge = function() {
        var a = Fe;
        return function(b) {
            return b instanceof a
        }
    };
    Ve = function(a, b) {
        var c;
        a: {
            try {
                if (a) {
                    var d = a.getItem("google_experiment_mod");
                    break a
                }
            } catch (g) {}
            d = null
        }
        d = null != (c = d) ? c : "";
        try {
            var e = He(d);
            if (d) {
                var f = He(d);
                Ie(f, Je(Ke(1), -1));
                Le(f)
            }
        } catch (g) {
            Me(d), e = new Ne
        }
        if (c = (_.C = Oe(e, Pe, 1), _.v(_.C, "find")).call(_.C, function(g) {
                return _.Qe(g, 1, 0) === b
            }))
            if (f = _.Re(c, 2), null === f || isNaN(f)) Me(d);
            else return f;
        d = (0, _.Se)() ? null : Math.floor(1E3 * _.Te());
        if (null === d) return null;
        c ? Je(c, d) : Ie(e, Je(Ke(b), d));
        return Ue(a, Le(e)) ? d : null
    };
    Me = function(a) {
        .01 > Math.random() && We({
            data: a
        }, "ls_tamp")
    };
    Xe = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            vf: b.__uspapiReturn.callId
        }
    };
    Ye = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            vf: b.__gppReturn.callId
        }
    };
    Ze = function(a, b) {
        b = void 0 === b ? window : b;
        if (_.D(a, 5)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    $e = function(a) {
        return "null" !== a.origin
    };
    df = function(a, b, c) {
        b = _.D(b, 5) && $e(c) ? c.document.cookie : null;
        return null === b ? null : (new cf({
            cookie: b
        })).get(a) || ""
    };
    _.ff = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : ef()
    };
    _.gf = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    hf = function(a, b) {
        b = void 0 === b ? _.t : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    _.jf = function(a) {
        a = void 0 === a ? _.t : a;
        var b = Math.min(hf("domLoading", a) || Infinity, hf("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max(hf("responseEnd", a), hf("navigationStart", a)) : b
    };
    kf = function(a, b, c) {
        return b[a] || c
    };
    nf = function(a) {
        _.lf(mf).F(a)
    };
    _.of = function() {
        return _.lf(mf).B()
    };
    pf = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.C = c.allowedFeatures(), _.v(_.C, "includes")).call(_.C, a))
    };
    _.G = function(a) {
        return _.lf(qf).o(a.j, a.defaultValue)
    };
    _.rf = function(a) {
        return _.lf(qf).F(a.j, a.defaultValue)
    };
    sf = function(a) {
        return _.lf(qf).B(a.j, a.defaultValue)
    };
    uf = function(a) {
        _.lf(tf).j(a)
    };
    zf = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.t : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        wf(_.lf(mf), a);
        xf(b);
        yf(_.lf(tf), b);
        _.lf(qf).N()
    };
    xf = function(a) {
        var b = _.lf(qf);
        b.o = function(c, d) {
            return kf(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.F = function(c, d) {
            return kf(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.j = function(c, d) {
            return kf(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.B = function(c, d) {
            return kf(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.N = function() {
            kf(15, a, function() {})(2)
        }
    };
    Bf = function(a) {
        a = void 0 === a ? _.Te() : a;
        return function(b) {
            return _.Af(a + "." + b) % 1E3
        }
    };
    Ff = function(a) {
        var b = void 0 === b ? Cf : b;
        var c = _.v(Object, "assign").call(Object, {}, a),
            d = a.id,
            e = a.style;
        a = a.data;
        c = (delete c.id, delete c.style, delete c.data, c);
        if (_.v(Object, "keys").call(Object, c).length) throw Error("Invalid attribute(s): " + _.v(Object, "keys").call(Object, c));
        d = {
            id: d,
            style: e ? e : void 0
        };
        if (a)
            for (e = _.y(_.v(a, "entries").call(a)), a = e.next(); !a.done; a = e.next()) c = _.y(a.value), a = c.next().value, c = c.next().value, ce(Df.test(a)), d[a] = c;
        return _.Ef("div", d, b)
    };
    Kf = function(a) {
        Gf();
        var b = Hf.googleToken[5] || 0;
        a && (0 != b || If[3] >= ef() ? Jf.Rf(a) : (Jf.Rc().push(a), Jf.Lg()));
        If[3] >= ef() && If[2] >= ef() || Jf.Lg()
    };
    Of = function(a, b, c, d) {
        var e = new _.Lf,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.Be(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (m) {}
            },
            h = Mf(a);
        return h ? (_.ub(a, "message", g), f = c(h), e.promise) : (c = Nf(a)) ? (f = String(Math.floor(2147483647 * _.Te())), _.ub(a, "message", g), b(c, f), e.promise) : null
    };
    Pf = function(a) {
        return Of(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    Qf = function(a) {
        return !!Mf(a) || !!Nf(a)
    };
    Mf = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    Nf = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    Rf = function(a) {
        var b, c;
        return null != (c = (_.C = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.v(_.C, "find")).call(_.C, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    Uf = function(a, b, c) {
        var d, e, f, g, h;
        return _.wb(function(k) {
            if (1 == k.j) return d = c ? a.filter(function(l) {
                return !l.Mb
            }) : a, xb(k, _.x.Promise.all(d.map(function(l) {
                return l.sb.promise
            })), 2);
            if (a.length === d.length) return k.return();
            e = a.filter(function(l) {
                return l.Mb
            });
            if (_.G(Sf)) {
                f = _.y(b);
                for (g = f.next(); !g.done; g = f.next()) h = g.value, Tf(h);
                return xb(k, _.x.Promise.all(e.map(function(l) {
                    return l.sb.promise
                })), 0)
            }
            return xb(k, _.x.Promise.race([_.x.Promise.all(e.map(function(l) {
                return l.sb.promise
            })), new _.x.Promise(function(l) {
                return void setTimeout(l, c)
            })]), 0)
        })
    };
    Wf = function(a, b, c, d) {
        var e = _.G(Vf);
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var f, g = null != (f = b.googletag.queryIds) ? f : [];
                e && (b.googletag.queryIds = g);
                g.push(c);
                500 < g.length && g.shift();
                e || (b.googletag.queryIds = g)
            }
        } catch (h) {}
    };
    ag = function(a) {
        var b = a.If,
            c = a.Ne,
            d = a.lf,
            e = a.Jf,
            f = a.Oe;
        a = a.mf;
        for (var g = [], h = 0; h < a; h++)
            for (var k = 0; k < d; k++) {
                var l = d - 1,
                    m = a - 1;
                g.push({
                    x: b + (0 === l ? 0 : k / l) * (c - b),
                    y: e + (0 === m ? 0 : h / m) * (f - e)
                })
            }
        return g
    };
    _.ig = function(a) {
        var b = a.xa,
            c = a.gf,
            d = a.Vd,
            e = a.Tf,
            f = a.Ha;
        a = a.Qh;
        var g = 0;
        try {
            g |= b != b.top ? 512 : 0;
            var h = Math.min(b.screen.width || 0, b.screen.height || 0);
            g |= h ? 320 > h ? 8192 : 0 : 2048;
            var k;
            if (k = b.navigator) {
                var l = b.navigator.userAgent;
                k = /Android 2/.test(l) || /iPhone OS [34]_/.test(l) || /Windows Phone (?:OS )?[67]/.test(l) || /MSIE.*Windows NT/.test(l) || /Windows NT.*Trident/.test(l)
            }
            g |= k ? 1048576 : 0;
            g = c ? g | (b.innerHeight >= c ? 0 : 1024) : g | (_.bg(b) ? 0 : 8);
            g |= cg(b, d);
            g |= dg(b)
        } catch (m) {
            g |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = ag({
                    If: 0,
                    Ne: b.innerWidth,
                    lf: 3,
                    Jf: 0,
                    Oe: Math.min(Math.round(b.innerWidth / 320 * 50), eg) + 15,
                    mf: 3
                });
                null != fg(gg(b, c), d) && (g |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, h = Math.min(Math.round(b.innerWidth / 320 * 50), eg) + 15, k = ag({
                    If: 0,
                    Ne: d,
                    lf: 3,
                    Jf: e - h,
                    Oe: e,
                    mf: 3
                }), 25 < h && k.push({
                    x: d - 25,
                    y: e - 25
                }), null != fg(gg(b, c), k) && (g |= 16777216)
        }
        a && null != _.hg(b, void 0 === f ? null : f) && (g |= 16777216);
        return g
    };
    _.hg = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = ag({
            If: 0,
            Ne: a.innerWidth,
            lf: 10,
            Jf: c - 45,
            Oe: c,
            mf: 10
        });
        return fg(gg(a, b), c)
    };
    gg = function(a, b) {
        return new jg(a, {
            ng: kg(a, void 0 === b ? null : b)
        })
    };
    kg = function(a, b) {
        if (b = void 0 === b ? null : b) {
            var c = b;
            return function(d, e, f) {
                var g, h;
                _.lg(c, "ach_evt", {
                    tn: d.tagName,
                    id: null != (g = d.getAttribute("id")) ? g : "",
                    cls: null != (h = d.getAttribute("class")) ? h : "",
                    ign: String(f),
                    pw: a.innerWidth,
                    ph: a.innerHeight,
                    x: e.x,
                    y: e.y
                }, !0, 1)
            }
        }
    };
    ng = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.mg(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    pg = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.og(d, function(e) {
                    return !_.v(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = ng(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    qg = function(a, b) {
        .001 > _.Te() && We({
            c: a,
            s: b
        }, "gpt_whirs")
    };
    rg = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    wg = function(a) {
        var b = new sg;
        b = _.rd(b, 1, Date.now());
        b = _.rd(b, 2, a.pvsid);
        b = _.tg(b, 3, a.wb || a.nb);
        var c = _.of();
        b = _.id(b, 4, c, zc);
        b = _.rd(b, 5, a.Pi);
        a = _.tg(b, 12, a.ai);
        var d;
        if (b = null == (d = _.x.globalThis.performance) ? void 0 : d.memory) {
            d = new ug;
            try {
                _.rd(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.rd(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.rd(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.vg(a, 10, d);
        return a
    };
    Ag = function(a) {
        var b = _.jf();
        if (a.nd) {
            var c = a.Lb;
            a = wg(a);
            var d = new xg;
            b = _.rd(d, 2, b);
            b = _.yg(a, 6, zg, b);
            ue(c, b)
        }
    };
    H = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.sb.apply(0, arguments),
                f = Bg(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.nd && a.uj) {
                    var h = a.Lb,
                        k = wg(a);
                    var l = _.rd(k, 5, a.Oi);
                    var m = new Cg;
                    var n = _.ld(m, 1, b, 0);
                    var p = _.ld(n, 2, g, 0);
                    var r = _.yg(l, 9, zg, p);
                    ue(h, r)
                }
            } catch (u) {}
            return f
        }
    };
    Bg = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.sb.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.lf(Dg);
            try {
                var l = _.G(Eg);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (m) {
                try {
                    if (g) Fg.call(this, a, 110, m);
                    else if (Fg.call(this, a, b, m), !d) throw m;
                } catch (n) {
                    if (_.Gg(h), !g && !d) throw m;
                }
            }
            return f
        }
    };
    Hg = function(a, b, c, d) {
        return Bg(a, b, c, void 0 === d ? !1 : d)()
    };
    Fg = function(a, b, c) {
        if (a.Vg) {
            var d;
            c = _.Ig(c) ? c.error : c;
            var e = new Jg,
                f = new Kg;
            try {
                var g = _.Lg(window);
                _.rd(f, 1, g)
            } catch (m) {}
            try {
                var h = _.of();
                _.id(f, 2, h, zc)
            } catch (m) {}
            try {
                _.tg(f, 3, window.document.URL)
            } catch (m) {}
            g = _.vg(e, 2, f);
            h = new Mg;
            b = _.ld(h, 1, b, 0);
            try {
                _.tg(b, 2, "string" === typeof(null == c ? void 0 : c.name) ? c.name : "Unknown error")
            } catch (m) {}
            try {
                _.tg(b, 3, "string" === typeof(null == c ? void 0 : c.message) ? c.message : "Caught " + c)
            } catch (m) {}
            try {
                (d = "string" === typeof(null == c ? void 0 : c.stack) ? c.stack : Error().stack) && _.id(b, 4, d.split(/\n\s*/), _.Ec)
            } catch (m) {}
            d = _.vg(g, 1, b);
            b = new Ng;
            try {
                _.tg(b, 1, a.wb || a.nb)
            } catch (m) {}
            try {
                var k = Og();
                _.ld(b, 2, k, 0)
            } catch (m) {}
            try {
                var l = [].concat(_.se(_.v(Pg, "keys").call(Pg)));
                _.id(b, 3, l, _.Ec)
            } catch (m) {}
            _.yg(d, 4, Qg, b);
            _.rd(d, 5, a.jg);
            te(a.Lb, d)
        }
    };
    Ug = function(a, b) {
        var c, d;
        return null != (d = null == (c = _.v(a, "find").call(a, function(e) {
            e = _.Rg(e, Sg, 1);
            return Tg(e, 1) <= Tg(b, 1) && Tg(e, 2) <= Tg(b, 2)
        })) ? void 0 : Oe(c, Sg, 2)) ? d : null
    };
    Yg = function(a, b, c) {
        return "number" === typeof b && "number" === typeof c && Oe(a, Vg, 6).length ? Ug(Oe(a, Vg, 6), Wg(Xg(new Sg, b), c)) : Oe(a, Sg, 5)
    };
    $g = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = Zg(!1, b), c = Yg(a, b.width, b.height));
        null != c || (c = Yg(a));
        return null == c ? [] : c.map(function(d) {
            return _.D(d, 3) ? "fluid" : [Tg(d, 1), Tg(d, 2)]
        })
    };
    ah = function(a) {
        var b = [],
            c = !1;
        a = _.y($g(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    ch = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(_.bh(a, 1)), c.push(ah(a)), c.push(_.bh(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.Af(c.join(":")).toString() : "0"
    };
    _.fh = function(a) {
        _.lf(dh).j = !0;
        return eh[a]
    };
    hh = function(a) {
        var b = a.document;
        return gh(a) ? b.URL : b.referrer
    };
    kh = function(a) {
        try {
            return ih(a, window.top)
        } catch (b) {
            return new _.jh(-12245933, -12245933)
        }
    };
    ph = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.lh(mh, a), a = new _.oh(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    rh = function(a, b) {
        for (var c = {}, d = _.y(_.v(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = b[e].clone(),
                g = _.lf(qh),
                h = g.j.get(e);
            null == h ? h = ++_.lf(Dg).F : g.j.delete(e);
            _.I(f, 20, h);
            c[e] = f
        }
        return {
            ba: a.clone(),
            Y: c
        }
    };
    th = function() {
        for (var a = "", b = _.y(sh()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    sh = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    Ah = function(a, b, c, d) {
        var e = uh(b, a) || vh(b, a);
        if (!e) return null;
        var f = kh(e),
            g = e === vh(b, a),
            h = wh(function() {
                var p = g ? vh(b, a) : e;
                return p && xh(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = $g(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min(null != (m = yh(k("padding-top"))) ? m : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min(null != (n = yh(k("padding-left"))) ? n : 0, d))
            }
        }
        return f && zh(e) ? f : new _.jh(-12245933, -12245933)
    };
    Bh = function(a, b, c, d) {
        var e = vh(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = Ah(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    Ch = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    Dh = function(a) {
        return Ch(a) + "__container__"
    };
    uh = function(a, b) {
        var c;
        return (null == (c = vh(a, b)) ? void 0 : c.querySelector('[id="' + Dh(a) + '"]')) || null
    };
    Eh = function(a, b) {
        var c, d;
        return null != (d = null == (c = uh(a, b)) ? void 0 : c.querySelector('iframe[id="' + Ch(a) + '"]')) ? d : null
    };
    vh = function(a, b) {
        b = void 0 === b ? document : b;
        return Fh().F.get(a) || b.getElementById(a.getDomId())
    };
    Gh = function(a) {
        return Math.round(Number(yh(a)))
    };
    Ih = function(a) {
        if (!_.G(Hh)) return !0;
        var b = a.parentElement;
        return !b || 1 >= b.children.length ? !1 : _.v(Array, "from").call(Array, b.children).some(function(c) {
            return c !== a && !(_.C = ["script", "style"], _.v(_.C, "includes")).call(_.C, c.tagName.toLowerCase())
        })
    };
    Kh = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.Jh(a, c), a = a.parentElement
    };
    Lh = function(a, b, c, d, e) {
        _.Jh(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.Jh(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.Jh(a, f)), !0) : !1
    };
    Nh = function(a, b, c, d, e, f, g, h, k, l) {
        window.setTimeout(function() {
            var m = ah(d);
            if (window.IntersectionObserver) {
                var n, p = null != (n = Eh(c, b)) ? n : vh(c, b);
                m = Mh(a, b, c, e, f, g, m, h, k, l, p);
                (new window.IntersectionObserver(m, {
                    threshold: .98
                })).observe(p)
            }
        }, 500)
    };
    Mh = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = _.rf(Oh);
        return Bg(a, 459, function(p, r) {
            (p = null == p ? void 0 : p[0]) && Ph(a, b, c, d, e, f, g, h, k, l, r, m, p, n)
        })
    };
    Ph = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        var u = p.boundingClientRect,
            w = p.intersectionRatio,
            A = window.innerWidth,
            F = u.left,
            B = u.right,
            E = 0 > F + 2,
            N = 0 < B - (A + 2);
        (.98 <= w || E || N) && Qh(k, function(Q) {
            m.unobserve(n);
            var P = E || N;
            var Y = new Rh;
            Sh(n, P) && Y.set(10);
            if (void 0 !== h && Ih(n)) {
                var ja, xa = null == (ja = vh(c, b)) ? void 0 : ja.parentElement,
                    ia;
                ja = xa ? null == (ia = xh(xa, window)) ? void 0 : ia.width : void 0;
                h !== ja && Y.set(16)
            }
            P ? (Y.set(8), P = Th(Y)) : P = Uh(b, c, w, Y);
            ia = Vh(c, n, f);
            Y = ia.Hi;
            ia = ia.Ii;
            Wh(Q, a);
            J(Q, "qid", l);
            J(Q, "iu", c.getAdUnitPath());
            J(Q, "e", String(P));
            E && J(Q, "ofl", String(F));
            N && J(Q, "ofr", String(B - A));
            J(Q, "ret", e + "x" + f);
            J(Q, "req", g);
            J(Q, "bm", String(d));
            J(Q, "efh", Number(Y));
            J(Q, "stk", Number(ia));
            J(Q, "ifi", Xh(window))
        }, r)
    };
    Uh = function(a, b, c, d) {
        var e = Eh(b, a) || vh(b, a);
        try {
            var f = e.getBoundingClientRect(),
                g = f.left,
                h = f.top,
                k = f.width,
                l = f.height,
                m = vh(b, a),
                n = xh(m, window);
            if ("hidden" === n.visibility || "none" === n.display) return Th(d);
            var p = Gh(n.getPropertyValue("border-top-width") || 0) + 1;
            b = g + k;
            f = h + l;
            c = (1 - c) * l;
            var r = a.elementsFromPoint(g + p + 2, h + c + p);
            var u = a.elementsFromPoint(b - p - 2, h + c + p);
            var w = a.elementsFromPoint(b - p - 2, f - c - p);
            var A = a.elementsFromPoint(g + p + 2, f - c - p);
            var F = a.elementsFromPoint(b / 2, f - c - p)
        } catch (E) {
            return d.set(1), Th(d)
        }
        if (!(r && r.length && u && u.length && w && w.length && A && A.length && F && F.length)) return d.set(7), Th(d);
        a = function(E, N) {
            for (var Q = !1, P = 0; P < E.length; P++) {
                var Y = E[P];
                if (Q) {
                    var ja = xh(Y, window);
                    if ("hidden" !== ja.visibility && !Yh(Y) && !B(e, Y)) {
                        d.set(N);
                        "absolute" === ja.position && d.set(11);
                        break
                    }
                } else e === Y && (Q = !0)
            }
        };
        Zh(e) && d.set(9);
        var B = function(E, N) {
            return $h(E, N) || $h(N, E)
        };
        g = r[0];
        e === g || B(e, g) || Yh(g) || d.set(2);
        g = u[0];
        e === g || B(e, g) || Yh(g) || d.set(3);
        g = w[0];
        e === g || B(e, g) || Yh(g) || d.set(4);
        g = A[0];
        e === g || B(e, g) || Yh(g) || d.set(5);
        if (Yh(e)) return Th(d);
        a(r, 12);
        a(u, 13);
        a(w, 14);
        a(A, 15);
        a(F, 6);
        return Th(d)
    };
    Sh = function(a, b) {
        var c = !1,
            d = !1;
        return ai(a, function(e, f) {
            d = d || "scroll" === e.overflowX || "auto" === e.overflowX;
            c = c || "flex" === e.display;
            return b && c && d || "listbox" === f.role
        })
    };
    Vh = function(a, b, c) {
        var d = (a = vh(a)) && xh(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        bi(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = ci(k, _.t, -1, -1);
                else {
                    l = l && l.height;
                    var m = (l && _.v(l, "endsWith").call(l, "px") ? Gh(l) : 0) >= c;
                    !l || m || "string" === typeof l && _.v(di, "includes").call(di, l) || (e = !1)
                }
            f || (k = xh(k, _.t), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            Hi: e,
            Ii: f
        }
    };
    ci = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.v(di, "includes").call(di, e.height) || (null == e ? 0 : e.maxHeight) && !_.v(ei, "includes").call(ei, e.maxHeight) || fi(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.v(di, "includes").call(di, g) || !!f && !_.v(ei, "includes").call(ei, f)
        }, c, d) ? !1 : !0
    };
    fi = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (E) {
                    if (15 == E.code) throw E.styleSheet = k, E;
                }
                h = l
            } catch (E) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var m = h[l],
                        n, p = c;
                    if (!(n = f.call(a, m.selectorText) && p(m))) a: {
                        var r = void 0;p = a;
                        var u = c,
                            w = e,
                            A = null != (r = m.cssRules) ? r : [];
                        for (r = 0; r < Math.min(A.length, w); r++) {
                            var F = A[r],
                                B = u;
                            if (f.call(p, F.selectorText) && B(F)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (E) {}
        }
        return !1
    };
    Yh = function(a) {
        return ai(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    Zh = function(a) {
        return ai(a, function(b) {
            var c;
            return (_.C = ["left", "right"], _.v(_.C, "includes")).call(_.C, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    gi = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    ii = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = hi.j();
        0 === e.j && (e.j = .001 > Math.random() ? 2 : 1);
        2 === e.j && (e = {}, We(_.v(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(_.Lg(window)), e.em = c, e.lid = b, e.eids = _.of().join(), e), d), "esp"))
    };
    ki = function(a, b) {
        return Oe(a, ji, 2).some(function(c) {
            return _.bh(c, 1) === b && null != _.bh(c, 2)
        })
    };
    li = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.x.Promise(function(c) {
            var d = function() {
                c(b());
                _.Be(a, "load", d)
            };
            _.ub(a, "load", d)
        })
    };
    mi = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    ri = function(a, b, c, d) {
        if (b)
            for (var e = _.y(mi(b)), f = e.next(), g = {}; !f.done; g = {
                    cc: g.cc
                }, f = e.next())
                if (g.cc = f.value, f = ni().get(g.cc, b).Yb) {
                    var h = oi(f);
                    if (2 !== h && 3 !== h) {
                        h = !1;
                        if (c) {
                            var k = /^(\d+)$/.exec(g.cc);
                            if (k && !(h = _.v(c.split(","), "includes").call(c.split(","), k[1]))) continue;
                            if (!h && !c.split(",").some(function(l) {
                                    return function(m) {
                                        var n;
                                        return null == d ? void 0 : null == (n = d.get(m)) ? void 0 : n.has(l.cc)
                                    }
                                }(g))) continue
                        }
                        pi(f, 9, h);
                        h = _.bh(f, 2);
                        qi(a, 2, ji, f);
                        f = {};
                        ii(19, g.cc, null, (f.hs = h ? "1" : "0", f))
                    }
                }
    };
    si = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    Ei = function(a, b, c, d, e) {
        var f, g, h, k, l, m, n, p, r, u, w, A, F;
        return _.wb(function(B) {
            return 1 == B.j ? (f = new ti, g = new ui(a, c, e), K(f, g), K(f, new vi(g.A, void 0, d, e)), h = new wi(g.m, e), K(f, h), k = new xi(h.m, e), K(f, k), l = new yi(b, k.m, e), K(f, l), K(f, new vi(l.A, void 0, d, e)), m = new zi(l.m, l.I, 300, 1E3, e), K(f, m), K(f, new vi(m.m, void 0, d, e)), n = new Ai(e), K(f, n), p = new Bi(n.C, k.A, e), K(f, p), r = new yi(b, p.m, e), K(f, r), u = new vi(r.m, void 0, d, e), K(f, u), Di(f), F = a, xb(B, m.m.promise, 2)) : B.return({
                id: F,
                collectorGeneratedData: null != (A = null == (w = B.o) ? void 0 : _.bh(w, 2)) ? A : null
            })
        })
    };
    Ki = function(a, b, c, d) {
        var e = {};
        e = void 0 === e ? Fi : e;
        Gi() !== Hi(window) ? ii(16, "") : Ii(a, "encryptedSignalProviders", c) && Ii(a, "secureSignalProviders", c) || (ii(38, ""), Ji(a, "encryptedSignalProviders", b, e, c, d), Ji(a, "secureSignalProviders", b, e, c, function() {}))
    };
    Ii = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Ji = function(a, b, c, d, e, f) {
        var g, h = new Li(null != (g = a[b]) ? g : [], c, "secureSignalProviders" === b, f, d);
        a[b] = new Mi(h);
        h.addErrorHandler(e)
    };
    Pi = function(a, b) {
        var c = new ti,
            d = new Ai(b);
        a = new Ni(d.C, a, b);
        Oi(c, [d, a]);
        Di(c)
    };
    Ti = function(a, b, c, d, e) {
        var f = b.toString();
        if (Qi.has(f)) return null;
        Qi.add(f);
        f = new ti;
        a = new ui(a, c, e);
        var g = new vi(a.A, c, d, e),
            h = new Ri(a.m, e),
            k = new wi(h.m, e);
        b = new Si(k.m, b, e);
        c = new vi(b.m, c, d, e);
        Oi(f, [a, g, h, k, b, c]);
        Di(f);
        return f
    };
    Ui = function(a, b) {
        /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = je(b), a.src = _.ib(b).toString())
    };
    Wi = function(a, b, c) {
        c = void 0 === c ? Vi : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.ub(a, "load", function() {
            return void c(a, b)
        }))
    };
    Xi = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    Yi = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    $i = function(a) {
        if (a === a.top || _.Zi(a.top)) return _.x.Promise.resolve({
            status: 4
        });
        var b = Xi(a);
        if (!b) return _.x.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && Yi(a.document.referrer)) return _.x.Promise.resolve({
            status: 3
        });
        var c = new _.Lf;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                Jd: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    dj = function(a, b) {
        var c = aj(a);
        return c.messageChannelSendRequestFn ? _.x.Promise.resolve(c.messageChannelSendRequestFn) : new _.x.Promise(function(d) {
            function e(k) {
                return h.j(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.Ae("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            b && (f.credentialless = !0);
            f.src = _.ib(bj).toString();
            var g = (new URL(bj.toString())).origin,
                h = cj({
                    destination: a,
                    eb: f,
                    origin: g,
                    mb: "goog:gRpYw:doubleclick"
                });
            h.j("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    kj = function(a, b, c, d) {
        var e = {
            skipTopicsObservation: _.G(ej),
            includeBuyerTopics: _.G(fj)
        };
        e = void 0 === e ? {} : e;
        var f = gj(d),
            g = f.Dd,
            h = f.Cd;
        b = aj(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics,
            sendPingToRCS: !1
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && wa(k, g)));
            else if (Ee()(k)) l || (l = k !== g);
            else return c.Gb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var m = new hj;
                var n = _.I(m, 2, _.ff());
                k instanceof Uint8Array ? ij(n, 1, jj, pc(k, !1, !1)) : ij(n, 3, jj, k);
                d.setItem("goog:cached:topics", Le(n))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = a);
        return g && !h ? _.x.Promise.resolve(g) : b.getTopicsPromise
    };
    gj = function(a) {
        if (!a) return {
            Dd: null,
            Cd: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                Dd: null,
                Cd: !0
            };
            var c = lj(b),
                d = mj(c, jj);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    var f, g = nj(c, oj(c, jj, 1));
                    Qb(Pb);
                    var h = g.na;
                    if (null == h || Ob(h)) var k = h;
                    else {
                        if ("string" === typeof h)
                            if (Hb) {
                                a = h;
                                pj.test(a) && (a = a.replace(pj, Lb));
                                var l = atob(a);
                                var m = new Uint8Array(l.length);
                                for (a = 0; a < l.length; a++) m[a] = l.charCodeAt(a);
                                var n = m
                            } else n = qj(h);
                        else n = null;
                        k = n
                    }
                    var p = k;
                    e = (f = null == p ? p : g.na = p) ? new Uint8Array(f) : rj || (rj = new Uint8Array(0));
                    break;
                case 3:
                    e = _.Qe(c, oj(c, jj, 3), 0);
                    break;
                default:
                    eb(d)
            }
            var r = _.ye(c, 2) + 6048E5 < _.ff();
            return {
                Dd: e,
                Cd: r
            }
        } catch (u) {
            return {
                Dd: null,
                Cd: !0
            }
        }
    };
    sj = function(a, b) {
        b = aj(b);
        b.setTopicsCalled ? _.x.Promise.resolve() : (b.setTopicsCalled = !0, a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: !1,
            sendPingToRCS: !1
        }))
    };
    aj = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    vj = function(a) {
        if (Ta()) {
            var b = a.document.documentElement.lang;
            tj(a) ? uj(_.Lg(a), !0, "", b) : (new MutationObserver(function(c, d) {
                tj(a) && (uj(_.Lg(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    tj = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    uj = function(a, b, c, d) {
        We({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    xj = function(a) {
        var b = "";
        wj(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    Aj = function(a, b) {
        var c = yj.get(a);
        c || (b = c = b(), zj.set(b, a), yj.set(a, b));
        return c
    };
    Cj = function(a, b) {
        return Aj(b, function() {
            return new Bj(a, b)
        })
    };
    L = function(a) {
        return function() {
            return new Dj(a, [].concat(_.se(_.sb.apply(0, arguments))))
        }
    };
    Ej = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Ej(b) : String(b)
        }).join(", ") + "]"
    };
    Fj = function(a, b) {
        b = Ej(b);
        b = b.substring(1, b.length - 1);
        return new Dj(96, [a, b])
    };
    Gj = function(a) {
        return (_.C = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable gameManualInterstitialSlotReady gameManualInterstitialSlotClosed".split(" "), _.v(_.C, "includes")).call(_.C, a) ? a : null
    };
    Ij = function(a, b, c) {
        return Aj(c, function() {
            return new Hj(a, b, c)
        })
    };
    Kj = function(a, b, c) {
        return Aj(c, function() {
            return new Jj(a, b, c)
        })
    };
    Lj = function() {
        var a;
        return null != (a = _.t.googletag) ? a : _.t.googletag = {
            cmd: []
        }
    };
    Oj = function(a) {
        var b = window;
        "complete" === _.t.document.readyState ? Hg(a, 94, function() {
            Lj()._pubconsole_disable_ || null !== Mj(b) && Nj(a, b)
        }) : _.ub(_.t, "load", Bg(a, 94, function() {
            Lj()._pubconsole_disable_ || null !== Mj(b) && Nj(a, b)
        }))
    };
    Nj = function(a, b) {
        b = void 0 === b ? _.t : b;
        if (!Pj) {
            var c = new Qj("gpt_pubconsole_loaded");
            Wh(c, a);
            J(c, "param", String(Mj(b)));
            J(c, "api", String(Rj));
            Sj(c);
            _.Tj(b.document, Uj);
            Pj = !0
        }
    };
    Mj = function(a) {
        var b = hh(a),
            c;
        return null != (c = (_.C = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.v(_.C, "find")).call(_.C, function(d) {
            return null !== Vj(b, d)
        })) ? c : null
    };
    Wj = function() {
        Lj()._pubconsole_disable_ = !0
    };
    Zj = function() {
        Xj && (Lj().console.openConsole(Yj), Yj = void 0, Xj = !1)
    };
    hk = function(a, b, c, d, e) {
        if ("string" !== typeof c || ak(c)) M(e, Fj("Slot.setTargeting", [c, d]), a);
        else {
            var f = [];
            Array.isArray(d) ? f = d : sa(d) ? f = _.v(Array, "from").call(Array, d) : d && (f = [d]);
            f = f.map(String);
            (d = (_.C = bk(b), _.v(_.C, "find")).call(_.C, function(g) {
                return _.bh(g, 1) === c
            })) ? dk(d, f): (d = dk(ek(new fk, c), f), qi(b, 9, fk, d));
            e.info(gk(c, f.join(), b.getAdUnitPath()), a)
        }
    };
    ik = function(a, b, c, d) {
        if (null != c && "object" === typeof c)
            for (var e = _.y(_.v(Object, "keys").call(Object, c)), f = e.next(); !f.done; f = e.next()) f = f.value, hk(a, b, f, c[f], d);
        else d.error(Fj("Slot.updateTargetingFromMap", [c]), a)
    };
    jk = function(a, b, c, d) {
        "string" === typeof a ? b.setClickUrl(a) : M(d, Fj("Slot.setClickUrl", [a]), c)
    };
    lk = function(a, b, c) {
        return Aj(c, function() {
            return new kk(a, b, c, c.j)
        })
    };
    mk = function(a) {
        return _.v(Object, "assign").call(Object, {}, a, _.v(Object, "fromEntries").call(Object, _.v(Object, "entries").call(Object, a).map(function(b) {
            b = _.y(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    qk = function() {
        var a = {},
            b = mk(nk);
        a.OutOfPageFormat = b;
        b = mk(ok);
        a.TrafficSource = b;
        b = mk(pk);
        a.Taxonomy = b;
        return a
    };
    rk = function(a, b) {
        var c = {};
        b = (c[0] = Bf(b.pvsid), c);
        return _.lf(mf).o(a, b)
    };
    tk = function(a, b) {
        var c;
        return null == (c = _.sk(a, "__gads", b)) ? void 0 : _.v(c.split(":"), "find").call(c.split(":"), function(d) {
            return 0 === d.indexOf("ID=")
        })
    };
    uk = function(a, b, c, d) {
        (c = tk(c, d)) ? (d = {}, b = (d[0] = Bf(b.pvsid), d[1] = Bf(c), d), _.lf(mf).o(a, b)) : rk(a, b)
    };
    wk = function() {
        for (var a = _.lf(qf).j(vk.j, vk.defaultValue) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Ak = function() {
        if (xk) return xk;
        for (var a = sf(yk), b = [], c = 0; c < a.length; c += 2) zk(a[c], a[c + 1], b);
        return xk = b.join("&")
    };
    Fk = function(a, b) {
        if (!b || !_.ha(b)) return null;
        var c = !1,
            d = new Bk;
        _.Ck(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? pi(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? pi(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? pi(d, 3, b.sandbox) : c = g = !0;
                    break;
                default:
                    g = !0
            }
            g && a.error(Dk("setSafeFrameConfig", Ek(b), f, Ek(e)))
        });
        return c ? null : d
    };
    Hk = function(a) {
        var b = new Bk;
        a = _.y(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) null != Gk(c, 1) && pi(b, 1, _.D(c, 1)), null != Gk(c, 2) && pi(b, 2, _.D(c, 2)), null != Gk(c, 3) && pi(b, 3, _.D(c, 3));
        return b
    };
    Jk = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = Ik.exec(null != (b = null == (a = _.fh(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    Kk = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    Lk = function(a, b) {
        var c = b.B;
        return a.map(function(d) {
            return _.v(c, "find").call(c, function(e) {
                return e.j === d
            })
        }).filter(Ge())
    };
    Mk = function(a, b, c) {
        var d = [];
        a = _.y(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            b.F = e;
            var f = rk(9, c);
            1 === f.length && (d.push(e), d.push(e + "-" + f[0]))
        }
        return d
    };
    Pk = function(a, b, c, d, e, f) {
        var g = Nk(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.Wa;
        if (!f || !g) return M(b, Fj("PubAdsService.definePassback", [d, e])), null;
        pi(g, 17, !0);
        c.slotAdded(f, g);
        return {
            Hg: lk(a, b, new Ok(a, f, c)),
            Wa: g
        }
    };
    Rk = function(a, b, c, d, e) {
        return Aj(c, function() {
            return new Qk(a, b, c, d, e)
        })
    };
    Tk = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(Sk) : "fluid" === a
    };
    Uk = function(a) {
        return Array.isArray(a) && 2 === a.length && Sk(a[0]) && Sk(a[1])
    };
    Wk = function(a) {
        return Array.isArray(a) ? Wg(Xg(new Sg, a[0]), a[1]) : Vk()
    };
    Yk = function(a) {
        var b = [];
        if (Xk(a)) b.push(Wk(a));
        else if (Array.isArray(a)) {
            a = _.y(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, Xk(c) ? b.push(Wk(c)) : wa(c, ["fluid"]) && b.push(Vk())
        }
        return b
    };
    Zk = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return Yk(a)
    };
    Xk = function(a) {
        return _.G($k) ? Array.isArray(a) && 2 === a.length ? a.every(al) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    qa = function(a, b) {
        a: {
            b = b[0];a = a[0];
            for (var c = _.oa, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.oa(b.length, a.length)
        }
        return b
    };
    bl = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.v(a, "includes").call(a, 0)
    };
    cl = function(a) {
        if (bl(a)) return {
            size: [],
            Bf: !0
        };
        if (Array.isArray(a) && 0 < a.length && "number" !== typeof a[0]) {
            var b = !1;
            a = a.filter(function(c) {
                c = bl(c);
                b = b || c;
                return !c
            });
            return {
                size: a,
                Bf: b
            }
        }
        return {
            size: a,
            Bf: !1
        }
    };
    fl = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new dl("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!Uk(b)) throw new dl("Size must be an array of two non-negative integers");
        b = Wg(Xg(new Sg, b[0]), b[1]);
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = Yk(a[1]), 0 === a.length) throw new dl("At least one slot size must be present");
        var c = new Vg;
        b = _.vg(c, 1, b);
        return _.el(b, 2, a)
    };
    gl = function(a, b) {
        if (!b) return [];
        var c = [];
        b = _.y((_.C = gd(b, 26), _.v(_.C, "values")).call(_.C));
        for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            try {
                c.push(JSON.parse(d))
            } catch (e) {
                Fg(a, 1023, e)
            }
        }
        return c
    };
    il = function(a, b, c) {
        return Aj(c, function() {
            return new hl(a, b, c)
        })
    };
    ql = function(a, b, c, d, e, f, g) {
        var h = new ti,
            k = new jl(a, g);
        K(h, k);
        e = new kl(a, d, e);
        K(h, e);
        e = new ll(a, b, d, f, k.Za);
        K(h, e);
        g = new ml(a, b, c, d, g, f, k.Za);
        K(h, g);
        if (_.G(nl)) {
            b = new ol(a, b, c, d, f, k.Za);
            K(h, b);
            var l = b.m
        }
        a = new pl(a, k.Za, g.m, e.m, l);
        K(h, a);
        Di(h);
        return {
            Za: a.C,
            Ma: h
        }
    };
    rl = function(a) {
        switch (Number(a)) {
            case 0:
                return "";
            case 1:
                return "Out-of-page creative";
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            case 7:
                return "Game Manual Interstitial";
            case 4:
                return "Rewarded";
            default:
                return ""
        }
    };
    sl = function(a) {
        if (!_.Zi(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    xl = function(a, b, c) {
        return new tl(a, b, ul, function(d) {
            d = d.detail;
            var e;
            return "asmreq" === (null == (e = d.data) ? void 0 : e.type) && vl(wl(d.data.payload), 1) === Number(c) ? d : null
        })
    };
    zl = function(a) {
        a = (_.Zi(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!yl(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    Al = function(a, b, c, d) {
        var e = _.Ae("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    Bl = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    Dl = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !Cl(b, c, d))) {
                    a: {
                        do {
                            var g = xh(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    El = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    Gl = function(a, b) {
        var c, d;
        return null != (d = null != (c = null == b ? void 0 : b.get(_.G(Fl) ? El(a) : a)) ? c : null == b ? void 0 : b.get(_.Af(a))) ? d : 0
    };
    Ml = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = _.y(e);
            g = a.next();
            for (f = {}; !g.done; f = {
                    xd: f.xd
                }, g = a.next()) {
                e = g.value;
                g = e.code;
                e = e.bids;
                var h = void 0;
                if (g && null != (h = e) && h.length && (g = Gl(g, b), f.xd = g / 1E6, !(0 >= g))) {
                    h = void 0;
                    e = _.y(null != (h = e) ? h : []);
                    var k = e.next();
                    for (h = {}; !k.done; h = {
                            rb: h.rb,
                            ue: h.ue
                        }, k = e.next()) k = k.value, h.ue = "function" === typeof k.getFloor ? k.getFloor : void 0, h.rb = Hl(Il(Jl(new Kl, 4), g), c), k.getFloor = function(l, m) {
                        return function(n) {
                            4 === _.Qe(l.rb, 1, 0) && Jl(l.rb, 1);
                            var p, r = null == (p = l.ue) ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.xd
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Qe(l.rb, 1, 0) && (n = Il(Jl(l.rb, 6), 1E6 * r.floor), Ll(n, 3, r.currency)), r) : (r.floor || 0) > m.xd ? (1 === _.Qe(l.rb, 1, 0) && Il(Jl(l.rb, 5), 1E6 * r.floor), r) : n : n
                        }
                    }(h, f), d.set(k.getFloor, h.rb)
                }
            }
        }
    };
    Nl = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return Lj().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    Pl = function(a, b) {
        return Aj(b, function() {
            return new Ol(a, b)
        })
    };
    bm = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(u) {
                        return (_.C = _.Sl(u, 2), _.v(_.C, "includes")).call(_.C, r)
                    })
                }), g.length)) {
                var m, n;
                f = null == (m = e.adUnits) ? void 0 : null == (n = _.v(m, "find").call(m, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : n.mediaTypes;
                m = _.y(g);
                for (n = m.next(); !n.done; n = m.next()) n = n.value, g = Tl(n, d, f), g = Ul(a, Vl(pi(Wl(Xl(new Yl, n.bidder), 1), 6, !0), g)), _.G(Zl) && $l(n.bidder, e, g), "number" === typeof n.timeToRespond && am(g, n.timeToRespond)
            }
        }
    };
    $l = function(a, b, c) {
        for (var d = []; a && !_.v(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.id(c, 10, d, _.Ec)
    };
    cm = function(a, b, c) {
        null != yc(Xd(a, 3)) || (c === b.getAdUnitPath() ? _.I(a, 3, 1) : c === b.getDomId() && _.I(a, 3, 2))
    };
    fm = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Qe(f, 1, 0)) && _.vg(b, 5, f);
        void 0 !== dm(a, Kl, 5, !1) || (f ? 1 === _.Qe(f, 1, 0) ? em(a, f) : em(a, Il(Jl(Hl(new Kl, e), 1), Gl(c, d))) : em(a, Jl(Hl(new Kl, e), Gl(c, d) ? 2 : 3)))
    };
    Tl = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            m = a.adUnitCode,
            n = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var u = new gm;
        "number" === typeof d && (_.I(u, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.ye(u, 2) || _.I(u, 8, d)));
        "string" === typeof f && Ll(u, 3, f);
        (_.C = ["string", "number"], _.v(_.C, "includes")).call(_.C, typeof h) && hm(u, im(new jm, String(h)));
        if ("object" === typeof k)
            for (b = _.v(Object, "fromEntries").call(Object, b.map(function(F) {
                    return [_.bh(F, 1), _.Sl(F, 2)]
                })), f = _.y(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.y(_.v(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.y(g.value);
                    var w = g.next().value;
                    g = g.next().value;
                    w = (w + h).slice(0, 20);
                    var A = void 0;
                    if (null != (A = b[w]) && A.length)
                        if (b[w][0] === String(g)) d.push(w);
                        else {
                            d = [];
                            break
                        }
                }
                km(u, _.Sl(u, 4).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.I(u, 5, 1);
                break;
            case "native":
                _.I(u, 5, 2);
                Qh("hbyg_nat", function(F) {
                    J(F, "pub_url", document.URL);
                    J(F, "b", l);
                    J(F, "auc", null != m ? m : "");
                    J(F, "hmt", Number(!!c));
                    var B;
                    J(F, "hat", Number(!!(null == c ? 0 : null == (B = c.native) ? 0 : B.adTemplate)))
                }, _.rf(lm));
                break;
            case "video":
                _.I(u, 5, 3)
        }
        "number" === typeof r && "number" === typeof a && u.setSize(mm(nm(a), r));
        "string" === typeof n && Ll(u, 1, n);
        return u
    };
    om = function(a, b) {
        var c = new _.x.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.y(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.se(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.y(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).pj = f)
            }
        }
        d = new _.x.Map;
        a = _.y(_.v(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.y(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.pj, g && h && d.set(f, {
            latency: h - g,
            xg: !1
        });
        e = _.y(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.xg = !0;
        return d
    };
    pm = function(a, b) {
        for (var c = new Rh, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return Th(c)
    };
    sm = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.Pc ? "" : c.Pc;
        c = void 0 === c.va ? "," : c.va;
        if (_.G(qm)) return rm(a, b);
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    rm = function(a, b) {
        return a.map(function(c) {
            return b(c)
        })
    };
    vm = function(a, b, c, d, e, f, g) {
        if (f) {
            var h = {
                    Hf: new tm
                },
                k = new ti;
            a = new um(a, b, c, d, e, f, g, h);
            K(k, a);
            Di(k);
            return {
                Kh: h,
                Ma: k
            }
        }
    };
    xm = function(a, b, c, d, e) {
        if (b && !(.01 < Math.random())) {
            var f = new ti;
            K(f, new wm(a, c, b.xb, d, e));
            Di(f)
        }
    };
    zm = function(a, b) {
        var c;
        return !(null != (c = ym(b, 22)) ? !c : !_.D(a, 15))
    };
    Am = function(a, b) {
        var c;
        return !(null != (c = ym(a, 11)) ? !c : !_.D(b, 10))
    };
    Bm = function(a, b, c, d) {
        if (a = vh(a, b)) {
            var e;
            if (c = null != (e = ym(c, 24)) ? e : _.D(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.t.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    Cm = function(a, b, c, d) {
        M(a, Dk("googletag.setConfig.commerce", Ek(b), c, Ek(d)))
    };
    Dm = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    Em = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    Im = function(a, b, c) {
        var d = window,
            e = new ti;
        d = new Fm(d);
        _.O(e, d);
        c = new Gm(a, d, c);
        K(e, c);
        a = new Hm(a, d, b, c.lc);
        K(e, a);
        Di(e);
        return {
            lc: c.lc,
            pg: a.m,
            Ma: e
        }
    };
    Jm = function(a) {
        if (61440 >= a.length) return {
            url: a,
            Sf: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            Sf: a.length - b.length + 8
        }
    };
    Km = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    Lm = function(a, b) {
        b = void 0 === b ? window : b;
        return !!Km(a, b)
    };
    Mm = function(a) {
        var b = "";
        a && 2012 < a && (b = "_fy" + a);
        return b
    };
    Pm = function(a, b) {
        var c = b.Y;
        return sm(a, function(d) {
            return Nm(c[d.getDomId()]).join("&")
        }, Om)
    };
    Nm = function(a) {
        a = Qm(a);
        var b = [];
        _.Ck(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    Qm = function(a) {
        for (var b = {}, c = _.y(bk(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[_.R(d, 1)] = _.Sl(d, 2);
        a = _.Sl(a, 8);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    Rm = function(a) {
        var b = !1,
            c = Oe(a, fk, 2).map(function(d) {
                var e = _.R(d, 1);
                b = "excl_cat" === e;
                d = _.Sl(d, 2);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.Sl(a, 3);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    Sm = function(a) {
        var b, c;
        return null != (c = null == (b = _.v(a, "find").call(a, function(d) {
            return "page_url" === _.bh(d, 1)
        })) ? void 0 : _.Sl(b, 2)[0]) ? c : null
    };
    Tm = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    Um = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        wj(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    Vm = function(a, b) {
        var c = b.Y;
        return !!Sm(b.ba.Ea()) || a.some(function(d) {
            return null !== Sm(c[d.getDomId()].Ea())
        })
    };
    Ym = function() {
        if (Va()) {
            var a = Xa();
            var b = 0;
            a = Wm(String(a)).split(".");
            for (var c = Wm("11").split("."), d = Math.max(a.length, c.length), e = 0; 0 == b && e < d; e++) {
                var f = a[e] || "",
                    g = c[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    b = Xm(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Xm(0 == f[2].length, 0 == g[2].length) || Xm(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == b)
            }
            b = 0 <= b
        } else b = 65 <= Za();
        return b
    };
    Zm = function(a, b) {
        var c = _.Ae("DIV");
        c.id = a;
        c.textContent = b;
        _.Jh(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    cn = function(a) {
        return null != $m(a, 1) ? null != an(a, 3) && 0 !== (0, _.bn)() ? $m(a, 1) * an(a, 3) : $m(a, 1) : null
    };
    dn = function(a, b) {
        if ("undefined" !== typeof IntersectionObserver) return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    fn = function(a, b, c, d, e) {
        var f = void 0 === f ? _.x.globalThis.IntersectionObserver : f;
        if (!b) return {
            cf: e
        };
        var g = cn(b);
        if (null == g) return {
            cf: e
        };
        b = new ti;
        a = new en(a, d, c, void 0, g, e, f);
        K(b, a);
        Di(b);
        return {
            cf: a.C,
            Ni: b
        }
    };
    hn = function(a, b, c, d) {
        for (var e = _.y(_.v(Object, "entries").call(Object, gn)), f = e.next(); !f.done; f = e.next()) {
            var g = _.y(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && M(a, g(c, d))
        }
    };
    nn = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && _.D(c, 5)) {
            c = c ? Ze(c) : null;
            var d = 0;
            try {
                d |= a != a.top ? 512 : 0;
                var e;
                if (!(e = !a.navigator)) {
                    var f = a.navigator;
                    e = "brave" in f && "isBrave" in f.brave || !1
                }
                d |= e || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                d |= cg(a, 2500);
                if (_.G(jn)) {
                    var g = _.kn(a).clientHeight;
                    d |= g ? 320 > g ? 2097152 : 0 : 1073741824
                }
                d |= dg(a);
                0 < b && !_.ln(_.mn(c, b)) && (d |= 134217728)
            } catch (h) {
                d |= 32
            }
            a = d
        } else a = 4194304;
        return a
    };
    rn = function(a, b, c, d, e, f) {
        d = on(d);
        if (5 !== d) return !1;
        var g = nn(e, !pn(c), f);
        if (g &= -134217729) Qh("gpt_int_ns", function(h) {
            J(h, "nsr", g);
            Wh(h, a)
        }, _.rf(qn)), hn(b, g, d, c.getAdUnitPath());
        return !!g
    };
    sn = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42;
            case 7:
                return 10
        }
    };
    vn = function(a, b) {
        a = sn(a);
        if (!a) return null;
        if (10 === a) return 0;
        var c = 0;
        if (!(_.C = [11, 10], _.v(_.C, "includes")).call(_.C, a)) {
            c |= _.t != _.t.top ? 512 : 0;
            var d = _.tn(_.t);
            d = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && d.adCount ? 1 == a || 2 == a ? !(!d.adCount[1] && !d.adCount[2]) : (d = d.adCount[a]) ? 1 <= d : !1 : !1;
            d && (c |= 64);
            if (c) return c
        }
        2 === a || 1 === a ? (b = {
            xa: _.t,
            Vd: _.un,
            Tf: b ? a : void 0
        }, 0 === (0, _.bn)() && (b.Vd = 3E3, b.gf = 650), c |= _.ig(b)) : 8 === a ? c |= nn(_.t) : 11 !== a && 42 !== a && (c |= 32);
        c || (b = _.tn(_.t), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return c
    };
    yn = function(a, b, c, d) {
        var e = d.gg,
            f = d.adUnitPath;
        d = void 0 === d.hb ? !1 : d.hb;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && wn(e)) ? xn(a, b, f, c, {
            Eb: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            hb: d
        }) : (b.error(Fj("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    wn = function(a) {
        switch (a) {
            case 6:
                return !0;
            case 7:
                return !0;
            default:
                return !!yl(nk, function(b) {
                    return b === a
                })
        }
    };
    xn = function(a, b, c, d, e) {
        var f = e.format;
        b = d.add(a, b, c, [1, 1], {
            Eb: e.Eb,
            format: f,
            hb: e.hb
        });
        a = b.slotId;
        b = b.Wa;
        a && b && (_.I(b, 15, f), _.zn(a, function() {
            var g = window,
                h = sn(f);
            if (h) {
                g = _.tn(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    In = function(a, b, c, d, e) {
        var f = window,
            g = new ti,
            h = K(g, new An(a, b, ul, function(m) {
                return Bn("i-adframe-load", m.detail.data)
            })),
            k = K(g, new An(a, b, ul, function(m) {
                return Bn("i-dismiss", m.detail.data)
            }));
        h = 0 < _.rf(Cn) ? K(g, new Dn(a, h.C, void 0)).C : h.C;
        h = K(g, new En(a, b, c, h));
        K(g, new Fn(a, f, d, e, h.C));
        if (f.top === f) var l = K(g, new Gn(a, f, h.C)).C;
        K(g, new Hn(a, b, c, h.C, k.C, l));
        return g
    };
    Bn = function(a, b) {
        try {
            var c = JSON.parse(b);
            return "sth" === c.googMsgType && c.msg_type === a
        } catch (d) {}
        return !1
    };
    Jn = function(a, b, c) {
        return new tl(c, a, ul, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    Mn = function(a, b, c) {
        if ("object" === typeof a && null !== a && _.v(Object, "keys").call(Object, a).some(function(d) {
                return (_.C = _.v(Object, "values").call(Object, Kn), _.v(_.C, "includes")).call(_.C, Number(d))
            })) return !0;
        Ln("taxonomies", a, b, c);
        return !1
    };
    On = function(a, b) {
        var c = Oe(b, Nn, 1).filter(function(d) {
            return _.Qe(d, 1, 0) !== a
        });
        _.el(b, 1, c)
    };
    Vn = function(a, b, c, d) {
        if (void 0 !== _.v(b, "values"))
            if (null === _.v(b, "values")) On(a, c);
            else if (Pn(_.v(b, "values"), d, b) && (b = Qn(a, _.v(b, "values"), d, b), b.length)) {
            var e = (_.C = Oe(c, Nn, 1), _.v(_.C, "find")).call(_.C, function(f) {
                return _.Qe(f, 1, 0) === a
            });
            e ? Rn(e, b) : Sn(c, Rn(Tn(new Nn, a), b));
            d.info(Un(Ek(b), Ek(a)))
        }
    };
    Pn = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        Ln("taxonomyData.values", a, b, c);
        return !1
    };
    Qn = function(a, b, c, d) {
        var e = [],
            f = [],
            g = !1;
        b = _.y(b);
        for (var h = b.next(); !h.done; h = b.next()) h = h.value, 5 <= e.length && (g = !0), "string" !== typeof h ? f.push(h) : g || h in e || e.push(h);
        0 < f.length && Ln("taxonomyData.values", f, c, d);
        g && M(c, Wn(Ek(a), Ek(5)));
        return e
    };
    Ln = function(a, b, c, d) {
        M(c, Dk("googletag.setConfig.pps", Ek(d), a, Ek(b)))
    };
    Yn = function(a, b, c) {
        if (b) {
            var d = {
                    wf: new tm
                },
                e = new ti;
            K(e, new Xn(a, b, c, d));
            Di(e);
            return {
                Ma: e,
                ge: d
            }
        }
    };
    Zn = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.v(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    ao = function(a, b) {
        var c = _.rf($n);
        Math.random() <= c && We(b, a)
    };
    ho = function(a, b, c) {
        var d = {};
        if (!c) return b.error(bo("missing data-rendering attribute")), d;
        try {
            var e = co(eo(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : void 0 !== dm(f, fo, 1, !1)) ? (b = new go, b = _.ld(b, 4, 1, 0), b = _.ld(b, 2, 7, 0), a = _.tg(b, 3, a.wb || a.nb), b = _.Rg(e, fo, 1), a = _.vg(a, 5, b), a = _.qd(a, 6, !0), d.wj = a) : b.error(bo("invalid data-rendering attribute"));
        var g;
        d.nj = null == (g = e) ? void 0 : _.R(g, 2);
        var h;
        d.Ce = null == (h = e) ? void 0 : _.R(h, 3);
        return d
    };
    ko = function(a, b) {
        var c = Vj(b, "ai");
        if (!c || 0 === c.length) return _.x.Promise.resolve(b);
        var d = io();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.x.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.Lf;
                var g = e.resolve;
                e = e.promise;
                jo(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Bg(a, h, k)
                });
                return e
            }
        }
        return _.x.Promise.resolve(b)
    };
    lo = function(a, b, c, d) {
        var e, f, g;
        return _.wb(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            var k = d.replace;
            var l = (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f);
            var m = [];
            for (n in l) zk(n, l[n], m);
            l = m.join("&");
            if (l) {
                m = -1;
                0 > m && (m = 0);
                var n = -1;
                if (0 > n || n > m) {
                    n = m;
                    var p = ""
                } else p = "".substring(n + 1, m);
                m = ["".slice(0, n), p, "".slice(m)];
                n = m[1];
                m[1] = l ? n ? n + "&" + l : l : n;
                l = m[0] + (m[1] ? "?" + m[1] : "") + m[2]
            } else l = "";
            g = k.call(d, "?", l + "&");
            return h.return(ko(a, g))
        })
    };
    mo = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.x.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.Lf;
                var g = d.resolve;
                d = d.promise;
                jo(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Bg(a, h, k)
                });
                return d
            }
        }
        return _.x.Promise.resolve(b)
    };
    so = function(a, b) {
        var c = window;
        var d = void 0 === d ? Db : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = io(),
                g;
            null == (g = f ? new no(function(k, l) {
                return Bg(a, k, l)
            }, function() {}) : void 0) || oo(g);
            var h = Zn(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.S(e, h);
            e.prototype.connectedCallback = function() {
                var k = ho(a, b, this.dataset.rendering),
                    l = k.wj,
                    m = k.nj;
                k = k.Ce;
                l && d(po(window, l));
                m && mo(a, m, f).then(function(n) {
                    return void qo(n)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Ce = k, this.addEventListener("click", this.j)) : M(b, ro(k)))
            };
            e.prototype.j = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && lo(a, this, k, this.Ce).then(function(m) {
                    return void qo(m)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    uo = function(a) {
        to = a
    };
    wo = function(a, b, c, d) {
        Ki(b, d, function(e, f) {
            Fg(a, e, f);
            var g, h;
            null == (h = (g = window.console).error) || h.call(g, f)
        }, function() {
            return void M(c, vo())
        })
    };
    yo = function(a, b, c, d) {
        if (c) {
            var e = {
                    Ac: new tm,
                    me: new tm,
                    oe: new tm
                },
                f = new ti;
            K(f, new xo(a, b, c, d, e));
            Di(f);
            return {
                Ma: f,
                Aj: e
            }
        }
    };
    Ao = function(a, b, c) {
        var d = window;
        if (_.G(ej) && b) {
            var e = new ti;
            K(e, new zo(a, d, b, c));
            Di(e);
            return e
        }
    };
    Co = function(a, b, c, d) {
        if (b) {
            var e = b.Ib,
                f = b.mj;
            if (b.hh && 4 === e) {
                b = new tm;
                e = new tm;
                if (!f) return b.H({
                    kind: 1,
                    reason: 1
                }), e.H(!1), {
                    jh: {
                        Mg: b,
                        tg: e
                    }
                };
                f = new ti;
                a = new Bo(a, c, d, b, e);
                K(f, a);
                Di(f);
                return {
                    jh: {
                        Mg: b,
                        tg: e
                    },
                    Fj: f
                }
            }
        }
    };
    Do = function(a) {
        var b = a.He,
            c = a.Ab,
            d = void 0 === a.Vf ? [] : a.Vf,
            e = a.gj ? b.resolveToConfig.promise : void 0,
            f;
        a = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            trustedScoringSignalsUrl: "https://securepubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != (f = a.interestGroupBuyers) ? f : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: 0,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.j.promise,
            sellerTimeout: 50,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise,
            perBuyerCumulativeTimeouts: b.perBuyerCumulativeTimeouts.promise,
            directFromSellerSignals: b.directFromSellerSignals.promise
        };
        return {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: 0,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            perBuyerCumulativeTimeouts: {},
            componentAuctions: [a].concat(_.se(d)),
            directFromSellerSignals: b.directFromSellerSignals.promise,
            resolveToConfig: e
        }
    };
    Eo = function(a, b) {
        b = b.He;
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        b.directFromSellerSignals.resolve(a.directFromSellerSignals);
        b.resolveToConfig.resolve(!!a.resolveToConfig);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.v(c, "find").call(c, function(f) {
                return (_.C = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.v(_.C, "includes")).call(_.C, f.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.j.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {});
            var e;
            b.perBuyerCumulativeTimeouts.resolve(null != (e = a.perBuyerCumulativeTimeouts) ? e : {})
        } else b.auctionSignals.resolve(void 0), b.j.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({}), b.perBuyerCumulativeTimeouts.resolve({})
    };
    Lo = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r;
        return _.wb(function(u) {
            if (1 == u.j) return ("string" !== typeof a || _.v(a, "startsWith").call(a, "urn:")) && Fo.deprecatedURNToURL && Fo.deprecatedReplaceInURN ? xb(u, Fo.deprecatedURNToURL(a), 2) : u.return();
            c = u.o;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(Go)) ? f : []).forEach(function(w) {
                d[w] = e
            });
            g = b.vi || "";
            (null != (h = c.match(Ho)) ? h : []).forEach(function(w) {
                d[w] = g
            });
            k = b.Hh || "";
            (null != (l = c.match(Io)) ? l : []).forEach(function(w) {
                d[w] = k
            });
            m = b.Fh || "";
            (null != (n = c.match(Jo)) ? n : []).forEach(function(w) {
                d[w] = m
            });
            p = b.Eh || "";
            (null != (r = c.match(Ko)) ? r : []).forEach(function(w) {
                d[w] = p
            });
            return xb(u, Fo.deprecatedReplaceInURN(a, d), 0)
        })
    };
    Mo = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.D(c, 18),
            f = _.D(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.R(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.D(c, 4) && (d += "&is_plog=1");
        (e = _.R(c, 11)) && (d += "&ecrs=" + e);
        (null == c ? 0 : _.D(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        qo(d)
    };
    No = function() {
        return new _.x.Promise(function(a) {
            setTimeout(function() {
                a(null)
            }, 0)
        })
    };
    Oo = function(a, b) {
        var c = b.getEscapedQemQueryId(),
            d = _.R(b, 6);
        Qh("pre_run_ad_auction_ping", function(e) {
            Wh(e, a);
            J(e, "winner_qid", null != c ? c : "");
            J(e, "xfpQid", null != d ? d : "");
            J(e, "publisher_tag", "gpt")
        }, 1)
    };
    Ro = function(a, b, c, d, e, f) {
        var g = 3 === b,
            h = 2 === b,
            k = 1 === b,
            l = _.G(Po) ? Qo(b) : "string" === typeof b,
            m = f.getEscapedQemQueryId(),
            n = _.R(f, 6);
        Qh("run_ad_auction_stats", function(p) {
            Wh(p, a);
            J(p, "duration_ms", c);
            J(p, "applied_timeout_ms", d);
            J(p, "timed_out", h ? 1 : 0);
            J(p, "error", g ? 1 : 0);
            J(p, "auction_skipped", k ? 1 : 0);
            J(p, "auction_winner", l ? 1 : 0);
            J(p, "thread_release_only", _.D(f, 15) ? 1 : 0);
            J(p, "winner_qid", null != m ? m : "");
            J(p, "xfpQid", null != n ? n : "");
            J(p, "publisher_tag", "gpt");
            e && J(p, "parallel", "1")
        }, 1)
    };
    So = function(a, b, c, d, e) {
        var f = e.getEscapedQemQueryId(),
            g = _.R(e, 6);
        Qh("run_ad_auction_complete", function(h) {
            Wh(h, a);
            J(h, "duration_ms", Math.round(performance.now() - d));
            J(h, "applied_timeout_ms", c);
            J(h, "auction_has_winner", !!b);
            f && J(h, "winner_qid", f);
            g && J(h, "xfpQid", g)
        }, 1)
    };
    Qo = function(a) {
        return "string" === typeof a || ("function" === typeof FencedFrameConfig ? a instanceof FencedFrameConfig : !1)
    };
    To = function(a) {
        return "gads_privacy_sandbox_td_buyerlist__" + a
    };
    Uo = function(a, b) {
        return a.filter(function(c) {
            return sd(Xd(c, 2), 0) > b
        })
    };
    Wo = function(a, b) {
        a = new _.x.Map(a.map(function(e) {
            return [_.R(e, 1), e]
        }));
        b = _.y(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = a.get(_.R(c, 1));
            d ? Vo(d, Math.max(sd(Xd(c, 2), 0), sd(Xd(d, 2), 0))) : a.set(_.R(c, 1), c)
        }
        return _.v(Array, "from").call(Array, _.v(a, "values").call(a))
    };
    $o = function(a, b) {
        var c = Date.now();
        if (Xo(a, b)) return new _.x.Map;
        b = new _.x.Map(_.v(Object, "entries").call(Object, a).filter(function(k) {
            var l = _.y(k);
            k = l.next().value;
            l = l.next().value;
            return _.v(k, "startsWith").call(k, "gads_privacy_sandbox_td_buyerlist__") && l
        }).map(function(k) {
            var l = _.y(k);
            k = l.next().value;
            l = l.next().value;
            return [k, Yo(l)]
        }));
        for (var d = _.y(b), e = d.next(); !e.done; e = d.next()) {
            var f = _.y(e.value);
            e = f.next().value;
            f = f.next().value;
            var g = Oe(f, Zo, 1),
                h = Uo(g, c);
            0 === h.length ? (b.delete(e), a.removeItem(e)) : h.length < g.length && (_.el(f, 1, h), a.setItem(e, Le(f)))
        }
        return b
    };
    Xo = function(a, b) {
        if (!_.D(b, 3)) return !1;
        b = String(_.Af(_.R(b, 2) + _.R(b, 4) + _.D(b, 3)));
        if (a.getItem("gads_privacy_sandbox_tcf_hash") === b) return !1;
        for (var c = _.y(_.v(Object, "keys").call(Object, a).filter(function(e) {
                return _.v(e, "startsWith").call(e, "gads_privacy_sandbox_td_buyerlist__")
            })), d = c.next(); !d.done; d = c.next()) a.removeItem(d.value);
        a.setItem("gads_privacy_sandbox_tcf_hash", b);
        return !0
    };
    ap = function(a) {
        var b = Date.now() + 864E5;
        return a.map(function(c) {
            var d = new Zo;
            c = _.tg(d, 1, c);
            return Vo(c, b)
        })
    };
    gp = function(a, b, c, d) {
        var e = vh(a, document);
        e && Wf(e, window, d, !0);
        bp(_.lf(Dg), "5", vl(c.Y[a.getDomId()], 20));
        cp(a, dp, 801, {
            bg: null,
            isBackfill: !1
        });
        if (_.ep(b, a) && !Eh(a, document)) {
            b = c.ba;
            c = c.Y[a.getDomId()];
            var f;
            (null != (f = ym(c, 10)) ? f : _.D(b, 11)) && Bm(a, document, c, b)
        }
        cp(a, fp, 825, {
            isEmpty: !0
        })
    };
    lp = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A) {
        if (hp.runAdAuction && pf("run-ad-auction", document) && !_.G(ip) && w) {
            w = {
                xf: new jp,
                Da: new tm,
                Db: new tm
            };
            var F = new ti;
            K(F, new kp(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A));
            Di(F);
            return {
                Ma: F,
                Gj: w
            }
        }
    };
    np = function(a, b, c, d, e, f, g) {
        if (b) {
            var h = b.Ib;
            if (b.hh && 0 !== h) return b = new ti, a = new mp(a, h, c, d, e, f, g), K(b, a), Di(b), {
                Ej: a.m,
                Dj: b
            }
        }
    };
    op = function() {
        for (var a = _.y(_.v(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (Ia(d, "/tag/js/gpt.js") || Ia(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), b = new _.oe(b.textContent, pe), hb(c, b), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    pp = function(a, b) {
        b = _.y(_.v(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.y(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    sp = function(a, b, c) {
        var d = [];
        c = [].concat(_.se(c.ga)).slice();
        if (b) {
            if (!Array.isArray(b)) return M(a, Fj("googletag.destroySlots", [b])), !1;
            ma(b);
            d = c.filter(function(e) {
                return _.v(b, "includes").call(b, e.j)
            })
        } else d = c;
        if (!d.length) return !1;
        qp(d);
        rp(d);
        return !0
    };
    Jp = function(a, b, c, d, e, f, g, h, k, l) {
        var m = Lj(),
            n, p, r = H(a, 74, function(w, A, F) {
                return e.defineSlot(a, b, w, A, F)
            }),
            u = {};
        r = (u._loaded_ = !0, u.cmd = [], u._vars_ = m._vars_, u.evalScripts = function() {
            try {
                op()
            } catch (F) {
                Fg(a, 297, F);
                var w, A;
                null == (w = window.console) || null == (A = w.error) || A.call(w, F)
            }
        }, u.display = H(a, 95, function(w) {
            void tp(c, w, e)
        }), u.defineOutOfPageSlot = H(a, 73, function(w, A) {
            return (w = yn(a, b, e, {
                gg: A,
                adUnitPath: w
            })) ? w.j : null
        }), u.getVersion = H(a, 946, function() {
            return a.Ub ? String(a.Ub) : a.nb
        }), u.pubads = H(a, 947, function() {
            return Rk(a, b, c, e, h)
        }), u.companionAds = H(a, 816, function() {
            null != n || (n = new up(a, b, c, f));
            return Ij(a, b, n)
        }), u.content = H(a, 817, function() {
            null != p || (p = new vp(a, b, g));
            return Kj(a, b, p)
        }), u.setAdIframeTitle = H(a, 729, uo), u.getEventLog = H(a, 945, function() {
            return new wp(a, b)
        }), u.sizeMapping = H(a, 90, function() {
            return new xp(a, b)
        }), u.enableServices = H(a, 91, function() {
            for (var w = _.y(yp), A = w.next(); !A.done; A = w.next()) A = A.value, A.o && b.info(zp()), Ap(A)
        }), u.destroySlots = H(a, 75, function(w) {
            return sp(b, w, e)
        }), u.enums = qk(), u.defineSlot = r, u.defineUnit = r, u.getWindowsThatCanCommunicateWithHostpageLibrary = H(a, 955, function(w) {
            return Bp(k, w).map(function(A) {
                var F;
                return null == (F = Eh(A, document)) ? void 0 : F.contentWindow
            }).filter(function(A) {
                return !!A
            })
        }), u.disablePublisherConsole = H(a, 93, Wj), u.onPubConsoleJsLoad = H(a, 731, Zj), u.openConsole = H(a, 732, function(w) {
            Rj = !0;
            var A;
            (null == (A = Lj()) ? 0 : A.console) ? Lj().console.openConsole(w): (w && (Yj = w), Xj = !0, Nj(a))
        }), u.setConfig = H(a, 1034, function(w) {
            if (_.ha(w)) {
                var A = w.commerce,
                    F = w.pps;
                if (null === A) Cp(Dp(d, Ep, 33), 1);
                else if (void 0 !== A)
                    if (w = Dp(d, Ep, 33), _.ha(A)) {
                        var B = A.query,
                            E = A.categories,
                            N = A.productIds,
                            Q = A.filter,
                            P = Fp(w, Gp, 1).clone();
                        null === B ? Cp(P, 1) : Dm(B) ? Ll(P, 1, B) : void 0 !== B && Cm(b, A, "query", B);
                        null === E ? Cp(P, 2) : Em(E) ? _.id(P, 2, E, _.Ec) : void 0 !== E && Cm(b, A, "categories", E);
                        null === N ? Cp(P, 3) : Em(N) ? _.id(P, 3, N, _.Ec) : void 0 !== N && Cm(b, A, "productIds", N);
                        null === Q ? Cp(P, 4) : Dm(Q) ? Ll(P, 4, Q) : void 0 !== Q && Cm(b, A, "filter", Q);
                        null != _.bh(P, 1) || _.Sl(P, 2).length ? _.vg(w, 1, P) : M(b, Hp())
                    } else M(b, Fj("googletag.setConfig.commerce", [A]));
                if (null === F) Cp(Dp(d, Ep, 33), 2);
                else if (void 0 !== F && (A = Dp(Dp(d, Ep, 33), Ip, 2), "object" === typeof F && F.hasOwnProperty("taxonomies") ? w = !0 : (M(b, Fj("googletag.setConfig.pps", [F])), w = !1), w))
                    if (w = F.taxonomies, void 0 === w) Ln("taxonomies", w, b, F);
                    else if (null === w) Cp(A, 1);
                else if (Mn(w, b, F))
                    for (F = _.y(_.v(Object, "entries").call(Object, w)), B = F.next(); !B.done; B = F.next()) {
                        B = _.y(B.value);
                        var Y = B.next().value;
                        B = B.next().value;
                        E = A;
                        N = b;
                        P = w;
                        if (void 0 === Y || null === Y) Ln("taxonomy", Y, N, P);
                        else {
                            Q = Number(Y);
                            var ja = Q,
                                xa = N,
                                ia = P;
                            (_.C = _.v(Object, "values").call(Object, pk), _.v(_.C, "includes")).call(_.C, Number(ja)) ? Y = !0 : (Ln("taxonomy", Y, xa, ia), Y = !1);
                            Y && void 0 !== B && (null === B ? On(Q, E) : (Y = N, "object" === typeof B && B.hasOwnProperty("values") ? P = !0 : (Ln("taxonomyData", B, Y, P), P = !1), P && Vn(Q, B, E, N)))
                        }
                    }
            } else M(b, Fj("googletag.setConfig", [w]))
        }), u.apiReady = !0, u);
        wo(a, m, b, l);
        pp(m, r)
    };
    Lp = function() {
        var a = void 0 === a ? window : a;
        Kp = _.ff(a)
    };
    Tp = function(a) {
        var b = window,
            c = new ti,
            d = new Mp(a, b);
        d = K(c, d).C;
        var e = "function" !== typeof b.document.browsingTopics;
        var f = !pf("browsing-topics", b.document);
        e = e || f;
        pf("shared-storage", b.document) || !e ? (e = {
            Zb: new tm
        }, f = new ti, K(f, new Np(a, b, e.Zb, d)), Di(f)) : e = void 0;
        f = new ti;
        var g = new Op(a, b);
        K(f, g);
        Di(f);
        f = {
            Zi: g.m
        };
        _.G(Pp) && K(c, new Qp(a, b));
        if (Ta()) {
            g = {
                Ig: new tm
            };
            var h = new ti;
            K(h, new Rp(a, window, g.Ig));
            Di(h);
            a = g
        } else a = void 0;
        g = b.navigator;
        h = b.document;
        b = _.G(ip);
        h = !!g.runAdAuction && pf("run-ad-auction", h);
        b = !b && h;
        h = _.rf(Sp);
        b = {
            hh: b,
            Ib: h,
            mj: !!g.getInterestGroupAdAuctionData
        };
        Di(c);
        return {
            Yi: f,
            fj: a,
            ne: e,
            Vh: d,
            Cj: b
        }
    };
    Up = function(a) {
        .001 > _.Te() && We({
            c: "sd",
            s: String(a)
        }, "gpt_whirs")
    };
    Vp = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    Pq = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B) {
        var E = new ti,
            N = Zg(!0, window),
            Q = k.ba,
            P = k.Y[e.getDomId()],
            Y = B.ne,
            ja = B.Vh,
            xa = new Wp(a, window);
        K(E, xa);
        var ia = m.zi,
            na = m.Lj,
            ta = m.li,
            Oa = m.tb,
            va = m.Jh,
            Ua = m.Ei,
            Pa = m.se,
            rc = m.ti,
            Hd = m.Te,
            nh = m.Bd,
            $b = m.Jj,
            ck = m.Di,
            af = m.Mi,
            bf = m.Lf,
            Xf = m.Ai,
            Yf = m.ei,
            sc = m.Da,
            Id = m.ih;
        B = m.kd;
        var Zf = m.Ph,
            jd = new tm;
        jd.H(p);
        var tc = new Xp(a, window.top, jd);
        K(E, tc);
        var $f = new Yp(a, on(P), N.height, Hd, ia);
        K(E, $f);
        var Lc = new Zp(a, e, vh(e, n), e.getDomId(), Dh(e), n.documentElement, on(P), h, f);
        $p(E, Lc);
        m = new tm;
        m.Oa(Lc.o.promise.then(function(me) {
            return me.C
        }));
        Lc = new aq(a, sc, va, Ua, Pa);
        K(E, Lc);
        sc = new bq(a, _.Rg(Q, cq, 5));
        K(E, sc);
        ia = new dq(a, window.location.hash, N.width, na, ia, m);
        K(E, ia);
        na = new eq(a, e.getAdUnitPath(), P, f, nh, na, $f.C, ia.D, ia.A, Lc.C, m);
        K(E, na);
        Pa = new fq(a, Q, P, va, Pa, na.I);
        K(E, Pa);
        if (_.G(gq)) {
            var Mb = lp(a, e, tc.C, P, h, p, f, na.Da, na.m, m, r, k, F, Oa, Id, g, u);
            if (Mb) {
                _.O(E, Mb.Ma);
                var bb = Mb.Gj
            }
        } else 2 === _.rf(Sp) && (bb = new hq(a, e.getAdUnitPath(), void 0, void 0, tc.C, Id), K(E, bb)), bb = new iq(a, P, void 0, u, Id), K(E, bb), bb = new jq(a, h, p, f, void 0, void 0, void 0, bb.C, m, r, void 0, void 0, Id, na.Da, na.m), K(E, bb), g && (Mb = new kq(a, e, k, h, Oa, bb.D), K(E, Mb), F = new lq(a, F, bb.D), K(E, F), Mb = new mq(a, Mb.m, F.C), K(E, Mb), Mb = Mb.C), F = new An(a, e, fp), K(E, F), F = new nq(a, bb.m, F.C), K(E, F), K(E, new oq(a, window.document, void 0, F.C, Id)), bb = {
            xf: Mb,
            Da: bb.Da,
            Db: bb.Db
        };
        var kd, ne;
        Mb = null != (ne = null == (kd = bb) ? void 0 : kd.Da) ? ne : na.Da;
        var Vb, ac;
        kd = null != (ac = null == (Vb = bb) ? void 0 : Vb.Db) ? ac : na.m;
        var bc;
        Vb = null == (bc = bb) ? void 0 : bc.xf;
        bc = new pq(a, e, Q, P, on(P), n, h, m, Pa.C, kd, ta, Vb);
        K(E, bc);
        ac = new qq(a, bc.C);
        K(E, ac);
        ne = new rq(a, e, N, h, ac.C, sc.m, Vb);
        K(E, ne);
        ac = new sq(a, window, m);
        K(E, ac);
        sc = new tq(a, ne.C, bc.C, sc.m, Vb);
        K(E, sc);
        N = new uq(a, n, e, P, N, ta, m, bc.C, kd, na.Bd, ac.C, Oa, Vb);
        K(E, N);
        $b = new vq(a, Q, P, Mb, Pa.C, $b);
        K(E, $b);
        Yf = new wq(a, window, Yf, xa.C, Vb);
        K(E, Yf);
        ac = new xq(a, on(P), n);
        K(E, ac);
        A = new yq(a, A, on(P), Hd, rc, Vb);
        K(E, A);
        af = new zq(a, af, Vb);
        K(E, af);
        _.G(Aq) ? (Y = Ao(a, Y, Zf)) && _.O(E, Y) : _.G(ej) && (null == Y ? 0 : Y.Zb) && (Y = new Bq(a, window, void 0, Y.Zb, Zf), K(E, Y));
        l = new Cq(a, e, h, k, w, l, window, Mb, Pa.C, sc.C, m, bc.C, kd, Oa, ta, $b.C, Ua, ck, bf, N.C, Yf.C, ac.C, A.C, Id, ja, Vb);
        K(E, l);
        ja = new Dq(a, window, e, l.A, jd);
        K(E, ja);
        switch (on(P)) {
            case 2:
            case 3:
                _.G(Eq) ? K(E, new Fq(a, h, on(P), e, window, Hd, l.m, m, A.C, kd)) : K(E, new Gq(a, h, on(P), e, window, Hd, l.m, m, A.C, kd));
                break;
            case 5:
                K(E, new Hq(a, e, k.Dc, window, rc, l.m, m, tc.C, A.C, Oa));
                break;
            case 4:
                k = new Iq(a, e, w, window, l.m, m);
                _.O(E, k);
                Di(k);
                break;
            case 7:
                $p(E, In(a, e, w, l.m, m))
        }
        n = new Jq(a, e, l.m, n, w);
        K(E, n);
        n = xl(a, e, Kq(h, e));
        K(E, n);
        h = new Lq(a, Kq(h, e), window.top, l.m, xa.C, n.C);
        K(E, h);
        K(E, new Mq(a, e, ta, va, bf, l.m, bc.C, l.D));
        e = new Nq(a, window, Xf, l.m, bc.C, m);
        K(E, e);
        K(E, new Oq(a, Lj(), Q, b, c, d, B));
        return E
    };
    Sq = function(a, b, c) {
        var d = null;
        try {
            var e = Qq(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.ba,
                    h = c.Y[f.getDomId()],
                    k;
                f = null == (k = Bh(f, h, b.document, zm(g, h))) ? void 0 : k.y;
                k = Zg(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++Rq
            })
        } catch (f) {}
        return d
    };
    $q = function(a) {
        return Hg(a.la.context, 1132, function() {
            if (a.ma.ga.length) {
                var b = new _.x.Set(sf(Tq));
                for (var c = _.y(_.D(a.la.ca, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id adsid".split(" ") : []), d = c.next(); !d.done; d = c.next()) b.add(d.value);
                d = new _.x.Map;
                c = _.y(Uq);
                for (var e = c.next(); !e.done; e = c.next()) e = e.value, e(a, d);
                c = "https://" + (Vq(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
                d = _.y(d);
                for (e = d.next(); !e.done; e = d.next()) {
                    var f = _.y(e.value);
                    e = f.next().value;
                    var g = f.next().value;
                    f = g.value;
                    g = void 0 === g.options ? {} : g.options;
                    (new RegExp("[?&]" + e + "=")).test(c);
                    if (!b.has(e) && null != f) {
                        var h = void 0 === g.va ? "," : g.va,
                            k = void 0 === g.ya ? !1 : g.ya,
                            l = void 0 === g.vb ? !1 : g.vb;
                        if (f = "object" !== typeof f ? null == f || !k && 0 === f ? null : encodeURIComponent(f) : Array.isArray(f) && f.length ? _.G(qm) && l || _.G(Wq) ? Xq(f, g) : encodeURIComponent(f.join(h)) : null) "?" !== c[c.length - 1] && (c += "&"), c += e + "=" + f
                    }
                }
                if (1 === _.rf(Yq) || 2 === _.rf(Yq)) b = _.rf(Zq), b = 0 >= b ? "" : (_.C = _.v(Array, "from").call(Array, {
                    length: Math.ceil(b / 8)
                }), _.v(_.C, "fill")).call(_.C, "testdata").join("").substring(0, b), 2 === _.rf(Yq) && (c += "&dblt=" + b);
                b = c
            } else b = "";
            return b
        })
    };
    Vq = function(a) {
        var b = a.la.ca,
            c, d;
        a = null != (d = null == (c = ar(a.ma.X.ba)) ? void 0 : _.D(c, 9)) ? d : !1;
        c = _.D(b, 8);
        return a || c || !_.D(b, 5)
    };
    Xq = function(a, b) {
        var c = void 0 === b.va ? "," : b.va,
            d = void 0 === b.Nc ? "" : b.Nc,
            e = void 0 === b.ya ? !1 : b.ya,
            f = !1;
        a = a.map(function(g) {
            f || (f = !!g);
            return String(0 === g && e ? g : g || d)
        });
        return f || e ? encodeURIComponent(a.join(c)) : null
    };
    br = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.sb.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.se(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.wb(function(l) {
                if (1 == l.j) return d && clearTimeout(d), d = 0, f = new _.Lf, g = b(f.resolve), h = ++e, xb(l, 0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.zn(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    jr = function() {
        var a = new cr;
        var b = (new dr).setCorrelator(_.Lg(_.t));
        var c = _.of().join();
        b = _.tg(b, 5, c);
        b = _.ld(b, 2, 1, 0);
        a = _.vg(a, 1, b);
        b = new er;
        c = _.G(fr);
        b = _.qd(b, 7, c);
        c = _.G(gr);
        b = _.qd(b, 8, c);
        c = _.G(hr);
        b = _.qd(b, 9, c);
        b = _.qd(b, 10, !0);
        c = _.G(ir);
        b = _.qd(b, 13, c);
        b = _.qd(b, 16, !0);
        a = _.vg(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    lr = function() {
        var a = kr,
            b = Number(a);
        return 1 > b || Math.floor(b) !== b ? (We({
            v: a
        }, "gpt_inv_ver"), "1") : a
    };
    nr = function(a, b) {
        var c = mr() || (0, _.Se)() ? 1 : _.Te(),
            d = .001 > c;
        d ? (b.m = !0, nf(31067358)) : .002 > c && nf(31067357);
        rk(23, a);
        return {
            nd: d,
            Pi: 1E3,
            uj: 1E-4 > c,
            Oi: 1E4,
            Vg: d,
            jg: 1E3
        }
    };
    qr = function(a, b) {
        var c = b.wb;
        /m\d+/.test(c) ? c = Number(c.substring(1)) : (c && We({
            mjsv: c
        }, "gpt_inv_ver"), c = void 0);
        var d = window.document.URL,
            e = _.rf(or);
        return _.v(Object, "assign").call(Object, {}, b, a, {
            Ub: c,
            Lb: new pr(e),
            ai: d,
            mg: 2012
        })
    };
    _.rr = function(a) {
        var b;
        a = (null != (b = void 0 === a ? null : a) ? b : window).googletag;
        return (null == a ? 0 : a.apiReady) ? a : void 0
    };
    sr = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    tr = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    ur = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.vr = ur(this);
    wr = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.x = {};
    xr = {};
    _.v = function(a, b, c) {
        if (!c || null != a) {
            c = xr[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    yr = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.x ? f = _.x : f = _.vr;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = wr && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? tr(_.x, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === xr[d] && (a = 1E9 * Math.random() >>> 0, xr[d] = wr ? _.vr.Symbol(d) : "$jscp$" + a + "$" + d), tr(f, xr[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    yr("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.j = f;
            tr(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.j
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    yr("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.x.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.vr[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && tr(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return zr(sr(this))
                }
            })
        }
        return a
    }, "es6");
    zr = function(a) {
        a = {
            next: a
        };
        a[_.v(_.x.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.Ar = function(a) {
        return a.raw = a
    };
    Br = function(a, b) {
        a.raw = b;
        return a
    };
    _.y = function(a) {
        var b = "undefined" != typeof _.x.Symbol && _.v(_.x.Symbol, "iterator") && a[_.v(_.x.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: sr(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.se = function(a) {
        if (!(a instanceof Array)) {
            a = _.y(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    Cr = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    Dr = wr && "function" == typeof _.v(Object, "assign") ? _.v(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) Cr(d, e) && (a[e] = d[e])
        }
        return a
    };
    yr("Object.assign", function(a) {
        return a || Dr
    }, "es6");
    var Er = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        Fr = function() {
            function a() {
                function c() {}
                new c;
                Reflect.construct(c, [], function() {});
                return new c instanceof c
            }
            if (wr && "undefined" != typeof Reflect && Reflect.construct) {
                if (a()) return Reflect.construct;
                var b = Reflect.construct;
                return function(c, d, e) {
                    c = b(c, d);
                    e && Reflect.setPrototypeOf(c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = Er(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        Gr;
    if (wr && "function" == typeof _.v(Object, "setPrototypeOf")) Gr = _.v(Object, "setPrototypeOf");
    else {
        var Hr;
        a: {
            var Ir = {
                    a: !0
                },
                Jr = {};
            try {
                Jr.__proto__ = Ir;
                Hr = Jr.a;
                break a
            } catch (a) {}
            Hr = !1
        }
        Gr = Hr ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    Kr = Gr;
    _.S = function(a, b) {
        a.prototype = Er(b.prototype);
        a.prototype.constructor = a;
        if (Kr) Kr(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.xj = b.prototype
    };
    Lr = function() {
        this.m = !1;
        this.B = null;
        this.o = void 0;
        this.j = 1;
        this.A = this.F = 0;
        this.N = null
    };
    Mr = function(a) {
        if (a.m) throw new TypeError("Generator is already running");
        a.m = !0
    };
    Lr.prototype.J = function(a) {
        this.o = a
    };
    var Nr = function(a, b) {
        a.N = {
            kg: b,
            Gi: !0
        };
        a.j = a.F || a.A
    };
    Lr.prototype.return = function(a) {
        this.N = {
            return: a
        };
        this.j = this.A
    };
    xb = function(a, b, c) {
        a.j = c;
        return {
            value: b
        }
    };
    zb = function(a) {
        a.F = 0;
        var b = a.N.kg;
        a.N = null;
        return b
    };
    Or = function(a) {
        this.j = new Lr;
        this.o = a
    };
    Rr = function(a, b) {
        Mr(a.j);
        var c = a.j.B;
        if (c) return Pr(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.j.return);
        a.j.return(b);
        return Qr(a)
    };
    Pr = function(a, b, c, d) {
        try {
            var e = b.call(a.j.B, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.j.m = !1, e;
            var f = e.value
        } catch (g) {
            return a.j.B = null, Nr(a.j, g), Qr(a)
        }
        a.j.B = null;
        d.call(a.j, f);
        return Qr(a)
    };
    Qr = function(a) {
        for (; a.j.j;) try {
            var b = a.o(a.j);
            if (b) return a.j.m = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.j.o = void 0, Nr(a.j, c)
        }
        a.j.m = !1;
        if (a.j.N) {
            b = a.j.N;
            a.j.N = null;
            if (b.Gi) throw b.kg;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    Sr = function(a) {
        this.next = function(b) {
            Mr(a.j);
            a.j.B ? b = Pr(a, a.j.B.next, b, a.j.J) : (a.j.J(b), b = Qr(a));
            return b
        };
        this.throw = function(b) {
            Mr(a.j);
            a.j.B ? b = Pr(a, a.j.B["throw"], b, a.j.J) : (Nr(a.j, b), b = Qr(a));
            return b
        };
        this.return = function(b) {
            return Rr(a, b)
        };
        this[_.v(_.x.Symbol, "iterator")] = function() {
            return this
        }
    };
    Tr = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.x.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.x.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.wb = function(a) {
        return Tr(new Sr(new Or(a)))
    };
    _.sb = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    yr("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    yr("Reflect.construct", function() {
        return Fr
    }, "es6");
    yr("Reflect.setPrototypeOf", function(a) {
        return a ? a : Kr ? function(b, c) {
            try {
                return Kr(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    yr("Promise", function(a) {
        function b() {
            this.j = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (null == this.j) {
                this.j = [];
                var h = this;
                this.F(function() {
                    h.N()
                })
            }
            this.j.push(g)
        };
        var d = _.vr.setTimeout;
        b.prototype.F = function(g) {
            d(g, 0)
        };
        b.prototype.N = function() {
            for (; this.j && this.j.length;) {
                var g = this.j;
                this.j = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.B(l)
                    }
                }
            }
            this.j = null
        };
        b.prototype.B = function(g) {
            this.F(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.F = void 0;
            this.j = [];
            this.J = !1;
            var h = this.B();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.B = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.I),
                reject: g(this.N)
            }
        };
        e.prototype.I = function(g) {
            if (g === this) this.N(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.T(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.pa(g) : this.m(g)
            }
        };
        e.prototype.pa = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.N(k);
                return
            }
            "function" == typeof h ? this.W(h, g) : this.m(g)
        };
        e.prototype.N = function(g) {
            this.A(2, g)
        };
        e.prototype.m = function(g) {
            this.A(1, g)
        };
        e.prototype.A = function(g, h) {
            if (0 != this.o) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.F = h;
            2 === this.o && this.M();
            this.V()
        };
        e.prototype.M = function() {
            var g = this;
            d(function() {
                if (g.D()) {
                    var h = _.vr.console;
                    "undefined" !== typeof h && h.error(g.F)
                }
            }, 1)
        };
        e.prototype.D = function() {
            if (this.J) return !1;
            var g = _.vr.CustomEvent,
                h = _.vr.Event,
                k = _.vr.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.vr.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.F;
            return k(g)
        };
        e.prototype.V = function() {
            if (null != this.j) {
                for (var g = 0; g < this.j.length; ++g) f.o(this.j[g]);
                this.j = null
            }
        };
        var f = new b;
        e.prototype.T = function(g) {
            var h = this.B();
            g.Ed(h.resolve, h.reject)
        };
        e.prototype.W = function(g, h) {
            var k = this.B();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(u) {
                    try {
                        l(p(u))
                    } catch (w) {
                        m(w)
                    }
                } : r
            }
            var l, m, n = new e(function(p, r) {
                l = p;
                m = r
            });
            this.Ed(k(g, l), k(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Ed = function(g, h) {
            function k() {
                switch (l.o) {
                    case 1:
                        g(l.F);
                        break;
                    case 2:
                        h(l.F);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.o);
                }
            }
            var l = this;
            null == this.j ? f.o(k) : this.j.push(k);
            this.J = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.y(g), m = l.next(); !m.done; m = l.next()) c(m.value).Ed(h, k)
            })
        };
        e.all = function(g) {
            var h = _.y(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function n(u) {
                    return function(w) {
                        p[u] = w;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).Ed(n(p.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    yr("Object.setPrototypeOf", function(a) {
        return a || Kr
    }, "es6");
    yr("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.j = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.y(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!Cr(g, d)) {
                var k = new b;
                tr(g, d, {
                    value: k
                })
            }
            if (!Cr(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.j] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && Cr(g, d) ? g[d][this.j] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && Cr(g, d) && Cr(g[d], this.j)
        };
        f.prototype.delete = function(g) {
            return c(g) && Cr(g, d) && Cr(g[d], this.j) ? delete g[d][this.j] : !1
        };
        return f
    }, "es6");
    yr("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.v(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.y([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.v(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.x.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = _.y(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.Ka ? l.Ka.value = k : (l.Ka = {
                next: this[1],
                yb: this[1].yb,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.Ka), this[1].yb.next = l.Ka, this[1].yb = l.Ka, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.Ka && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.Ka.yb.next = h.Ka.next, h.Ka.next.yb = h.Ka.yb, h.Ka.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].yb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).Ka
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).Ka) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.v(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[_.v(_.x.Symbol, "iterator")] = _.v(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && Cr(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            Ka: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    Ka: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return zr(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.yb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.yb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var Ur = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.v(_.x.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    yr("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Ur(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    yr("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Ur(this, function(b) {
                return b
            })
        }
    }, "es6");
    var Vr = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    yr("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Vr(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var Wr = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                i: e,
                nh: f
            }
        }
        return {
            i: -1,
            nh: void 0
        }
    };
    yr("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return Wr(this, b, c).nh
        }
    }, "es6");
    yr("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Cr(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    yr("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    yr("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.v(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    yr("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Vr(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    yr("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    yr("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    yr("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    }, "es6");
    yr("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.v(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    yr("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.x.Symbol && _.v(_.x.Symbol, "iterator") && b[_.v(_.x.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    yr("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Ur(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    yr("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    }, "es6");
    var Xr = function(a) {
        return a ? a : _.v(Array.prototype, "fill")
    };
    yr("Int8Array.prototype.fill", Xr, "es6");
    yr("Uint8Array.prototype.fill", Xr, "es6");
    yr("Uint8ClampedArray.prototype.fill", Xr, "es6");
    yr("Int16Array.prototype.fill", Xr, "es6");
    yr("Uint16Array.prototype.fill", Xr, "es6");
    yr("Int32Array.prototype.fill", Xr, "es6");
    yr("Uint32Array.prototype.fill", Xr, "es6");
    yr("Float32Array.prototype.fill", Xr, "es6");
    yr("Float64Array.prototype.fill", Xr, "es6");
    yr("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.v(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.y([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.v(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.j = new _.x.Map;
            if (c) {
                c = _.y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.j.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.j.set(c, c);
            this.size = this.j.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.j.delete(c);
            this.size = this.j.size;
            return c
        };
        b.prototype.clear = function() {
            this.j.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.j.has(c)
        };
        b.prototype.entries = function() {
            return _.v(this.j, "entries").call(this.j)
        };
        b.prototype.values = function() {
            return _.v(this.j, "values").call(this.j)
        };
        b.prototype.keys = _.v(b.prototype, "values");
        b.prototype[_.v(_.x.Symbol, "iterator")] = _.v(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.j.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    yr("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Cr(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    yr("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Vr(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    yr("globalThis", function(a) {
        return a || _.vr
    }, "es_2020");
    yr("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.S(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    yr("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.v(Array, "from").call(Array, b);
            return _.x.Promise.all(b.map(function(c) {
                return _.x.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.x.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    yr("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.v(_.x.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.v(_.x.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    yr("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return Wr(this, b, c).i
        }
    }, "es6");
    yr("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.x.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.x.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    yr("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.v(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    yr("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    yr("String.fromCodePoint", function(a) {
        return a ? a : function(b) {
            for (var c = "", d = 0; d < arguments.length; d++) {
                var e = Number(arguments[d]);
                if (0 > e || 1114111 < e || e !== Math.floor(e)) throw new RangeError("invalid_code_point " + e);
                65535 >= e ? c += String.fromCharCode(e) : (e -= 65536, c += String.fromCharCode(e >>> 10 & 1023 | 55296), c += String.fromCharCode(e & 1023 | 56320))
            }
            return c
        }
    }, "es6");
    yr("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    _.t = this || self;
    vc = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    };
    sa = function(a) {
        var b = vc(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.ha = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    ka = "closure_uid_" + (1E9 * Math.random() >>> 0);
    la = 0;
    Yr = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    Zr = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.$r = function(a, b, c) {
        _.$r = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Yr : Zr;
        return _.$r.apply(null, arguments)
    };
    _.as = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    ef = function() {
        return Date.now()
    };
    var bs;
    var ds, cs;
    _.es = function(a, b) {
        this.j = a === cs && b || "";
        this.o = ds
    };
    _.es.prototype.fb = !0;
    _.es.prototype.Ra = function() {
        return this.j
    };
    _.fs = function(a) {
        return a instanceof _.es && a.constructor === _.es && a.o === ds ? a.j : "type_error:Const"
    };
    _.gs = function(a) {
        return new _.es(cs, a)
    };
    ds = {};
    cs = {};
    var Cb = _.gs("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var hs, is, wh, ks;
    hs = function() {
        return !0
    };
    is = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    wh = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.js = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    ks = function(a) {
        var b = 0,
            c = !1,
            d = [],
            e = function() {
                b = 0;
                c && (c = !1, f())
            },
            f = function() {
                b = _.t.setTimeout(e, 200);
                var g = d;
                d = [];
                a.apply(void 0, g)
            };
        return function(g) {
            d = arguments;
            b ? c = !0 : f()
        }
    };
    var ls, aa;
    ls = {
        passive: !0
    };
    aa = wh(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.t.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.ub = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, ba(d)), !0) : !1
    };
    _.Be = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, ba(d)), !0) : !1
    };
    var os;
    _.ca = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.ms = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.mg = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.ns = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    os = function(a, b) {
        return Array.prototype.reduce.call(a, b, 0)
    };
    _.og = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var Da = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var ps = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var pe;
    pe = {};
    _.oe = function(a) {
        this.j = a;
        this.fb = !0
    };
    _.oe.prototype.toString = function() {
        return this.j.toString()
    };
    _.oe.prototype.Ra = function() {
        return this.j.toString()
    };
    _.gb = function(a) {
        return a instanceof _.oe && a.constructor === _.oe ? a.j : "type_error:SafeScript"
    };
    var ts, vs, us, rs, ws, je, ss;
    _.qs = function(a) {
        this.j = a
    };
    _.qs.prototype.toString = function() {
        return this.j + ""
    };
    _.qs.prototype.fb = !0;
    _.qs.prototype.Ra = function() {
        return this.j.toString()
    };
    ts = function(a, b) {
        a = rs.exec(_.ib(a).toString());
        var c = a[3] || "";
        return je(a[1] + ss("?", a[2] || "", b) + ss("#", c))
    };
    _.ib = function(a) {
        return a instanceof _.qs && a.constructor === _.qs ? a.j : "type_error:TrustedResourceUrl"
    };
    _.Bb = function(a, b) {
        var c = _.fs(a);
        if (!us.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(vs, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.es ? _.fs(d) : encodeURIComponent(String(d))
        });
        return je(a)
    };
    vs = /%{(\w+)}/g;
    us = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    rs = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    ws = {};
    je = function(a) {
        return new _.qs(a, ws)
    };
    ss = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var xs = function(a, b) {
            var c = a.length - b.length;
            return 0 <= c && a.indexOf(b, c) == c
        },
        ak = function(a) {
            return /^[\s\xa0]*$/.test(a)
        },
        Wm = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Fs = function(a) {
            if (!ys.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(zs, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(As, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Bs, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Cs, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Ds, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Es, "&#0;"));
            return a
        },
        zs = /&/g,
        As = /</g,
        Bs = />/g,
        Cs = /"/g,
        Ds = /'/g,
        Es = /\x00/g,
        ys = /[\x00&<>"']/,
        Ia = function(a, b) {
            return -1 != a.indexOf(b)
        },
        Xm = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var Gs, Hs, Js, Ks, Ls, Ms, pb;
    _.$a = function(a) {
        this.j = a
    };
    _.$a.prototype.toString = function() {
        return this.j.toString()
    };
    _.$a.prototype.fb = !0;
    _.$a.prototype.Ra = function() {
        return this.j.toString()
    };
    _.ab = function(a) {
        return a instanceof _.$a && a.constructor === _.$a ? a.j : "type_error:SafeUrl"
    };
    Gs = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    Hs = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.Is = function(a) {
        if (a instanceof _.$a) return a;
        a = "object" == typeof a && a.fb ? a.Ra() : String(a);
        Hs.test(a) ? a = pb(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(Gs) ? pb(a) : null);
        return a
    };
    try {
        new URL("s://g"), Js = !0
    } catch (a) {
        Js = !1
    }
    Ks = Js;
    Ls = function(a) {
        if (a instanceof _.$a) return a;
        a = "object" == typeof a && a.fb ? a.Ra() : String(a);
        a: {
            var b = a;
            if (Ks) {
                try {
                    var c = new URL(b)
                } catch (d) {
                    b = "https:";
                    break a
                }
                b = c.protocol
            } else b: {
                c = document.createElement("a");
                try {
                    c.href = b
                } catch (d) {
                    b = void 0;
                    break b
                }
                b = c.protocol;b = ":" === b || "" === b ? "https:" : b
            }
        }
        "javascript:" === b && (a = "about:invalid#zClosurez");
        return pb(a)
    };
    Ms = {};
    pb = function(a) {
        return new _.$a(a, Ms)
    };
    _.qb = pb("about:invalid#zClosurez");
    _.Ns = {};
    _.Os = function(a) {
        this.j = a;
        this.fb = !0
    };
    _.Os.prototype.Ra = function() {
        return this.j
    };
    _.Os.prototype.toString = function() {
        return this.j.toString()
    };
    _.Ps = new _.Os("", _.Ns);
    _.Qs = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Rs = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Ss = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    var Ga, Ts;
    a: {
        for (var Us = ["CLOSURE_FLAGS"], Vs = _.t, Ws = 0; Ws < Us.length; Ws++)
            if (Vs = Vs[Us[Ws]], null == Vs) {
                Ts = null;
                break a
            }
        Ts = Vs
    }
    var Xs = Ts && Ts[610401301];
    Ga = null != Xs ? Xs : !1;
    var Ha, Ys = _.t.navigator;
    Ha = Ys ? Ys.userAgentData || null : null;
    var Zs, bt, lt, ct, st, dt, Cf;
    Zs = {};
    _.$s = function(a) {
        this.j = a;
        this.fb = !0
    };
    _.$s.prototype.Ra = function() {
        return this.j.toString()
    };
    _.$s.prototype.toString = function() {
        return this.j.toString()
    };
    _.kb = function(a) {
        return a instanceof _.$s && a.constructor === _.$s ? a.j : "type_error:SafeHtml"
    };
    bt = function(a) {
        return a instanceof _.$s ? a : _.at(Fs("object" == typeof a && a.fb ? a.Ra() : String(a)))
    };
    _.Ef = function(a, b, c) {
        var d = String(a);
        if (!ct.test(d)) throw Error("");
        if (d.toUpperCase() in dt) throw Error("");
        return _.et(String(a), b, c)
    };
    lt = function(a) {
        var b = bt(Cf),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = bt(e), c.push(_.kb(e).toString()))
            };
        a.forEach(d);
        return _.at(c.join(_.kb(b).toString()))
    };
    _.rt = function(a) {
        return lt(Array.prototype.slice.call(arguments))
    };
    _.at = function(a) {
        return new _.$s(a, Zs)
    };
    _.et = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!ct.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.es) f = _.fs(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in st)
                                if (f instanceof _.qs) f = _.ib(f).toString();
                                else if (f instanceof _.$a) f = _.ab(f);
                            else if ("string" === typeof f) f = (_.Is(f) || _.qb).Ra();
                            else throw Error("");
                        }
                        f.fb && (f = f.Ra());
                        f = g + '="' + Fs(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === ps[a.toLowerCase()] ? b += ">" : (c = _.rt(c), b += ">" + _.kb(c).toString() + "</" + a + ">");
        return _.at(b)
    };
    ct = /^[a-zA-Z0-9-]+$/;
    st = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    dt = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    Cf = new _.$s(_.t.trustedTypes && _.t.trustedTypes.emptyHTML || "", Zs);
    _.tt = _.at("<br>");
    var ut;
    try {
        new URL("s://g"), ut = !0
    } catch (a) {
        ut = !1
    }
    var cb = ut;
    var vt = {
            ik: 0,
            lk: 1,
            gk: 2,
            hk: 3,
            0: "FORMATTED_HTML_CONTENT",
            1: "HTML_FORMATTED_CONTENT",
            2: "EMBEDDED_INTERNAL_CONTENT",
            3: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        wt = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + vt[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.S(wt, Error);
    var mb = function(a) {
            this.Ji = a
        },
        ob = [nb("data"), nb("http"), nb("https"), nb("mailto"), nb("ftp"), new mb(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })];
    var yb = function(a) {
        return new _.x.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var Fb, Eb = "undefined" !== typeof TextEncoder;
    _.xt = function(a) {
        _.xt[" "](a);
        return a
    };
    _.xt[" "] = function() {};
    var yt = function(a, b) {
        try {
            return _.xt(a[b]), !0
        } catch (c) {}
        return !1
    };
    var zt, Bt, Ct, Dt, Et, Ft;
    zt = Na();
    _.At = Qa();
    Bt = Ka("Edge");
    Ct = Ka("Gecko") && !(Ia(Fa().toLowerCase(), "webkit") && !Ka("Edge")) && !(Ka("Trident") || Ka("MSIE")) && !Ka("Edge");
    Dt = Ia(Fa().toLowerCase(), "webkit") && !Ka("Edge");
    Et = function() {
        var a = _.t.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var Gt = "",
            Ht = function() {
                var a = Fa();
                if (Ct) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Bt) return /Edge\/([\d\.]+)/.exec(a);
                if (_.At) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Dt) return /WebKit\/(\S+)/.exec(a);
                if (zt) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Ht && (Gt = Ht ? Ht[1] : "");
        if (_.At) {
            var It = Et();
            if (null != It && It > parseFloat(Gt)) {
                Ft = String(It);
                break a
            }
        }
        Ft = Gt
    }
    var Jt = Ft,
        Kt;
    if (_.t.document && _.At) {
        var Lt = Et();
        Kt = Lt ? Lt : parseInt(Jt, 10) || void 0
    } else Kt = void 0;
    var Mt = Kt;
    !Ka("Android") || Ta();
    Ta();
    Va();
    var Nt = {},
        Ot = null,
        Pt = Ct || Dt || "function" == typeof _.t.btoa,
        Ib = function(a, b) {
            void 0 === b && (b = 0);
            Qt();
            b = Nt[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        Rt = function(a, b) {
            if (Pt && !b) a = _.t.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Ib(c, b)
            }
            return a
        },
        eo = function(a) {
            var b = "";
            St(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        qj = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : Ia("=.", a[b - 1]) && (c = Ia("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            St(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        St = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Ot[l];
                    if (null != m) return m;
                    if (!ak(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            Qt();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        Qt = function() {
            if (!Ot) {
                Ot = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Nt[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === Ot[f] && (Ot[f] = e)
                    }
                }
            }
        };
    var Nb = "undefined" !== typeof Uint8Array,
        Hb = !_.At && "function" === typeof btoa,
        pj = /[-_.]/g,
        Kb = {
            "-": "+",
            _: "/",
            ".": "="
        },
        rj, Pb = {};
    var Tt, nc = function(a, b) {
            Qb(b);
            this.na = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        oc = function() {
            return Tt || (Tt = new nc(null, Pb))
        },
        yd = function(a) {
            var b = a.na;
            return null == b ? "" : "string" === typeof b ? b : a.na = Jb(b)
        };
    nc.prototype.isEmpty = function() {
        return null == this.na
    };
    var Sb = 0,
        Tb = 0,
        Wb = "function" === typeof BigInt;
    var Ut = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Wt = function(a) {
            if (!a) return Vt || (Vt = new Ut(0, 0));
            if (!/^\d+$/.test(a)) return null;
            Xb(a);
            return new Ut(Sb, Tb)
        },
        Vt, Xt = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Yd = function(a) {
            if (!a) return Yt || (Yt = new Xt(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            Xb(a);
            return new Xt(Sb, Tb)
        },
        Yt;
    var Zt = function() {
        this.j = []
    };
    Zt.prototype.length = function() {
        return this.j.length
    };
    Zt.prototype.end = function() {
        var a = this.j;
        this.j = [];
        return a
    };
    var $d = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.j.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.j.push(b)
        },
        Zd = function(a, b) {
            for (; 127 < b;) a.j.push(b & 127 | 128), b >>>= 7;
            a.j.push(b)
        },
        $t = function(a, b) {
            if (0 <= b) Zd(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.j.push(b & 127 | 128), b >>= 7;
                a.j.push(1)
            }
        };
    var de = function() {
            this.F = [];
            this.o = 0;
            this.j = new Zt
        },
        ee = function(a, b) {
            0 !== b.length && (a.F.push(b), a.o += b.length)
        },
        au = function(a, b) {
            Zd(a.j, 8 * b + 2);
            b = a.j.end();
            ee(a, b);
            b.push(a.o);
            return b
        },
        bu = function(a, b) {
            var c = b.pop();
            for (c = a.o + a.j.length() - c; 127 < c;) b.push(c & 127 | 128), c >>>= 7, a.o++;
            b.push(c);
            a.o++
        },
        cu = function(a, b, c) {
            Zd(a.j, 8 * b + 2);
            Zd(a.j, c.length);
            ee(a, a.j.end());
            ee(a, c)
        };
    var Vd = function(a) {
        this.j = a
    };
    var du = "function" === typeof _.x.Symbol && "symbol" === typeof(0, _.x.Symbol)() ? (0, _.x.Symbol)() : void 0,
        fc = du ? function(a, b) {
            a[du] |= b
        } : function(a, b) {
            void 0 !== a.gb ? a.gb |= b : Object.defineProperties(a, {
                gb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        },
        Vc = du ? function(a, b) {
            a[du] &= ~b
        } : function(a, b) {
            void 0 !== a.gb && (a.gb &= ~b)
        },
        Zb = du ? function(a) {
            return a[du] | 0
        } : function(a) {
            return a.gb | 0
        },
        Xc = du ? function(a) {
            return a[du]
        } : function(a) {
            return a.gb
        },
        cc = du ? function(a, b) {
            a[du] = b
        } : function(a, b) {
            void 0 !== a.gb ? a.gb = b : Object.defineProperties(a, {
                gb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };
    var Hc = {},
        eu, Uc, fu = [];
    cc(fu, 23);
    Uc = Object.freeze(fu);
    var gu = function(a, b, c) {
        this.F = 0;
        this.j = a;
        this.o = b;
        this.B = c
    };
    gu.prototype.next = function() {
        if (this.F < this.j.length) {
            var a = this.j[this.F++];
            return {
                done: !1,
                value: this.o ? this.o.call(this.B, a) : a
            }
        }
        return {
            done: !0,
            value: void 0
        }
    };
    gu.prototype[_.v(_.x.Symbol, "iterator")] = function() {
        return new gu(this.j, this.o, this.B)
    };
    var cd = {};
    var Kc = "function" === typeof _.x.Symbol && "symbol" === typeof(0, _.x.Symbol)() ? (0, _.x.Symbol)() : "di";
    var bd = function(a, b, c, d) {
        c = void 0 === c ? Mc : c;
        d = void 0 === d ? Mc : d;
        var e = Fr(_.x.Map, [], this.constructor);
        var f = Zb(a);
        f |= 32;
        cc(a, f);
        e.j = f;
        e.F = b;
        e.o = c || Mc;
        e.B = e.F ? Pc : d || Mc;
        for (var g = 0; g < a.length; g++) {
            var h = a[g],
                k = c(h[0], !1, !0),
                l = h[1];
            b || (l = d(h[1], !1, !0, void 0, void 0, f));
            null != k && _.x.Map.prototype.set.call(e, k, l)
        }
        return e
    };
    _.S(bd, _.x.Map);
    var hu = function(a) {
            if (a.j & 2) throw Error("Cannot mutate an immutable Map");
        },
        zd = function(a, b) {
            b = void 0 === b ? Qc : b;
            return ed(a, b)
        },
        ed = function(a, b) {
            b = void 0 === b ? Qc : b;
            var c = [];
            a = _.v(_.x.Map.prototype, "entries").call(a);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    q = bd.prototype;
    q.clear = function() {
        hu(this);
        _.x.Map.prototype.clear.call(this)
    };
    q.delete = function(a) {
        hu(this);
        return _.x.Map.prototype.delete.call(this, this.o(a, !0, !1))
    };
    q.entries = function() {
        var a = _.v(Array, "from").call(Array, _.v(_.x.Map.prototype, "keys").call(this));
        return new gu(a, Rc, this)
    };
    q.keys = function() {
        return _.v(_.x.Map.prototype, "keys").call(this)
    };
    q.values = function() {
        var a = _.v(Array, "from").call(Array, _.v(_.x.Map.prototype, "keys").call(this));
        return new gu(a, bd.prototype.get, this)
    };
    q.forEach = function(a, b) {
        var c = this;
        _.x.Map.prototype.forEach.call(this, function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    q.set = function(a, b) {
        hu(this);
        a = this.o(a, !0, !1);
        return null == a ? this : null == b ? (_.x.Map.prototype.delete.call(this, a), this) : _.x.Map.prototype.set.call(this, a, this.B(b, !0, !0, this.F, !1, this.j))
    };
    q.get = function(a) {
        a = this.o(a, !1, !1);
        var b = _.x.Map.prototype.get.call(this, a);
        if (void 0 !== b) {
            var c = this.j,
                d = this.F;
            return d ? (Array.isArray(b) && c & 16 && ic(b), c = this.B(b, !1, !0, d, this.N, c), c !== b && _.x.Map.prototype.set.call(this, a, c), c) : b
        }
    };
    bd.prototype[_.v(_.x.Symbol, "iterator")] = function() {
        return _.v(this, "entries").call(this)
    };
    var Xd, Tc, an, Gk, nj, ad, Cp, ij, oj, mj, Dp, dm, Fp, Oe, qi, $m, Tg, iu, pi, Ll, vl, ju, lu, mu, ym, nu, ou, pu;
    Xd = function(a, b) {
        a = a.K;
        return Tc(a, Xc(a), b)
    };
    Tc = function(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= lc(b)) {
            if (b & 128) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 128 && (d = a[e - 1][c], null != d)) return d;
            b = c + ((b >> 8 & 1) - 1);
            if (b < e) return a[b]
        }
    };
    _.I = function(a, b, c, d) {
        var e = a.K,
            f = Xc(e);
        qc(f);
        Sc(e, f, b, c, d);
        return a
    };
    an = function(a, b) {
        a = a.K;
        var c = Xc(a),
            d = Tc(a, c, b);
        var e = null == d ? d : "number" === typeof d || "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        null != e && e !== d && Sc(a, c, b, e);
        return e
    };
    Gk = function(a, b) {
        a = Xd(a, b);
        return null == a ? a : "boolean" !== typeof a && "number" !== typeof a ? void 0 : !!a
    };
    nj = function(a, b) {
        a = a.K;
        var c = Xc(a),
            d = Tc(a, c, b),
            e = pc(d, !0, !!(c & 18));
        null != e && e !== d && Sc(a, c, b, e);
        return null == e ? oc() : e
    };
    Cp = function(a, b) {
        return _.I(a, b, void 0, !1)
    };
    ij = function(a, b, c, d) {
        var e = a.K,
            f = Xc(e);
        qc(f);
        (c = nd(e, f, c)) && c !== b && null != d && Sc(e, f, c);
        Sc(e, f, b, d);
        return a
    };
    oj = function(a, b, c) {
        a = a.K;
        return nd(a, Xc(a), b) === c ? c : -1
    };
    mj = function(a, b) {
        a = a.K;
        return nd(a, Xc(a), b)
    };
    Dp = function(a, b, c) {
        a = a.K;
        var d = Xc(a);
        qc(d);
        var e = Tc(a, d, c);
        b = Oc(Jc(e, b, !0, d));
        e !== b && Sc(a, d, c, b);
        return b
    };
    dm = function(a, b, c, d) {
        a = a.K;
        var e = Xc(a),
            f = Tc(a, e, c, d);
        b = Jc(f, b, !1, e);
        b !== f && null != b && Sc(a, e, c, b, d);
        return b
    };
    Fp = function(a, b, c) {
        return (a = dm(a, b, c, !1)) ? a : Ic(b)
    };
    _.Rg = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = dm(a, b, c, d);
        if (null == b) return b;
        a = a.K;
        var e = Xc(a);
        if (!(e & 2)) {
            var f = Oc(b);
            f !== b && (b = f, Sc(a, e, c, b, d))
        }
        return b
    };
    Oe = function(a, b, c) {
        var d = a.K,
            e = Xc(d);
        a = !!(e & 2);
        b = od(d, e, b, c, a ? 1 : 2);
        if (!(a || Zb(b) & 8)) {
            for (c = 0; c < b.length; c++) a = b[c], d = Oc(a), a !== d && (b[c] = d);
            fc(b, 8)
        }
        return b
    };
    _.vg = function(a, b, c) {
        null == c && (c = void 0);
        return _.I(a, b, c)
    };
    _.yg = function(a, b, c, d) {
        null == d && (d = void 0);
        return ij(a, b, c, d)
    };
    _.el = function(a, b, c) {
        var d = a.K,
            e = Xc(d);
        qc(e);
        if (null != c) {
            for (var f = !!c.length, g = 0; g < c.length; g++) {
                var h = c[g];
                f = f && !(Zb(h.K) & 2)
            }
            g = Zb(c);
            h = g | 1;
            h = (f ? h | 8 : h & -9) | 4;
            h != g && (c = ec(c, h))
        }
        null == c && (c = void 0);
        Sc(d, e, b, c);
        return a
    };
    qi = function(a, b, c, d) {
        pd(a, b, c, d);
        return a
    };
    $m = function(a, b) {
        return xc(Xd(a, b))
    };
    Tg = function(a, b) {
        a: if (a = Xd(a, b), null != a) {
            switch (typeof a) {
                case "string":
                    a = +a;
                    break a;
                case "number":
                    break a
            }
            a = void 0
        }return a
    };
    iu = function() {
        var a = Fh().j;
        return Xd(a, 26)
    };
    pi = function(a, b, c) {
        return _.I(a, b, null == c ? c : wc(c))
    };
    _.bh = function(a, b) {
        return Gc(Xd(a, b))
    };
    _.Sl = function(a, b, c, d) {
        return Yc(a, b, Gc, c, d)
    };
    Ll = function(a, b, c) {
        return _.I(a, b, Fc(c))
    };
    _.tg = function(a, b, c) {
        return _.ld(a, b, Fc(c), "")
    };
    _.D = function(a, b, c) {
        return sd(Gk(a, b), void 0 === c ? !1 : c)
    };
    _.Re = function(a, b) {
        return sd($m(a, b), 0)
    };
    vl = function(a, b) {
        return sd(Tg(a, b), 0)
    };
    _.ye = function(a, b) {
        return sd(Xd(a, b), 0)
    };
    _.R = function(a, b) {
        return sd(_.bh(a, b), "")
    };
    _.Qe = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        return sd(yc(Xd(a, b)), c)
    };
    ju = function(a, b, c) {
        a = _.Sl(a, b, void 0, 2);
        if ("number" !== typeof c || 0 > c || c >= a.length) throw Error();
        return a[c]
    };
    lu = function(a) {
        return _.ye(a, oj(a, ku, 3))
    };
    mu = function(a, b) {
        return _.R(a, oj(a, b, 2))
    };
    ym = function(a, b) {
        a = Gk(a, b);
        return null == a ? void 0 : a
    };
    nu = function(a, b) {
        a = $m(a, b);
        return null == a ? void 0 : a
    };
    ou = function(a, b) {
        a = _.bh(a, b);
        return null == a ? void 0 : a
    };
    pu = function(a, b) {
        a = yc(Xd(a, b));
        return null == a ? void 0 : a
    };
    var td;
    _.T = function(a, b, c) {
        this.K = _.z(a, b, c)
    };
    _.T.prototype.toJSON = function() {
        if (eu) var a = Jd(this, this.K, !1);
        else a = Bd(this.K, Dd, void 0, void 0, !1, !1), a = Jd(this, a, !0);
        return a
    };
    var Le = function(a) {
        eu = !0;
        try {
            return JSON.stringify(a.toJSON(), xd)
        } finally {
            eu = !1
        }
    };
    _.T.prototype.clone = function() {
        var a = this.K;
        return Gd(this, a, Xc(a), !1)
    };
    _.T.prototype.ff = Hc;
    var Od = (0, _.x.Symbol)(),
        Md = (0, _.x.Symbol)(),
        Ld = (0, _.x.Symbol)(),
        qu = Wd(function(a, b, c) {
            b = an(b, c);
            if (null != b) {
                Zd(a.j, 8 * c + 5);
                a = a.j;
                var d = +b;
                0 === d ? 0 < 1 / d ? Sb = Tb = 0 : (Tb = 0, Sb = 2147483648) : isNaN(d) ? (Tb = 0, Sb = 2147483647) : (d = (c = 0 > d ? -2147483648 : 0) ? -d : d, 3.4028234663852886E38 < d ? (Tb = 0, Sb = (c | 2139095040) >>> 0) : 1.1754943508222875E-38 > d ? (d = Math.round(d / Math.pow(2, -149)), Tb = 0, Sb = (c | d) >>> 0) : (b = Math.floor(Math.log(d) / Math.LN2), d *= Math.pow(2, -b), d = Math.round(8388608 * d), 16777216 <= d && ++b, Tb = 0, Sb = (c | b + 127 << 23 | d & 8388607) >>> 0));
                c = Sb;
                a.j.push(c >>> 0 & 255);
                a.j.push(c >>> 8 & 255);
                a.j.push(c >>> 16 & 255);
                a.j.push(c >>> 24 & 255)
            }
        }),
        ru = Wd(ae),
        su = Wd(ae),
        tu = Wd(function(a, b, c) {
            b = Xd(b, c);
            null != b && ("string" === typeof b && Wt(b), null != b && (Zd(a.j, 8 * c), "number" === typeof b ? (a = a.j, Ub(b), $d(a, Sb, Tb)) : (c = Wt(b), $d(a.j, c.o, c.j))))
        }),
        uu = Wd(function(a, b, c) {
            b = $m(b, c);
            null != b && null != b && (Zd(a.j, 8 * c), $t(a.j, b))
        }),
        vu = Wd(function(a, b, c) {
            b = Gk(b, c);
            null != b && (Zd(a.j, 8 * c), a.j.j.push(b ? 1 : 0))
        }),
        wu = Wd(function(a, b, c) {
            b = _.bh(b, c);
            null != b && cu(a, c, Gb(b))
        }),
        xu = Wd(function(a, b, c) {
            b = _.Sl(b, c);
            if (null != b)
                for (var d = 0; d < b.length; d++) {
                    var e = b[d];
                    null != e && cu(a, c, Gb(e))
                }
        }),
        yu = Wd(function(a, b, c, d, e) {
            b = dm(b, d, c);
            null != b && (c = au(a, c), e(b, a), bu(a, c))
        }),
        zu = Wd(function(a, b, c, d, e) {
            b = b.K;
            d = od(b, Xc(b), d, c, 1);
            if (null != d)
                for (b = 0; b < d.length; b++) {
                    var f = au(a, c);
                    e(d[b], a);
                    bu(a, f)
                }
        }),
        Au = Wd(function(a, b, c) {
            b = yc(Xd(b, c));
            null != b && (b = parseInt(b, 10), Zd(a.j, 8 * c), $t(a.j, b))
        });
    var be = void 0;
    var fo = function(a) {
        this.K = _.z(a)
    };
    _.S(fo, _.T);
    var go = function(a) {
        this.K = _.z(a)
    };
    _.S(go, _.T);
    var Bu = function(a) {
            this.j = a.o;
            this.o = a.F;
            this.B = a.B;
            this.Zc = a.Zc;
            this.G = a.G;
            this.yc = a.yc;
            this.Sd = a.Sd;
            this.je = a.je;
            this.Rd = a.Rd;
            this.F = a.j
        },
        Cu = function(a, b, c) {
            this.o = a;
            this.F = b;
            this.B = c;
            this.G = window;
            this.yc = "env";
            this.Sd = "n";
            this.je = "0";
            this.Rd = "1";
            this.j = !0
        };
    Cu.prototype.build = function() {
        return new Bu(this)
    };
    var po = function(a, b) {
        var c = void 0 === _.D(b, 6) ? !0 : _.D(b, 6),
            d, e, f = he(_.Qe(b, 2, 0)),
            g = _.R(b, 3);
        a: switch (_.Qe(b, 4, 0)) {
            case 1:
                var h = "pt";
                break a;
            case 2:
                h = "cr";
                break a;
            default:
                h = ""
        }
        f = new Cu(f, g, h);
        b = null != (e = null == (d = _.Rg(b, fo, 5)) ? void 0 : _.R(d, 1)) ? e : "";
        f.Zc = b;
        f.j = c;
        f.G = a;
        return f.build()
    };
    var jm = function(a) {
        this.K = _.z(a)
    };
    _.S(jm, _.T);
    jm.prototype.getId = function() {
        return _.R(this, 1)
    };
    var im = function(a, b) {
            return Ll(a, 1, b)
        },
        Du = [jm, 1, wu];
    var Eu = function(a) {
        this.K = _.z(a)
    };
    _.S(Eu, _.T);
    Eu.prototype.getWidth = function() {
        return _.Re(this, 1)
    };
    var nm = function(a) {
        var b = new Eu;
        return _.I(b, 1, a)
    };
    Eu.prototype.getHeight = function() {
        return _.Re(this, 2)
    };
    var mm = function(a, b) {
            return _.I(a, 2, b)
        },
        Fu = [Eu, 1, uu, 2, uu];
    var Gu = function(a) {
        this.K = _.z(a)
    };
    _.S(Gu, _.T);
    var Hu = [Gu, 1, su, 2, vu];
    var gm = function(a) {
        this.K = _.z(a)
    };
    _.S(gm, _.T);
    var km = function(a, b) {
            _.id(a, 4, b, _.Ec)
        },
        hm = function(a, b) {
            _.vg(a, 6, b)
        };
    gm.prototype.setSize = function(a) {
        return _.vg(this, 7, a)
    };
    gm.fa = [4];
    var Iu = [gm, 1, wu, 2, su, 8, su, 3, wu, 4, xu, 5, Au, 6, yu, Du, 7, yu, Fu, 9, yu, Hu];
    var Kl = function(a) {
        this.K = _.z(a)
    };
    _.S(Kl, _.T);
    var Jl = function(a, b) {
            return _.I(a, 1, b)
        },
        Hl = function(a, b) {
            return pi(a, 4, b)
        },
        Il = function(a, b) {
            return _.I(a, 2, b)
        },
        Ju = [Kl, 1, Au, 4, vu, 2, uu, 3, wu];
    var Yl = function(a) {
        this.K = _.z(a)
    };
    _.S(Yl, _.T);
    var Xl = function(a, b) {
            return Ll(a, 1, b)
        },
        am = function(a, b) {
            _.I(a, 2, b)
        },
        Vl = function(a, b) {
            return qi(a, 3, gm, b)
        },
        Wl = function(a, b) {
            return _.I(a, 4, b)
        };
    Yl.prototype.qg = function() {
        return _.Qe(this, 7, 0)
    };
    Yl.fa = [10, 3];
    var Ku = [Yl, 1, wu, 10, xu, 2, su, 3, zu, Iu, 4, Au, 5, yu, Ju, 6, vu, 7, Au];
    var Lu = function(a) {
        this.K = _.z(a)
    };
    _.S(Lu, _.T);
    var Mu = [Lu, 1, Au, 2, vu];
    var Nu = function(a) {
        this.K = _.z(a)
    };
    _.S(Nu, _.T);
    var Ul = function(a, b) {
            return pd(a, 2, Yl, b)
        },
        em = function(a, b) {
            _.vg(a, 5, b)
        },
        Ou = function(a, b) {
            _.vg(a, 9, b)
        };
    Nu.fa = [2];
    var Pu = [Nu, 1, Au, 6, wu, 2, zu, Ku, 3, Au, 4, wu, 5, yu, Ju, 9, yu, Mu, 7, vu, 8, uu];
    var Qu = function(a) {
        this.K = _.z(a)
    };
    _.S(Qu, _.T);
    var Ru = function(a) {
        var b = new Nu;
        b = _.I(b, 1, 1);
        return pd(a, 1, Nu, b)
    };
    Qu.fa = [1];
    Qu.prototype.j = fe([Qu, 1, zu, Pu]);
    var Su = function(a) {
        this.K = _.z(a)
    };
    _.S(Su, _.T);
    var ku = [2, 3];
    var Tu = function(a) {
        this.K = _.z(a)
    };
    _.S(Tu, _.T);
    Tu.fa = [1];
    var Uu = function(a) {
        this.K = _.z(a)
    };
    _.S(Uu, _.T);
    Uu.fa = [1];
    var Vu = function(a) {
        this.K = _.z(a)
    };
    _.S(Vu, _.T);
    var Wu = [2, 3];
    var Xu = function(a) {
        this.K = _.z(a)
    };
    _.S(Xu, _.T);
    Xu.fa = [2];
    var Yu = function(a) {
        this.K = _.z(a)
    };
    _.S(Yu, _.T);
    Yu.fa = [6, 4];
    var Zu = function(a) {
        this.K = _.z(a)
    };
    _.S(Zu, _.T);
    Zu.fa = [4];
    var $u = function(a) {
        this.K = _.z(a)
    };
    _.S($u, _.T);
    var av = function(a) {
        this.K = _.z(a)
    };
    _.S(av, _.T);
    av.prototype.Qd = function() {
        return Fp(this, $u, 2)
    };
    av.fa = [1];
    var bv = function(a) {
        this.K = _.z(a)
    };
    _.S(bv, _.T);
    var cv = function(a) {
        this.K = _.z(a)
    };
    _.S(cv, _.T);
    cv.fa = [1];
    var dv = function(a) {
        this.K = _.z(a)
    };
    _.S(dv, _.T);
    var ev = [dv, 1, Au, 2, su];
    var fv = function(a) {
        this.K = _.z(a)
    };
    _.S(fv, _.T);
    var gv = [fv, 1, ru];
    var hv = function(a) {
        this.K = _.z(a)
    };
    _.S(hv, _.T);
    hv.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 1)
    };
    var iv = [hv, 1, wu, 2, yu, gv, 3, yu, ev];
    var jv = function(a) {
        this.K = _.z(a)
    };
    _.S(jv, _.T);
    jv.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    var kv = function(a) {
        this.K = _.z(a)
    };
    _.S(kv, _.T);
    kv.fa = [5];
    _.lv = function(a) {
        this.K = _.z(a)
    };
    _.S(_.lv, _.T);
    _.mv = function(a) {
        return Oe(a, kv, 15)
    };
    _.lv.fa = [15];
    var nv = function(a) {
        this.K = _.z(a)
    };
    _.S(nv, _.T);
    nv.prototype.getAdUnitPath = function() {
        return _.R(this, 2)
    };
    var ov = function(a) {
        this.K = _.z(a)
    };
    _.S(ov, _.T);
    var pv = [5, 7, 8, 9];
    var qv = function(a) {
        this.K = _.z(a)
    };
    _.S(qv, _.T);
    qv.fa = [4, 5, 6];
    var rv = function(a) {
        this.K = _.z(a)
    };
    _.S(rv, _.T);
    rv.prototype.getValue = function() {
        return _.R(this, 2)
    };
    rv.prototype.We = function() {
        return null != _.bh(this, 2)
    };
    var sv = function(a) {
        this.K = _.z(a)
    };
    _.S(sv, _.T);
    sv.fa = [13];
    var tv = function(a) {
        this.K = _.z(a)
    };
    _.S(tv, _.T);
    tv.fa = [13];
    var uv = function(a) {
        this.K = _.z(a)
    };
    _.S(uv, _.T);
    var vv = function(a) {
            var b = new uv;
            return _.I(b, 1, a)
        },
        wv = [uv, 1, Au];
    var ji = function(a) {
        this.K = _.z(a)
    };
    _.S(ji, _.T);
    var xv = function(a) {
        var b = new ji;
        return Ll(b, 1, a)
    };
    ji.prototype.Sa = function(a) {
        return _.vg(this, 10, a)
    };
    var yv = ge(ji),
        zv = [ji, 1, wu, 2, wu, 3, su, 7, su, 8, qu, 4, uu, 5, uu, 6, uu, 9, vu, 11, vu, 10, yu, wv];
    var Av = function(a) {
        this.K = _.z(a)
    };
    _.S(Av, _.T);
    var Bv = [Av, 4, Au, 5, wu];
    var Cv = function(a) {
        this.K = _.z(a)
    };
    _.S(Cv, _.T);
    var Dv = [Cv, 1, tu, 2, tu, 3, tu];
    var Ev = function(a) {
        this.K = _.z(a)
    };
    _.S(Ev, _.T);
    Ev.prototype.Sa = function(a) {
        return _.vg(this, 7, a)
    };
    var Fv = [Ev, 5, wu, 4, wu, 2, yu, Dv, 3, yu, Dv, 6, vu, 7, yu, Bv, 8, su];
    var Gv = function(a) {
        this.K = _.z(a)
    };
    _.S(Gv, _.T);
    Gv.fa = [1, 2];
    Gv.prototype.j = fe([Gv, 1, zu, Fv, 2, zu, zv]);
    var Hv = function(a) {
        this.K = _.z(a)
    };
    _.S(Hv, _.T);
    Hv.prototype.getValue = function() {
        return _.bh(this, 1)
    };
    Hv.prototype.We = function() {
        return null != _.bh(this, 1)
    };
    Hv.prototype.getVersion = function() {
        return yc(Xd(this, 5))
    };
    var Iv = function(a) {
        this.K = _.z(a)
    };
    _.S(Iv, _.T);
    var Jv = function(a) {
        this.K = _.z(a)
    };
    _.S(Jv, _.T);
    var Kv = function(a) {
        this.K = _.z(a)
    };
    _.S(Kv, _.T);
    var Lv = function(a) {
        this.K = _.z(a)
    };
    _.S(Lv, _.T);
    Lv.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 4)
    };
    Lv.fa = [2];
    var Mv = function(a) {
        this.K = _.z(a)
    };
    _.S(Mv, _.T);
    var Nv = function(a) {
        this.K = _.z(a)
    };
    _.S(Nv, _.T);
    var Ov = function(a) {
        this.K = _.z(a)
    };
    _.S(Ov, _.T);
    var Pv = function(a) {
        this.K = _.z(a)
    };
    _.S(Pv, _.T);
    var Qv = function(a) {
        this.K = _.z(a)
    };
    _.S(Qv, _.T);
    Qv.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 2)
    };
    var Rv = function(a) {
        this.K = _.z(a)
    };
    _.S(Rv, _.T);
    var Sv = function(a) {
        this.K = _.z(a)
    };
    _.S(Sv, _.T);
    Sv.prototype.getWidth = function() {
        return _.Re(this, 9)
    };
    Sv.prototype.getHeight = function() {
        return _.Re(this, 10)
    };
    Sv.fa = [3, 7, 11];
    var Tv = function(a) {
        this.K = _.z(a)
    };
    _.S(Tv, _.T);
    Tv.prototype.getHeight = function() {
        return $m(this, 6)
    };
    Tv.prototype.getWidth = function() {
        return $m(this, 7)
    };
    Tv.prototype.getEscapedQemQueryId = function() {
        return _.bh(this, 34)
    };
    Tv.fa = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63];
    var Uv = [39, 48];
    var Vv = function(a) {
        this.K = _.z(a)
    };
    _.S(Vv, _.T);
    var co = ge(Vv);
    var Wv = function(a) {
        this.K = _.z(a)
    };
    _.S(Wv, _.T);
    var Xv = ge(Wv);
    Wv.fa = [1, 2, 3];
    var Yv = window;
    var er = function(a) {
        this.K = _.z(a)
    };
    _.S(er, _.T);
    er.fa = [15];
    var dr = function(a) {
        this.K = _.z(a)
    };
    _.S(dr, _.T);
    dr.prototype.getCorrelator = function() {
        return _.ye(this, 1)
    };
    dr.prototype.setCorrelator = function(a) {
        return _.rd(this, 1, a)
    };
    var cr = function(a) {
        this.K = _.z(a)
    };
    _.S(cr, _.T);
    var Zv = _.At || Dt;
    var aw, bw, cw;
    _.$v = wh(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.kb(Cf);
        return !b.parentElement
    });
    aw = function(a, b) {
        b = b instanceof _.$a ? b : Ls(b);
        a.href = _.ab(b)
    };
    bw = /^[\w+/_-]+[=]{0,2}$/;
    cw = function(a, b) {
        b = (b || _.t).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && bw.test(a) ? a : "" : ""
    };
    _.jh = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    q = _.jh.prototype;
    q.clone = function() {
        return new _.jh(this.x, this.y)
    };
    q.equals = function(a) {
        return a instanceof _.jh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    q.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    q.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    q.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.oh = function(a, b) {
        this.width = a;
        this.height = b
    };
    q = _.oh.prototype;
    q.clone = function() {
        return new _.oh(this.width, this.height)
    };
    q.aspectRatio = function() {
        return this.width / this.height
    };
    q.isEmpty = function() {
        return !(this.width * this.height)
    };
    q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var dw, ew, fw, hw;
    dw = function(a) {
        return a = Fs(a)
    };
    ew = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ ef()).toString(36)
    };
    fw = 2147483648 * Math.random() | 0;
    _.gw = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    hw = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var kw, mw, lw, pw, rw, ww;
    kw = function(a) {
        return a ? new _.iw(_.jw(a)) : bs || (bs = new _.iw)
    };
    mw = function(a, b) {
        Aa(b, function(c, d) {
            c && "object" == typeof c && c.fb && (c = c.Ra());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : lw.hasOwnProperty(d) ? a.setAttribute(lw[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    lw = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.ow = function(a) {
        a = a.document;
        a = _.nw(a) ? a.documentElement : a.body;
        return new _.oh(a.clientWidth, a.clientHeight)
    };
    pw = function(a) {
        return a.scrollingElement ? a.scrollingElement : !Dt && _.nw(a) ? a.documentElement : a.body || a.documentElement
    };
    _.qw = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    rw = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!sa(f) || _.ha(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.ha(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.ms(g ? ea(f) : f, d)
            }
        }
    };
    _.sw = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.nw = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.tw = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.uw = function(a) {
        var b;
        if (Zv && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.ha(b) && 1 == b.nodeType ? b : null
    };
    _.vw = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    _.jw = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    ww = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.qw(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.iw = function(a) {
        this.j = a || _.t.document || document
    };
    q = _.iw.prototype;
    q.wi = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    q.Oj = _.iw.prototype.wi;
    q.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    q.createElement = function(a) {
        return _.sw(this.j, a)
    };
    q.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };
    q.append = function(a, b) {
        rw(_.jw(a), a, arguments)
    };
    q.Dh = _.tw;
    q.contains = _.vw;
    var xw = function() {
        return Ga && Ha ? !Ha.mobile && (Ka("iPad") || Ka("Android") || Ka("Silk")) : Ka("iPad") || Ka("Android") && !Ka("Mobile") || Ka("Silk")
    };
    var zw, zk, Aw, Vj;
    _.yw = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    zw = function(a) {
        return a ? decodeURI(a) : a
    };
    zk = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) zk(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    Aw = /#|$/;
    Vj = function(a, b) {
        var c = a.search(Aw);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var wj, Gi, Bw, Hi, xh, yl, Ue, mr, Dw, Ew, yh, Fw, Gw, Hw, Iw, Jw, Kw, Lw, Mw, Nw, $h, bi, ai, Ow, Pw, Rw, Sw, Tw, Uw, Vw, Ww, al, Sk, Xw, Ek, Yw;
    _.Zi = function(a) {
        try {
            return !!a && null != a.location.href && yt(a, "foo")
        } catch (b) {
            return !1
        }
    };
    wj = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.t : d;
        c = (void 0 === c ? 0 : c) ? Bw(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.Zi(c) || !a(c));) c = Bw(c)
    };
    Gi = function() {
        var a = window;
        wj(function(b) {
            a = b;
            return !1
        });
        return a
    };
    Bw = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    Hi = function(a) {
        return _.Zi(a.top) ? a.top : null
    };
    _.Tj = function(a, b) {
        var c = _.Ae("SCRIPT", a);
        jb(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    xh = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.Te = function() {
        if (!_.x.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.x.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.Ck = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.Cw = function(a) {
        var b = [];
        _.Ck(a, function(c) {
            b.push(c)
        });
        return b
    };
    yl = function(a, b) {
        return Ca(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.Af = function(a, b) {
        var c = a.length;
        if (0 == c) return 0;
        b = b || 305419896;
        for (var d = 0; d < c; d++) b ^= (b << 5) + (b >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < b ? b : 4294967296 + b
    };
    _.Se = wh(function() {
        return _.og(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Dw) || 1E-4 > Math.random()
    });
    Ue = function(a, b) {
        try {
            if (a) return a.setItem("google_experiment_mod", b), b
        } catch (c) {}
        return null
    };
    mr = wh(function() {
        return Dw("MSIE")
    });
    Dw = function(a) {
        return Ia(Fa(), a)
    };
    Ew = /^([0-9.]+)px$/;
    yh = function(a) {
        return (a = Ew.exec(a)) ? +a[1] : null
    };
    Fw = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    Gw = function(a) {
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    Hw = {
        Sj: "allow-forms",
        Tj: "allow-modals",
        Uj: "allow-orientation-lock",
        Vj: "allow-pointer-lock",
        Wj: "allow-popups",
        Xj: "allow-popups-to-escape-sandbox",
        Yj: "allow-presentation",
        Zj: "allow-same-origin",
        ak: "allow-scripts",
        bk: "allow-top-navigation",
        ck: "allow-top-navigation-by-user-activation"
    };
    Iw = wh(function() {
        return _.Cw(Hw)
    });
    Jw = function(a) {
        var b = Iw();
        return a.length ? _.mg(b, function(c) {
            return !(0 <= _.ca(a, c))
        }) : b
    };
    Kw = function() {
        var a = _.Ae("IFRAME"),
            b = {};
        _.ms(Iw(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    Lw = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && Ia(a, "[native code]")
    };
    Mw = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = Bw(a))) break
        }
        return null
    };
    Nw = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.Ae("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.bn = wh(function() {
        return (Ga && Ha ? Ha.mobile : !xw() && (Ka("iPod") || Ka("iPhone") || Ka("Android") || Ka("IEMobile"))) ? 2 : xw() ? 1 : 0
    });
    $h = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.Jh = function(a, b) {
        _.Ck(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    bi = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    ai = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = xh(a, window);
            if (d) {
                if (b(d, a)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Ow = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.ns(a, parseFloat)
    };
    Pw = {};
    _.Qw = (Pw["http://googleads.g.doubleclick.net"] = !0, Pw["http://pagead2.googlesyndication.com"] = !0, Pw["https://googleads.g.doubleclick.net"] = !0, Pw["https://pagead2.googlesyndication.com"] = !0, Pw);
    Rw = function(a) {
        _.t.console && _.t.console.warn && _.t.console.warn(a)
    };
    Sw = [];
    Tw = function() {
        var a = Sw;
        Sw = [];
        a = _.y(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    Uw = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    Vw = function() {
        var a = void 0 === a ? Math.random : a;
        return Math.floor(a() * Math.pow(2, 52))
    };
    _.Lg = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Vw(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Ww = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (Sw.push(b), 1 == Sw.length && (_.x.Promise ? _.x.Promise.resolve().then(Tw) : window.setImmediate ? setImmediate(Tw) : setTimeout(Tw, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    al = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    Sk = function(a) {
        return 0 === a || al(a)
    };
    Xw = function(a) {
        return new _.x.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    };
    Ek = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.Ae = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Yw = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.Zi(a) && (b = a);
        return b
    };
    _.Zw = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    q = _.Zw.prototype;
    q.getWidth = function() {
        return this.right - this.left
    };
    q.getHeight = function() {
        return this.bottom - this.top
    };
    q.clone = function() {
        return new _.Zw(this.top, this.right, this.bottom, this.left)
    };
    q.contains = function(a) {
        return this && a ? a instanceof _.Zw ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    q.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    q.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    q.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var $w = function(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    };
    $w.prototype.clone = function() {
        return new $w(this.left, this.top, this.width, this.height)
    };
    var ax = function(a) {
            return new _.Zw(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        bx = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new $w(c, e, d - c, a - e)
            }
            return null
        };
    q = $w.prototype;
    q.contains = function(a) {
        return a instanceof _.jh ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    q.distance = function(a) {
        var b = a.x < this.left ? this.left - a.x : Math.max(a.x - (this.left + this.width), 0);
        a = a.y < this.top ? this.top - a.y : Math.max(a.y - (this.top + this.height), 0);
        return Math.sqrt(b * b + a * a)
    };
    q.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    q.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    q.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var cx = function(a) {
        return (a = void 0 === a ? ie() : a) ? _.Zi(a.master) ? a.master : null : null
    };
    var fx, hx, mh, ix, jx, ih;
    _.ex = function(a, b, c) {
        if ("string" === typeof b)(b = _.dx(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.dx(c, d);
                f && (c.style[f] = e)
            }
    };
    fx = {};
    _.dx = function(a, b) {
        var c = fx[b];
        if (!c) {
            var d = _.gw(b);
            c = d;
            void 0 === a.style[d] && (d = (Dt ? "Webkit" : Ct ? "Moz" : _.At ? "ms" : null) + hw(d), void 0 !== a.style[d] && (c = d));
            fx[b] = c
        }
        return c
    };
    _.gx = function(a, b) {
        var c = _.jw(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    hx = function(a, b) {
        return _.gx(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    mh = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    ix = function(a) {
        if (_.At && !(8 <= Number(Mt))) return a.offsetParent;
        var b = _.jw(a),
            c = hx(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = hx(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    jx = function(a) {
        var b = _.jw(a),
            c = new _.jh(0, 0);
        var d = b ? _.jw(b) : document;
        d = !_.At || 9 <= Number(Mt) || _.nw(kw(d).j) ? d.documentElement : d.body;
        if (a == d) return c;
        a = mh(a);
        d = kw(b).j;
        b = pw(d);
        d = d.parentWindow || d.defaultView;
        b = _.At && d.pageYOffset != b.scrollTop ? new _.jh(b.scrollLeft, b.scrollTop) : new _.jh(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    ih = function(a, b) {
        var c = new _.jh(0, 0),
            d = _.qw(_.jw(a));
        if (!yt(d, "parent")) return c;
        do {
            var e = d == b ? jx(a) : _.kx(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.kx = function(a) {
        a = mh(a);
        return new _.jh(a.left, a.top)
    };
    _.lx = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.lh = function(a, b) {
        if ("none" != hx(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.mx = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Dt && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = mh(a), new _.oh(a.right - a.left, a.bottom - a.top)) : new _.oh(b, c)
    };
    var Xh = function(a) {
        a = cx(ie(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var nx = function(a, b) {
        if (_.x.globalThis.fetch) _.x.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var ox = function(a) {
        this.K = _.z(a)
    };
    _.S(ox, _.T);
    var px = function(a) {
        this.K = _.z(a)
    };
    _.S(px, _.T);
    var Cg = function(a) {
        this.K = _.z(a)
    };
    _.S(Cg, _.T);
    var xg = function(a) {
        this.K = _.z(a)
    };
    _.S(xg, _.T);
    var ug = function(a) {
        this.K = _.z(a)
    };
    _.S(ug, _.T);
    var qx = function(a) {
        this.K = _.z(a)
    };
    _.S(qx, _.T);
    var sg = function(a) {
        this.K = _.z(a)
    };
    _.S(sg, _.T);
    sg.prototype.getTagSessionCorrelator = function() {
        return _.ye(this, 2)
    };
    sg.fa = [4];
    var zg = [6, 7, 8, 9, 11];
    var Ng = function(a) {
        this.K = _.z(a)
    };
    _.S(Ng, _.T);
    Ng.fa = [3];
    var Mg = function(a) {
        this.K = _.z(a)
    };
    _.S(Mg, _.T);
    Mg.fa = [4, 5];
    var Kg = function(a) {
        this.K = _.z(a)
    };
    _.S(Kg, _.T);
    Kg.prototype.getTagSessionCorrelator = function() {
        return _.ye(this, 1)
    };
    Kg.fa = [2];
    var Jg = function(a) {
        this.K = _.z(a)
    };
    _.S(Jg, _.T);
    var Qg = [4, 6];
    _.U = function() {
        this.N = this.N;
        this.pa = this.pa
    };
    _.U.prototype.N = !1;
    _.U.prototype.wa = function() {
        this.N || (this.N = !0, this.F())
    };
    _.O = function(a, b) {
        _.zn(a, _.as(ve, b))
    };
    _.zn = function(a, b) {
        a.N ? b() : (a.pa || (a.pa = []), a.pa.push(b))
    };
    _.U.prototype.F = function() {
        if (this.pa)
            for (; this.pa.length;) this.pa.shift()()
    };
    var rx = function(a, b, c, d, e) {
            this.m = a;
            this.N = b;
            this.J = c;
            this.F = d;
            this.B = e;
            this.j = [];
            this.o = null
        },
        sx = function(a) {
            null !== a.o && (clearTimeout(a.o), a.o = null);
            if (a.j.length) {
                var b = re(a.j);
                a.N(a.m + "?e=1", b);
                a.j = []
            }
        };
    rx.prototype.Ef = function() {
        var a = _.sb.apply(0, arguments),
            b = this;
        this.B && 65536 <= re(this.j.concat(a)).length && sx(this);
        this.j.push.apply(this.j, _.se(a));
        this.j.length >= this.F && sx(this);
        this.j.length && null === this.o && (this.o = setTimeout(function() {
            sx(b)
        }, this.J))
    };
    var pr = function(a, b, c) {
        rx.call(this, "https://pagead2.googlesyndication.com/pagead/ping", nx, void 0 === a ? 1E3 : a, void 0 === b ? 100 : b, (void 0 === c ? !1 : c) && !!_.x.globalThis.fetch)
    };
    _.S(pr, rx);
    var tx = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? !1 : b
        },
        ux = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? 0 : b
        },
        vx = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? "" : b
        },
        wx = function(a) {
            var b = void 0 === b ? [] : b;
            this.j = a;
            this.defaultValue = b
        };
    var xx, Oh, Hh, zx, lm, Ax, Bx, Fl, Zl, Cx, Dx, Ex, Zq, Yq, Fx, Gx, Hx, Ix, Jx, Kx, Lx, Mx, Nx, $n, Ox, nl, Vf, Px, Qx, Sf, Aq, gq, Wq, qm, Rx, qn, Ux, Vx, Xx, Eg, Yx, Zx, Eq, Cn, $x, ay, by, cy, dy, ey, fy, gy, hy, yk, vk, iy, Tq, ly, my, $k, ny, oy, py, or, fj, ej, ip, Sp, qy, ry, Po, sy, ty, uy, vy, wy, xy, yy, zy, Ay, gr, hr, jn, ir, fr, By, Cy, Pp, Dy, Fy;
    xx = new tx(1122, !0);
    _.yx = new tx(545471060);
    Oh = new ux(7, .1);
    Hh = new tx(543536815);
    zx = new tx(212);
    lm = new ux(474069761);
    Ax = new ux(455645877);
    Bx = new ux(462420536);
    Fl = new tx(476475256);
    Zl = new tx(514499457, !0);
    Cx = new ux(448338836, .01);
    Dx = new ux(427198696, 1);
    Ex = new ux(438663674);
    Zq = new ux(45409629);
    Yq = new ux(522348973);
    Fx = new tx(369430);
    Gx = new ux(408380992, .01);
    Hx = new ux(377289019, 1E4);
    Ix = new ux(488);
    Jx = new tx(45414566, !0);
    Kx = new ux(529, 20);
    Lx = new vx(10);
    Mx = new tx(489217043);
    Nx = new tx(495013820);
    $n = new ux(447000223, .01);
    Ox = new tx(360245597, !0);
    nl = new tx(540043576);
    Vf = new tx(543738408);
    Px = new tx(471855283);
    Qx = new tx(539488524);
    Sf = new tx(465118388);
    Aq = new tx(537888660);
    gq = new tx(539097417);
    Wq = new tx(45401686);
    qm = new tx(45401685, !0);
    Rx = new tx(200);
    _.Sx = new tx(479390945);
    _.Tx = new tx(518650310);
    qn = new ux(492, .01);
    Ux = new ux(363650251);
    Vx = new ux(474872234);
    _.Wx = new tx(531615531);
    Xx = new tx(83);
    Eg = new tx(85);
    Yx = new tx(437061931, !0);
    Zx = new tx(537116804);
    Eq = new tx(524098256);
    Cn = new ux(532520346, 120);
    $x = new wx(466086960);
    ay = new tx(45388169);
    by = new ux(398776877, 6E4);
    cy = new ux(374201269, 6E4);
    dy = new ux(371364213, 6E4);
    ey = new ux(376149757, .0025);
    fy = new tx(453275889);
    gy = new tx(377936516, !0);
    hy = new ux(24);
    yk = new wx(1);
    vk = new vx(2, "1-0-40");
    iy = new tx(441529989);
    _.jy = new ux(506394061, 100);
    _.ky = new tx(526684968, !0);
    Tq = new wx(489);
    ly = new tx(392065905);
    my = new ux(360245595, 500);
    $k = new tx(45397804, !0);
    ny = new tx(45398607, !0);
    oy = new tx(424117738);
    py = new tx(516301089, !0);
    or = new ux(397316938, 1E3);
    fj = new tx(531493729);
    ej = new tx(507033477, !0);
    ip = new tx(399705355);
    Sp = new ux(514795754, 2);
    qy = new tx(45415915, !0);
    ry = new tx(529748032);
    Po = new tx(523169149, !0);
    sy = new tx(501);
    ty = new tx(439828594);
    uy = new tx(483962503);
    vy = new ux(494575051);
    wy = new wx(489560439);
    xy = new wx(505762507);
    yy = new tx(453);
    zy = new tx(454);
    Ay = new tx(506738118);
    gr = new tx(77);
    hr = new tx(78);
    jn = new tx(309);
    ir = new tx(80);
    fr = new tx(76);
    By = new tx(84);
    Cy = new tx(1958);
    Pp = new tx(1973);
    Dy = new tx(188);
    _.Ey = new ux(1972);
    Fy = new tx(485990406);
    var Gy = function(a, b, c, d, e, f) {
            try {
                var g = a.j,
                    h = _.Ae("SCRIPT", g);
                h.async = !0;
                jb(h, b);
                g.head.appendChild(h);
                h.addEventListener("load", function() {
                    e();
                    d && g.head.removeChild(h)
                });
                h.addEventListener("error", function() {
                    0 < c ? Gy(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
                })
            } catch (k) {
                f()
            }
        },
        Hy = function(a, b, c, d) {
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            Gy(kw(a), b, 0, !1, c, d)
        };
    Ba({
        xk: 0,
        wk: 1,
        tk: 2,
        nk: 3,
        uk: 4,
        pk: 5,
        vk: 6,
        rk: 7,
        sk: 8,
        mk: 9,
        qk: 10,
        yk: 11
    }).map(function(a) {
        return Number(a)
    });
    Ba({
        Ak: 0,
        Bk: 1,
        zk: 2
    }).map(function(a) {
        return Number(a)
    });
    var Iy = function(a, b) {
        this.j = we(a);
        this.o = b
    };
    Iy.prototype[_.v(_.x.Symbol, "iterator")] = function() {
        return this
    };
    Iy.prototype.next = function() {
        var a = this.j.next();
        return {
            value: a.done ? void 0 : this.o.call(void 0, a.value),
            done: a.done
        }
    };
    var Jy = function(a, b) {
            return new Iy(a, b)
        },
        Ky = function(a) {
            this.o = a;
            this.j = 0
        };
    Ky.prototype[_.v(_.x.Symbol, "iterator")] = function() {
        return this
    };
    Ky.prototype.next = function() {
        for (; this.j < this.o.length;) {
            var a = this.o[this.j].next();
            if (!a.done) return a;
            this.j++
        }
        return {
            done: !0
        }
    };
    var Ly = function() {
        return new Ky(_.sb.apply(0, arguments).map(we))
    };
    var My = _.t.URL,
        Ny;
    try {
        new My("http://example.com"), Ny = !0
    } catch (a) {
        Ny = !1
    }
    var Oy = Ny,
        Py = function(a) {
            this.j = new _.x.Map;
            0 == a.indexOf("?") && (a = a.substring(1));
            a = _.y(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                1 < c.length && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.j.get(b);
                null == c && (c = [], this.j.set(b, c));
                c.push(d)
            }
        };
    Py.prototype.get = function(a) {
        return (a = this.j.get(a)) && a.length ? a[0] : null
    };
    Py.prototype.getAll = function(a) {
        return [].concat(_.se(this.j.get(a) || []))
    };
    Py.prototype.has = function(a) {
        return this.j.has(a)
    };
    Py.prototype[_.v(_.x.Symbol, "iterator")] = function() {
        return Ly.apply(null, _.se(Jy(this.j, function(a) {
            var b = a[0];
            return Jy(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    Py.prototype.toString = function() {
        return Qy(this)
    };
    var Qy = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.v(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        Sy = function(a) {
            var b = _.sw(document, "A");
            try {
                aw(b, pb(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if ("" === c || ":" === c || ":" != c[c.length - 1]) throw Error(a + " is not a valid URL.");
            if (!Ry.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            Ry.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        Ty = function(a) {
            if (Oy) {
                try {
                    var b = new My(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = Ry.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                "null" == b.origin && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a);
                return b
            }
            return Sy(a)
        },
        Ry = new _.x.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        Uy = function(a) {
            return Oy && a.searchParams ? a.searchParams : new Py(a.search)
        };
    var Vy = function(a) {
            var b = Uy(Ty(a.location.href));
            a = b.get("fcconsent");
            b = b.get("fc");
            return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
        },
        Wy = function(a) {
            a = Uy(Ty(a.location.href)).get("fctype");
            return -1 !== ["ab", "gdpr", "consent", "ccpa", "monetization"].indexOf(a) ? a : null
        };
    var Xy = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.Ae("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var Yy = function(a) {
        this.K = _.z(a)
    };
    _.S(Yy, _.T);
    Yy.fa = [1, 2];
    var Zy = function(a) {
        this.K = _.z(a)
    };
    _.S(Zy, _.T);
    var xe = ge(Zy);
    var $y = function(a, b, c, d) {
        _.U.call(this);
        this.I = b;
        this.D = c;
        this.V = d;
        this.J = new _.x.Map;
        this.M = 0;
        this.m = new _.x.Map;
        this.A = new _.x.Map;
        this.B = void 0;
        this.o = a
    };
    _.S($y, _.U);
    $y.prototype.F = function() {
        delete this.j;
        this.J.clear();
        this.m.clear();
        this.A.clear();
        this.B && (_.Be(this.o, "message", this.B), delete this.B);
        delete this.o;
        delete this.V;
        _.U.prototype.F.call(this)
    };
    var az = function(a) {
            if (a.j) return a.j;
            a.D && a.D(a.o) ? a.j = a.o : a.j = Mw(a.o, a.I);
            var b;
            return null != (b = a.j) ? b : null
        },
        cz = function(a, b, c) {
            if (az(a))
                if (a.j === a.o)(b = a.J.get(b)) && b(a.j, c);
                else {
                    var d = a.m.get(b);
                    if (d && d.dd) {
                        bz(a);
                        var e = ++a.M;
                        a.A.set(e, {
                            rc: d.rc,
                            Wh: d.Ud(c),
                            aj: "addEventListener" === b
                        });
                        a.j.postMessage(d.dd(c, e), "*")
                    }
                }
        },
        bz = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = a.V ? a.V(b) : void 0;
                    if (c) {
                        var d = c.vf,
                            e = a.A.get(d);
                        if (e) {
                            e.aj || a.A.delete(d);
                            var f;
                            null == (f = e.rc) || f.call(e, e.Wh, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.ub(a.o, "message", a.B))
        };
    var dz = function(a, b) {
            var c = {
                cb: function(d) {
                    d = xe(d);
                    b.Cb({
                        consentData: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        ez = {
            Ud: function(a) {
                return a.Cb
            },
            dd: function(a, b) {
                return {
                    __fciCall: {
                        callId: b,
                        command: a.command,
                        spsp: a.spsp || void 0
                    }
                }
            },
            rc: function(a, b) {
                a({
                    consentData: b
                })
            }
        },
        Fm = function(a) {
            _.U.call(this);
            this.j = this.o = !1;
            this.caller = new $y(a, "googlefcPresent", void 0, ze);
            this.caller.J.set("getDataWithCallback", dz);
            this.caller.m.set("getDataWithCallback", ez)
        };
    _.S(Fm, _.U);
    Fm.prototype.F = function() {
        this.caller.wa();
        _.U.prototype.F.call(this)
    };
    var fz = function(a) {
            a.o || (a.j = !!az(a.caller), a.o = !0);
            return a.j
        },
        gz = function(a) {
            return new _.x.Promise(function(b) {
                fz(a) && cz(a.caller, "getDataWithCallback", {
                    command: "loaded",
                    Cb: function(c) {
                        b(c.consentData)
                    }
                })
            })
        },
        hz = function(a, b) {
            fz(a) && cz(a.caller, "getDataWithCallback", {
                command: "prov",
                spsp: Le(b),
                Cb: function() {}
            })
        };
    var iz = function(a, b, c, d, e) {
            Ce(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        We = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.Ck(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            qo(d, c)
        },
        qo = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : iz(c, a, void 0, b, d)
        };
    var jz = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        kz = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.o = a;
            this.j = null;
            this.m = {};
            this.V = 0;
            var c;
            this.A = null != (c = b.lb) ? c : 500;
            var d;
            this.J = null != (d = b.Lh) ? d : !1;
            this.B = null
        };
    _.S(kz, _.U);
    kz.prototype.F = function() {
        this.m = {};
        this.B && (_.Be(this.o, "message", this.B), delete this.B);
        delete this.m;
        delete this.o;
        delete this.j;
        _.U.prototype.F.call(this)
    };
    var mz = function(a) {
        return "function" === typeof a.o.__tcfapi || null != lz(a)
    };
    kz.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.J
            },
            d = _.js(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.A && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.A));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = jz(c), c.internalBlockOnErrors = b.J, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            nz(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    kz.prototype.removeEventListener = function(a) {
        a && a.listenerId && nz(this, "removeEventListener", null, a.listenerId)
    };
    var oz = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        nz = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.o.__tcfapi) a = a.o.__tcfapi, a(b, 2, c, d);
            else if (lz(a)) {
                pz(a);
                var e = ++a.V;
                a.m[e] = c;
                a.j && (c = {}, a.j.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        lz = function(a) {
            if (a.j) return a.j;
            a.j = Mw(a.o, "__tcfapiLocator");
            return a.j
        },
        pz = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.m[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.ub(a.o, "message", a.B))
        },
        qz = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = jz(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (We({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        rz = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return oz(a, c)
            })
        };
    var sz = function(a, b, c) {
            this.j = a;
            this.F = b;
            this.o = void 0 === c ? function() {} : c
        },
        tz = function(a, b, c) {
            return new sz(a, b, c)
        };
    sz.prototype.start = function(a) {
        if (this.j === this.j.top) try {
            Xy(this.j), uz(this, a)
        } catch (b) {}
    };
    var uz = function(a, b) {
            var c = Vy(a.j),
                d = Wy(a.j),
                e = {};
            c = (e.fc = c, e.fctype = d, e);
            c = vz(a.F, c);
            Hy(a.j, c, function() {
                a.o(!0)
            }, function() {
                a.o(!1)
            });
            b && hz(new Fm(a.j), b)
        },
        vz = function(a, b) {
            var c = _.gs("https://fundingchoicesmessages.google.com/i/%{id}");
            b = _.v(Object, "assign").call(Object, {}, b, {
                ers: 3
            });
            return ts(_.Bb(c, {
                id: a
            }), b)
        };
    var wz = _.x.Promise;
    var xz = function(a) {
        this.F = a
    };
    xz.prototype.o = function(a, b, c) {
        this.F.then(function(d) {
            d.o(a, b, c)
        })
    };
    xz.prototype.j = function(a, b) {
        return this.F.then(function(c) {
            return c.j(a, b)
        })
    };
    var yz = function(a) {
        this.data = a
    };
    var zz = function(a) {
        this.F = a
    };
    zz.prototype.o = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        Az(d.port1, b);
        this.F.postMessage(a, [d.port2].concat(c))
    };
    zz.prototype.j = function(a, b) {
        var c = this;
        return new wz(function(d) {
            c.o(a, d, b)
        })
    };
    var Bz = function(a, b) {
            Az(a, b);
            return new zz(a)
        },
        Az = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new yz(c.data, Bz(c.ports[0])))
            })
        };
    var cj = function(a) {
            var b = a.eb,
                c = void 0 === a.mb ? "ZNWN1d" : a.mb,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.ae ? void 0 : a.ae;
            return Cz({
                destination: a.destination,
                qg: function() {
                    return b.contentWindow
                },
                Ui: Dz(a.origin),
                mb: c,
                onMessage: d,
                ae: e
            })
        },
        Cz = function(a) {
            var b = a.destination,
                c = a.qg,
                d = a.Ui,
                e = void 0 === a.zc ? void 0 : a.zc,
                f = a.mb,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.ae ? void 0 : a.ae,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new xz(new wz(function(l, m) {
                var n = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", n, !1), e && p.data.t !== e ? m(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(Bz(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", n, !1)
            }))
        },
        Dz = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var Ez = navigator,
        Fz = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        Gz = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return Fz(a.toLowerCase())
        },
        Hz = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        Iz = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        Jz = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var gh = function(a) {
            return !!a && a.top == a
        },
        Kz = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (gh(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var Rh = function() {
        this.o = [];
        this.j = -1
    };
    Rh.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.v(Number, "isInteger").call(Number, a) && this.o[a] !== b && (this.o[a] = b, this.j = -1)
    };
    Rh.prototype.get = function(a) {
        return !!this.o[a]
    };
    var Th = function(a) {
        -1 === a.j && (a.j = os(a.o, function(b, c, d) {
            return c ? b + Math.pow(2, d) : b
        }));
        return a.j
    };
    var Pe = function(a) {
        this.K = _.z(a)
    };
    _.S(Pe, _.T);
    var Ke = function(a) {
            var b = new Pe;
            return _.ld(b, 1, a, 0)
        },
        Je = function(a, b) {
            return _.ld(a, 2, b, 0)
        };
    var Ne = function(a) {
        this.K = _.z(a)
    };
    _.S(Ne, _.T);
    var Ie = function(a, b) {
            qi(a, 1, Pe, b)
        },
        He = ge(Ne);
    Ne.fa = [1];
    _.Ig = function(a) {
        return !!(a.error && a.meta && a.id)
    };
    var Lz = function(a, b) {
            (0, a.__uspapi)("getUSPData", 1, function(c, d) {
                b.Cb({
                    consentData: null != c ? c : void 0,
                    Ld: d ? void 0 : 2
                })
            })
        },
        Mz = {
            Ud: function(a) {
                return a.Cb
            },
            dd: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            rc: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    consentData: null != (c = b.returnValue) ? c : void 0,
                    Ld: b.success ? void 0 : 2
                })
            }
        },
        Nz = function(a) {
            _.U.call(this);
            this.caller = new $y(a, "__uspapiLocator", function(b) {
                return "function" === typeof b.__uspapi
            }, Xe);
            this.caller.J.set("getDataWithCallback", Lz);
            this.caller.m.set("getDataWithCallback", Mz)
        };
    _.S(Nz, _.U);
    Nz.prototype.F = function() {
        this.caller.wa();
        _.U.prototype.F.call(this)
    };
    var Oz = function(a, b) {
        var c = {};
        if (az(a.caller)) {
            var d = _.js(function() {
                b(c)
            });
            cz(a.caller, "getDataWithCallback", {
                Cb: function(e) {
                    e.Ld || (c = e.consentData);
                    d()
                }
            });
            setTimeout(d, 500)
        } else b(c)
    };
    var Pz = function(a, b) {
            (0, a.__gpp)("addEventListener", b.listener)
        },
        Qz = function(a, b) {
            (0, a.__gpp)("getSection", function(c) {
                b.Cb({
                    consentData: null != c ? c : void 0,
                    Ld: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        Rz = {
            Ud: function(a) {
                return a.listener
            },
            dd: function(a, b) {
                a = {};
                return a.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: 1
                }, a
            },
            rc: function(a, b) {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        Sz = {
            Ud: function(a) {
                return a.Cb
            },
            dd: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "getSection",
                    version: 1,
                    parameter: a.apiPrefix
                }, c
            },
            rc: function(a, b) {
                b = b.__gppReturn;
                var c;
                a({
                    consentData: null != (c = b.returnValue) ? c : void 0,
                    Ld: b.success ? void 0 : 2
                })
            }
        },
        Tz = function(a) {
            _.U.call(this);
            this.caller = new $y(a, "__gppLocator", function(b) {
                return "function" === typeof b.__gpp
            }, Ye);
            this.caller.J.set("addEventListener", Pz);
            this.caller.m.set("addEventListener", Rz);
            this.caller.J.set("getDataWithCallback", Qz);
            this.caller.m.set("getDataWithCallback", Sz)
        };
    _.S(Tz, _.U);
    Tz.prototype.F = function() {
        this.caller.wa();
        _.U.prototype.F.call(this)
    };
    Tz.prototype.addEventListener = function(a) {
        cz(this.caller, "addEventListener", {
            listener: a
        })
    };
    var cf = function(a) {
            this.j = a || {
                cookie: ""
            }
        },
        Wz = function() {
            var a = Uz;
            if (!_.t.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                df: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            Vz(a, "TESTCOOKIESENABLED");
            return !0
        };
    cf.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.cl;
            d = c.sj || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.df
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    cf.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.j.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Wm(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var Vz = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            df: 0,
            path: c,
            domain: d
        })
    };
    cf.prototype.isEmpty = function() {
        return !this.j.cookie
    };
    cf.prototype.clear = function() {
        for (var a = (this.j.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Wm(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) Vz(this, b[a])
    };
    var Uz = new cf("undefined" == typeof document ? null : document);
    _.Xz = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var aA, $z, cA, bA;
    _.Yz = function() {
        this.F = "&";
        this.o = {};
        this.B = 0;
        this.j = []
    };
    _.Zz = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    aA = function(a, b, c, d, e) {
        var f = [];
        _.Ck(a, function(g, h) {
            (g = $z(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    $z = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push($z(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(aA(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    cA = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = bA(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.j.length; f++)
            for (var g = a.j[f], h = a.o[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = aA(h[k], a.F, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.F;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    bA = function(a) {
        var b = 1,
            c;
        for (c in a.o) b = c.length > b ? c.length : b;
        return 3997 - b - a.F.length - 1
    };
    _.dA = function() {
        this.j = Math.random()
    };
    _.lg = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.j : Math.random()) < (e || .001)) try {
            if (c instanceof _.Yz) var f = c;
            else f = new _.Yz, _.Ck(c, function(h, k) {
                var l = f,
                    m = l.B++;
                h = _.Zz(k, h);
                l.j.push(m);
                l.o[m] = h
            });
            var g = cA(f, "/pagead/gen_204?id=" + b + "&");
            g && iz(_.t, g)
        } catch (h) {}
    };
    var eA = null,
        fA = function() {
            if (null === eA) {
                eA = "";
                try {
                    var a = "";
                    try {
                        a = _.t.top.location.hash
                    } catch (c) {
                        a = _.t.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        eA = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return eA
        };
    var gA = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.slotId = e;
        this.taskId = void 0;
        this.uniqueId = Math.random()
    };
    var hA, iA, jA, kA, lA;
    hA = _.t.performance;
    iA = !!(hA && hA.mark && hA.measure && hA.clearMarks);
    jA = wh(function() {
        var a;
        if (a = iA) a = fA(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    kA = function(a, b) {
        this.o = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.o = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.j = jA() || (null != c ? c : Math.random() < a)
    };
    _.Gg = function(a) {
        a && hA && jA() && (hA.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), hA.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    lA = function(a, b, c, d, e, f) {
        a.j && (b = new gA(b, c, d, void 0 === e ? 0 : e, f), !a.j || 2048 < a.o.length || a.o.push(b))
    };
    kA.prototype.start = function(a, b) {
        if (!this.j) return null;
        a = new gA(a, b, _.gf() || _.ff());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        hA && jA() && hA.mark(b);
        return a
    };
    kA.prototype.end = function(a) {
        if (this.j && "number" === typeof a.value) {
            a.duration = (_.gf() || _.ff()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            hA && jA() && hA.mark(b);
            !this.j || 2048 < this.o.length || this.o.push(a)
        }
    };
    var bp = function(a, b, c) {
        var d = _.gf();
        d && lA(a, b, 9, d, 0, c)
    };
    _.mA = function(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            for (var c; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (d) {
            return b
        }
    };
    var dl = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.v(Object, "setPrototypeOf").call(Object, this, dl.prototype)
    };
    _.S(dl, Error);
    dl.prototype.name = "PublisherInputError";
    var nA = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.v(Object, "setPrototypeOf").call(Object, this, nA.prototype)
    };
    _.S(nA, Error);
    nA.prototype.name = "ServerError";
    var oA = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.v(Object, "setPrototypeOf").call(Object, this, oA.prototype)
    };
    _.S(oA, Error);
    oA.prototype.name = "NetworkError";
    var pA = 0,
        qA = je(_.fs(_.gs("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    _.lf = function(a) {
        var b = "Sb";
        if (a.Sb && a.hasOwnProperty(b)) return a.Sb;
        b = new a;
        return a.Sb = b
    };
    var mf = function() {};
    mf.prototype.j = function() {};
    mf.prototype.F = function() {};
    mf.prototype.o = function() {
        return []
    };
    mf.prototype.B = function() {
        return []
    };
    var wf = function(a, b) {
        a.j = kf(1, b, function() {});
        a.o = function(c, d) {
            return kf(2, b, function() {
                return []
            })(c, 2, d)
        };
        a.B = function() {
            return kf(3, b, function() {
                return []
            })(2)
        };
        a.F = function(c) {
            kf(16, b, function() {})(c, 2)
        }
    };
    var qf = function() {
        var a = {};
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.F = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.B = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.N = function() {}
    };
    var tf = function() {
            this.j = function() {}
        },
        yf = function(a, b) {
            a.j = kf(14, b, function() {})
        };
    var Zg = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.oh(b.innerWidth, b.innerHeight)).round() : _.ow(b || window).round()
            } catch (d) {
                return new _.oh(-12245933, -12245933)
            }
        },
        rA = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        Qq = function(a, b) {
            b = void 0 === b ? _.t : b;
            a = a.scrollingElement || rA(a);
            return new _.jh(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        zh = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var sA = function(a) {
        this.K = _.z(a)
    };
    _.S(sA, _.T);
    sA.fa = [10];
    var uA, vA, wA;
    _.tA = function(a) {
        this.j = a;
        this.o = 0
    };
    uA = function(a, b) {
        if (0 === a.o) {
            if (_.sk(a, "__gads", b)) b = !0;
            else {
                var c = a.j;
                _.D(b, 5) && $e(c) && (new cf(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === df("GoogleAdServingTest", b, a.j)) {
                    var d = a.j;
                    _.D(b, 5) && $e(d) && Vz(new cf(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.o = b ? 2 : 1
        }
        return 2 === a.o
    };
    _.sk = function(a, b, c) {
        return c ? df(b, c, a.j) : null
    };
    vA = function(a, b, c, d) {
        if (d) {
            var e = {
                df: Math.max(Xd(c, 2) - Date.now() / 1E3, 0),
                path: _.bh(c, 3),
                domain: _.bh(c, 4),
                sj: !1
            };
            c = c.getValue();
            a = a.j;
            _.D(d, 5) && $e(a) && (new cf(a.document)).set(b, c, e)
        }
    };
    wA = function(a, b, c) {
        if (c && df(b, c, a.j)) {
            var d = a.j.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.y(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.j, _.D(c, 5) && $e(f) && Vz(new cf(f.document), b, "/", e.value)
        }
    };
    var xA = {},
        yA = (xA[3] = je(_.fs(_.gs("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), xA);
    ({})[3] = je(_.fs(_.gs("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var zA = function(a) {
            this.j = a;
            this.o = ew()
        },
        AA = function(a) {
            var b = {};
            _.ms(a, function(c) {
                b[c.j] = c.o
            });
            return b
        };
    var BA = _.Ar(["https://adservice.google.com/adsid/integrator.", ""]),
        CA = _.Ar(["https://adservice.google.com/adsid/integrator.", ""]),
        DA = _.Ar(["https://adservice.google.com/adsid/integrator.", ""]),
        EA = {},
        FA = new _.x.Map([
            [".google.com", (EA.json = _.ke(BA, "json"), EA.js = _.ke(CA, "js"), EA["sync.js"] = _.ke(DA, "sync.js"), EA)]
        ]);
    var GA = function(a, b, c) {
        var d = _.Ae("LINK", a);
        try {
            if (d.rel = "preload", Ia("preload", "stylesheet")) {
                d.href = _.ib(b).toString();
                var e = cw('style[nonce],link[rel="stylesheet"][nonce]', d.ownerDocument && d.ownerDocument.defaultView);
                e && d.setAttribute("nonce", e)
            } else d.href = b instanceof _.qs ? _.ib(b).toString() : b instanceof _.$a ? _.ab(b) : _.ab(Ls(b))
        } catch (f) {
            return
        }
        d.as = "script";
        c && d.setAttribute("nonce", c);
        if (a = a.getElementsByTagName("head")[0]) try {
            a.appendChild(d)
        } catch (f) {}
    };
    var Df = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var Hf = _.t,
        HA = function(a) {
            var b = new _.x.Map([
                ["domain", _.t.location.hostname]
            ]);
            If[3] >= ef() && b.set("adsid", If[1]);
            return le(FA.get(a).js, b)
        },
        If, IA, Gf = function() {
            Hf = _.t;
            If = Hf.googleToken = Hf.googleToken || {};
            var a = ef();
            If[1] && If[3] > a && 0 < If[2] || (If[1] = "", If[2] = -1, If[3] = -1, If[4] = "", If[6] = "");
            IA = Hf.googleIMState = Hf.googleIMState || {};
            FA.has(IA[1]) || (IA[1] = ".google.com");
            Array.isArray(IA[5]) || (IA[5] = []);
            "boolean" !== typeof IA[6] && (IA[6] = !1);
            Array.isArray(IA[7]) || (IA[7] = []);
            "number" !== typeof IA[8] && (IA[8] = 0)
        },
        Jf = {
            Ve: function() {
                return 0 < IA[8]
            },
            jj: function() {
                IA[8]++
            },
            kj: function() {
                0 < IA[8] && IA[8]--
            },
            lj: function() {
                IA[8] = 0
            },
            fl: function() {
                return !1
            },
            Rc: function() {
                return IA[5]
            },
            Rf: function(a) {
                try {
                    a()
                } catch (b) {
                    _.t.setTimeout(function() {
                        throw b;
                    }, 0)
                }
            },
            Lg: function() {
                if (!Jf.Ve()) {
                    var a = _.t.document,
                        b = function(e) {
                            e = HA(e);
                            a: {
                                try {
                                    var f = cw("script[nonce]");
                                    break a
                                } catch (g) {}
                                f = void 0
                            }
                            GA(a, e.toString(), f);
                            f = _.Ae("SCRIPT", a);
                            f.type = "text/javascript";
                            f.onerror = function() {
                                return _.t.processGoogleToken({}, 2)
                            };
                            jb(f, e);
                            try {
                                (a.head || a.body || a.documentElement).appendChild(f), Jf.jj()
                            } catch (g) {}
                        },
                        c = IA[1];
                    b(c);
                    ".google.com" != c && b(".google.com");
                    b = {};
                    var d = (b.newToken = "FBT", b);
                    _.t.setTimeout(function() {
                        return _.t.processGoogleToken(d, 1)
                    }, 1E3)
                }
            }
        },
        JA = function(a) {
            _.t.processGoogleToken = _.t.processGoogleToken || function(b, c) {
                var d = b;
                d = void 0 === d ? {} : d;
                c = void 0 === c ? 0 : c;
                b = d.newToken || "";
                var e = "NT" == b,
                    f = parseInt(d.freshLifetimeSecs || "", 10),
                    g = parseInt(d.validLifetimeSecs || "", 10),
                    h = d["1p_jar"] || "";
                d = d.pucrd || "";
                Gf();
                1 == c ? Jf.lj() : Jf.kj();
                var k = Hf.googleToken = Hf.googleToken || {},
                    l = 0 == c && b && "string" === typeof b && !e && "number" === typeof f && 0 < f && "number" === typeof g && 0 < g && "string" === typeof h;
                e = e && !Jf.Ve() && (!(If[3] >= ef()) || "NT" == If[1]);
                var m = !(If[3] >= ef()) && 0 != c;
                if (l || e || m) e = ef(), f = e + 1E3 * f, g = e + 1E3 * g, 1E-5 > Math.random() && iz(_.t, "https://pagead2.googlesyndication.com/pagead/gen_204?id=imerr&err=" + c), k[5] = c, k[1] = b, k[2] = f, k[3] = g, k[4] = h, k[6] = d, Gf();
                if (l || !Jf.Ve()) {
                    c = Jf.Rc();
                    for (b = 0; b < c.length; b++) Jf.Rf(c[b]);
                    c.length = 0
                }
            };
            Kf(a)
        };
    _.KA = _.Ar(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
    var LA = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.mb = a;
        this.status = 1;
        this.B = b;
        this.o = c;
        this.M = d;
        this.Xc = !!e;
        this.m = Math.random();
        this.J = {};
        this.j = null;
        this.V = (0, _.$r)(this.I, this);
        this.A = f
    };
    _.S(LA, _.U);
    LA.prototype.I = function(a) {
        if (!("*" !== this.o && a.origin !== this.o || !this.Xc && a.source != this.B)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.ha(b) && (a = b.i, b.c === this.mb && a != this.m)) {
                if (2 !== this.status) try {
                    this.status = 2, MA(this), this.j && (this.j(), this.j = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.ha(b)) && this.J.hasOwnProperty(a)) this.J[a](b)
            }
        }
    };
    var MA = function(a) {
        var b = {};
        b.c = a.mb;
        b.i = a.m;
        a.A && (b.e = a.A);
        a.B.postMessage(JSON.stringify(b), a.o)
    };
    LA.prototype.D = function() {
        if (1 === this.status) {
            try {
                this.B.postMessage && MA(this)
            } catch (a) {}
            window.setTimeout((0, _.$r)(this.D, this), 50)
        }
    };
    LA.prototype.connect = function(a) {
        a && (this.j = a);
        _.ub(window, "message", this.V);
        this.M && this.D()
    };
    var NA = function(a, b, c) {
            a.J[b] = c
        },
        OA = function(a, b, c) {
            var d = {};
            d.c = a.mb;
            d.i = a.m;
            d.s = b;
            d.p = c;
            try {
                a.B.postMessage(JSON.stringify(d), a.o)
            } catch (e) {}
        };
    LA.prototype.F = function() {
        this.status = 3;
        _.Be(window, "message", this.V);
        _.U.prototype.F.call(this)
    };
    var PA = new _.x.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        QA = new _.x.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var RA = function(a) {
        this.K = _.z(a)
    };
    _.S(RA, _.T);
    var wl = ge(RA);
    var SA = function(a) {
        this.K = _.z(a)
    };
    _.S(SA, _.T);
    var TA = function(a) {
        this.K = _.z(a)
    };
    _.S(TA, _.T);
    var VA, WA, XA, YA;
    _.UA = function(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    };
    VA = function(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };
    WA = function(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    };
    XA = function(a, b) {
        if (3 == _.UA(b)) return !1;
        a();
        return !0
    };
    YA = function(a, b) {
        if (!XA(a, b)) {
            var c = !1,
                d = VA(b),
                e = function() {
                    !c && XA(a, b) && (c = !0, _.Be(b, d, e))
                };
            d && _.ub(b, d, e)
        }
    };
    var no = function(a, b) {
            this.j = a;
            this.F = b;
            this.o = {}
        },
        oo = function(a) {
            io() && (document.addEventListener("touchstart", function(b) {
                a.j(902, function() {
                    a.o[b.touches[0].identifier] = Date.now()
                })()
            }, ls), document.addEventListener("touchend", function(b) {
                a.j(902, function() {
                    var c = b.changedTouches[0],
                        d = c.clientX,
                        e = c.clientY,
                        f = c.force;
                    c = a.o[c.identifier];
                    if (void 0 !== c) try {
                        var g = io(),
                            h = {
                                x: d,
                                y: e,
                                duration_ms: Date.now() - c
                            };
                        if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.v(Object, "assign").call(Object, {}, h, {
                            type: 1,
                            force: f
                        })));
                        else {
                            var k, l, m;
                            null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (m = l.reportGmaTouchEvent) || m.postMessage(h)
                        }
                    } catch (n) {
                        a.F("paw_sigs", {
                            msg: "reportTouchError",
                            err: n instanceof Error ? n.message : "nonError"
                        })
                    }
                })()
            }, ls))
        },
        jo = function(a, b, c, d, e) {
            var f = 200,
                g = ao;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.Te())),
                k = 0,
                l = function(m) {
                    try {
                        var n = "object" === typeof m.data ? m.data : JSON.parse(m.data);
                        h === n.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), n.signal ? c(n.signal) : n.error && d(n.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == m.data ? "null" : 500 < m.data.length ? m.data.substring(0, 500) : m.data
                        })
                    }
                };
            window.addEventListener("message", function(m) {
                e(903, function() {
                    l(m)
                })()
            });
            a.postMessage(_.v(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        io = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    _.Lf = function() {
        var a = this;
        this.promise = new _.x.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var ZA = function(a) {
        this.K = _.z(a)
    };
    _.S(ZA, _.T);
    ZA.fa = [1];
    var $A = function(a) {
        this.K = _.z(a)
    };
    _.S($A, _.T);
    var aB = function(a, b) {
        return _.ld(a, 1, b, 0)
    };
    var bB = function(a) {
        this.K = _.z(a)
    };
    _.S(bB, _.T);
    var cB = function(a) {
        _.U.call(this);
        this.J = a;
        this.j = [];
        this.o = [];
        this.m = [];
        this.B = []
    };
    _.S(cB, _.U);
    var eB = function(a, b, c) {
        a.o.push({
            Mb: void 0 === c ? !1 : c,
            sb: b
        });
        _.G(Px) && dB(b, a.J)
    };
    cB.prototype.F = function() {
        this.j.length = 0;
        this.m.length = 0;
        if (_.G(Px))
            for (var a = _.y(this.o), b = a.next(); !b.done; b = a.next()) b.value.sb.Gd();
        this.o.length = 0;
        this.B.length = 0;
        _.U.prototype.F.call(this)
    };
    var fB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.v(Object, "setPrototypeOf").call(Object, this, fB.prototype);
        this.name = "InputError"
    };
    _.S(fB, Error);
    var gB = function() {
            this.Ua = !1
        },
        hB = function() {
            gB.apply(this, arguments);
            this.j = [];
            this.jd = new _.Lf
        };
    _.S(hB, gB);
    var jB = function(a, b) {
            a.Ua || (a.Ua = !0, a.tc = b, a.jd.resolve(b), _.G(Px) && iB(a))
        },
        kB = function(a, b) {
            a.Ua = !0;
            a.be = b;
            a.jd.reject(b);
            _.G(Px) && iB(a)
        },
        iB = function(a) {
            for (var b = _.y(a.j), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.tc);
            a.j.length = 0
        };
    hB.prototype.Gd = function() {
        this.j.length = 0
    };
    var dB = function(a, b) {
        _.G(Px) && a.j.push(b)
    };
    _.vr.Object.defineProperties(hB.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.jd.promise
            }
        },
        kb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ua
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.be
            }
        }
    });
    var tm = function() {
        hB.apply(this, arguments)
    };
    _.S(tm, hB);
    q = tm.prototype;
    q.H = function(a) {
        jB(this, a)
    };
    q.Ba = function(a) {
        jB(this, null != a ? a : null)
    };
    q.ha = function() {
        jB(this, null)
    };
    q.Oa = function(a) {
        var b = this;
        a.then(function(c) {
            b.H(c)
        })
    };
    q.Sa = function(a) {
        this.Ua || (this.Ua = !0, this.tc = null, this.be = a, this.jd.reject(a), _.G(Px) && iB(this))
    };
    var lB = function() {
        hB.apply(this, arguments)
    };
    _.S(lB, hB);
    lB.prototype.H = function(a) {
        jB(this, a)
    };
    lB.prototype.Oa = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.H(c)
        })
    };
    lB.prototype.Sa = function(a) {
        this.Ua || (this.Ua = !0, this.be = a, this.jd.reject(a))
    };
    var mB = function() {
        lB.apply(this, arguments)
    };
    _.S(mB, lB);
    mB.prototype.Ba = function(a) {
        jB(this, null != a ? a : null)
    };
    mB.prototype.ha = function() {
        jB(this, null)
    };
    mB.prototype.Oa = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.Ba(c)
        })
    };
    var nB = function(a) {
        this.Ua = !1;
        this.pb = a
    };
    _.S(nB, gB);
    nB.prototype.kb = function() {
        return this.pb.Ua
    };
    nB.prototype.We = function() {
        return null != this.pb.tc
    };
    _.vr.Object.defineProperties(nB.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.pb.be
            }
        }
    });
    var oB = function(a) {
        nB.call(this, a);
        this.pb = a
    };
    _.S(oB, nB);
    _.vr.Object.defineProperties(oB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.pb.tc
            }
        }
    });
    var pB = function(a) {
        nB.call(this, a);
        this.pb = a
    };
    _.S(pB, nB);
    _.vr.Object.defineProperties(pB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.pb.tc) ? a : null
            }
        }
    });
    var qB = function() {
        nB.apply(this, arguments)
    };
    _.S(qB, nB);
    _.vr.Object.defineProperties(qB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.pb.tc) ? a : null
            }
        }
    });
    var jp = function() {
        hB.apply(this, arguments)
    };
    _.S(jp, hB);
    jp.prototype.notify = function() {
        jB(this, null)
    };
    var rB = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        sB = function(a, b) {
            b = void 0 === b ? !1 : b;
            hB.call(this);
            var c = this;
            this.F = a;
            this.o = 0;
            if (_.G(Px)) {
                a = _.y(this.F);
                for (var d = a.next(), e = {}; !d.done; e = {
                        Hc: e.Hc
                    }, d = a.next()) e.Hc = d.value, dB(e.Hc, function(f) {
                    return function(g) {
                        c.o += 1;
                        f.Hc.error ? kB(c, f.Hc.error) : b || null !== g ? jB(c, null != g ? g : null) : c.o === c.F.length && jB(c, null)
                    }
                }(e))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    kB(c, g);
                    return null
                })
            }), _.v(_.x.Promise, "any").call(_.x.Promise, a).then(function(f) {
                c.Ua || jB(c, f)
            }, function() {
                c.Ua || jB(c, null)
            })
        };
    _.S(sB, hB);
    var tB = function(a, b) {
        hB.call(this);
        this.lb = a;
        this.defaultValue = b
    };
    _.S(tB, hB);
    var Tf = function(a) {
        setTimeout(function() {
            var b;
            jB(a, null != (b = a.defaultValue) ? b : null)
        }, a.lb)
    };
    var vB = function(a, b) {
        _.U.call(this);
        var c = this;
        this.id = a;
        this.lb = b;
        this.ra = this.qa = this.oa = this.started = !1;
        this.B = new cB(function() {
            uB(c)
        });
        _.O(this, this.B)
    };
    _.S(vB, _.U);
    vB.prototype.start = function() {
        var a = this,
            b;
        return _.wb(function(c) {
            switch (c.j) {
                case 1:
                    if (a.started) return c.return();
                    a.started = !0;
                    c.F = 2;
                    return xb(c, Uf(a.B.o, a.B.B, a.lb), 4);
                case 4:
                    if (a.N) {
                        c.j = 5;
                        break
                    }
                    for (var d = 0, e = _.y(a.B.m), f = e.next(); !f.done; f = e.next()) {
                        if (!f.value.We()) throw Error("missing input: " + a.id + "/" + d);
                        ++d
                    }
                    return xb(c, a.j(), 5);
                case 5:
                    c.j = 0;
                    c.F = 0;
                    break;
                case 2:
                    b = zb(c);
                    if (a.N) return c.return();
                    b instanceof fB ? a.J(b) : b instanceof Error && (a.V(b), a.o(b));
                    c.j = 0
            }
        })
    };
    var uB = function(a) {
            if (!a.started && a.oa) try {
                var b = a.B.o,
                    c = a.lb ? b.filter(function(k) {
                        return !k.Mb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.Mb
                    }),
                    e, f = null == (e = _.v(b, "find").call(b, function(k) {
                        return void 0 !== k.sb.error
                    })) ? void 0 : e.sb.error;
                if (f) throw a.started = !0, f;
                if (!c.some(function(k) {
                        return !k.sb.kb
                    })) {
                    if (d.length)
                        if (_.G(Sf)) {
                            for (var g = _.y(a.B.B), h = g.next(); !h.done; h = g.next()) Tf(h.value);
                            if (d.some(function(k) {
                                    return !k.sb.kb
                                })) return
                        } else if (a.qa || (a.qa = !0, setTimeout(function() {
                            a.ra = !0;
                            uB(a)
                        }, a.lb)), d.some(function(k) {
                            return !k.sb.kb
                        }) && !a.ra) return;
                    a.started = !0;
                    a.j()
                }
            } catch (k) {
                a.N || (k instanceof fB ? a.J(k) : k instanceof Error && (a.V(k), a.o(k)))
            }
        },
        V = function(a, b) {
            b = void 0 === b ? new tm : b;
            a.B.j.push(b);
            return b
        },
        wB = function(a) {
            var b = void 0 === b ? new lB : b;
            a.B.j.push(b);
            return b
        },
        xB = function(a, b) {
            b = void 0 === b ? new jp : b;
            a.B.j.push(b);
            return b
        },
        W = function(a, b) {
            eB(a.B, b);
            b = new oB(b);
            a.B.m.push(b);
            return b
        },
        X = function(a, b) {
            eB(a.B, b);
            return new pB(b)
        },
        yB = function(a, b) {
            if (_.G(Sf)) {
                if (a.lb) {
                    var c = new tB(a.lb, void 0);
                    b = new sB([b, c], !0);
                    eB(a.B, b, !0);
                    a.B.B.push(c);
                    return new pB(b)
                }
                eB(a.B, b);
                return new pB(b)
            }
            eB(a.B, b, !0);
            return new pB(b)
        },
        zB = function(a, b) {
            eB(a.B, b)
        },
        AB = function(a, b) {
            if (_.G(Sf))
                if (a.lb) {
                    var c = new tB(a.lb);
                    b = new sB([b, c], !0);
                    eB(a.B, b, !0);
                    a.B.B.push(c)
                } else zB(a, b);
            else eB(a.B, b, !0)
        },
        BB = function(a, b) {
            b = new sB(b);
            eB(a.B, b);
            b = new oB(b);
            a.B.m.push(b);
            return b
        };
    vB.prototype.J = function() {};
    vB.prototype.o = function(a) {
        if (this.B.j.length) {
            a = new fB(a.message);
            for (var b = _.y(this.B.j), c = b.next(); !c.done; c = b.next()) c = c.value, c.kb || kB(c, a)
        }
    };
    var ti = function() {
        _.U.apply(this, arguments);
        this.m = [];
        this.J = [];
        this.V = {};
        this.B = [];
        this.o = new _.Lf;
        this.j = {}
    };
    _.S(ti, _.U);
    var K = function(a, b) {
            _.O(a, b);
            a.m.push(b);
            return b
        },
        Oi = function(a, b) {
            b = _.y(b);
            for (var c = b.next(); !c.done; c = b.next()) K(a, c.value)
        },
        $p = function(a, b) {
            a.J.push(b);
            _.O(a, b)
        },
        Di = function(a) {
            var b, c, d, e, f, g, h, k, l, m, n, p;
            return _.wb(function(r) {
                switch (r.j) {
                    case 1:
                        if (!a.B.length) {
                            r.j = 2;
                            break
                        }
                        return xb(r, _.x.Promise.all(a.B.map(function(u) {
                            return u.o.promise
                        })), 2);
                    case 2:
                        b = _.y(a.m);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.G(Px) ? (d.oa = !0, uB(d)) : d.start();
                        e = _.y(a.J);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, Di(g);
                        if (!a.j) {
                            r.j = 4;
                            break
                        }
                        h = _.v(Object, "keys").call(Object, a.j);
                        if (!h.length) {
                            r.j = 4;
                            break
                        }
                        return xb(r, _.x.Promise.all(_.v(Object, "values").call(Object, a.j).map(function(u) {
                            return u.promise
                        })), 6);
                    case 6:
                        for (k = r.o, l = 0, m = _.y(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.V[p] = k[l++];
                    case 4:
                        return a.o.resolve(a.V), r.return(a.o.promise)
                }
            })
        };
    ti.prototype.F = function() {
        _.U.prototype.F.call(this);
        this.m.length = 0;
        this.J.length = 0;
        this.B.length = 0
    };
    var CB = function(a) {
        this.K = _.z(a)
    };
    _.S(CB, _.T);
    CB.fa = [1];
    var DB = [CB, 1, zu, iv];
    var EB = function(a) {
        this.K = _.z(a)
    };
    _.S(EB, _.T);
    EB.fa = [1, 2];
    EB.prototype.j = fe([EB, 1, zu, iv, 2, zu, DB]);
    var GB, FB;
    GB = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new FB;
        this.sideRailProcessedFixedElements = new _.x.Set;
        this.sideRailAvailableSpace = new _.x.Map;
        this.sideRailPlasParam = new _.x.Map
    };
    _.tn = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.x.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.x.Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.x.Map)) : a.google_reactive_ads_global_state = new GB;
        return a.google_reactive_ads_global_state
    };
    FB = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var LB, IB;
    _.HB = function(a) {
        this.j = _.tn(a).floatingAdsStacking
    };
    _.JB = function(a, b) {
        return new IB(a, b)
    };
    _.KB = function(a) {
        a = _.Cw(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    LB = function(a) {
        var b = _.KB(a);
        _.ms(a.j.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    IB = function(a, b) {
        this.o = a;
        this.F = b;
        this.j = null
    };
    _.MB = function(a) {
        if (null == a.j) {
            var b = a.o,
                c = a.F,
                d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            LB(b);
            a.j = d
        }
    };
    _.NB = function(a) {
        if (null != a.j) {
            var b = a.o;
            delete b.j.maxZIndexRestrictions[a.j];
            LB(b);
            a.j = null
        }
    };
    var cg, dg;
    _.un = 728 * 1.38;
    _.bg = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.OB = function(a) {
        var b = _.kn(a).clientWidth;
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    cg = function(a, b) {
        return (a = _.kn(a).clientWidth) ? a > (void 0 === b ? 420 : b) ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    dg = function(a) {
        return (a = _.OB(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.kn = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.PB = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    var jg = function(a, b) {
            b = void 0 === b ? {} : b;
            this.xa = a;
            this.Wa = b
        },
        fg = function(a, b) {
            b = _.y(b);
            for (var c = b.next(); !c.done; c = b.next()) {
                var d = a;
                c = c.value;
                var e = d.xa.document;
                var f = c;
                e.hasOwnProperty("_goog_efp_called_") || (e._goog_efp_called_ = e.elementFromPoint(f.x, f.y));
                if (e = e.elementFromPoint(f.x, f.y)) {
                    if (!(f = QB(d, e, c))) a: {
                        f = d.xa.document;
                        for (e = e.offsetParent; e && e !== f.body; e = e.offsetParent) {
                            var g = QB(d, e, c);
                            if (g) {
                                f = g;
                                break a
                            }
                        }
                        f = null
                    }
                    d = f || null
                } else d = null;
                if (d) return d
            }
            return null
        },
        QB = function(a, b, c) {
            if ("fixed" !== hx(b, "position")) return null;
            var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= _.lh(_.mx, b).width && 1 >= _.lh(_.mx, b).height ? !0 : !1;
            a.Wa.ng && a.Wa.ng(b, c, d);
            return d ? null : b
        };
    var eg = 90 * 1.38;
    var RB;
    _.SB = function(a, b) {
        if (!a.body) return null;
        var c = new RB;
        c.apply(a, b);
        return function() {
            _.ex(a.body, {
                filter: c.j,
                webkitFilter: c.j,
                overflow: c.F,
                position: c.B,
                top: c.N
            });
            b.scrollTo(0, c.o)
        }
    };
    RB = function() {
        this.j = this.N = this.B = this.F = null;
        this.o = 0
    };
    RB.prototype.apply = function(a, b) {
        this.F = a.body.style.overflow;
        this.B = a.body.style.position;
        this.N = a.body.style.top;
        this.j = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.PB(b);
        _.ex(a.body, "top", -this.o + "px")
    };
    _.mn = function(a, b) {
        var c;
        if (!(c = 0 >= b) && !(c = null == a)) {
            try {
                a.setItem("__storage_test__", "__storage_test__");
                var d = a.getItem("__storage_test__");
                a.removeItem("__storage_test__");
                var e = "__storage_test__" === d
            } catch (f) {
                e = !1
            }
            c = !e
        }
        return c ? null : pg(a, b)
    };
    _.ln = function(a) {
        return !!a && 1 > a.length
    };
    var Qj = function(a) {
            var b = void 0 === b ? _.Lg(_.t) : b;
            this.id = a;
            this.o = .001 > Math.random();
            this.j = {
                pvsid: String(b)
            }
        },
        TB = function(a) {
            a = rg(a);
            var b;
            Pg.set(a, (null != (b = Pg.get(a)) ? b : 0) + 1)
        },
        Og = function() {
            return [].concat(_.se(_.v(Pg, "values").call(Pg))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        J = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.j[b] = c : delete a.j[b])
        },
        Sj = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if (UB()) b = !0;
            else {
                var c = a.o;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && iz(window, VB(a) || "", void 0, _.G(Yx))
        },
        VB = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.Ck(a.j, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        WB = function(a) {
            var b = [].concat(_.se(_.v(Pg, "keys").call(Pg)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? J(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), J(a, "nw_id", b.join()))
        },
        Wh = function(a, b) {
            J(a, "vrg", String(b.Ub || b.nb));
            WB(a);
            J(a, "nslots", Og().toString());
            b = _.of();
            b.length && J(a, "eid", b.join());
            J(a, "pub_url", document.URL)
        },
        Qh = function(a, b, c) {
            c = void 0 === c ? .001 : c;
            if (void 0 === c || 0 > c || 1 < c) c = .001;
            Math.random() < c && (a = new Qj(a), b(a), Sj(a))
        },
        Pg = new _.x.Map,
        UB = wh(function() {
            return !!Gw(_.t.location.href)
        });
    var Dg = function() {
        kA.call(this, _.G(Eg) || _.G(By) ? 1 : 0, _.t);
        this.F = 0;
        var a = _.G(Eg) || _.G(By);
        _.t.google_measure_js_timing = a || _.t.google_measure_js_timing
    };
    _.S(Dg, kA);
    _.XB = function(a) {
        this.context = a
    };
    _.XB.prototype.zb = function(a, b) {
        return Hg(this.context, a, b)
    };
    _.XB.prototype.Aa = function(a, b) {
        return Bg(this.context, a, b)
    };
    _.XB.prototype.Gb = function(a, b) {
        Fg(this.context, a, b);
        return !1
    };
    var YB = {},
        ZB = (YB.companion_ads = "companionAds", YB.content = "content", YB.publisher_ads = "pubads", YB);
    var Sg = function(a) {
        this.K = _.z(a)
    };
    _.S(Sg, _.T);
    Sg.prototype.getWidth = function() {
        return vl(this, 1)
    };
    var Xg = function(a, b) {
        return _.I(a, 1, b)
    };
    Sg.prototype.getHeight = function() {
        return vl(this, 2)
    };
    var Wg = function(a, b) {
            return _.I(a, 2, b)
        },
        Vk = function() {
            var a = new Sg;
            return pi(a, 3, !0)
        };
    var cq = function(a) {
        this.K = _.z(a)
    };
    _.S(cq, _.T);
    var Bk = function(a) {
        this.K = _.z(a)
    };
    _.S(Bk, _.T);
    var fk = function(a) {
        this.K = _.z(a)
    };
    _.S(fk, _.T);
    var ek = function(a, b) {
            return Ll(a, 1, b)
        },
        dk = function(a, b) {
            return _.id(a, 2, b, _.Ec)
        },
        $B = function(a, b) {
            return md(a, 2, _.Ec(b))
        };
    fk.fa = [2];
    var Nn = function(a) {
        this.K = _.z(a)
    };
    _.S(Nn, _.T);
    var Tn = function(a, b) {
            return _.I(a, 1, b)
        },
        Rn = function(a, b) {
            return _.id(a, 2, b, _.Ec)
        };
    Nn.fa = [2];
    var Ip = function(a) {
        this.K = _.z(a)
    };
    _.S(Ip, _.T);
    var Sn = function(a, b) {
        qi(a, 1, Nn, b)
    };
    Ip.fa = [1];
    var Gp = function(a) {
        this.K = _.z(a)
    };
    _.S(Gp, _.T);
    Gp.fa = [2, 3];
    var Ep = function(a) {
        this.K = _.z(a)
    };
    _.S(Ep, _.T);
    var aC = function(a) {
        this.K = _.z(a)
    };
    _.S(aC, _.T);
    aC.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.I(this, 5, a)
    };
    aC.prototype.clearTagForChildDirectedTreatment = function() {
        return Cp(this, 5)
    };
    aC.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.I(this, 6, a)
    };
    var bC = function(a) {
        this.K = _.z(a)
    };
    _.S(bC, _.T);
    bC.prototype.getCategoryExclusions = function(a) {
        return ju(this, 3, a)
    };
    bC.prototype.Ea = function() {
        return Oe(this, fk, 14)
    };
    bC.prototype.Qb = function() {
        return _.Rg(this, Bk, 18)
    };
    var ar = function(a) {
        return _.Rg(a, aC, 25)
    };
    bC.prototype.getCorrelator = function() {
        return sd(Xd(this, 26), 0)
    };
    bC.prototype.setCorrelator = function(a) {
        return _.I(this, 26, a)
    };
    bC.prototype.Qd = function() {
        return Fp(this, Ep, 33)
    };
    bC.fa = [2, 3, 14];
    var qh = function() {
        this.j = new _.x.Map
    };
    var cC = {},
        eh = (cC[23] = .001, cC[253] = !1, cC[246] = [], cC[150] = "", cC[221] = /^true$/.test("false"), cC[36] = /^true$/.test("false"), cC[172] = null, cC[260] = void 0, cC[251] = null, cC),
        dh = function() {
            this.j = !1
        };
    var dC = function() {
            this.o = {};
            this.j = new bC;
            this.F = new _.x.Map;
            this.j.setCorrelator(Vw());
            _.fh(36) && pi(this.j, 15, !0)
        },
        eC = function(a) {
            var b = Fh(),
                c = a.getDomId();
            if (c && !b.o.hasOwnProperty(c)) {
                var d = _.lf(qh),
                    e = ++_.lf(Dg).F;
                d.j.set(c, e);
                _.I(a, 20, e);
                b.o[c] = a
            }
        },
        fC = function(a, b) {
            return a.o[b]
        },
        Fh = function() {
            return _.lf(dC)
        };
    var gC = wh(th);
    var di = ["auto", "inherit", "100%"],
        ei = di.concat(["none"]);
    var Cl = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        bi(a, function(e) {
            return d = ci(e, b, 10, 10)
        }, c);
        return d
    };
    var hC = function(a, b, c, d, e, f) {
            this.F = a.clone();
            this.o = b.clone();
            this.B = c;
            this.j = d.clone();
            this.N = e;
            this.m = f
        },
        iC = function(a) {
            return JSON.stringify({
                windowCoords_t: a.F.top,
                windowCoords_r: a.F.right,
                windowCoords_b: a.F.bottom,
                windowCoords_l: a.F.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.B,
                allowedExpansion_t: a.j.top,
                allowedExpansion_r: a.j.right,
                allowedExpansion_b: a.j.bottom,
                allowedExpansion_l: a.j.left,
                xInView: a.N,
                yInView: a.m
            })
        },
        jC = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Zw(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = jx(a);
            d = _.lh(_.mx, a);
            var e = new $w(c.x, c.y, d.width, d.height);
            c = ax(e);
            d = String(hx(a, "zIndex"));
            var f = new _.Zw(0, Infinity, Infinity, 0);
            for (var g = kw(a), h = g.j.body, k = g.j.documentElement, l = pw(g.j); a = ix(a);)
                if (!(_.At && 0 == a.clientWidth || Dt && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != hx(a, "overflow")) {
                    var m = jx(a),
                        n = new _.jh(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.j;
            g = _.ow(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new $w(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? bx(e, f) : null;
            g = a = 0;
            l && !(new _.oh(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Zw(0, 0, 0, 0);
            if (h = f)(e = bx(e, f)) ? (k = ax(f), m = ax(e), h = m.right != k.left && k.right != m.left, k = m.bottom != k.top && k.bottom != m.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Zw(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new hC(b, c, d, l, a, g)
        };
    var kC = function(a) {
        this.B = a;
        this.N = null;
        this.D = this.status = 0;
        this.o = null;
        this.mb = "sfchannel" + a
    };
    var lC = function(a) {
        this.j = a
    };
    lC.prototype.getValue = function(a, b) {
        return null == this.j[a] || null == this.j[a][b] ? null : this.j[a][b]
    };
    var mC = function(a, b) {
        this.Md = a;
        this.Nd = b;
        this.o = this.j = !1
    };
    var nC = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.o = a;
        this.F = b;
        this.B = c;
        this.permissions = d;
        this.metadata = e;
        this.N = f;
        this.Xc = g;
        this.hostpageLibraryTokens = h;
        this.j = ""
    };
    var oC = function(a, b) {
        this.o = a;
        this.B = b
    };
    oC.prototype.j = function(a) {
        this.B && a && (a.sentinel = this.B);
        return JSON.stringify(a)
    };
    var pC = function(a, b, c) {
        oC.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.S(pC, oC);
    pC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var qC = function(a, b, c, d) {
        oC.call(this, a, void 0 === d ? "" : d);
        this.N = b;
        this.F = c
    };
    _.S(qC, oC);
    qC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o,
            initialWidth: this.N,
            initialHeight: this.F
        })
    };
    var rC = function(a, b, c) {
        oC.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.S(rC, oC);
    rC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var sC = function(a, b, c, d) {
        oC.call(this, a, void 0 === d ? "" : d);
        this.F = b;
        this.push = c
    };
    _.S(sC, oC);
    sC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o,
            expand_t: this.F.top,
            expand_r: this.F.right,
            expand_b: this.F.bottom,
            expand_l: this.F.left,
            push: this.push
        })
    };
    var tC = function(a, b) {
        oC.call(this, a, void 0 === b ? "" : b)
    };
    _.S(tC, oC);
    tC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o
        })
    };
    var uC = function(a, b, c) {
        oC.call(this, a, void 0 === c ? "" : c);
        this.N = b
    };
    _.S(uC, oC);
    uC.prototype.j = function() {
        var a = {
            uid: this.o,
            newGeometry: iC(this.N)
        };
        return oC.prototype.j.call(this, a)
    };
    var vC = function(a, b, c, d, e, f) {
        uC.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.F = d;
        this.push = e
    };
    _.S(vC, uC);
    vC.prototype.j = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: iC(this.N),
            expand_t: this.F.top,
            expand_r: this.F.right,
            expand_b: this.F.bottom,
            expand_l: this.F.left,
            push: this.push
        };
        this.B && (a.sentinel = this.B);
        return JSON.stringify(a)
    };
    var wC = function(a, b, c, d) {
        oC.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.S(wC, oC);
    wC.prototype.j = function() {
        return oC.prototype.j.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var xC = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        wj(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var yC = function() {
            this.j = []
        },
        AC = function(a, b, c, d, e) {
            a.j.push(new zC(b, c, d, e))
        },
        BC = function(a) {
            for (var b = a.j.length - 1; 0 <= b; b--) {
                var c = a.j[b];
                c.o ? (c.F.style.removeProperty(c.j), c.F.style.setProperty(c.j, String(c.B), c.N)) : c.F.style[c.j] = c.B
            }
            a.j.length = 0
        },
        zC = function(a, b, c, d) {
            this.F = a;
            this.j = (this.o = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
            this.B = this.o ? a.style.getPropertyValue(this.j) : a.style[this.j];
            this.N = this.o ? a.style.getPropertyPriority(this.j) : void 0;
            this.o ? (a.style.removeProperty(this.j), a.style.setProperty(this.j, String(c), d)) : a.style[this.j] = String(c)
        };
    var CC, DC;
    CC = function(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    DC = function() {
        var a = window,
            b = _.gf(a);
        b && CC({
            label: "2",
            type: 9,
            value: b
        }, a)
    };
    _.EC = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = d || window,
            g = "undefined" !== typeof queueMicrotask;
        return function() {
            e && g && queueMicrotask(function() {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var h = _.gf(),
                k = 3;
            try {
                var l = b.apply(this, arguments)
            } catch (m) {
                k = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && h && CC(_.v(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (_.gf() || 0) - h,
                    type: k
                }, e && g && {
                    taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                }), f)
            }
            return l
        }
    };
    var JC = function(a) {
        kC.call(this, a.uniqueId);
        var b = this;
        this.J = a.Yk;
        this.V = 1 === a.size;
        this.aa = new mC(a.permissions.Md && !this.V, a.permissions.Nd && !this.V);
        this.m = a.uf;
        var c;
        this.za = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.sa = "file:" == c ? "*" : c + "//" + d;
        this.Ca = !!a.Xc;
        this.T = a.Sg ? "//" + a.Sg + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.ka = a.eb ? "*" : "https:" + this.T;
        this.da = !!a.di;
        this.ra = FC(a);
        this.F = new yC;
        GC(this, a.uf, a.size);
        this.N = this.qa = jC(a.uf);
        this.M = a.rj || "1-0-40";
        var e;
        this.ia = null != (e = a.Oh) ? e : "";
        HC(this, a);
        this.pa = _.EC(412, function() {
            return IC(b)
        }, a.bb);
        this.I = -1;
        this.A = 0;
        var f = _.EC(415, function() {
            b.j && (b.j.name = "", a.Dg && a.Dg(), _.Be(b.j, "load", f))
        }, a.bb);
        _.ub(this.j, "load", f);
        this.Ye = _.EC(413, this.Ye, a.bb);
        this.yf = _.EC(417, this.yf, a.bb);
        this.Cf = _.EC(419, this.Cf, a.bb);
        this.Re = _.EC(411, this.Re, a.bb);
        this.Ee = _.EC(409, this.Ee, a.bb);
        this.W = _.EC(410, this.W, a.bb);
        this.nf = _.EC(416, this.nf, a.bb);
        this.o = new LA(this.mb, this.j.contentWindow, this.ka, !1);
        NA(this.o, "init_done", (0, _.$r)(this.Ye, this));
        NA(this.o, "register_done", (0, _.$r)(this.yf, this));
        NA(this.o, "report_error", (0, _.$r)(this.Cf, this));
        NA(this.o, "expand_request", (0, _.$r)(this.Re, this));
        NA(this.o, "collapse_request", (0, _.$r)(this.Ee, this));
        NA(this.o, "creative_geometry_update", (0, _.$r)(this.W, this));
        this.o.connect((0, _.$r)(this.nf, this))
    };
    _.S(JC, kC);
    var GC = function(a, b, c) {
            a.V ? (b.style.width = _.lx("100%", !0), b.style.height = _.lx("auto", !0)) : (b.style.width = _.lx(c.width, !0), b.style.height = _.lx(c.height, !0))
        },
        HC = function(a, b) {
            var c = b.eb,
                d = b.content,
                e = b.Vc,
                f = b.size,
                g = void 0 === b.Wc ? "3rd party ad content" : b.Wc,
                h = b.Od;
            b = b.Ae;
            var k = {
                shared: {
                    sf_ver: a.M,
                    ck_on: Wz() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.M + ";" + d.length + ";" + d;
            k = new nC(a.B, a.sa, a.qa, a.aa, new lC(k), a.V, a.Ca, a.za);
            var l = {};
            l.uid = k.o;
            l.hostPeerName = k.F;
            l.initialGeometry = iC(k.B);
            var m = k.permissions;
            m = JSON.stringify({
                expandByOverlay: m.Md,
                expandByPush: m.Nd,
                readCookie: m.j,
                writeCookie: m.o
            });
            l = (l.permissions = m, l.metadata = JSON.stringify(k.metadata.j), l.reportCreativeGeometry = k.N, l.isDifferentSourceWindow = k.Xc, l.goog_safeframe_hlt = AA(k.hostpageLibraryTokens), l);
            k.j && (l.sentinel = k.j);
            k = JSON.stringify(l);
            d += k;
            a.da && f instanceof _.oh && (k = _.qw(_.jw(a.m)), l = _.qw(_.jw(a.m)).location.protocol + a.T, pA || _.Tj(k.document, qA), pA++, k.google_eas_queue = k.google_eas_queue || [], k.google_eas_queue.push({
                a: e,
                b: l,
                c: f.width,
                d: f.height,
                e: "sf-gdn-exp-" + pA,
                f: void 0,
                g: void 0,
                h: void 0,
                i: void 0
            }));
            k = f.width;
            f = f.height;
            a.V && (f = k = 0);
            l = {};
            e = (l.id = e, l.title = g, l.name = d, l.scrolling = "no", l.marginWidth = "0", l.marginHeight = "0", l.width = String(k), l.height = String(f), l["data-is-safeframe"] = "true", l);
            void 0 === c && (g = _.qw(_.jw(a.m)), f = a.ia, d = a.T, (k = f) && (k = "?" + k), d = (void 0 === d ? "//tpc.googlesyndication.com" : d) + ("/safeframe/" + a.M + "/html/container.html" + k), (k = xC(g)) && (d += (f ? "&" : "?") + "n=" + k), f = "https:" + d, d = [], a.da && (k = Gw(g.location.href), g = d.push, k = [0 < k.length ? "google_debug" + (k ? "=" + k : "") + "&" : "", "xpc=", "sf-gdn-exp-" + a.B, "&p=", encodeURIComponent(_.t.document.location.protocol), "//", encodeURIComponent(_.t.document.location.host)].join(""), g.call(d, k)), d.length && (f += "#" + d.join("&")), e.src = f);
            null !== a.ra && (e.sandbox = a.ra);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.j = c, mw(a.j, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ea(c, e), h = _.Ae("IFRAME"), mw(h, c), a.j = h);
            a.V && (a.j.style.minWidth = "100%");
            a.m.appendChild(a.j)
        };
    q = JC.prototype;
    q.nf = function() {
        _.ub(window, "resize", this.pa);
        _.ub(window, "scroll", this.pa)
    };
    q.Ye = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new pC(b.uid, b.version, b.sentinel);
            if (this.B !== c.o || this.M !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.J) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    q.yf = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.B !== (new qC(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.J) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    q.Cf = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new rC(b.uid, b.description, b.sentinel);
            if (this.B !== c.o) throw Error("Wrong source container");
            var d;
            null == (d = this.J) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.J) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    q.Re = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.D) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new sC(b.uid, new _.Zw(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.B !== c.o) throw Error("Wrong source container");
            if (!(0 <= c.F.top && 0 <= c.F.left && 0 <= c.F.bottom && 0 <= c.F.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.aa.Nd || !c.push && this.aa.Md) {
                var e = c.F,
                    f = c.push,
                    g = this.N = jC(this.j);
                if (e.top <= g.j.top && e.right <= g.j.right && e.bottom <= g.j.bottom && e.left <= g.j.left) {
                    if (!f)
                        for (var h = this.j.parentNode; h && h.style; h = h.parentNode) AC(this.F, h, "overflowX", "visible", "important"), AC(this.F, h, "overflowY", "visible", "important");
                    var k = ax(new $w(0, 0, this.N.o.getWidth(), this.N.o.getHeight()));
                    _.ha(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    AC(this.F, this.m, "position", "relative");
                    AC(this.F, this.j, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        AC(this.F, this.m, "width", l + "px");
                        var m = k.getHeight();
                        AC(this.F, this.m, "height", m + "px")
                    } else AC(this.F, this.j, "zIndex", "10000");
                    var n = k.getWidth();
                    AC(this.F, this.j, "width", n + "px");
                    var p = k.getHeight();
                    AC(this.F, this.j, "height", p + "px");
                    AC(this.F, this.j, "left", k.left + "px");
                    AC(this.F, this.j, "top", k.top + "px");
                    this.D = 2;
                    this.N = jC(this.j);
                    d = !0
                } else d = !1
            }
            a = d;
            OA(this.o, "expand_response", (new vC(this.B, a, this.N, c.F, c.push)).j());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (u) {
            var r;
            null == (r = this.J) || r.error("Invalid EXPAND_REQUEST message. Reason: " + u.message)
        }
    };
    q.Ee = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (2 != this.D) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid)) throw Error("Cannot parse JSON message");
            if (this.B !== (new tC(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            BC(this.F);
            this.D = 0;
            this.j && (this.N = jC(this.j));
            OA(this.o, "collapse_response", (new uC(this.B, this.N)).j())
        } catch (d) {
            var c;
            null == (c = this.J) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var IC = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.A) {
            case 0:
                KC(a);
                a.I = window.setTimeout((0, _.$r)(a.oa, a), 1E3);
                a.A = 1;
                break;
            case 1:
                a.A = 2;
                break;
            case 2:
                a.A = 2
        }
    };
    JC.prototype.W = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ha(b) || !gi(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new wC(b.uid, b.width, b.height, b.sentinel);
            if (this.B !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.V) d !== this.j.height && (this.j.height = d, IC(this));
            else {
                var e;
                null == (e = this.J) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.J) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    JC.prototype.oa = function() {
        if (1 == this.status || 2 == this.status) switch (this.A) {
            case 1:
                this.A = 0;
                break;
            case 2:
                KC(this), this.I = window.setTimeout((0, _.$r)(this.oa, this), 1E3), this.A = 1
        }
    };
    var KC = function(a) {
            a.N = jC(a.j);
            OA(a.o, "geometry_update", (new uC(a.B, a.N)).j())
        },
        FC = function(a) {
            var b = null;
            a.Ug && (b = a.Ug);
            return null == b ? null : b.join(" ")
        },
        LC = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        MC = ["allow-top-navigation"],
        NC = ["allow-same-origin"],
        OC = Jw([].concat(_.se(LC), _.se(MC)));
    Jw([].concat(_.se(LC), _.se(NC)));
    Jw([].concat(_.se(LC), _.se(MC), _.se(NC)));
    var PC = _.Ar(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        QC = {
            Ki: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.ke) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.ke)) throw new RangeError("Invalid subdomain: " + a.ke);
                return je("https://" + a.ke + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            el: function(a) {
                return _.ke(PC, a)
            }
        };
    var RC = function() {};
    RC.j = function() {
        throw Error("Must be overridden");
    };
    var hi = function() {
        this.j = 0
    };
    _.S(hi, RC);
    hi.Sb = void 0;
    hi.j = function() {
        return hi.Sb ? hi.Sb : hi.Sb = new hi
    };
    var SC = function() {
            this.cache = {}
        },
        ni = function() {
            TC || (TC = new SC);
            return TC
        },
        oi = function(a) {
            var b = Xd(a, 3);
            if (!b) return 3;
            if (void 0 === _.bh(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    SC.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            Yb: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            ii(6, a, null == (d = g) ? void 0 : d.message);
            return {
                Yb: null,
                success: !1
            }
        }
        if (!c) return {
            Yb: null,
            success: !0
        };
        try {
            var e = yv(c);
            this.cache[a] = e;
            return {
                Yb: e,
                success: !0
            }
        } catch (g) {
            var f;
            ii(5, a, null == (f = g) ? void 0 : f.message);
            return {
                Yb: null,
                success: !1
            }
        }
    };
    SC.prototype.set = function(a, b) {
        var c = _.bh(a, 1),
            d = "_GESPSK-" + c;
        _.I(a, 3, Date.now());
        try {
            b.setItem(d, Le(a))
        } catch (f) {
            var e;
            ii(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var TC = null;
    var UC = function(a, b) {
        vB.call(this, a);
        this.id = a;
        this.D = b
    };
    _.S(UC, vB);
    UC.prototype.V = function(a) {
        this.D(this.id, a)
    };
    var vi = function(a, b, c, d) {
        UC.call(this, 1041, d);
        this.storage = b;
        this.A = W(this, a);
        c && (this.m = X(this, c))
    };
    _.S(vi, UC);
    vi.prototype.j = function() {
        var a = this.A.value,
            b, c, d = null != (c = this.storage) ? c : null == (b = this.m) ? void 0 : b.value;
        d && ni().set(a, d) && null != _.bh(a, 2) && ii(27, _.bh(a, 1))
    };
    var xi = function(a, b) {
        UC.call(this, 1048, b);
        this.m = V(this);
        this.A = V(this);
        this.I = W(this, a)
    };
    _.S(xi, UC);
    xi.prototype.j = function() {
        var a = this.I.value,
            b = function(c) {
                var d = {};
                ii(c, _.bh(a, 1), null, (d.tic = String(Math.round((Date.now() - Xd(a, 3)) / 6E4)), d))
            };
        switch (oi(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.A.H(a);
                break;
            case 2:
                b(26);
                this.m.H(a);
                break;
            case 3:
                ii(9, _.bh(a, 1));
                this.m.H(a);
                break;
            case 4:
                b(23), this.m.H(a)
        }
    };
    var VC = function(a, b) {
        UC.call(this, 1094, b);
        this.m = xB(this);
        this.A = W(this, a)
    };
    _.S(VC, UC);
    VC.prototype.j = function() {
        var a = this.A.value;
        if (a) {
            if (void 0 !== a)
                for (var b = _.y(_.v(Object, "keys").call(Object, a)), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, _.v(c, "startsWith").call(c, "_GESPSK")) try {
                        a.removeItem(c)
                    } catch (d) {}
            TC = new SC;
            this.m.notify()
        }
    };
    var Ni = function(a, b, c) {
        UC.call(this, 1049, c);
        this.storage = b;
        zB(this, a)
    };
    _.S(Ni, UC);
    Ni.prototype.j = function() {
        for (var a = _.y(mi(this.storage)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = ni().get(b, this.storage).Yb;
            if (c) {
                var d = oi(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = ni();
                    c = _.bh(c, 1);
                    try {
                        this.storage.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        ii(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    ii(40, b)
                }
            }
        }
    };
    var ui = function(a, b, c) {
        UC.call(this, 1027, c);
        this.Hd = a;
        this.storage = b;
        this.m = V(this);
        this.A = V(this)
    };
    _.S(ui, UC);
    ui.prototype.j = function() {
        var a = ni().get(this.Hd, this.storage).Yb;
        a || (a = xv(this.Hd), a = _.I(a, 3, Date.now()), this.A.H(a.Sa(vv(100))));
        this.m.H(a)
    };
    var Fi = {};
    var Ri = function(a, b) {
        UC.call(this, 1036, b);
        this.m = V(this);
        this.A = W(this, a)
    };
    _.S(Ri, UC);
    Ri.prototype.j = function() {
        var a = this.A.value;
        0 !== oi(a) && this.m.H(a)
    };
    var Bi = function(a, b, c) {
        UC.call(this, 1046, c);
        this.C = xB(this);
        this.m = V(this);
        this.A = W(this, b);
        zB(this, a)
    };
    _.S(Bi, UC);
    Bi.prototype.j = function() {
        this.m.H(this.A.value)
    };
    var yi = function(a, b, c) {
        UC.call(this, 1047, c);
        this.collectorFunction = a;
        this.m = V(this);
        this.A = V(this);
        this.I = V(this);
        this.M = W(this, b)
    };
    _.S(yi, UC);
    yi.prototype.j = function() {
        var a = this,
            b = this.M.value,
            c = _.bh(b, 1);
        ii(18, c);
        try {
            var d = _.ff();
            this.collectorFunction().then(function(e) {
                ii(29, c, null, {
                    delta: String(_.ff() - d)
                });
                a.m.H(Ll(b, 2, e));
                a.I.Ba(e)
            }).catch(function(e) {
                ii(28, c, si(e));
                a.A.H(b.Sa(vv(106)))
            })
        } catch (e) {
            ii(1, c, si(e)), this.A.H(b.Sa(vv(107)))
        }
    };
    var wi = function(a, b) {
        UC.call(this, 1028, b);
        this.m = V(this);
        this.A = W(this, a)
    };
    _.S(wi, UC);
    wi.prototype.j = function() {
        var a = this.A.value,
            b = _.bh(a, 1);
        null != Xd(a, 3) || ii(35, b);
        this.m.H(a)
    };
    var zi = function(a, b, c, d, e) {
        UC.call(this, 1050, e);
        this.M = c;
        this.I = d;
        this.m = V(this);
        this.A = W(this, a);
        this.T = X(this, b)
    };
    _.S(zi, UC);
    zi.prototype.j = function() {
        var a = this.A.value,
            b = _.bh(a, 1),
            c = this.T.value;
        if (null == c) ii(41, b), a.Sa(vv(111)), this.m.H(a);
        else if ("string" !== typeof c) ii(21, b), this.m.H(a.Sa(vv(113)));
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.I : this.M)) {
                var d = {};
                ii(12, b, null, (d.sl = String(c.length), d));
                b = a.Sa(vv(108));
                Cp(b, 2)
            } else c.length || ii(20, b), Cp(a, 10);
            this.m.H(a)
        }
    };
    var Ai = function(a) {
        UC.call(this, 1046, a);
        this.C = xB(this)
    };
    _.S(Ai, UC);
    Ai.prototype.j = function() {
        var a = this;
        li().then(function() {
            return a.C.notify()
        })
    };
    var WC = function(a, b, c, d) {
        UC.call(this, 1059, d);
        this.M = b;
        this.I = c;
        this.m = V(this);
        this.T = W(this, a);
        this.A = X(this, c)
    };
    _.S(WC, UC);
    WC.prototype.j = function() {
        var a = this.A.value;
        if (a) {
            var b = this.T.value,
                c = b.id,
                d = b.collectorFunction,
                e;
            b = null != (e = b.networkCode) ? e : c;
            c = {};
            ii(42, b, null, (c.ea = String(Number(this.M)), c));
            this.m.Oa(Ei(b, d, a, this.I, this.D))
        }
    };
    var XC = function(a, b) {
        UC.call(this, 1057, b);
        this.m = a;
        this.A = V(this);
        this.I = V(this)
    };
    _.S(XC, UC);
    XC.prototype.j = function() {
        if (this.m)
            if ("object" !== typeof this.m) ii(46, "UNKNOWN_COLLECTOR_ID"), YC(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.m.id,
                    b = this.m.networkCode;
                a && b && (delete this.m.id, ii(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, ii(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), YC(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.m.collectorFunction ? (ii(14, a), YC(this, a, 105)) : (_.C = sf(xy), _.v(_.C, "includes")).call(_.C, a) ? (ii(22, a), YC(this, a, 104)) : this.I.H(this.m)
            }
        else ii(39, "UNKNOWN_COLLECTOR_ID"), YC(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var YC = function(a, b, c) {
        a.A.H(xv(b).Sa(vv(c)))
    };
    var Li = function(a, b, c, d, e) {
        var f = document;
        f = void 0 === f ? document : f;
        e = void 0 === e ? Fi : e;
        this.j = b;
        this.F = c;
        this.Z = f;
        this.A = d;
        this.J = e;
        this.m = [];
        this.N = [];
        this.B = [];
        this.o = 0;
        a = _.y(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    Li.prototype.push = function(a) {
        var b = this;
        this.F || this.A();
        var c = function(f, g) {
            return void ZC(b, f, g)
        };
        a = new XC(a, c);
        var d = new vi(a.A, void 0, this.j, c);
        c = new WC(a.I, this.F, this.j, c, this.J);
        var e = new ti;
        Oi(e, [a, d, c]);
        Di(e);
        a = c.m.promise;
        this.m.push(a);
        d = _.y(this.N);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    Li.prototype.addOnSignalResolveCallback = function(a) {
        this.N.push(a);
        for (var b = _.y(this.m), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    Li.prototype.addErrorHandler = function(a) {
        this.B.push(a)
    };
    Li.prototype.clearAllCache = function() {
        var a = this,
            b = this.Z.currentScript instanceof HTMLScriptElement ? this.Z.currentScript.src : "";
        if (1 === this.o) {
            var c = {};
            ii(49, "", null, (c.url = b, c))
        } else if (c = String(_.Af(null != b ? b : "")), (_.C = sf(wy), _.v(_.C, "includes")).call(_.C, c)) c = {}, ii(48, "", null, (c.url = b, c));
        else {
            var d = new ti;
            c = new VC(this.j, function(e, f) {
                return void ZC(a, e, f)
            });
            K(d, c);
            Di(d);
            this.o = 1;
            setTimeout(function() {
                a.o = 0
            }, 1E3 * _.rf(vy));
            d = {};
            ii(43, "", null, (d.url = b, d));
            return c.m.promise
        }
    };
    var ZC = function(a, b, c) {
            a = _.y(a.B);
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, d(b, c)
        },
        Mi = function(a) {
            this.push = function(b) {
                a.push(b)
            };
            this.addOnSignalResolveCallback = function(b) {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = function(b) {
                a.addErrorHandler(b)
            };
            this.clearAllCache = function() {
                a.clearAllCache()
            }
        };
    var Si = function(a, b, c) {
        UC.call(this, 1035, c);
        this.A = b;
        this.m = V(this);
        this.I = W(this, a)
    };
    _.S(Si, UC);
    Si.prototype.j = function() {
        var a = this,
            b = this.I.value,
            c = _.bh(b, 1),
            d = this.A.toString(),
            e = {};
        ii(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        jb(f, this.A);
        var g = function() {
            var h = {};
            ii(31, c, null, (h.url = d, h));
            a.m.H(b.Sa(vv(109)));
            _.Be(f, "error", g)
        };
        document.head.appendChild(f);
        _.ub(f, "error", g)
    };
    var Qi = new _.x.Set;
    var Vi = function(a, b) {
        try {
            Db(po(a, b))
        } catch (c) {}
    };
    var $C = function(a) {
        this.K = _.z(a)
    };
    _.S($C, _.T);
    $C.prototype.j = fe([$C, 4, su, 2, su, 1, su, 3, su, 5, vu]);
    var aD = [.05, .1, .2, .5],
        bD = [0, .5, 1],
        cD = function(a) {
            a = Hi(a);
            if (!a) return -1;
            try {
                var b = rA(a.document);
                var c = new _.oh(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.oh(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        dD = function(a, b) {
            return 0 >= a || 0 >= b ? [] : _.ns(aD, function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        fD = function(a) {
            this.N = a.G;
            this.F = a.Eb;
            this.m = a.timer;
            this.o = null;
            this.B = a.bb;
            this.j = eD(this);
            this.J = a.vj || !1
        },
        rD = function() {
            var a;
            return !!window.IntersectionObserver && Lw(null == (a = window.performance) ? void 0 : a.now)
        };
    fD.prototype.getSlotId = function() {
        return this.o
    };
    var zD = function(a, b) {
            if (a.j) {
                if (null != a.o) {
                    try {
                        yD(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.B && a.B(c)
                    }
                    a.j && a.j.unobserve(a.F)
                }
                a.o = b;
                a.j.observe(a.F)
            }
        },
        eD = function(a) {
            if (!_.t.IntersectionObserver) return null;
            var b = a.F.offsetWidth * a.F.offsetHeight,
                c = cD(a.N);
            b = [].concat(_.se(bD), _.se(dD(c, b)));
            ma(b);
            return new _.t.IntersectionObserver(function(d) {
                return AD(a, d)
            }, {
                threshold: b
            })
        },
        AD = function(a, b) {
            try {
                var c = cD(a.N);
                _.ms(b, function(d) {
                    a.J && yD(a, Math.round(d.time), d.boundingClientRect.width * d.boundingClientRect.height, d.intersectionRect.width * d.intersectionRect.height, c, d.isIntersecting)
                })
            } catch (d) {
                a.B && a.B(d)
            }
        },
        yD = function(a, b, c, d, e, f) {
            if (null == a.o) throw Error("Not Attached.");
            var g = new $C;
            c = _.I(g, 1, c);
            d = _.I(c, 2, d);
            e = _.I(d, 3, e);
            b = _.I(e, 4, b);
            f = pi(b, 5, f);
            f = Ib(f.j(), 4);
            lA(a.m, "1", 10, f, void 0, a.o)
        };
    var BD = function(a, b) {
            this.j = a;
            this.o = b
        },
        CD = function(a) {
            if (a.j.frames.google_ads_top_frame) return !0;
            var b = Nw(a.j);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var hj = function(a) {
        this.K = _.z(a)
    };
    _.S(hj, _.T);
    var lj = ge(hj),
        jj = [1, 3];
    var De = {
        Sk: 0,
        Ok: 1,
        Pk: 9,
        Lk: 2,
        Mk: 3,
        Rk: 5,
        Qk: 7,
        Nk: 10
    };
    var DD = _.Ar(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        bj = _.ke(DD);
    var ED = function() {
            this.id = "goog_" + fw++
        },
        FD = function(a) {
            _.U.call(this);
            this.context = a;
            this.o = new _.x.Map
        };
    _.S(FD, _.U);
    FD.prototype.F = function() {
        _.U.prototype.F.call(this);
        this.o.clear()
    };
    FD.prototype.listen = function(a, b) {
        var c = this;
        if (this.N) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.o.get(d)) ? void 0 : e.add(b)) ? f : new _.x.Set([b]);
        this.o.set(d, g);
        return function() {
            return void GD(c, a, b)
        }
    };
    var ID = function(a) {
            var b = HD;
            var c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.x.Promise(function(d) {
                var e = a.listen(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        GD = function(a, b, c) {
            var d;
            return !(null == (d = a.o.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        },
        cp = function(a, b, c, d) {
            var e, f, g, h, k, l, m, n;
            _.wb(function(p) {
                e = "string" === typeof b ? b : b.id;
                f = a.o.get(e);
                if (null == (g = f) || !g.size) return p.return();
                h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                    detail: d,
                    bubbles: !0,
                    cancelable: !0
                }) : function() {
                    var r = document.createEvent("CustomEvent");
                    r.initCustomEvent(e, !0, !0, d);
                    return r
                }();
                k = [];
                l = _.y(f);
                m = l.next();
                for (n = {}; !m.done; n = {
                        ud: n.ud
                    }, m = l.next()) n.ud = m.value, k.push(new _.x.Promise(function(r) {
                    return function(u) {
                        return _.wb(function(w) {
                            if (1 == w.j) return xb(w, 0, 2);
                            Hg(a.context, c, function() {
                                a.o.has(e) && f.has(r.ud) && r.ud(h)
                            }, !0);
                            u();
                            w.j = 0
                        })
                    }
                }(n)));
                return xb(p, _.x.Promise.all(k), 0)
            })
        },
        JD = new ED,
        KD = new ED,
        dp = new ED,
        LD = new ED,
        fp = new ED,
        MD = new ED,
        ND = new ED,
        ul = new ED,
        HD = new ED,
        OD = new ED;
    var PD = function() {
            this.data = void 0;
            this.status = 0;
            this.j = []
        },
        QD = function(a) {
            a.data = void 0;
            a.status = 1
        };
    PD.prototype.Rc = function() {
        return this.j
    };
    PD.prototype.Gd = function() {
        this.j = []
    };
    var RD, VD, YD, Kq, ZD, UD, TD, SD, $D;
    RD = function() {
        this.j = new _.x.Map;
        this.m = 0;
        this.o = new _.x.Map;
        this.Jd = null;
        this.B = this.F = this.V = this.J = 0;
        this.A = new PD;
        this.N = new PD
    };
    VD = function(a, b) {
        a.j.get(b) || (a.j.set(b, {
            Wb: !0,
            sf: "",
            Lc: "",
            Pg: 0,
            yg: 0,
            pf: [],
            qf: [],
            Rb: !1
        }), _.zn(b, function() {
            a.j.delete(b);
            SD(a, b)
        }), b.listen(KD, function(c) {
            c = c.detail;
            var d = a.j.get(b);
            d.sf = _.bh(c, 33) || "";
            d.Rb = !0;
            TD(a, b, function() {
                return void(d.sf = "")
            });
            UD(a, b, function() {
                return void(d.Rb = !1)
            })
        }))
    };
    _.ep = function(a, b) {
        var c;
        return null == (c = a.j.get(b)) ? void 0 : c.Wb
    };
    _.WD = function(a, b) {
        if (a = a.j.get(b)) a.Wb = !1
    };
    _.XD = function(a, b) {
        if (a = a.j.get(b)) a.Wb = !0
    };
    YD = function(a, b) {
        if (!b.length) return [];
        var c = rg(b[0].getAdUnitPath());
        b.every(function(g) {
            return rg(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.y(a.j);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.y(e.value);
            e = f.next().value;
            (f = f.next().value.sf) && rg(e.getAdUnitPath()) === c && !_.v(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    Kq = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.Lc) ? d : ""
    };
    ZD = function(a, b) {
        return (a = a.j.get(b)) ? a.Pg - 1 : 0
    };
    UD = function(a, b, c) {
        (a = a.j.get(b)) && a.pf.push(c)
    };
    TD = function(a, b, c) {
        (a = a.j.get(b)) && a.qf.push(c)
    };
    SD = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.qf.slice(), a.qf.length = 0, a = _.y(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    $D = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.pf.slice(), a.pf.length = 0, a = _.y(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    RD.prototype.Rb = function(a) {
        var b, c;
        return null != (c = null == (b = this.j.get(a)) ? void 0 : b.Rb) ? c : !1
    };
    var aE = function(a, b, c) {
            if (a = a.j.get(b)) a.Ng = c
        },
        bE = function(a, b) {
            if (a = a.j.get(b)) {
                var c;
                null == (c = a.Ng) || c.wa();
                delete a.Ng
            }
        };
    var cE = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var zj = new _.x.Map,
        yj = new _.x.Map;
    var Bj = function(a, b) {
        this.push = H(a, 76, b.push.bind(b))
    };
    var Dj = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Dj.prototype.getMessageId = function() {
        return this.messageId
    };
    Dj.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var dE = L(2),
        eE = L(3),
        fE = L(4),
        gE = L(5),
        hE = L(6),
        iE = L(12),
        jE = L(14),
        kE = L(16),
        lE = L(19),
        mE = L(20),
        nE = L(23),
        oE = L(26),
        pE = L(28),
        qE = L(149),
        rE = L(30),
        sE = L(31),
        tE = L(34),
        uE = L(35),
        vE = L(36),
        zp = L(38),
        wE = L(40),
        xE = L(48),
        yE = L(50),
        zE = L(60),
        AE = L(63),
        BE = L(64),
        CE = L(66),
        DE = L(68),
        EE = L(69),
        FE = L(70),
        GE = L(71),
        HE = L(78),
        IE = L(80),
        JE = L(82),
        KE = L(84),
        LE = L(85),
        ME = L(87),
        gk = L(88),
        NE = L(92),
        OE = L(93),
        PE = L(99),
        QE = L(103),
        RE = L(104),
        SE = L(105),
        TE = L(106),
        UE = L(107),
        VE = L(108),
        WE = L(113),
        XE = L(114),
        YE = L(115),
        ZE = L(117),
        $E = L(118),
        aF = L(120),
        bF = L(119),
        Dk = L(121),
        cF = L(122),
        dF = L(123),
        bo = L(125),
        eF = L(126),
        fF = L(127),
        gF = L(144),
        Un = L(129),
        Wn = L(132),
        hF = L(134),
        iF = L(135),
        jF = L(136),
        kF = L(137),
        lF = L(138),
        mF = L(139),
        nF = L(140),
        ro = L(142),
        oF = L(143),
        pF = L(145),
        qF = L(147),
        Hp = L(148),
        rF = L(150),
        sF = L(152),
        tF = L(153),
        uF = L(154),
        vo = L(155);
    var vF = function(a, b, c) {
        var d = this;
        this.addEventListener = H(a, 86, function(e, f) {
            if ("function" !== typeof f) return M(b, Fj("Service.addEventListener", [e, f])), d;
            var g = Gj(e);
            if (!g) return M(b, OE(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = H(a, 904, function(e, f) {
            var g = Gj(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : M(b, Fj("Service.removeEventListener", [e, f]))
        });
        this.getSlots = H(a, 573, function() {
            return c.B.map(function(e) {
                return e.j
            })
        });
        this.getSlotIdMap = H(a, 574, function() {
            for (var e = {}, f = _.y(c.B), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.j;
            return e
        });
        this.getName = H(a, 575, function() {
            return c.getName()
        })
    };
    var Hj = function(a, b, c) {
        vF.call(this, a, b, c);
        this.setRefreshUnfilledSlots = H(a, 59, function(d) {
            return c.setRefreshUnfilledSlots(d)
        });
        this.notifyUnfilledSlots = H(a, 69, function(d) {
            c.Wb && wF(c, xF(c, d))
        });
        this.refreshAllSlots = H(a, 60, function() {
            c.Wb && wF(c)
        });
        this.setVideoSession = H(a, 61, function(d, e, f) {
            c.M = e;
            c.T = f;
            "number" === typeof d && (e = Fh().j, _.I(e, 29, d))
        });
        this.getDisplayAdsCorrelator = H(a, 62, function(d) {
            return yF(c, d)
        });
        this.getVideoStreamCorrelator = H(a, 63, function() {
            var d = Fh().j;
            d = sd(Xd(d, 29), 0);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = H(a, 64, function(d) {
            var e = _.v(c.B, "find").call(c.B, function(f) {
                return f.j === d
            });
            return !!e && zF(c, e)
        });
        this.onImplementationLoaded = H(a, 65, function() {
            c.j.info(xE("GPT CompanionAds"))
        });
        this.slotRenderEnded = H(a, 67, function(d, e, f) {
            var g = _.v(c.B, "find").call(c.B, function(h) {
                return h.j === d
            });
            return g && AF(c, g, e, f)
        })
    };
    _.S(Hj, vF);
    var Jj = function(a, b, c) {
        vF.call(this, a, b, c);
        this.setContent = H(a, 72, function(d) {
            var e = _.v(c.B, "find").call(c.B, function(f) {
                return f.j === d
            });
            M(b, gF(), e)
        })
    };
    _.S(Jj, vF);
    var BF = _.Ar(["https://console.googletagservices.com/pubconsole/loader.js"]),
        Uj = _.ke(BF),
        Yj, Xj = !1,
        Pj = !1,
        Rj = !1;
    var wp = function(a, b) {
        this.getAllEvents = H(a, 563, function() {
            return Pj ? CF(b).slice() : []
        });
        this.getEventsBySlot = H(a, 565, function(c) {
            return Pj ? DF(b, c).slice() : []
        });
        this.getEventsByLevel = H(a, 566, function(c) {
            return Pj ? EF(b, c).slice() : []
        })
    };
    var kk = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = Fh().j,
            h = fC(Fh(), f.getDomId());
        this.set = H(a, 83, function(k, l) {
            "page_url" === k && l && (k = [dk(ek(new fk, k), [String(l)])], _.el(h, 3, k));
            return e
        });
        this.get = H(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, m;
            return null != (m = null == (l = (_.C = h.Ea(), _.v(_.C, "find")).call(_.C, function(n) {
                return _.bh(n, 1) === k
            })) ? void 0 : _.Sl(l, 2)[0]) ? m : null
        });
        this.setClickUrl = H(a, 79, function(k) {
            jk(k, h, f, b);
            return e
        });
        this.setTargeting = H(a, 81, function(k, l) {
            hk(f, h, k, l, b);
            return e
        });
        this.updateTargetingFromMap = H(a, 85, function(k) {
            ik(f, h, k, b);
            return e
        });
        this.display = H(a, 78, function() {
            FF(d, f, rh(g, Fh().o))
        });
        this.setTagForChildDirectedTreatment = H(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = ar(g) || new aC;
                l.setTagForChildDirectedTreatment(k);
                _.vg(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = H(a, 567, function(k) {
            "boolean" === typeof k ? pi(h, 12, k) : M(b, Fj("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = H(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = ar(g) || new aC;
                l.setTagForUnderAgeOfConsent(k);
                _.vg(g, 25, l)
            }
            return e
        })
    };
    var Ol = function(a, b) {
        this.push = H(a, 932, function(c) {
            b.push(c)
        })
    };
    var Kn = {
        Kk: 0,
        Hk: 1,
        Ik: 2,
        Jk: 3
    };
    var nk = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5,
            GAME_MANUAL_INTERSTITIAL: 7
        },
        pk = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        ok = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var GF = "",
        xk = null;
    var Ok = function(a, b, c) {
        FD.call(this, a);
        this.slotId = b;
        this.j = c
    };
    _.S(Ok, FD);
    Ok.prototype.getSlotId = function() {
        return this.slotId
    };
    var Fe = function(a, b, c, d) {
        FD.call(this, a);
        this.adUnitPath = b;
        this.Eb = d;
        this.j = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.S(Fe, FD);
    q = Fe.prototype;
    q.getId = function() {
        return this.id
    };
    q.getAdUnitPath = function() {
        return this.adUnitPath
    };
    q.getName = function() {
        return this.adUnitPath
    };
    q.toString = function() {
        return this.getId()
    };
    q.getDomId = function() {
        return this.Eb
    };
    var HF = function(a, b) {
        a.j = b
    };
    var Ik = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var IF = _.js(function() {
            return void Rw("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        JF = _.js(function() {
            return void Rw("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        KF = _.js(function() {
            return void Rw("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        LF = function() {
            Object.defineProperty(window, "google_DisableInitialLoad", {
                get: function() {
                    IF();
                    return !0
                },
                set: function() {
                    IF()
                },
                configurable: !0
            })
        },
        Qk = function(a, b, c, d, e) {
            vF.call(this, a, b, c);
            var f = this,
                g = Fh().j,
                h = Fh().o,
                k = !1;
            this.setTargeting = H(a, 1, function(l, m) {
                var n = null;
                "string" === typeof m ? n = [m] : Array.isArray(m) ? n = m : sa(m) && (n = _.v(Array, "from").call(Array, m));
                var p = "string" === typeof l && !ak(l);
                n = n && za(n);
                var r, u = null != (r = null == n ? void 0 : n.every(function(w) {
                    return "string" === typeof w
                })) ? r : !1;
                if (!p || !u) return M(b, Fj("PubAdsService.setTargeting", [l, m])), f;
                m = n;
                p = (_.C = Oe(g, fk, 2), _.v(_.C, "find")).call(_.C, function(w) {
                    return _.bh(w, 1) === l
                });
                if ("gpt-beta" === l) {
                    if (c.o) return M(b, TE(m.join())), f;
                    if (p) return M(b, UE(m.join())), f;
                    m = Mk(m, e, a)
                }
                p ? dk(p, m) : (p = dk(ek(new fk, l), m), qi(g, 2, fk, p));
                b.info(gk(l, m.join(), c.getName()));
                return f
            });
            this.clearTargeting = H(a, 2, function(l) {
                if (void 0 === l) return Cp(g, 2), b.info(RE(c.getName())), f;
                if ("gpt-beta" === l) return M(b, VE(l)), f;
                var m = Oe(g, fk, 2),
                    n = _.v(m, "findIndex").call(m, function(p) {
                        return _.bh(p, 1) === l
                    });
                if (0 > n) return M(b, KE(l, c.getName())), f;
                m.splice(n, 1);
                _.el(g, 2, m);
                b.info(JE(l, c.getName()));
                return f
            });
            this.getTargeting = H(a, 38, function(l) {
                if ("string" !== typeof l) return M(b, Fj("PubAdsService.getTargeting", [l])), [];
                var m = (_.C = Oe(g, fk, 2), _.v(_.C, "find")).call(_.C, function(n) {
                    return _.bh(n, 1) === l
                });
                return m ? _.Sl(m, 2).slice() : []
            });
            this.getTargetingKeys = H(a, 39, function() {
                return Oe(g, fk, 2).map(function(l) {
                    return _.R(l, 1)
                })
            });
            this.setCategoryExclusion = H(a, 3, function(l) {
                if ("string" !== typeof l || ak(l)) return M(b, Fj("PubAdsService.setCategoryExclusion", [l])), f;
                (_.C = _.Sl(g, 3), _.v(_.C, "includes")).call(_.C, l) || md(g, 3, _.Ec(l));
                b.info(LE(l));
                return f
            });
            this.clearCategoryExclusions = H(a, 4, function() {
                Cp(g, 3);
                b.info(ME());
                return f
            });
            this.disableInitialLoad = H(a, 5, function() {
                pi(g, 4, !0);
                k || (k = !0, LF())
            });
            this.enableSingleRequest = H(a, 6, function() {
                if (c.o && !_.D(g, 6)) return M(b, zE("PubAdsService.enableSingleRequest")), !1;
                b.info(AE("single request"));
                pi(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = H(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = H(a, 8, function() {
                Rw("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = H(a, 485, function(l) {
                var m = new cq;
                m = _.I(m, 1, 800);
                m = _.I(m, 2, 400);
                m = _.I(m, 3, _.uc(3));
                if (_.ha(l)) {
                    var n = l.fetchMarginPercent;
                    "number" === typeof n && (0 <= n ? _.I(m, 1, n) : -1 === n && Cp(m, 1));
                    n = l.renderMarginPercent;
                    "number" === typeof n && (0 <= n ? _.I(m, 2, n) : -1 === n && Cp(m, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.I(m, 3, _.uc(l)) : -1 === l && _.I(m, 3, _.uc(1)))
                }
                window.IntersectionObserver || !$m(m, 1) && !$m(m, 2) ? _.vg(g, 5, m) : M(b, rF())
            });
            this.setCentering = H(a, 9, function(l) {
                l = !!l;
                b.info(BE("centering", String(l)));
                pi(g, 15, l)
            });
            this.definePassback = H(a, 10, function(l, m) {
                return (l = Pk(a, b, c, l, m, d)) && l.Hg
            });
            this.refresh = H(a, 11, function() {
                var l = _.sb.apply(0, arguments),
                    m = _.y(l),
                    n = m.next().value;
                m = m.next().value;
                m = void 0 === m ? {} : m;
                n && !Array.isArray(n) || !_.ha(m) || m.changeCorrelator && "boolean" !== typeof m.changeCorrelator ? M(b, Fj("PubAdsService.refresh", l)) : (m && !1 === m.changeCorrelator || g.setCorrelator(Vw()), n = n ? Lk(n, c) : c.B, c.refresh(rh(g, h), n) || M(b, Fj("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = H(a, 12, function() {
                pi(g, 21, !0);
                MF(c, g)
            });
            this.setVideoContent = H(a, 13, function(l, m) {
                NF(c, l, m, g)
            });
            this.collapseEmptyDivs = H(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                l = void 0 === l ? !1 : l;
                pi(g, 11, !0);
                l = !!l;
                pi(g, 10, l);
                b.info(HE(String(l)));
                return !!_.D(g, 11)
            });
            this.clear = H(a, 15, function(l) {
                if (Array.isArray(l)) return OF(c, g, h, Lk(l, c));
                if (void 0 === l) return OF(c, g, h, c.B);
                M(b, Fj("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = H(a, 16, function(l) {
                if ("string" !== typeof l) return M(b, Fj("PubAdsService.setLocation", [l])), f;
                Ll(g, 8, l);
                return f
            });
            this.setCookieOptions = H(a, 17, function() {
                JF();
                return f
            });
            this.setTagForChildDirectedTreatment = H(a, 18, function(l) {
                KF();
                if (1 !== l && 0 !== l) return M(b, cF("PubadsService.setTagForChildDirectedTreatment", Ek(l), "0,1")), f;
                var m = ar(g) || new aC;
                m.setTagForChildDirectedTreatment(l);
                _.vg(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = H(a, 19, function() {
                KF();
                var l = ar(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.vg(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = H(a, 20, function(l) {
                l = String(l);
                b.info(BE("PPID", l));
                Ll(g, 16, l);
                return f
            });
            this.set = H(a, 21, function(l, m) {
                if ("string" !== typeof l || !l.length || void 0 === cE()[l] || "string" !== typeof m) return M(b, Fj("PubAdsService.set", [l, m])), f;
                var n = (_.C = g.Ea(), _.v(_.C, "find")).call(_.C, function(p) {
                    return _.bh(p, 1) === l
                });
                n ? dk(n, [m]) : (n = $B(ek(new fk, l), m), qi(g, 14, fk, n));
                b.info(vE(l, String(m), c.getName()));
                return f
            });
            this.get = H(a, 22, function(l) {
                if ("string" !== typeof l) return M(b, Fj("PubAdsService.get", [l])), null;
                var m = (_.C = g.Ea(), _.v(_.C, "find")).call(_.C, function(n) {
                    return _.bh(n, 1) === l
                });
                return (m = m && _.Sl(m, 2)) ? m[0] : null
            });
            this.getAttributeKeys = H(a, 23, function() {
                return g.Ea().map(function(l) {
                    return _.R(l, 1)
                })
            });
            this.display = H(a, 24, function(l, m, n, p) {
                return void c.display(l, m, d, n, p)
            });
            this.updateCorrelator = H(a, 25, function() {
                Rw(Kk("update"));
                M(b, YE());
                g.setCorrelator(Vw());
                return f
            });
            this.defineOutOfPagePassback = H(a, 35, function(l) {
                l = Pk(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.I(l.Wa, 15, 1);
                return l.Hg
            });
            this.setForceSafeFrame = H(a, 36, function(l) {
                "boolean" !== typeof l ? M(b, Fj("PubAdsService.setForceSafeFrame", [Ek(l)])) : pi(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = H(a, 37, function(l) {
                var m = Fk(b, l);
                m ? _.vg(g, 18, m) : M(b, Fj("PubAdsService.setSafeFrameConfig", [l]));
                return f
            });
            this.setRequestNonPersonalizedAds = H(a, 445, function(l) {
                KF();
                if (0 !== l && 1 !== l) return M(b, cF("PubAdsService.setRequestNonPersonalizedAds", Ek(l), "0,1")), f;
                var m = ar(g) || new aC;
                pi(m, 8, !!l);
                _.vg(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = H(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                KF();
                if (2 !== l && 0 !== l && 1 !== l) return M(b, cF("PubadsService.setTagForUnderAgeOfConsent", Ek(l), "2,0,1")), f;
                var m = ar(g) || new aC;
                m.setTagForUnderAgeOfConsent(l);
                _.vg(g, 25, m);
                return f
            });
            this.getCorrelator = H(a, 27, function() {
                return String(Xd(g, 26))
            });
            this.getTagSessionCorrelator = H(a, 631, function() {
                return _.Lg(_.t)
            });
            this.getVideoContent = H(a, 30, function() {
                return PF(c, g)
            });
            this.getVersion = H(a, 568, function() {
                return a.Ub ? String(a.Ub) : a.nb
            });
            this.forceExperiment = H(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = H(a, 28, function(l) {
                Rw(Kk("set"));
                M(b, XE());
                if (gh(window)) return f;
                if (!al(l)) return M(b, Fj("PubadsService.setCorrelator", [Ek(l)])), f;
                l = g.setCorrelator(l);
                pi(l, 27, !0);
                return f
            });
            this.markAsAmp = H(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = H(a, 571, function() {
                return !!_.D(g, 6)
            });
            this.setImaContent = H(a, 328, function(l, m) {
                null != _.bh(g, 22) ? NF(c, l, m, g) : (pi(g, 21, !0), MF(c, g), "string" === typeof l && Ll(g, 19, l), "string" === typeof m && Ll(g, 20, m))
            });
            this.getImaContent = H(a, 329, function() {
                return null != _.bh(g, 22) ? PF(c, g) : c.o ? {
                    vid: _.R(g, 19) || "",
                    cmsid: _.R(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = H(a, 572, function() {
                return !!_.D(g, 4)
            });
            this.setPrivacySettings = H(a, 648, function(l) {
                if (!_.ha(l)) return M(b, Fj("PubAdsService.setPrivacySettings", [l])), f;
                var m = l.restrictDataProcessing,
                    n = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    u = l.nonPersonalizedAds,
                    w = l.userOptedOutOfPersonalization,
                    A = l.trafficSource,
                    F, B = null != (F = ar(g)) ? F : new aC;
                "boolean" === typeof u ? pi(B, 8, u) : void 0 !== u && M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "nonPersonalizedAds", Ek(u)));
                "boolean" === typeof w ? pi(B, 13, w) : void 0 !== w && M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "userOptedOutOfPersonalization", Ek(w)));
                "boolean" === typeof m ? pi(B, 1, m) : void 0 !== m && M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "restrictDataProcessing", Ek(m)));
                "boolean" === typeof r ? (m = Jk(), r && !_.D(B, 9) && a.nd && (u = a.Lb, w = wg(a), F = new qx, F = _.qd(F, 1, !0), F = _.qd(F, 2, m), w = _.yg(w, 11, zg, F), ue(u, w)), m ? pi(B, 9, r) : r && M(b, qF())) : void 0 !== r && M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "limitedAds", Ek(r)));
                void 0 !== p && (null === p ? B.setTagForUnderAgeOfConsent(2) : !1 === p ? B.setTagForUnderAgeOfConsent(0) : !0 === p ? B.setTagForUnderAgeOfConsent(1) : M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "underAgeOfConsent", Ek(p))));
                void 0 !== n && (null === n ? B.clearTagForChildDirectedTreatment() : !1 === n ? B.setTagForChildDirectedTreatment(0) : !0 === n ? B.setTagForChildDirectedTreatment(1) : M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "childDirectedTreatment", Ek(n))));
                void 0 !== A && (null === A ? Cp(B, 10) : (_.C = _.v(Object, "values").call(Object, ok), _.v(_.C, "includes")).call(_.C, A) ? _.I(B, 10, A) : M(b, Dk("PubAdsService.setPrivacySettings", Ek(l), "trafficSource", Ek(A))));
                _.vg(g, 25, B);
                return f
            })
        };
    _.S(Qk, vF);
    var xp = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = Bg(a, 88, function(f, g) {
            var h;
            if (h = Uk(f)) h = g, h = Tk(h) || Array.isArray(h) && h.every(Tk);
            if (h) {
                if (_.G(ny)) {
                    var k = cl(g);
                    h = k.size;
                    k.Bf && (g = Ej([f, g]), g = g.substring(1, g.length - 1), M(b, new Dj(151, ["SizeMappingBuilder.addSize", g])), g = h)
                }
                d.push([f, g])
            } else e.push([f, g]), M(b, Fj("SizeMappingBuilder.addSize", [f, g]));
            return c
        });
        this.build = Bg(a, 89, function() {
            if (e.length) return M(b, tE(Ek(e))), null;
            ra(d);
            return d
        })
    };
    var QF = function(a, b) {
        this.getId = H(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = H(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = H(a, 595, function() {
            return b.getName()
        });
        this.toString = H(a, 596, function() {
            return b.toString()
        });
        this.getDomId = H(a, 597, function() {
            return b.getDomId()
        })
    };
    var Vg = function(a) {
        this.K = _.z(a)
    };
    _.S(Vg, _.T);
    Vg.fa = [2];
    var RF = function(a) {
        this.K = _.z(a)
    };
    _.S(RF, _.T);
    RF.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    RF.prototype.getDomId = function() {
        return _.R(this, 2)
    };
    var SF = function(a, b) {
        Ll(a, 2, b)
    };
    RF.prototype.Ea = function() {
        return Oe(this, fk, 3)
    };
    RF.prototype.getServices = function(a) {
        return ju(this, 4, a)
    };
    var TF = function(a, b) {
        _.el(a, 5, b)
    };
    RF.prototype.getClickUrl = function() {
        return _.R(this, 7)
    };
    RF.prototype.setClickUrl = function(a) {
        return Ll(this, 7, a)
    };
    RF.prototype.getCategoryExclusions = function(a) {
        return ju(this, 8, a)
    };
    var bk = function(a) {
        return Oe(a, fk, 9)
    };
    RF.prototype.Qb = function() {
        return _.Rg(this, Bk, 13)
    };
    var on = function(a) {
        return _.Qe(a, 15, 0)
    };
    RF.fa = [3, 4, 5, 6, 8, 9, 27];
    var UF = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        VF = function(a, b) {
            a.advertiserId = b
        },
        WF = function(a, b) {
            a.campaignId = b
        },
        XF = function(a, b) {
            a.yieldGroupIds = b
        },
        YF = function(a, b) {
            a.companyIds = b
        };
    var ZF = function(a, b) {
        this.width = a;
        this.height = b
    };
    ZF.prototype.getWidth = function() {
        return this.width
    };
    ZF.prototype.getHeight = function() {
        return this.height
    };
    var hl = function(a, b, c) {
        var d = this,
            e = fC(Fh(), c.getDomId()),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.zn(c, function() {
            e = new RF;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.listen(dp, function(n) {
            var p = n.detail;
            n = p.bg;
            p = p.isBackfill;
            n && (f = n, l = p)
        });
        this.set = H(a, 40, function(n, p) {
            if ("string" !== typeof n || "string" !== typeof p || void 0 === cE()[n]) return M(b, Fj("Slot.set", [n, p]), c), d;
            var r = (_.C = e.Ea(), _.v(_.C, "find")).call(_.C, function(u) {
                return _.bh(u, 1) === n
            });
            r ? dk(r, [p]) : (r = ek(new fk, n), $B(r, p), qi(e, 3, fk, r));
            return d
        });
        this.get = H(a, 41, function(n) {
            if ("string" !== typeof n) return M(b, Fj("Slot.get", [n]), c), null;
            var p = (_.C = e.Ea(), _.v(_.C, "find")).call(_.C, function(r) {
                return _.bh(r, 1) === n
            });
            return (p = p && _.Sl(p, 2)) ? p[0] : null
        });
        this.getAttributeKeys = H(a, 42, function() {
            return e.Ea().map(function(n) {
                return _.R(n, 1)
            })
        });
        this.addService = H(a, 43, function(n) {
            n = zj.get(n);
            if (!n) return M(b, Fj("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.C = _.Sl(e, 4), _.v(_.C, "includes")).call(_.C, p)) return b.info(iE(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = H(a, 44, function(n) {
            try {
                var p = e;
                if (!Array.isArray(n)) throw new dl("Size mapping must be an array");
                var r = n.map(fl);
                _.el(p, 6, r)
            } catch (u) {
                n = u, Fg(a, 44, n), Rw("Incorrect usage of googletag.Slot defineSizeMapping: " + n.message)
            }
            return d
        });
        this.setClickUrl = H(a, 45, function(n) {
            jk(n, e, c, b);
            return d
        });
        this.setCategoryExclusion = H(a, 46, function(n) {
            "string" !== typeof n || ak(n) ? M(b, Fj("Slot.setCategoryExclusion", [n]), c) : ((_.C = _.Sl(e, 8), _.v(_.C, "includes")).call(_.C, n) || md(e, 8, _.Ec(n)), b.info(jE(n), c));
            return d
        });
        this.clearCategoryExclusions = H(a, 47, function() {
            Cp(e, 8);
            b.info(kE(), c);
            return d
        });
        this.getCategoryExclusions = H(a, 48, function() {
            return _.Sl(e, 8).slice()
        });
        this.setTargeting = H(a, 49, function(n, p) {
            hk(c, e, n, p, b);
            return d
        });
        this.updateTargetingFromMap = H(a, 649, function(n) {
            ik(c, e, n, b);
            return d
        });
        this.clearTargeting = H(a, 50, function(n) {
            if (void 0 === n) return Cp(e, 9), b.info(lE(c.getAdUnitPath()), c), d;
            var p = bk(e),
                r = _.v(p, "findIndex").call(p, function(u) {
                    return _.bh(u, 1) === n
                });
            if (0 > r) return M(b, KE(n, c.getAdUnitPath()), c), d;
            p.splice(r, 1);
            _.el(e, 9, p);
            b.info(QE(n, c.getAdUnitPath()), c);
            return d
        });
        this.getTargeting = H(a, 51, function(n) {
            if ("string" !== typeof n) return M(b, Fj("Slot.getTargeting", [n]), c), [];
            var p = (_.C = bk(e), _.v(_.C, "find")).call(_.C, function(r) {
                return _.bh(r, 1) === n
            });
            return p ? _.Sl(p, 2).slice() : []
        });
        this.getTargetingKeys = H(a, 52, function() {
            return bk(e).map(function(n) {
                return _.R(n, 1)
            })
        });
        this.setCollapseEmptyDiv = H(a, 53, function(n, p) {
            var r = e;
            p = void 0 === p ? !1 : p;
            p = void 0 === p ? !1 : p;
            "boolean" !== typeof n || "boolean" !== typeof p ? M(b, Fj("Slot.setCollapseEmptyDiv", [n, p]), c) : (r = pi(r, 10, n), pi(r, 11, n && p), p && !n && M(b, mE(c.toString()), c));
            return d
        });
        this.getAdUnitPath = H(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = H(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = H(a, 55, function(n) {
            var p = e;
            "boolean" !== typeof n ? M(b, Fj("Slot.setForceSafeFrame", [String(n)]), c) : pi(p, 12, n);
            return d
        });
        this.setSafeFrameConfig = H(a, 56, function(n) {
            var p = e,
                r = Fk(b, n);
            r ? _.vg(p, 13, r) : b.error(Fj("Slot.setSafeFrameConfig", [n]), c);
            return d
        });
        c.listen(KD, function(n) {
            n = n.detail;
            if (Gk(n, 8)) g = null;
            else {
                g = new UF;
                var p = !!Gk(n, 9);
                g.isBackfill = p;
                var r = Yc(n, 15, Bc),
                    u = Yc(n, 16, Bc);
                r.length && u.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = u[0], p || (g.creativeId = r[0], g.lineItemId = u[0], (p = Yc(n, 22, Bc)) && p.length && (g.creativeTemplateId = p[0])));
                Yc(n, 17, Bc).length && VF(g, Yc(n, 17, Bc)[0]);
                Yc(n, 18, Bc).length && WF(g, Yc(n, 18, Bc)[0]);
                Yc(n, 19, Bc).length && XF(g, Yc(n, 19, Bc));
                Yc(n, 20, Bc).length && YF(g, Yc(n, 20, Bc));
                n = Yc(n, 45, Xc(n.K) & 18 ? Zc : $c).map(function(w) {
                    return yd(w)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = H(a, 355, function() {
            return g
        });
        this.getName = H(a, 170, function() {
            b.error(oF());
            return c.getAdUnitPath()
        });
        var m = new QF(a, c);
        this.getSlotId = H(a, 579, function() {
            return m
        });
        this.getServices = H(a, 580, function() {
            return _.Sl(e, 4).map(function(n) {
                var p = ZB[n];
                if (p) {
                    var r, u, w;
                    n = null != (w = null == (u = (r = Lj())[p]) ? void 0 : u.call(r)) ? w : null
                } else n = null;
                return n
            })
        });
        this.getSizes = H(a, 581, function(n, p) {
            var r, u;
            return null != (u = null == (r = Yg(e, n, p)) ? void 0 : r.map(function(w) {
                return _.D(w, 3) ? "fluid" : new ZF(w.getWidth(), w.getHeight())
            })) ? u : null
        });
        this.getClickUrl = H(a, 582, function() {
            var n;
            return null != (n = e.getClickUrl()) ? n : ""
        });
        this.getTargetingMap = H(a, 583, function() {
            for (var n = {}, p = _.y(bk(e)), r = p.next(); !r.done; r = p.next()) r = r.value, _.R(r, 1) && (n[_.bh(r, 1)] = _.Sl(r, 2));
            return n
        });
        this.getOutOfPage = H(a, 584, function(n) {
            return "number" === typeof n ? on(e) === n : 0 !== on(e)
        });
        this.getCollapseEmptyDiv = H(a, 585, function() {
            return null != Gk(e, 10) ? _.D(e, 10) : null
        });
        this.getDivStartsCollapsed = H(a, 586, function() {
            return null != Gk(e, 11) ? _.D(e, 11) : null
        });
        c.listen(LD, function(n) {
            h = n.detail.Uh
        });
        this.getContentUrl = H(a, 587, function() {
            return h()
        });
        this.getFirstLook = H(a, 588, function() {
            Rw("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.listen(KD, function(n) {
            var p;
            k = null != (p = n.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = H(a, 591, function() {
            return k
        });
        this.getHtml = H(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = H(a, 1022, function(n) {
            if (_.ha(n)) {
                if (n = n.componentAuction, null != n) {
                    var p = {
                        componentAuction: n
                    };
                    if (_.ha(p)) {
                        if (n = gd(e, 26), void 0 !== p.componentAuction) {
                            p = _.y(p.componentAuction);
                            for (var r = p.next(); !r.done; r = p.next()) {
                                var u = r.value;
                                r = u.configKey;
                                u = u.auctionConfig;
                                "string" !== typeof r || ak(r) || (null === u ? n.delete(r) : u && n.set(r, JSON.stringify(u)))
                            }
                        }
                    } else M(b, Fj("googletag.Slot.setConfig", [p]))
                }
            } else M(b, Fj("googletag.slot.setConfig", [n]))
        })
    };
    var cG = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.O = c;
            this.j = new _.x.Map;
            this.o = new _.x.Map;
            this.timer = _.lf(Dg);
            rD() && (_.ub(window, "DOMContentLoaded", Bg(a, 334, function() {
                for (var f = _.y(e.j), g = f.next(); !g.done; g = f.next()) {
                    var h = _.y(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    $F(e, g, h) && e.j.delete(g)
                }
            })), b.listen(MD, function(f) {
                f = f.detail;
                var g = f.Y;
                return void aG(e, bG(d, f.Gf), vl(g, 20))
            }), b.listen(ND, function(f) {
                f = f.detail;
                var g = f.Y;
                f = bG(d, f.Gf);
                g = vl(g, 20);
                var h = e.o.get(f);
                null != h ? zD(h, g) : aG(e, f, g)
            }))
        },
        aG = function(a, b, c) {
            $F(a, b, c) ? a.j.delete(b) : (a.j.set(b, c), _.zn(b, function() {
                return a.j.delete(b)
            }))
        },
        $F = function(a, b, c) {
            var d = vh(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new fD({
                G: window,
                timer: a.timer,
                Eb: d,
                bb: function(e) {
                    return void Fg(a.context, 336, e)
                },
                vj: _.G(By)
            });
            if (!d.j) return !1;
            zD(d, c);
            a.o.set(b, d);
            UD(a.O, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var dG = function(a) {
        this.o = a;
        this.F = this.j = 0
    };
    dG.prototype.push = function() {
        for (var a = _.y(_.sb.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.x.globalThis), this.j++)
            } catch (c) {
                this.F++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.o.error(rE(String(c)))
            }
        }
        this.o.info(sE(String(this.j), String(this.F)));
        return this.j
    };
    var Z = function(a, b, c) {
        vB.call(this, b, c);
        this.context = a
    };
    _.S(Z, vB);
    Z.prototype.V = function(a) {
        Fg(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var eG = function(a, b, c, d, e) {
        var f = null,
            g = Bg(a.context, b, e);
        _.ub(c, d, g) && (f = function() {
            return _.Be(c, d, g)
        }, _.zn(a, f));
        return f
    };
    var pl = function(a, b, c, d, e) {
        Z.call(this, a, 959);
        this.Za = b;
        this.C = V(this);
        this.m = W(this, b);
        zB(this, c);
        zB(this, d);
        e && zB(this, e)
    };
    _.S(pl, Z);
    pl.prototype.j = function() {
        this.C.H(this.m.value)
    };
    var ol = function(a, b, c, d, e, f) {
        Z.call(this, a, 1172);
        this.D = b;
        this.O = c;
        this.G = d;
        this.m = xB(this);
        zB(this, e);
        this.A = W(this, f)
    };
    _.S(ol, Z);
    ol.prototype.j = function() {
        var a = this,
            b = new Tz(this.G);
        _.O(this, b);
        if (az(b.caller)) {
            var c = this.O.N,
                d = c.status,
                e = function(f) {
                    var g = _.id(a.A.value, 10, f.applicableSections, _.Ac);
                    Ll(g, 11, f.gppString);
                    a.m.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    QD(c);
                    c.j.push(e);
                    this.D.info(aF());
                    b.addEventListener(Bg(this.context, 1173, function(f, g) {
                        g && "signalStatus" === f.eventName && "ready" === f.data && (c.data = f.pingData, c.status = 2, c.Rc().forEach(function(h) {
                            h(f.pingData)
                        }), c.Gd())
                    }));
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.m.notify()
    };
    var ml = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.A = b;
        this.O = c;
        this.G = d;
        this.I = e;
        this.m = xB(this);
        zB(this, f);
        this.D = W(this, g)
    };
    _.S(ml, Z);
    ml.prototype.j = function() {
        var a = this,
            b = new kz(this.G, {
                lb: -1,
                Lh: !0
            });
        _.O(this, b);
        if (mz(b)) {
            var c = this.O.A,
                d = c.status,
                e = function(f) {
                    var g = a.D.value,
                        h, k, l;
                    if (l = !(null == (h = a.I) ? 0 : _.D(h, 9))) {
                        var m = void 0 === m ? !1 : m;
                        l = qz(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !m || "string" !== typeof f.tcString || !f.tcString.length ? !0 : oz(f, "1") : !1
                    }
                    h = pi(g, 5, l);
                    l = !rz(f, ["3", "4"]);
                    h = pi(h, 9, l);
                    h = Ll(h, 2, f.tcString);
                    l = null != (k = f.addtlConsent) ? k : "";
                    k = Ll(h, 4, l);
                    _.I(k, 7, f.internalErrorState);
                    null != f.gdprApplies && pi(g, 3, f.gdprApplies);
                    _.G(oy) && !rz(f, ["2", "7", "9", "10"]) && pi(g, 8, !0);
                    a.m.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    QD(c);
                    c.j.push(e);
                    this.A.info($E());
                    b.addEventListener(function(f) {
                        qz(f) ? ("tcunavailable" === f.tcString ? a.A.info(bF("failed")) : a.A.info(bF("succeeded")), c.data = f, c.status = 2, c.Rc().forEach(function(g) {
                            g(f)
                        }), c.Gd()) : QD(c)
                    });
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.m.notify()
    };
    var ll = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.D = b;
        this.G = c;
        this.m = xB(this);
        zB(this, d);
        this.A = W(this, e)
    };
    _.S(ll, Z);
    ll.prototype.j = function() {
        var a = this,
            b = new Nz(this.G);
        _.O(this, b);
        if (az(b.caller)) {
            var c = Bg(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && Ll(a.A.value, 1, d.uspString);
                a.m.notify()
            });
            this.D.info(ZE());
            Oz(b, c)
        } else this.m.notify()
    };
    var jl = function(a, b) {
        Z.call(this, a, 958);
        this.m = b;
        this.Za = V(this)
    };
    _.S(jl, Z);
    jl.prototype.j = function() {
        var a = new sA,
            b, c = null == (b = this.m) ? void 0 : _.D(b, 9);
        pi(a, 5, !c);
        this.Za.H(a)
    };
    var kl = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.G = b;
        this.A = d;
        this.m = W(this, c)
    };
    _.S(kl, Z);
    kl.prototype.j = function() {
        var a = this;
        Hg(this.context, 894, function() {
            return void Qh("cmpMet", function(b) {
                Wh(b, a.context);
                var c = new kz(a.G);
                _.O(a, c);
                var d = new Nz(a.G);
                _.O(a, d);
                J(b, "fc", Number(a.m.value));
                J(b, "tcfv1", Number(!!a.G.__cmp));
                J(b, "tcfv2", Number(mz(c)));
                J(b, "usp", Number(!!az(d.caller)));
                J(b, "ptt", 17)
            }, a.A)
        })
    };
    var fG = function(a, b, c) {
        Z.call(this, a, 1103);
        this.m = b;
        this.ca = c;
        this.C = V(this)
    };
    _.S(fG, Z);
    fG.prototype.j = function() {
        this.C.H(!!_.D(this.ca, 5) && !_.D(this.ca, 9) && (this.m ? _.D(this.m, 9) || _.D(this.m, 8) || _.D(this.m, 1) || _.G(fy) && _.D(this.m, 13) || 1 === _.Qe(this.m, 6, 2) || 1 === yc(Xd(this.m, 5)) ? !1 : !0 : !0))
    };
    var gG = ["Debug", "Info", "Warning", "Error", "Fatal"],
        hG = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.j = c;
            this.timestamp = new Date
        };
    q = hG.prototype;
    q.getSlot = function() {
        return this.j
    };
    q.getLevel = function() {
        return this.level
    };
    q.getTimestamp = function() {
        return this.timestamp
    };
    q.getMessage = function() {
        return this.message
    };
    q.toString = function() {
        return this.timestamp.toTimeString() + ": " + gG[this.level] + ": " + this.message
    };
    var iG = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return rl(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            },
            154: function(a) {
                return "Refresh is disabled for " + rl(a[0]) + " " + a[1] + "."
            },
            152: function() {
                return "Attempted to load GPT multiple times."
            },
            155: function() {
                return "Using deprecated googletag.encryptedSignalProviders. Please use googletag.secureSignalProviders instead."
            }
        },
        jG = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            153: function() {
                return "Attempted to load GPT from both standard and limited ads domains."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var kG = function(a) {
            this.context = a;
            this.F = this.B = this.j = 0;
            this.N = window;
            this.o = [];
            this.o.length = 1E3
        },
        CF = function(a) {
            return [].concat(_.se(a.o.slice(a.j)), _.se(a.o.slice(0, a.j))).filter(function(b) {
                return !!b
            })
        },
        DF = function(a, b) {
            return CF(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        EF = function(a, b) {
            return CF(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    kG.prototype.log = function(a, b, c, d) {
        var e = this;
        d = void 0 === d ? !1 : d;
        var f, g;
        c = new hG(a, b, null != (g = null == (f = void 0 === c ? null : c) ? void 0 : f.j) ? g : null);
        this.o[this.j] = c;
        this.j = (this.j + 1) % 1E3;
        g = _.rf(Ix) && 100 > this.B;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs(),
            k = b.getMessageId(),
            l = iG[k] || jG[k];
        g && f && (b = _.rf(Ix), Qh("gpt_eventlog_messages", function(m) {
            ++e.B;
            Wh(m, e.context);
            J(m, "level", a);
            J(m, "messageId", k);
            J(m, "args", h.join("|"));
            l || J(m, "noMsg", !0);
            var n = Error(),
                p;
            J(m, "stack", _.mA(null != (p = n.stack) ? p : "", n.message))
        }, b));
        if (l) {
            b = "[GPT] " + l(h);
            if (d) throw new dl(b);
            d = this.F < _.rf(Kx) && f && _.t.console;
            if (this.N === top && d || _.v(_.t.navigator.userAgent, "includes").call(_.t.navigator.userAgent, "Lighthouse"))(function(m) {
                var n, p, r, u;
                return void(2 === a ? null == (p = (n = _.t.console).warn) ? void 0 : p.call(n, m) : null == (u = (r = _.t.console).error) ? void 0 : u.call(r, m))
            })(b), this.F++
        }
        return c
    };
    kG.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var M = function(a, b, c) {
        return a.log(2, b, c, !1)
    };
    kG.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var lG = function() {
            var a = {
                    ba: Fh().j,
                    fh: new Date(Date.now()),
                    dg: window.location.href
                },
                b = this;
            a = void 0 === a ? {} : a;
            var c = void 0 === a.ba ? Fh().j : a.ba,
                d = void 0 === a.fh ? new Date(Date.now()) : a.fh,
                e = void 0 === a.dg ? window.location.href : a.dg;
            this.F = "";
            this.B = this.j = this.storage = null;
            this.N = this.m = !1;
            this.o = function() {
                return !1
            };
            a = {};
            var f = {},
                g = {};
            this.J = (g[3] = (a[72] = function(h, k) {
                var l = b.j;
                k = Number(k);
                h = null !== l ? _.Af("w5uHecUBa2S:" + Number(h) + ":" + l) % k === Math.floor(d.valueOf() / 864E5) % k : void 0;
                return h
            }, a[13] = function() {
                return _.sb.apply(0, arguments).some(function(h) {
                    return 0 == b.F.lastIndexOf(h, 0)
                })
            }, a[12] = function() {
                return !!_.D(c, 6)
            }, a[15] = function(h) {
                return b.o(h)
            }, a[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (h) {
                    return !1
                }
            }, a[67] = function() {
                return b.m
            }, a[68] = function() {
                return b.N
            }, a[74] = function() {
                return _.v(_.sb.apply(0, arguments), "includes").call(_.sb.apply(0, arguments), String(_.Af(e)))
            }, a), g[4] = (f[8] = function(h) {
                var k;
                return null != (k = Ve(b.storage, Number(h))) ? k : void 0
            }, f[10] = function(h) {
                return b.j ? _.Af(h + b.j) % 1E3 : void 0
            }, f[14] = function() {
                var h = Number(b.B || void 0);
                isNaN(h) ? h = void 0 : (h = new Date(1E3 * h), h = 1E4 * h.getFullYear() + 100 * (h.getMonth() + 1) + h.getDate());
                return h
            }, f), g[5] = {}, g)
        },
        mG = function(a, b) {
            if (b && !a.j) {
                b = b.split(":");
                a.j = _.v(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("ID=")
                }) || null;
                var c;
                a.B = (null == (c = _.v(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("T=")
                })) ? void 0 : c.substring(2)) || null
            }
        };
    var Lq = function(a, b, c, d, e, f) {
        Z.call(this, a, 863);
        this.m = c;
        this.Lc = Number(b);
        this.A = W(this, d);
        this.D = W(this, e);
        this.I = W(this, f)
    };
    _.S(Lq, Z);
    Lq.prototype.j = function() {
        var a = sl(this.m),
            b = this.I.value,
            c = this.A.value,
            d = this.D.value,
            e = this.m;
        var f = sl(e);
        var g = c.getBoundingClientRect();
        e = _.Zi(e) ? ih(c, e) : {
            x: 0,
            y: 0
        };
        c = e.x;
        e = e.y;
        g = new _.Zw(e, c + g.right, e + g.bottom, c);
        c = new SA;
        c = _.I(c, 1, g.top);
        c = _.I(c, 3, g.bottom);
        c = _.I(c, 2, g.left);
        g = _.I(c, 4, g.right);
        c = new TA;
        c = _.I(c, 1, this.Lc);
        d = pi(c, 2, !d);
        d = _.vg(d, 3, g);
        a = _.I(d, 4, a);
        f = _.I(a, 5, f);
        f = {
            type: "asmres",
            payload: Le(f)
        };
        b.ports[0].postMessage(f)
    };
    var nG = function(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        Z.call(this, a, 1060);
        var e = this;
        this.C = xB(this);
        rB(this.C, new _.x.Promise(function(f) {
            var g = eG(e, e.id, b, c, function(h) {
                d(h) && (g(), f())
            })
        }))
    };
    _.S(nG, Z);
    nG.prototype.j = function() {};
    var tl = function(a, b, c, d) {
        Z.call(this, a, 1061);
        var e = this;
        this.C = V(this);
        this.C.Oa(new _.x.Promise(function(f) {
            var g = b.listen(c, function(h) {
                h = d(h);
                null !== h && (g(), f(h))
            });
            _.zn(e, g)
        }))
    };
    _.S(tl, Z);
    tl.prototype.j = function() {};
    var An = function(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        Z.call(this, a, 1061);
        var e = this;
        this.C = xB(this);
        rB(this.C, new _.x.Promise(function(f) {
            var g = b.listen(c, function(h) {
                d(h) && (g(), f())
            });
            _.zn(e, g)
        }))
    };
    _.S(An, Z);
    An.prototype.j = function() {};
    var oG = /(<head(\s+[^>]*)?>)/i,
        aq = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.C = V(this);
            this.m = W(this, b);
            this.A = X(this, c);
            this.D = W(this, d);
            this.I = W(this, e)
        };
    _.S(aq, Z);
    aq.prototype.j = function() {
        var a;
        0 !== this.m.value.kind || null == (a = this.A.value) || !_.bh(a, 1) || this.I.value ? this.C.H(this.m.value) : (a = this.m.value.ob, Sa() || (a = a.replace(oG, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.D.value && (a = a.replace(oG, '$1<meta name="referrer" content="origin">')), this.C.H({
            kind: 0,
            ob: a
        }))
    };
    var pG = function(a, b, c, d) {
        Z.call(this, a, 1124);
        this.m = xB(this);
        this.D = W(this, b);
        this.A = W(this, c);
        zB(this, d)
    };
    _.S(pG, Z);
    pG.prototype.j = function() {
        _.ex(this.A.value, {
            "min-width": "100%",
            visibility: "hidden"
        });
        _.ex(this.D.value, "min-width", "100%");
        this.m.notify()
    };
    var qG = function(a, b, c, d, e) {
        Z.call(this, a, 1125);
        this.A = W(this, b);
        this.m = W(this, c);
        zB(this, d);
        zB(this, e)
    };
    _.S(qG, Z);
    qG.prototype.j = function() {
        var a = this.A.value,
            b = a.contentDocument;
        b && (a.setAttribute("height", String(b.body.offsetHeight)), a.setAttribute("width", String(b.body.offsetWidth)), _.ex(this.m.value, "visibility", "visible"))
    };
    var Mq = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.slotId = b;
        this.Lf = e;
        this.A = f;
        this.D = g;
        this.C = V(this);
        this.m = new An(this.context, this.slotId, HD);
        this.M = X(this, c);
        this.I = X(this, d);
        this.T = W(this, h)
    };
    _.S(Mq, Z);
    Mq.prototype.j = function() {
        var a = !this.T.value;
        if (null == this.I.value || "height" !== this.M.value || a) this.m.wa(), this.C.H(!1);
        else {
            a = new ti;
            _.O(this, a);
            var b = new pG(this.context, this.A, this.D, this.Lf);
            K(a, b);
            K(a, this.m);
            K(a, new qG(this.context, this.A, this.D, this.m.C, b.m));
            Di(a);
            this.C.H(!0)
        }
    };
    var uq = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 699);
        this.Z = b;
        this.slotId = c;
        this.m = d;
        this.Dc = e;
        this.C = xB(this);
        this.M = X(this, f);
        this.W = W(this, g);
        this.D = W(this, h);
        this.T = W(this, k);
        this.A = X(this, l);
        this.aa = W(this, m);
        this.I = W(this, n);
        p && zB(this, p)
    };
    _.S(uq, Z);
    uq.prototype.j = function() {
        var a = this.W.value,
            b = this.D.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.M.value) {
            var c, d = null != (c = this.A.value) ? c : 0;
            c = this.T.value;
            var e = this.aa.value,
                f = this.I.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                case 4:
                case 5:
                    var h = this.context;
                    g = this.Z;
                    var k = this.slotId,
                        l = this.m,
                        m = this.Dc,
                        n, p = a.parentElement ? null == (n = xh(a.parentElement, window)) ? void 0 : n.width : void 0;
                    n = c.width;
                    var r = c.height,
                        u = 0;
                    var w = 0;
                    var A = $g(l);
                    A = _.y(A);
                    for (var F = A.next(); !F.done; F = A.next()) {
                        var B = F.value;
                        Array.isArray(B) && (F = B[0], B = B[1], u < F && (u = F), w < B && (w = B))
                    }
                    w = [u, w];
                    u = w[0] < n;
                    r = w[1] < r;
                    if (u || r) {
                        w = n + "px";
                        A = {
                            "max-height": "none",
                            "max-width": w,
                            padding: "0px",
                            width: w
                        };
                        r && (A.height = "auto");
                        Kh(b, a, A);
                        b = {};
                        if ((_.C = [2, 5], _.v(_.C, "includes")).call(_.C, d) || u && n > Gh(e.width)) b.width = w, b["max-width"] = w;
                        r && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (E in b)
                                if (Object.prototype.hasOwnProperty.call(b, E)) {
                                    var E = !1;
                                    break c
                                }
                            E = !0
                        }
                        E ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.Jh(a, b), b = !0)
                    } else b = !1;
                    b: switch (w = c.width, E = g.defaultView || g.parentWindow || _.t, d) {
                        case 2:
                        case 5:
                            a = Lh(a, E, w, e, m);
                            break b;
                        case 1:
                        case 4:
                            if (e = a.parentElement)
                                if (m = ph(e)) {
                                    F = m.width;
                                    m = vh(k, E.document);
                                    n = xh(m, E);
                                    r = n.position;
                                    B = Gh(n.width) || 0;
                                    u = xh(e, E);
                                    A = "rtl" === u.direction ? "Right" : "Left";
                                    m = A.toLowerCase();
                                    E = "absolute" === r ? 0 : Gh(u["padding" + A]);
                                    u = Gh(u["border" + A + "Width"]);
                                    w = Math.max(Math.round((F - Math.max(B, w)) / 2), 0);
                                    F = {};
                                    B = 0;
                                    var N = Ow(n);
                                    N && (B = N[4] * ("Right" === A ? -1 : 1), A = N[3] || 1, 1 !== (N[0] || 1) || 1 !== A) && (N[0] = 1, N[3] = 1, F.transform = "matrix(" + N.join(",") + ")");
                                    A = 0;
                                    switch (r) {
                                        case "fixed":
                                            var Q, P = null != (Q = Number(yh(n.getPropertyValue(m)))) ? Q : 0,
                                                Y;
                                            Q = null != (Y = e.getBoundingClientRect().left) ? Y : 0;
                                            A = P - Q;
                                            break;
                                        case "relative":
                                            A = null != (P = Number(yh(n.getPropertyValue(m)))) ? P : 0;
                                            break;
                                        case "absolute":
                                            F[m] = "0"
                                    }
                                    F["margin-" + m] = w - E - u - A - B + "px";
                                    _.Jh(a, F);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (Nh(h, g, k, l, d, c.width, c.height, p, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, Y = this.Z, g = this.slotId, k = this.m, p = this.Dc, l = a.parentElement ? null == (h = xh(a.parentElement, window)) ? void 0 : h.width : void 0, h = c.width, Q = c.height, P = Gh(e.height) || 0, Q >= P || "none" === e.display || "hidden" === e.visibility || !p || -12245933 === p.width || a.getBoundingClientRect().bottom <= p.height ? g = !1 : (p = {
                        height: Q + "px"
                    }, Kh(b, a, p), _.Jh(a, p), Nh(d, Y, g, k, 3, h, Q, l, "gpt_slotred", f), g = !0)
            }!g && _.G(zx) && Nh(this.context, this.Z, this.slotId, this.m, 0, c.width, c.height, void 0, "gpt_pgbrk", f)
        }
        this.C.notify()
    };
    var rG = null;
    var sq = function(a, b, c) {
        Z.call(this, a, 698);
        this.G = b;
        this.C = V(this);
        this.m = W(this, c)
    };
    _.S(sq, Z);
    sq.prototype.j = function() {
        this.C.Ba(xh(this.m.value, this.G))
    };
    var dq = function(a, b, c, d, e, f) {
        Z.call(this, a, 1114);
        this.M = b;
        this.T = c;
        this.D = V(this);
        this.A = V(this);
        this.I = W(this, d);
        this.m = W(this, e);
        this.W = W(this, f)
    };
    _.S(dq, Z);
    dq.prototype.j = function() {
        if (this.M) {
            var a = this.M.split(":");
            if (2 !== a.length || "#flexibleAdSlotDebugSize" !== a[0]) sG(this);
            else {
                var b = a[1];
                a = tG(this, b);
                var c;
                (c = /(?:.*)height=(ratio|[0-9]+)(?:;.*|$)/.exec(b)) ? (c = c[1], "ratio" === c ? c = a && this.I.value && this.m.value ? Math.floor(this.m.value / this.I.value * a) : null : (c = Number(c), c = 0 <= c ? c : null)) : c = null;
                b = (b = /(?:.*)ius=(.+,?)+(?:;.*|$)/.exec(b)) ? b[1].split(",") : [];
                a || c ? (this.D.H(new _.oh(null != a ? a : this.I.value, null != c ? c : this.m.value)), this.A.H(b)) : sG(this)
            }
        } else sG(this)
    };
    var tG = function(a, b) {
            b = /(?:.*)width=(parent|viewport|[0-9]+)(?:;.*|$)/.exec(b);
            if (!b) return null;
            b = b[1];
            if ("viewport" === b) return a.T;
            if ("parent" === b) {
                var c, d, e;
                return (b = null != (e = null == (d = ph(null == (c = a.W.value) ? void 0 : c.parentElement)) ? void 0 : d.width) ? e : null) ? Math.min(b, a.T) : null
            }
            a = Number(b);
            return 0 <= a ? a : null
        },
        sG = function(a) {
            a.D.ha();
            a.A.H([])
        };
    var eq = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.W = c;
        this.kc = d;
        this.Da = V(this);
        this.m = V(this);
        this.Bd = V(this);
        this.I = V(this);
        this.M = X(this, e);
        this.ia = X(this, f);
        this.da = X(this, g);
        this.aa = X(this, h);
        this.A = W(this, k);
        this.D = W(this, l);
        this.T = W(this, m)
    };
    _.S(eq, Z);
    eq.prototype.j = function() {
        var a = uG(this),
            b = this.aa.value,
            c;
        if (c = !this.kc && a && b) this.A.value.length ? (c = this.adUnitPath.split("/"), c = _.v(this.A.value, "includes").call(this.A.value, c[c.length - 1])) : c = !0;
        if (c) {
            c = this.T.value;
            var d, e, f = null != (e = null == (d = ph(c.parentElement)) ? void 0 : d.width) ? e : 0;
            d = b.width;
            b = b.height;
            vG(this, !0, d, b, {
                kind: 0,
                ob: '<html><body style="height:' + (b - 2 + "px;width:" + (d - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (d + "x" + b + "</p></body></html>")
            }, d <= f ? 1 : 2, c)
        } else if (a = this.ia.value, b = this.da.value, this.kc) vG(this, !1, null != a ? a : 0, null != b ? b : 0, this.D.value);
        else {
            if (null == a) throw new dl("Missing 'width'.");
            if (null == b) throw new dl("Missing 'height'.");
            vG(this, !1, a, b, this.D.value)
        }
    };
    var uG = function(a) {
            a = $g(a.W)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.oh(a[0], a[1]) : null
        },
        vG = function(a, b, c, d, e, f, g) {
            f = void 0 === f ? a.M.value : f;
            a.I.H(b);
            a.m.H(new _.oh(c, d));
            a.Da.H(e);
            a.Bd.Ba(f);
            g && _.ex(g, "opacity", .5)
        };
    var wG = function(a, b, c, d, e) {
        Z.call(this, a, 937, _.rf(by));
        this.Ya = b;
        this.m = V(this);
        this.A = V(this);
        this.D = V(this);
        this.Bb = c;
        this.Nb = d;
        this.ic = e
    };
    _.S(wG, Z);
    wG.prototype.j = function() {
        var a = {},
            b;
        if (null == (b = _.Rg(this.Ya, $u, 2)) ? 0 : _.D(b, 2)) a["*"] = {
            ed: !0
        };
        b = new _.x.Set;
        for (var c = _.y(Oe(this.Ya, Zu, 1)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = _.y([_.R(d, 2), _.R(d, 1)].filter(function(p) {
                    return !!p
                })), f = e.next(); !f.done; f = e.next()) a[f.value] = {
                ed: _.D(d, 3)
            };
            d = _.y(Yc(d, 4, xc));
            for (e = d.next(); !e.done; e = d.next()) b.add(e.value)
        }
        this.Bb.H(a);
        this.m.H([].concat(_.se(b)));
        var g, h;
        a = null == (g = _.Rg(this.Ya, $u, 2)) ? void 0 : null == (h = _.Rg(g, Uu, 1)) ? void 0 : Oe(h, Tu, 1);
        this.A.Ba((null == a ? 0 : a.length) ? a : null);
        var k;
        this.Nb.H(!(null == (k = _.Rg(this.Ya, $u, 2)) || !_.D(k, 4)));
        var l;
        this.ic.H(!(null == (l = _.Rg(this.Ya, $u, 2)) || !_.D(l, 5)));
        var m, n;
        g = null == (m = _.Rg(this.Ya, $u, 2)) ? void 0 : null == (n = _.Rg(m, Uu, 3)) ? void 0 : Oe(n, Tu, 1);
        this.D.Ba((null == g ? 0 : g.length) ? g : null)
    };
    wG.prototype.J = function(a) {
        this.o(a)
    };
    wG.prototype.o = function() {
        this.Bb.H({});
        this.m.H([]);
        this.A.ha();
        this.Nb.H(!1);
        this.ic.H(!1);
        this.D.ha()
    };
    var xG = function(a, b, c, d) {
        Z.call(this, a, 980);
        this.m = b;
        this.C = new jp;
        this.A = W(this, c);
        this.D = W(this, d)
    };
    _.S(xG, Z);
    xG.prototype.j = function() {
        (_.C = _.v(Object, "entries").call(Object, this.A.value), _.v(_.C, "find")).call(_.C, function(c) {
            var d = _.y(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.ed)
        }) && (this.m.N = !0);
        rk(25, this.context);
        for (var a = _.y(this.D.value), b = a.next(); !b.done; b = a.next()) nf(b.value);
        this.C.notify()
    };
    var yG = function(a, b, c, d) {
        Z.call(this, a, 931);
        this.m = X(this, b);
        this.Vb = c;
        this.Ob = d
    };
    _.S(yG, Z);
    yG.prototype.j = function() {
        var a = this.m.value,
            b = new _.x.Map;
        this.Vb.H(new _.x.Map);
        if (a) {
            var c;
            a = _.y(null != (c = this.m.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = Oe(d, Su, 1);
                c = 1 === _.Qe(c[0], 1, 0) ? lu(c[0]) : mu(c[0], ku);
                d = _.ye(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        this.Ob.H(b)
    };
    yG.prototype.o = function() {
        this.Vb.H(new _.x.Map);
        this.Ob.H(new _.x.Map)
    };
    var zG = function(a, b, c) {
        Z.call(this, a, 981);
        this.A = V(this);
        this.D = X(this, b);
        this.m = c
    };
    _.S(zG, Z);
    zG.prototype.j = function() {
        var a = new _.x.Map,
            b, c = _.y(null != (b = this.D.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = Oe(b, Su, 1);
            d = 1 === _.Qe(d[0], 1, 0) ? lu(d[0]) : mu(d[0], ku);
            a.set(d, _.ye(b, 2))
        }
        this.A.H(a);
        this.m.H(new Lu)
    };
    zG.prototype.o = function() {
        this.A.H(new _.x.Map);
        var a = this.m,
            b = a.H;
        var c = new Lu;
        c = _.I(c, 1, 2);
        b.call(a, c)
    };
    var AG = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.m = e;
        this.requestBidsConfig = f;
        zB(this, b);
        zB(this, c)
    };
    _.S(AG, Z);
    AG.prototype.j = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.m, [this.requestBidsConfig])
    };
    var BG = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.A = b;
        this.m = c;
        this.D = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.C = new jp
    };
    _.S(BG, Z);
    BG.prototype.j = function() {
        Ml(this.pbjs, this.A, this.m, this.D, this.requestBidsConfig);
        this.C.notify()
    };
    BG.prototype.o = function() {
        this.C.notify()
    };
    var CG = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.m = c;
        this.A = d;
        this.D = e;
        this.requestBidsConfig = f;
        this.C = new jp
    };
    _.S(CG, Z);
    CG.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.m) ? void 0 : a.get("*")) ? b : _.rf(Ex);
        if (c) this.Mb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.y(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.m) ? void 0 : c.get(_.G(Fl) ? El(e) : e)) ? a : null == (b = this.m) ? void 0 : b.get(_.Af(e))) ? g : 0, this.Mb(f)
        }
        this.C.notify()
    };
    CG.prototype.Mb = function(a) {
        var b;
        null != (b = this.A) && pi(b, 2, this.D);
        if (a) {
            var c;
            null == (c = this.A) || _.I(c, 1, 1);
            if (!this.D) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.y(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    CG.prototype.o = function() {
        this.C.notify()
    };
    var DG = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.j = a;
        this.B = b;
        this.o = c;
        this.m = d;
        this.A = e;
        this.J = f;
        this.V = g;
        this.pbjs = h
    };
    _.S(DG, _.U);
    DG.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new ti;
            _.O(this, d);
            var e = new CG(this.j, this.pbjs, this.A, this.J, this.V, a),
                f = new BG(this.j, this.B, this.o, this.m, this.pbjs, a);
            K(d, e);
            K(d, f);
            K(d, new AG(this.j, f.C, e.C, c, b, a));
            Di(d)
        }
    };
    var EG = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 951);
        this.G = window;
        this.I = W(this, b);
        this.A = X(this, d);
        this.D = W(this, e);
        this.T = W(this, f);
        this.m = X(this, g);
        this.W = X(this, h);
        this.M = W(this, k);
        zB(this, c);
        this.gd = null != l ? l : V(this);
        this.hd = null != m ? m : V(this)
    };
    _.S(EG, Z);
    EG.prototype.j = function() {
        var a = !!Lj().pbjs_hooks;
        this.hd.H(a);
        this.gd.Ba(a ? null : _.ff());
        var b, c = null == (b = this.A.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.m.value) ? void 0 : d.size) || _.rf(Ex);
        d = this.I.value;
        var e, f = null != (e = Lj().pbjs_hooks) ? e : [];
        e = new DG(this.context, this.A.value, this.D.value, this.T.value, this.m.value, this.W.value, this.M.value, d);
        _.O(this, e);
        f = _.y(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) Lj().pbjs_hooks = Pl(this.context, e);
        !c && !b || a || Nl(d, this.G)
    };
    var FG = function(a, b, c) {
        Z.call(this, a, 1093);
        this.m = new qB(b);
        this.A = W(this, c)
    };
    _.S(FG, Z);
    FG.prototype.j = function() {
        var a = this.m.value;
        if (a) {
            var b;
            (null == (b = this.A.value["*"]) ? 0 : b.ed) && Array.isArray(a.installedModules) && (b = new Qj("pbjs_modules"), Wh(b, this.context), J(b, "pbmods", a.installedModules.join("~")), Sj(b))
        }
    };
    var GG = function(a, b, c) {
        Z.call(this, a, 966);
        this.G = b;
        this.xb = c
    };
    _.S(GG, Z);
    GG.prototype.j = function() {
        var a = this,
            b = Rf(this.G);
        if (b) this.xb.H(b);
        else if ((b = Object.getOwnPropertyDescriptor(this.G, "_pbjsGlobals")) && !b.configurable) Qh("pdpg_error", function(d) {
            Wh(d, a.context)
        }, _.rf(Cx));
        else {
            var c = null;
            Object.defineProperty(this.G, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = Rf(a.G)) && a.xb.H(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    GG.prototype.o = function() {};
    var HG = function(a, b, c, d, e) {
        Z.call(this, a, 1146, _.rf(by));
        this.A = b;
        this.G = d;
        this.m = e;
        this.D = yB(this, c)
    };
    _.S(HG, Z);
    HG.prototype.j = function() {
        var a = this.D.value,
            b = new ti;
        _.O(this, b);
        var c = new GG(this.context, this.G, this.m.xb);
        K(b, c);
        if (a) {
            a = new wG(this.context, a, this.m.Bb, this.m.Nb, this.m.ic);
            K(b, a);
            var d = new xG(this.context, this.A, a.Bb, a.m);
            K(b, d);
            var e = new yG(this.context, a.A, this.m.Vb, this.m.Ob);
            K(b, e);
            var f = new zG(this.context, a.D, this.m.Be);
            K(b, f);
            d = new EG(this.context, c.xb, d.C, e.Ob, this.m.Nb, e.Vb, f.A, f.m, a.ic, this.m.gd, this.m.hd);
            K(b, d);
            c = new FG(this.context, c.xb, a.Bb);
            K(b, c)
        } else IG(this);
        Di(b)
    };
    var IG = function(a) {
        a.m.Bb.H({});
        a.m.Ob.H(new _.x.Map);
        a.m.Nb.H(!1);
        a.m.Vb.H(new _.x.Map);
        a.m.gd.ha();
        a.m.hd.H(!1);
        a.m.Be.H(new Lu);
        a.m.ic.H(!1)
    };
    HG.prototype.J = function(a) {
        this.o(a)
    };
    HG.prototype.o = function() {
        IG(this)
    };
    var JG = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        KG = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 920);
            this.W = b;
            this.Y = c;
            this.pbjs = f;
            this.I = g;
            this.A = V(this);
            this.D = V(this);
            this.M = [];
            this.m = new _.x.Map;
            this.da = W(this, d);
            this.aa = X(this, e.Ob);
            this.T = W(this, e.Nb);
            this.ka = W(this, e.Vb);
            this.ia = X(this, e.Be)
        };
    _.S(KG, Z);
    KG.prototype.j = function() {
        var a = LG(this, this.pbjs);
        a ? (this.I.Ba(a), this.A.H(this.m), this.D.H(this.M)) : MG(this)
    };
    KG.prototype.J = function(a) {
        this.o(a)
    };
    KG.prototype.o = function(a) {
        this.W.error(fF(a.message));
        MG(this)
    };
    var MG = function(a) {
            a.I.ha();
            a.A.ha();
            a.D.ha()
        },
        LG = function(a, b) {
            var c = (0, b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.da.value.map(function(g) {
                    var h = new Qu,
                        k = function(na) {
                            return na === g.getDomId() || na === g.getAdUnitPath()
                        },
                        l, m = null != (l = NG.get(g)) ? l : 0,
                        n;
                    l = null != (n = d.filter(function(na) {
                        var ta, Oa, va;
                        return Number(null == (ta = na.args) ? void 0 : ta.timestamp) > m && (null == (Oa = na.args) ? void 0 : null == (va = Oa.adUnitCodes) ? void 0 : _.v(va, "find").call(va, k))
                    })) ? n : [];
                    if (!l.length) return a.M.push(g), [g, h];
                    var p;
                    n = null == (p = l.reduce(function(na, ta) {
                        return Number(ta.args.timestamp) > Number(na.args.timestamp) ? ta : na
                    })) ? void 0 : p.args;
                    if (!n) return [g, h];
                    var r = void 0 === n.bidderRequests ? [] : n.bidderRequests;
                    p = void 0 === n.bidsReceived ? [] : n.bidsReceived;
                    var u = n.auctionId;
                    n = n.timestamp;
                    if (!u || null == n || !r.length) return [g, h];
                    NG.has(g) || _.zn(g, function() {
                        return NG.delete(g)
                    });
                    NG.set(g, n);
                    n = Ru(h);
                    Math.random() < _.rf(Dx) && b.version && JG.test(b.version) && Ll(n, 6, b.version);
                    var w;
                    Ou(n, null == (w = a.ia) ? void 0 : w.value);
                    w = wh(function() {
                        return om(c, u)
                    });
                    l = bk(a.Y[g.getDomId()]);
                    r = _.y(r);
                    for (var A = r.next(), F = {}; !A.done; F = {
                            td: F.td,
                            we: F.we
                        }, A = r.next()) {
                        var B = A.value;
                        F.td = B.bidderCode;
                        var E = B.bids;
                        A = B.timeout;
                        F.we = B.src;
                        B = B.auctionStart;
                        E = _.y(E);
                        for (var N = E.next(), Q = {}; !N.done; Q = {
                                Ec: Q.Ec
                            }, N = E.next()) {
                            var P = N.value;
                            Q.Ec = P.bidId;
                            var Y = P.transactionId;
                            N = P.adUnitCode;
                            var ja = P.getFloor;
                            P = P.mediaTypes;
                            if (Q.Ec && k(N)) {
                                e = !0;
                                cm(n, g, N);
                                Y && (null != _.bh(n, 4) || Ll(n, 4, Y), a.m.has(Y) || a.m.set(Y, B));
                                null != $m(n, 8) || _.I(n, 8, A);
                                var xa = _.v(p, "find").call(p, function(na) {
                                    return function(ta) {
                                        return ta.requestId === na.Ec
                                    }
                                }(Q));
                                Y = Ul(n, function(na) {
                                    return function() {
                                        var ta = Xl(new Yl, na.td);
                                        _.G(Zl) && $l(na.td, b, ta);
                                        switch (na.we) {
                                            case "client":
                                                _.I(ta, 7, 1);
                                                break;
                                            case "s2s":
                                                _.I(ta, 7, 2)
                                        }
                                        return ta
                                    }
                                }(F)());
                                fm(n, Y, N, a.aa.value, a.T.value, a.ka.value, ja);
                                xa ? (Wl(Y, 1), "number" === typeof xa.timeToRespond && am(Y, xa.timeToRespond), N = Tl(xa, l, P), Vl(Y, N)) : (N = w().get(Q.Ec)) && !N.xg ? am(Wl(Y, 2), Math.round(N.latency)) : am(Wl(Y, 3), A)
                            }
                        }
                    }
                    var ia;
                    (null == (ia = b.getConfig) ? 0 : ia.call(b).useBidCache) && bm(n, g, u, l, b);
                    return [g, h]
                });
            return e ? new _.x.Map(f) : null
        },
        NG = new _.x.Map;
    var OG, PG = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1019);
        this.Y = d;
        this.pbjs = e;
        this.A = new qB(f);
        this.D = new qB(g);
        this.m = X(this, b);
        this.I = X(this, c)
    };
    _.S(PG, Z);
    PG.prototype.j = function() {
        QG(this);
        RG(this)
    };
    var RG = function(a) {
            if (!(Math.random() >= _.rf(Bx))) {
                var b = (a.I.value || []).filter(function(k) {
                    return bk(a.Y[k.getDomId()]).some(function(l) {
                        return "hb_pb" === _.bh(l, 1)
                    })
                });
                if (b.length) {
                    var c, d, e, f, g, h = (null == (c = a.pbjs) ? 0 : null == (d = c.adUnits) ? 0 : d.length) ? [].concat(_.se(new _.x.Set(null == (e = a.pbjs) ? void 0 : e.adUnits.map(function(k) {
                        return k.code
                    })))) : _.v(Object, "keys").call(Object, (null == (f = a.pbjs) ? void 0 : null == (g = f.getAdserverTargeting) ? void 0 : g.call(f)) || {});
                    c = new Qj("haux");
                    J(c, "ius", b.map(function(k) {
                        return k.getAdUnitPath()
                    }).join("~"));
                    J(c, "dids", b.map(function(k) {
                        return k.getDomId()
                    }).join("~"));
                    J(c, "paucs", h.join("~"));
                    Wh(c, a.context);
                    Sj(c)
                }
            }
        },
        QG = function(a) {
            Qh("ppc_hrc", function(b) {
                var c;
                null != OG || (OG = null == (c = (_.C = window.google_js_reporting_queue = window.google_js_reporting_queue || [], _.v(_.C, "find")).call(_.C, function(k) {
                    return "1" === k.label
                })) ? void 0 : c.value);
                var d = hf("navigationStart", window);
                OG && J(b, "lt", OG);
                var e;
                J(b, "tids", [].concat(_.se((null == (e = a.m.value) ? void 0 : _.v(e, "keys").call(e)) || [])).join());
                var f;
                J(b, "asts", [].concat(_.se((null == (f = a.m.value) ? void 0 : _.v(f, "values").call(f)) || [])).map(function(k) {
                    return k - d
                }).join());
                var g;
                if (null == (g = a.A) ? 0 : g.value) J(b, "ht", a.A.value - d);
                else {
                    var h;
                    (null == (h = a.D) ? 0 : h.value) && J(b, "ht", 0)
                }
                Wh(b, a.context)
            }, a.m.value ? _.rf(Ax) : 0)
        };
    var um = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1153);
        this.m = b;
        this.Y = c;
        this.Hb = d;
        this.M = e;
        this.hc = f;
        this.A = h;
        this.T = W(this, f.Bb);
        this.D = new qB(f.xb);
        g && (this.I = X(this, g))
    };
    _.S(um, Z);
    um.prototype.j = function() {
        var a, b = null == (a = this.D) ? void 0 : a.value;
        if (a = SG(this)) null != b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.m.error(eF()), a = !1) : a = !0 : a = !1;
        if (a) {
            a = new ti;
            var c = new KG(this.context, this.m, this.Y, this.M, this.hc, b, this.A.Hf);
            K(a, c);
            K(a, new PG(this.context, c.A, c.D, this.Y, b, this.hc.gd, this.hc.hd));
            Di(a)
        } else this.A.Hf.ha()
    };
    var SG = function(a) {
        var b;
        if (null == (b = a.I) ? 0 : b.value) return !0;
        var c = a.T.value;
        if (!c) return !1;
        var d;
        return !(null == (d = c["*"]) || !d.ed) || a.Hb.split(",").some(function(e) {
            var f;
            return !(null == (f = c[e]) || !f.ed)
        })
    };
    var TG = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.D = d;
        this.fe = e;
        this.A = W(this, b);
        this.m = W(this, c)
    };
    _.S(TG, Z);
    TG.prototype.j = function() {
        for (var a = this, b = _.y(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), c = b.next(), d = {}; !c.done; d = {
                Fc: d.Fc,
                vd: d.vd
            }, c = b.next()) d.Fc = c.value, d.vd = function(e) {
            return function(f) {
                if (a.D === f.adId) {
                    var g = new Qj("hbm_brt");
                    Wh(g, a.context);
                    J(g, "et", e.Fc);
                    J(g, "sf", a.A.value);
                    J(g, "qqid", a.m.value);
                    var h, k, l;
                    J(g, "bc", String(null != (l = null != (k = f.bidderCode) ? k : null == (h = f.bid) ? void 0 : h.bidder) ? l : ""));
                    Sj(g)
                }
            }
        }(d), (0, this.fe.onEvent)(d.Fc, d.vd), _.zn(this, function(e) {
            return function() {
                return void Hg(a.context, a.id, function() {
                    var f, g;
                    return void(null == (g = (f = a.fe).offEvent) ? void 0 : g.call(f, e.Fc, e.vd))
                }, !0)
            }
        }(d))
    };
    TG.prototype.o = function() {};
    var wm = function(a, b, c, d, e) {
        Z.call(this, a, 1134);
        this.se = d;
        this.tb = e;
        this.A = X(this, b);
        this.m = new qB(c)
    };
    _.S(wm, Z);
    wm.prototype.j = function() {
        var a;
        if (this.A.value && null != (a = this.m.value) && a.onEvent) {
            a = new ti;
            var b = new TG(this.context, this.se, this.tb, this.A.value, this.m.value);
            K(a, b);
            Di(a)
        }
    };
    var UG = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.G = b;
        this.ca = c;
        this.C = xB(this);
        d && (this.m = X(this, d.Zb));
        zB(this, e)
    };
    _.S(UG, Z);
    UG.prototype.j = function() {
        var a;
        pf("shared-storage", this.G.document) && (null == (a = this.m) ? 0 : a.value) && _.D(this.ca, 5) && (a = this.m.value, a({
            message: "goog:spam:client_age",
            pvsid: this.context.pvsid,
            sendPingToRCS: !1
        }));
        this.C.notify()
    };
    var Mp = function(a, b) {
        Z.call(this, a, 1110);
        this.G = b;
        this.C = V(this)
    };
    _.S(Mp, Z);
    Mp.prototype.j = function() {
        var a = this.G;
        a = _.G(ty) && void 0 !== a.credentialless && (_.G(uy) || a.crossOriginIsolated);
        this.C.H(a)
    };
    var VG = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.O = b;
        this.X = c;
        this.Z = d;
        this.C = xB(this);
        this.m = W(this, e);
        zB(this, f)
    };
    _.S(VG, Z);
    VG.prototype.j = function() {
        var a = this.X,
            b = a.ba;
        a = a.Y;
        for (var c = _.y(this.m.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.Z;
            Am(e, b) && !this.O.Rb(d) && Bm(d, f, e, b)
        }
        this.C.notify()
    };
    var WG = function(a, b, c, d, e) {
        Z.call(this, a, 864);
        this.O = b;
        this.X = c;
        this.Z = d;
        this.m = xB(this);
        this.A = W(this, e)
    };
    _.S(WG, Z);
    WG.prototype.j = function() {
        for (var a = _.y(this.A.value), b = a.next(); !b.done; b = a.next())
            if (b = b.value, _.ep(this.O, b)) {
                var c = this.X,
                    d = c.ba;
                c = c.Y[b.getDomId()];
                Am(c, d) && Bm(b, this.Z, c, d);
                $D(this.O, b);
                var e = void 0,
                    f = void 0;
                null != (e = null != (f = ym(c, 10)) ? f : _.D(d, 11)) && e && Bm(b, this.Z, c, d)
            }
        this.m.notify()
    };
    var Hm = function(a, b, c, d) {
        Z.call(this, a, 879);
        this.A = b;
        this.m = V(this);
        c && (this.D = W(this, d))
    };
    _.S(Hm, Z);
    Hm.prototype.j = function() {
        var a, b;
        (null != (b = null == (a = this.D) ? void 0 : a.value) ? b : fz(this.A)) ? (a = gz(this.A), this.m.Oa(a)) : this.m.ha()
    };
    var Gm = function(a, b, c) {
        Z.call(this, a, 896);
        this.m = b;
        this.lc = V(this);
        c && zB(this, c)
    };
    _.S(Gm, Z);
    Gm.prototype.j = function() {
        this.lc.H(fz(this.m))
    };
    var XG = function(a, b) {
        Z.call(this, a, 1018);
        this.Pd = xB(this);
        this.m = X(this, b)
    };
    _.S(XG, Z);
    XG.prototype.j = function() {
        var a, b, c, d = _.y(null != (c = null == (a = this.m.value) ? void 0 : null == (b = _.Rg(a, Yy, 5)) ? void 0 : Yc(b, 1, xc)) ? c : []);
        for (a = d.next(); !a.done; a = d.next()) nf(a.value);
        this.Pd.notify()
    };
    var YG = function(a, b) {
        Z.call(this, a, 1070);
        this.m = V(this);
        this.A = X(this, b)
    };
    _.S(YG, Z);
    YG.prototype.j = function() {
        var a, b = null == (a = this.A.value) ? void 0 : _.Rg(a, Yy, 5);
        if (b) {
            a = [];
            for (var c = _.y(Yc(b, 2, Cc)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new hv;
                var f = new fv;
                e = _.I(f, 1, e);
                d = _.vg(d, 2, e);
                null != $m(b, 3) && (e = new dv, e = _.I(e, 1, 1), e = _.I(e, 2, _.Re(b, 3)), _.vg(d, 3, e));
                a.push(d)
            }
            this.m.H(a)
        } else this.m.H([])
    };
    var ZG = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.C = V(this);
        this.A = X(this, b);
        this.m = X(this, c);
        this.D = BB(this, [b, d])
    };
    _.S(ZG, Z);
    ZG.prototype.j = function() {
        if (this.m.value) {
            var a = this.A.value || this.D.value;
            a && $G(this, a) ? this.C.H(a) : (this.C.ha(), aH(this, a))
        } else this.C.ha()
    };
    ZG.prototype.J = function(a) {
        this.o(a)
    };
    ZG.prototype.o = function() {
        this.C.ha()
    };
    var $G = function(a, b) {
            return Oe(a.m.value, bv, 1).some(function(c) {
                return _.R(c, 1) === b
            })
        },
        aH = function(a, b) {
            Qh("pp_iris_failure", function(c) {
                J(c, "fnc", b);
                Wh(c, a.context)
            }, _.rf(ey))
        };
    var bH = function(a, b) {
        Z.call(this, a, 1015);
        this.m = V(this);
        this.A = X(this, b)
    };
    _.S(bH, Z);
    bH.prototype.j = function() {
        if (this.A.value)
            if (Oe(this.A.value, bv, 1).length) {
                var a = Oe(this.A.value, bv, 1)[0];
                (_.C = [2, 3], _.v(_.C, "includes")).call(_.C, _.Qe(a, 3, 0)) ? this.m.H(_.R(a, 1)) : this.m.ha()
            } else this.m.ha();
        else this.m.ha()
    };
    bH.prototype.J = function(a) {
        this.o(a)
    };
    bH.prototype.o = function() {
        this.m.ha()
    };
    var cH = function(a, b, c) {
        Z.call(this, a, 1017);
        this.G = c;
        this.C = xB(this);
        this.m = X(this, b)
    };
    _.S(cH, Z);
    cH.prototype.j = function() {
        var a = this;
        if (this.m.value) {
            var b = tz(this.G, this.m.value, function(c) {
                if (!c) {
                    c = kw(b.j);
                    for (var d = _.y(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.Dh(e.value)
                }
                a.C.notify()
            });
            b.start()
        } else this.C.notify()
    };
    cH.prototype.J = function(a) {
        this.o(a)
    };
    cH.prototype.o = function() {
        this.C.notify()
    };
    var dH = function(a, b) {
        Z.call(this, a, 1056);
        this.C = V(this);
        this.m = W(this, b)
    };
    _.S(dH, Z);
    dH.prototype.j = function() {
        var a = rg(this.m.value.getAdUnitPath());
        this.C.H(a)
    };
    dH.prototype.J = function(a) {
        this.o(a)
    };
    dH.prototype.o = function() {
        this.C.ha()
    };
    var eH = function(a, b, c, d) {
        Z.call(this, a, 906, _.rf(cy));
        this.m = xB(this);
        if (b === b.top) {
            var e = new ti;
            _.O(this, e);
            var f = new bH(a, c);
            K(e, f);
            d = new tl(a, d, MD, function(g) {
                return g.detail.Y
            });
            K(e, d);
            d = new dH(a, d.C);
            K(e, d);
            a = new ZG(a, f.m, c, d.C);
            K(e, a);
            b = new cH(this.context, a.C, b);
            K(e, b);
            AB(this, b.C);
            Di(e)
        } else this.m.notify()
    };
    _.S(eH, Z);
    eH.prototype.j = function() {
        this.m.notify()
    };
    eH.prototype.J = function(a) {
        this.o(a)
    };
    eH.prototype.o = function() {
        this.m.notify()
    };
    var Om = {
        va: "|"
    };
    var Dq = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.G = b;
        this.slotId = c;
        zB(this, d);
        this.m = W(this, e)
    };
    _.S(Dq, Z);
    Dq.prototype.j = function() {
        var a = this;
        this.slotId.listen(ul, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.m.value,
                        g = new Hv;
                    var h = Ll(g, 1, d ? "1" : "0");
                    var k = Ll(_.I(h, 2, 2147483647), 3, "/");
                    var l = Ll(k, 4, a.G.location.hostname);
                    var m = new _.tA(a.G);
                    vA(m, "__gpi_opt_out", l, f);
                    if (d || e) wA(m, "__gads", f), wA(m, "__gpi", f)
                }
            } catch (n) {}
        })
    };
    var fH = function(a, b, c) {
        Z.call(this, a, 944);
        this.G = b;
        this.m = new _.tA(this.G);
        this.A = W(this, c)
    };
    _.S(fH, Z);
    fH.prototype.j = function() {
        var a = this.A.value;
        if (uA(this.m, a)) {
            var b = _.sk(this.m, "__gpi_opt_out", a);
            if (b) {
                var c = new Hv;
                b = Ll(c, 1, b);
                b = Ll(_.I(b, 2, 2147483647), 3, "/");
                b = Ll(b, 4, this.G.location.hostname);
                vA(this.m, "__gpi_opt_out", b, a)
            }
        }
    };
    var gH = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.ca = b;
        this.ua = c;
        this.m = W(this, d)
    };
    _.S(gH, Z);
    gH.prototype.j = function() {
        if (_.D(this.ca, 5))
            for (var a = new _.x.Set, b = _.y(Oe(this.m.value, Hv, 14)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = pu(c, 5)) ? d : 1;
                a.has(e) || (vA(this.ua, 2 === e ? "__gpi" : "__gads", c, this.ca), a.add(e))
            }
    };
    var hH = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.j = {}
        },
        iH = function(a, b) {
            if (!_.v(a.o, "includes").call(a.o, b) && (_.C = [1, 2, 3], _.v(_.C, "includes")).call(_.C, b)) {
                var c = yA[b];
                if (c) {
                    var d = b + "_hostpage_library";
                    if (c = _.Tj(document, c)) c.id = d
                }
                a.o.push(b);
                b = new zA(b);
                a.hostpageLibraryTokens.push(b);
                a = Lj();
                a.hostpageLibraryTokens || (a.hostpageLibraryTokens = {});
                a.hostpageLibraryTokens[b.j] = b.o
            }
        },
        jH = function(a, b, c) {
            var d;
            a.j[b] = null != (d = a.j[b]) ? d : new _.x.Set;
            a.j[b].add(c)
        },
        Bp = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.j[b]) ? void 0 : _.v(c, "values").call(c)) ? d : [];
            return [].concat(_.se(a))
        };
    var kH = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Na = c;
        this.m = W(this, d)
    };
    _.S(kH, Z);
    kH.prototype.j = function() {
        for (var a = this, b = Yc(this.m.value, 23, yc), c = _.y(b), d = c.next(); !d.done; d = c.next()) d = d.value, iH(this.Na, d), jH(this.Na, d, this.slotId);
        b.length && Qh("gpt_hp", function(e) {
            Wh(e, a.context);
            J(e, "ls", b.join())
        }, _.rf(Gx))
    };
    var lH = function(a, b, c) {
        c = void 0 === c ? Ym : c;
        Z.call(this, a, 883);
        this.D = c;
        this.m = xB(this);
        this.A = W(this, b)
    };
    _.S(lH, Z);
    lH.prototype.j = function() {
        !_.D(this.A.value, 5) || _.G(Rx) ? this.m.notify() : this.D() ? rB(this.m, new _.x.Promise(function(a) {
            return void JA(a)
        })) : (JA(null), this.m.notify())
    };
    var Nq = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.G = b;
        this.I = X(this, c);
        this.A = W(this, d);
        this.m = W(this, e);
        this.D = W(this, f)
    };
    _.S(Nq, Z);
    Nq.prototype.j = function() {
        var a = this,
            b = this.I.value,
            c, d = null == b ? void 0 : null == (c = _.bh(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = _.bh(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.A.value;
            c = this.m.value;
            var f = this.D.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                m = Zm(e.id + "_top", d),
                n = Zm(e.id + "_bottom", b);
            _.Jh(n, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(m);
            f.appendChild(n);
            _.Jh(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.Jh(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.Jh(f, {
                position: "relative",
                display: (null == (p = this.G.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            eG(this, 722, this.G, "orientationchange", function() {
                var r;
                (null == (r = a.G.screen.orientation) ? 0 : r.angle) ? _.Jh(f, {
                    display: "none"
                }): _.Jh(f, {
                    display: "block"
                })
            });
            _.zn(this, function() {
                _.tw(m);
                _.tw(n);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var mH = _.Ar(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        zq = function(a, b, c) {
            Z.call(this, a, 1007);
            this.m = X(this, b);
            c && zB(this, c)
        };
    _.S(zq, Z);
    zq.prototype.j = function() {
        var a = this.m.value;
        if (null != a && a.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
            var b = document.createElement("iframe");
            a = tb(mH, encodeURIComponent(a.join()));
            b.removeAttribute("srcdoc");
            if (a instanceof _.qs) throw new wt("TrustedResourceUrl", 3);
            var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
            b.setAttribute("sandbox", "");
            for (var d = 0; d < c.length; d++) b.sandbox.supports && !b.sandbox.supports(c[d]) || b.sandbox.add(c[d]);
            a = _.db(a);
            void 0 !== a && (b.src = a);
            b.id = "koelBirdIGRegisterIframe";
            document.head.appendChild(b)
        }
    };
    var bq = function(a, b) {
        Z.call(this, a, 1176);
        this.A = b;
        this.m = V(this)
    };
    _.S(bq, Z);
    bq.prototype.j = function() {
        var a, b = this.m,
            c = b.Ba,
            d = null != (a = this.A) ? a : new cq;
        a = null != $m(d, 2) ? null != an(d, 3) && 0 !== (0, _.bn)() ? $m(d, 2) * an(d, 3) : $m(d, 2) : null;
        c.call(b, a)
    };
    var tq = function(a, b, c, d, e, f) {
        f = void 0 === f ? dn : f;
        Z.call(this, a, 666);
        this.A = f;
        this.C = xB(this);
        zB(this, b);
        e && zB(this, e);
        this.m = W(this, c);
        this.D = X(this, d)
    };
    _.S(tq, Z);
    tq.prototype.j = function() {
        var a = this.D.value,
            b = this.m.value;
        null == a || 0 > a || !zh(b) ? this.C.notify() : nH(this, a, b)
    };
    var nH = function(a, b, c) {
        var d = a.A(b, Bg(a.context, 291, function(e, f) {
            e = _.y(e);
            for (var g = e.next(); !g.done; g = e.next())
                if (g = g.value, !(0 >= g.intersectionRatio)) {
                    f.unobserve(g.target);
                    a.C.notify();
                    break
                }
        }));
        d ? (d.observe(c), _.zn(a, function() {
            d.disconnect()
        })) : a.C.notify()
    };
    var rq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.Dc = c;
        this.O = d;
        this.C = xB(this);
        this.A = W(this, e);
        this.m = X(this, f);
        g && zB(this, g)
    };
    _.S(rq, Z);
    rq.prototype.j = function() {
        var a = this,
            b, c = null != (b = this.m.value) ? b : 0;
        if (0 !== (0, _.bn)() || 0 < c)
            if (b = VA(document), WA(document) && b && (0 < ZD(this.O, this.slotId) || !oH(this)) && b) {
                var d = eG(this, 324, document, b, function() {
                    WA(document) || (d && d(), a.C.notify())
                });
                if (d) return
            }
        this.C.notify()
    };
    var oH = function(a) {
        try {
            var b = top;
            if (!b) return !0;
            var c = Qq(b.document, b).y,
                d = c + a.Dc.height,
                e = a.A.value;
            return e.y >= c && e.y <= d
        } catch (f) {
            return !0
        }
    };
    var qq = function(a, b) {
        Z.call(this, a, 676);
        this.C = V(this);
        this.m = W(this, b)
    };
    _.S(qq, Z);
    qq.prototype.j = function() {
        var a = kh(this.m.value);
        this.C.H(a)
    };
    var en = function(a, b, c, d, e, f, g) {
        g = void 0 === g ? _.x.globalThis.IntersectionObserver : g;
        Z.call(this, a, 886);
        this.ga = b;
        this.O = c;
        this.D = d;
        this.A = e;
        this.m = g;
        this.C = xB(this);
        zB(this, f)
    };
    _.S(en, Z);
    en.prototype.j = function() {
        if (this.A) var a = this.A;
        else if (a = this.D ? cn(this.D) : null, null == a) {
            this.C.notify();
            return
        }
        this.ga.some(function(b) {
            return !zh(vh(b))
        }) ? this.C.notify() : rB(this.C, pH(this, a))
    };
    var pH = function(a, b) {
        return new _.x.Promise(function(c) {
            if (a.m) {
                for (var d = new a.m(function(h, k) {
                        h.some(function(l) {
                            return 0 < l.intersectionRatio
                        }) && (k.disconnect(), c())
                    }, {
                        rootMargin: b + "%"
                    }), e = _.y(a.ga), f = e.next(), g = {}; !f.done; g = {
                        Ic: g.Ic
                    }, f = e.next()) {
                    f = f.value;
                    g.Ic = vh(f);
                    if (!g.Ic) return;
                    d.observe(g.Ic);
                    UD(a.O, f, function(h) {
                        return function() {
                            return void d.unobserve(h.Ic)
                        }
                    }(g))
                }
                _.zn(a, function() {
                    return void d.disconnect()
                })
            } else c()
        })
    };
    var qH = {},
        gn = (qH[64] = hF, qH[134217728] = iF, qH[32768] = jF, qH[536870912] = kF, qH[8] = lF, qH[512] = mF, qH[1048576] = nF, qH[4194304] = pF, qH);
    var pn = function(a) {
        return "22639388115" === rg(a.getAdUnitPath())
    };
    var rH = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1109);
        this.Z = c;
        this.ba = d;
        this.m = e;
        this.D = f;
        this.I = g;
        this.A = h;
        this.C = V(this);
        this.M = X(this, b)
    };
    _.S(rH, Z);
    rH.prototype.j = function() {
        var a = this,
            b = this.M.value;
        b && (this.A.push(function() {
            b.addService(a.m)
        }), Ww(this.Z, function() {
            a.I();
            a.D(b);
            _.D(a.ba, 4) && a.m.refresh([b])
        }))
    };
    var sH = function(a, b, c, d, e, f) {
        Z.call(this, a, 1108);
        this.adUnitPath = b;
        this.format = c;
        this.hb = d;
        this.D = e;
        this.A = f;
        this.C = V(this);
        this.m = V(this)
    };
    _.S(sH, Z);
    sH.prototype.j = function() {
        var a = yn(this.context, this.A, this.D, {
            gg: this.format,
            adUnitPath: this.adUnitPath,
            hb: this.hb
        });
        this.m.Ba(a);
        this.C.Ba(a ? a.j : null)
    };
    var tH = function(a, b, c, d) {
        Z.call(this, a, 1111);
        this.m = c;
        this.A = d;
        this.D = X(this, b)
    };
    _.S(tH, Z);
    tH.prototype.j = function() {
        var a = this.D.value;
        a && (a = fC(this.m, a.getSlotElementId()), qi(a, 27, hv, this.A))
    };
    var uH = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        ti.call(this);
        this.context = a;
        this.Z = b;
        this.adUnitPath = c;
        this.format = d;
        this.hb = e;
        this.W = f;
        this.I = g;
        this.M = h;
        this.D = k;
        this.ba = l;
        this.aa = m;
        this.da = n;
        this.T = p;
        this.A = r;
        a = K(this, new sH(this.context, this.adUnitPath, this.format, this.hb, this.da, this.T));
        this.A && K(this, new tH(this.context, a.C, this.aa, this.A));
        K(this, new rH(this.context, a.C, this.Z, this.ba, this.W, this.I, this.M, this.D));
        this.j = {
            gl: a.m
        }
    };
    _.S(uH, ti);
    var vH = [{
            name: "Interstitial",
            format: 1,
            rf: 5
        }, {
            name: "TopAnchor",
            format: 2,
            rf: 2
        }, {
            name: "BottomAnchor",
            format: 3,
            rf: 3
        }],
        wH = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 789);
            this.Z = b;
            this.googletag = c;
            this.D = d;
            this.m = e;
            this.A = f;
            this.I = g;
            this.C = V(this)
        };
    _.S(wH, Z);
    wH.prototype.j = function() {
        var a = this;
        vH.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.I)
        }).forEach(function(b) {
            var c = b.name;
            b = b.rf;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            c = new uH(a.context, a.Z, "/22639388115/example/" + c.toLowerCase(), b, !1, a.googletag.pubads(), function(f) {
                return void a.googletag.display(f)
            }, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, a.googletag.cmd, a.m.j, a.m, a.D, a.A);
            _.O(a, c);
            Di(c)
        })
    };
    var xH = function(a, b, c) {
        Z.call(this, a, 1163);
        _.G(Eq);
        this.m = W(this, b);
        c && zB(this, c)
    };
    _.S(xH, Z);
    xH.prototype.j = function() {
        this.m.value.Ch();
        this.m.value.sa()
    };
    var Gq = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 682);
        this.O = b;
        this.format = c;
        this.slotId = d;
        this.G = e;
        this.A = V(this);
        this.m = X(this, f);
        this.D = W(this, g);
        this.T = W(this, h);
        this.I = X(this, k);
        this.M = W(this, l)
    };
    _.S(Gq, Z);
    Gq.prototype.j = function() {
        var a = this,
            b;
        if (null != (b = this.m.value) && _.D(b, 12, !1)) {
            b = this.I.value.ji;
            var c = _.ep(this.O, this.slotId),
                d = this.T.value,
                e = this.D.value;
            _.Jh(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (yH) yH.Ah(e, this.M.value);
            else {
                yH = new b(this.context, this.format, e, this.G, d, this.O, this.slotId);
                b = {};
                d = _.y(Oe(this.m.value, rv, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[_.bh(f, 1)] = _.bh(f, 2);
                yH.Bh(b);
                _.G(Eq) ? (yH.xh(), this.A.H(yH)) : yH.sa();
                TD(this.O, this.slotId, function() {
                    yH && (yH.wa(), yH = null);
                    c && _.XD(a.O, a.slotId)
                })
            }
            _.zn(this, function() {
                return _.tw(e)
            })
        }
    };
    var yH = null;
    var Fq = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1155);
        this.O = b;
        this.format = c;
        this.slotId = d;
        this.G = e;
        this.Te = f;
        this.A = g;
        this.M = h;
        this.D = k;
        this.I = l;
        this.m = X(this, f)
    };
    _.S(Fq, Z);
    Fq.prototype.j = function() {
        var a;
        if (null != (a = this.m.value) && null != Gk(a, 12)) {
            a = new ti;
            _.O(this, a);
            var b, c = (null == (b = this.m.value) ? 0 : _.D(b, 15)) ? K(a, new An(this.context, this.slotId, ul, function(d) {
                d = d.detail.data;
                try {
                    var e = JSON.parse(d);
                    return "floating" === e.type && "loaded" === e.message
                } catch (f) {}
                return !1
            })).C : void 0;
            b = new Gq(this.context, this.O, this.format, this.slotId, this.G, this.Te, this.A, this.M, this.D, this.I);
            K(a, b);
            b = new xH(this.context, b.A, c);
            K(a, b);
            Di(a)
        }
    };
    var Gn = function(a, b, c) {
        Z.call(this, a, 1150);
        this.G = b;
        this.C = xB(this);
        zB(this, c)
    };
    _.S(Gn, Z);
    Gn.prototype.j = function() {
        var a = this;
        this.G.location.hash = "goog_game_inter";
        _.zn(this, function() {
            "goog_game_inter" === a.G.location.hash && (a.G.location.hash = "")
        });
        rB(this.C, new _.x.Promise(function(b) {
            return void eG(a, a.id, a.G, "hashchange", function(c) {
                xs(c.oldURL, "#goog_game_inter") && b()
            })
        }))
    };
    var zH = function(a, b) {
            this.serviceName = b;
            this.slot = a.j
        },
        AH = function(a, b) {
            zH.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.S(AH, zH);
    AH.prototype.setSize = function(a) {
        this.size = a;
        return this
    };
    var BH = function() {
        zH.apply(this, arguments)
    };
    _.S(BH, zH);
    var CH = function(a, b, c) {
        zH.call(this, a, b);
        this.inViewPercentage = c
    };
    _.S(CH, zH);
    var DH = function() {
        zH.apply(this, arguments)
    };
    _.S(DH, zH);
    var EH = function() {
        zH.apply(this, arguments)
    };
    _.S(EH, zH);
    var FH = function() {
        zH.apply(this, arguments)
    };
    _.S(FH, zH);
    var GH = function() {
        zH.apply(this, arguments)
    };
    _.S(GH, zH);
    var HH = function(a, b, c, d) {
        zH.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.S(HH, zH);
    var IH = function(a, b, c) {
        zH.call(this, a, b);
        this.payload = c
    };
    _.S(IH, zH);
    var JH = function() {
        zH.apply(this, arguments)
    };
    _.S(JH, zH);
    var KH = function(a, b, c) {
        zH.call(this, a, b);
        this.makeGameManualInterstitialVisible = c
    };
    _.S(KH, zH);
    var LH = function() {
        zH.apply(this, arguments)
    };
    _.S(LH, zH);
    var Hn = function(a, b, c, d, e, f) {
        Z.call(this, a, 1151);
        this.slotId = b;
        this.ta = c;
        zB(this, d);
        a = [e];
        f && a.push(f);
        f = new sB(a, !0);
        eB(this.B, f)
    };
    _.S(Hn, Z);
    Hn.prototype.j = function() {
        cp(this.ta, "gameManualInterstitialSlotClosed", 1148, new LH(this.slotId, "publisher_ads"))
    };
    var En = function(a, b, c, d) {
        Z.call(this, a, 1149);
        this.slotId = b;
        this.ta = c;
        this.C = xB(this);
        zB(this, d)
    };
    _.S(En, Z);
    En.prototype.j = function() {
        var a = new _.Lf,
            b = a.promise;
        cp(this.ta, "gameManualInterstitialSlotReady", 1147, new KH(this.slotId, "publisher_ads", a.resolve));
        rB(this.C, b)
    };
    var Dn = function(a, b, c) {
        c = void 0 === c ? MH : c;
        Z.call(this, a, 1158);
        this.m = c;
        this.A = 1E3 * _.rf(Cn);
        this.C = xB(this);
        zB(this, b)
    };
    _.S(Dn, Z);
    Dn.prototype.j = function() {
        var a = this;
        this.m.ee++ ? rB(this.C, Xw(this.A * (this.m.ee - 2) + (this.A - (Date.now() - this.m.bf))).then(function() {
            a.m.bf = Date.now();
            a.m.ee--
        })) : (this.m.bf = Date.now(), Xw(this.A).then(function() {
            return void a.m.ee--
        }), this.C.notify())
    };
    var MH = {
        ee: 0,
        bf: Date.now()
    };
    var NH = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        OH = {
            width: "100%",
            height: "100%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        Fn = function(a, b, c, d, e) {
            Z.call(this, a, 1150);
            this.G = b;
            this.m = W(this, c);
            this.D = W(this, d);
            zB(this, e);
            this.A = new _.HB(this.G)
        };
    _.S(Fn, Z);
    Fn.prototype.j = function() {
        var a = 0 === (0, _.bn)() ? "rgba(1,1,1,0.5)" : "white";
        _.Jh(this.m.value, _.v(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.bn)() ? OH : NH));
        _.Jh(this.D.value, _.v(Object, "assign").call(Object, {
            "background-color": a,
            opacity: "1",
            position: "fixed",
            margin: "0",
            padding: "0",
            "z-index": "2147483647",
            display: "block"
        }, NH));
        _.zn(this, _.SB(this.G.document, this.G));
        a = {};
        ww(this.m.value).postMessage(JSON.stringify((a.googMsgType = "sth", a.msg_type = "i-view", a)), "*");
        if (this.G === this.G.top) {
            var b = _.JB(this.A, 2147483646);
            _.MB(b);
            _.zn(this, function() {
                return void _.NB(b)
            })
        }
    };
    var PH = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.T = c;
        this.A = d;
        this.m = V(this);
        this.D = W(this, e);
        this.W = W(this, f);
        this.I = X(this, g);
        this.M = X(this, h)
    };
    _.S(PH, Z);
    PH.prototype.j = function() {
        var a = this,
            b = null != Tg(this.A, 14) ? 60 * vl(this.A, 14) : 604800;
        b = new this.M.value.Bi(window, this.D.value, this.W.value, new _.XB(this.context), this.T, QH(this), pn(this.slotId), function() {
            return void a.wa()
        }, b, this.I.value);
        _.O(this, b);
        this.m.H(b)
    };
    var QH = function(a) {
        var b = {};
        a = _.y(Oe(a.A, rv, 13));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[_.bh(c, 1)] = _.bh(c, 2);
        return b
    };
    var RH = function(a, b, c) {
        Z.call(this, a, 1142);
        this.m = _.rf(Ux);
        this.A = W(this, b);
        1 === this.m && zB(this, c)
    };
    _.S(RH, Z);
    RH.prototype.j = function() {
        this.A.value.aa(1 === this.m)
    };
    var SH = function(a, b, c, d, e) {
        Z.call(this, a, 1143);
        this.A = d;
        this.D = e;
        zB(this, b);
        a = new sB([d, e], !0);
        eB(this.B, a);
        this.m = W(this, c)
    };
    _.S(SH, Z);
    SH.prototype.j = function() {
        var a = new Qj("int_pm");
        J(a, "ts", Date.now());
        J(a, "flg", _.rf(Ux));
        J(a, "qem", this.m.value);
        J(a, "cr", Number(this.A.kb));
        J(a, "ph", Number(this.D.kb));
        Sj(a)
    };
    SH.prototype.o = function() {};
    var Hq = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1141);
        this.slotId = b;
        this.I = c;
        this.G = d;
        this.A = f;
        this.M = g;
        this.jb = h;
        this.D = k;
        this.tb = l;
        this.C = V(this);
        this.m = X(this, e)
    };
    _.S(Hq, Z);
    Hq.prototype.j = function() {
        var a = this;
        if (this.m.value) {
            var b = new ti;
            _.O(this, b);
            var c = K(b, new PH(this.context, this.slotId, this.I, this.m.value, this.A, this.M, this.jb, this.D));
            _.zn(c, function() {
                return void a.wa()
            });
            var d = _.rf(Ux),
                e = wh(function() {
                    return K(b, new An(a.context, a.slotId, ul, function(f) {
                        f = f.detail;
                        try {
                            var g = JSON.parse(f.data);
                            return "sth" === g.googMsgType && "i-adframe-load" === g.msg_type
                        } catch (h) {
                            return !1
                        }
                    })).C
                });
            switch (d) {
                case 0:
                    K(b, new RH(this.context, c.m, e()));
                    break;
                case 1:
                    K(b, new RH(this.context, c.m, e()))
            }
            Math.random() < _.rf(Vx) && (d = K(b, new nG(this.context, this.G, "pagehide")), K(b, new SH(this.context, c.m, this.tb, e(), d.C)));
            this.C.Oa(c.m.promise.then(function() {
                return !0
            }));
            Di(b)
        } else this.C.H(!1)
    };
    var TH = function(a) {
        this.module = a
    };
    TH.prototype.toString = function() {
        return String(this.module)
    };
    _.UH = new TH(2);
    _.VH = new TH(5);
    var yq = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.D = b;
        this.format = c;
        this.C = V(this);
        this.m = X(this, d);
        this.A = X(this, e);
        f && zB(this, f)
    };
    _.S(yq, Z);
    yq.prototype.j = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.m.value) || !_.D(a, 12, !1));
        a = 5 === this.format && this.A.value;
        b || a ? this.C.Oa(this.D.load(_.UH)) : this.C.ha()
    };
    var WH = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.X = b;
        this.m = c;
        this.C = xB(this);
        this.A = W(this, d);
        zB(this, e)
    };
    _.S(WH, Z);
    WH.prototype.j = function() {
        for (var a = _.y(this.A.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            switch (null == (c = this.X.Y[b.value.getDomId()]) ? void 0 : on(c)) {
                case 2:
                case 3:
                case 5:
                    this.m.load(_.UH);
                    return
            }
        }
        this.C.notify()
    };
    var XH = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.ta = c;
        zB(this, d);
        BB(this, [e, f])
    };
    _.S(XH, Z);
    XH.prototype.j = function() {
        cp(this.ta, "rewardedSlotClosed", 703, new JH(this.slotId, "publisher_ads"))
    };
    var YH = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.ta = c;
        zB(this, d);
        this.m = X(this, e)
    };
    _.S(YH, Z);
    YH.prototype.j = function() {
        var a, b = null == (a = this.m.value) ? void 0 : a.payload;
        cp(this.ta, "rewardedSlotGranted", 702, new IH(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var ZH = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        $H = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.G = b;
            this.I = f;
            this.C = xB(this);
            this.A = W(this, c);
            this.D = W(this, d);
            zB(this, e);
            this.m = new _.HB(this.G)
        };
    _.S($H, Z);
    $H.prototype.j = function() {
        var a = this;
        if (!this.I.kb) {
            var b = 0 === (0, _.bn)() ? "rgba(1,1,1,0.5)" : "white";
            _.Jh(this.D.value, _.v(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, ZH));
            _.zn(this, _.SB(this.G.document, this.G));
            ww(this.A.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.G === this.G.top) {
                this.G.location.hash = "goog_rewarded";
                var c = _.JB(this.m, 2147483646);
                _.MB(c);
                _.zn(this, function() {
                    _.NB(c);
                    "goog_rewarded" === a.G.location.hash && (a.G.location.hash = "")
                })
            }
            this.C.notify()
        }
    };
    var aI = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.G = b;
        this.m = W(this, c);
        zB(this, d)
    };
    _.S(aI, Z);
    aI.prototype.j = function() {
        if (this.G === this.G.top) var a = ww(this.m.value),
            b = eG(this, 503, this.G, "hashchange", function(c) {
                xs(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var bI = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.ta = c;
        this.C = xB(this);
        this.m = W(this, d)
    };
    _.S(bI, Z);
    bI.prototype.j = function() {
        var a = this.m.value,
            b = new _.Lf,
            c = b.promise,
            d;
        cp(this.ta, "rewardedSlotReady", 701, new HH(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        rB(this.C, c)
    };
    var cI = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        dI = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        eI = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.D = V(this);
            this.A = xB(this);
            this.I = W(this, c);
            this.m = BB(this, [d, e])
        };
    _.S(eI, Z);
    eI.prototype.j = function() {
        "ha_before_make_visible" === this.m.value.message ? this.A.notify() : (_.Jh(this.I.value, _.v(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.bn)() ? dI : cI)), this.D.H(this.m.value))
    };
    var Iq = function(a, b, c, d, e, f) {
        ti.call(this);
        var g = Jn(b, "granted", a);
        K(this, g);
        var h = Jn(b, "prefetched", a);
        K(this, h);
        var k = Jn(b, "closed", a);
        K(this, k);
        var l = Jn(b, "ha_before_make_visible", a);
        K(this, l);
        var m = new eI(a, b, e, h.C, l.C);
        K(this, m);
        h = new bI(a, b, c, m.D);
        K(this, h);
        f = new $H(a, d, e, f, h.C, m.A);
        K(this, f);
        K(this, new aI(a, d, e, f.C));
        K(this, new YH(a, b, c, h.C, g.C));
        K(this, new XH(a, b, c, h.C, k.C, l.C))
    };
    _.S(Iq, ti);
    var Qp = function(a, b) {
        Z.call(this, a, 1031);
        this.G = b
    };
    _.S(Qp, Z);
    Qp.prototype.j = function() {
        this.G === this.G.top && vj(this.G)
    };
    var Op = function(a, b, c) {
        c = void 0 === c ? Pf : c;
        Z.call(this, a, 1063);
        this.G = b;
        this.A = c;
        this.m = V(this)
    };
    _.S(Op, Z);
    Op.prototype.j = function() {
        var a = this;
        if (_.G(Ox) && Qf(this.G)) {
            var b = null,
                c = 0,
                d = Bg(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.wb(function(l) {
                        switch (l.j) {
                            case 1:
                                return f = a.A(a.G), g = "0", l.F = 2, xb(l, f, 4);
                            case 4:
                                g = null != (h = l.o) ? h : "0";
                                1E4 < g.length && (Fg(a.context, a.id, new dl("ML:" + g.length)), g = "0");
                                l.j = 3;
                                l.F = 0;
                                break;
                            case 2:
                                k = zb(l), Fg(a.context, a.id, k);
                            case 3:
                                b = g, c = _.ff(a.G) + 3E5, l.j = 0
                        }
                    })
                });
            var e = (_.C = d(), _.v(_.C, "finally")).call(_.C, function() {
                e = void 0
            });
            this.m.H(function() {
                var f, g;
                return _.wb(function(h) {
                    if (1 == h.j) {
                        f = _.ff(a.G) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.j = 2;
                            return
                        }
                        e || (e = (_.C = d(), _.v(_.C, "finally")).call(_.C, function() {
                            e = void 0
                        }));
                        return xb(h, e, 2)
                    }
                    return h.return(b)
                })
            })
        } else this.m.H(function() {
            return _.x.Promise.resolve("")
        })
    };
    Op.prototype.o = function() {
        this.m.H(function() {
            return _.x.Promise.resolve("")
        })
    };
    var fI = function(a, b) {
        Z.call(this, a, 1091);
        this.C = V(this);
        b && (this.m = X(this, b))
    };
    _.S(fI, Z);
    fI.prototype.j = function() {
        var a;
        null != (a = this.m) && a.value ? this.C.Oa(this.m.value()) : this.C.H("")
    };
    fI.prototype.o = function() {
        this.C.H("")
    };
    var gI = function(a, b) {
        Z.call(this, a, 1122);
        this.Z = b;
        this.C = xB(this)
    };
    _.S(gI, Z);
    gI.prototype.j = function() {
        var a = this;
        3 === _.UA(this.Z) ? rB(this.C, new _.x.Promise(function(b) {
            return void YA(b, a.Z)
        })) : this.C.notify()
    };
    var Rp = function(a, b, c) {
        Z.call(this, a, 1107);
        this.G = b;
        this.C = this.pb = c
    };
    _.S(Rp, Z);
    Rp.prototype.j = function() {
        var a = pf("run-ad-auction", this.G.document),
            b = pf("browsing-topics", this.G.document),
            c = pf("shared-storage", this.G.document),
            d = pf("attribution-reporting", this.G.document),
            e = 0;
        a && (e |= 1);
        b && (e |= 4);
        c && (e |= 8);
        d && (e |= 2);
        0 === e ? this.C.ha() : this.C.H(e)
    };
    Rp.prototype.o = function() {
        this.C.ha()
    };
    var hI = function(a, b, c, d) {
        Z.call(this, a, 1118);
        this.m = b;
        this.A = d;
        V(this, d);
        c && (this.D = X(this, c))
    };
    _.S(hI, Z);
    hI.prototype.j = function() {
        var a = new bB;
        a = _.ld(a, 1, this.m, 0);
        if (this.m & 1) {
            var b, c, d = iI(null != (c = null == (b = this.D) ? void 0 : b.value) ? c : null);
            _.vg(a, 2, d)
        }
        this.A.H(a)
    };
    var iI = function(a) {
        switch (_.rf(Sp)) {
            case 1:
                var b = 1;
                break;
            case 2:
                b = 2;
                break;
            case 3:
                b = 3;
                break;
            default:
                b = 0
        }
        var c = aB(new $A, b);
        null == a || a.forEach(function(d, e) {
            var f = hd(c, 2, ZA);
            var g = f.set,
                h = new ZA;
            d = _.id(h, 1, d, Dc);
            g.call(f, e, d)
        });
        return c
    };
    var Xn = function(a, b, c, d) {
        Z.call(this, a, 1165);
        this.A = c;
        this.ge = d;
        this.m = X(this, b.Ig)
    };
    _.S(Xn, Z);
    Xn.prototype.j = function() {
        if (this.m.value) {
            var a = new ti,
                b = new hI(this.context, this.m.value, this.A, this.ge.wf);
            K(a, b);
            Di(a)
        } else this.ge.wf.ha()
    };
    var jI = function(a, b, c) {
        Z.call(this, a, 873);
        this.G = b;
        this.m = W(this, c)
    };
    _.S(jI, Z);
    jI.prototype.j = function() {
        var a = this.context,
            b = this.m.value,
            c = this.G;
        !Lj()._pubconsole_disable_ && (b = df("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || Nj(a, c))
    };
    var kI = function() {
        this.resources = {}
    };
    var to = "3rd party ad content";
    var lI = function(a, b, c) {
        _.U.call(this);
        this.context = a;
        this.Ta = b;
        this.o = c;
        a = c.slotId;
        b = c.size;
        this.j = "height" === c.ki ? "fluid" : [b.width, b.height];
        this.Vc = Ch(a);
        this.Wc = to
    };
    _.S(lI, _.U);
    lI.prototype.render = function() {
        var a = this.Ta,
            b = this.o,
            c = b.slotId,
            d = b.X.Y,
            e = b.size,
            f = b.Pe,
            g = b.isBackfill,
            h = b.rd;
        Wf(b.Yg, _.qw(b.Z), null != f ? f : "", !1);
        bp(_.lf(Dg), "5", vl(d[c.getDomId()], 20));
        cp(c, dp, 801, {
            bg: 0 === a.kind ? a.ob : "",
            isBackfill: g
        });
        a = this.m();
        h && a && a.setAttribute("data-google-container-id", h);
        cp(c, fp, 825, {
            size: e,
            isEmpty: !1
        });
        return a
    };
    lI.prototype.loaded = function(a) {
        var b = this.o,
            c = b.slotId,
            d = b.ta;
        b = b.X.Y;
        cp(c, HD, 844);
        a && a.setAttribute("data-load-complete", !0);
        cp(d, "slotOnload", 710, new DH(c, "publisher_ads"));
        bp(_.lf(Dg), "6", vl(b[c.getDomId()], 20))
    };
    var mI = function(a) {
        a = a.Ta;
        a = 0 === a.kind ? a.ob : "";
        var b = "",
            c = !0,
            d = "sf";
        b = void 0 === b ? "" : b;
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? "" : d;
        if (a) {
            var e = a.toLowerCase(); - 1 < e.indexOf("<!doctype") || -1 < e.indexOf("<html") ? c && qg(d, 2) : (c && qg(d, 3), a = _.G(Cy) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>")
        } else c && qg(d, 1);
        return a
    };
    lI.prototype.F = function() {
        _.U.prototype.F.call(this);
        this.o.Yg.removeAttribute("data-google-query-id")
    };
    lI.prototype.J = function(a) {
        var b = this,
            c = nI(this, function() {
                return void b.loaded(c.j)
            }, a);
        _.zn(this, function() {
            100 != c.status && (2 == c.D && (BC(c.F), c.D = 0), window.clearTimeout(c.I), c.I = -1, c.A = 3, c.o && (c.o.wa(), c.o = null), _.Be(window, "resize", c.pa), _.Be(window, "scroll", c.pa), c.m && c.j && c.m == _.uw(c.j) && c.m.removeChild(c.j), c.j = null, c.m = null, c.status = 100)
        });
        return c
    };
    var nI = function(a, b, c) {
        var d = a.o,
            e = d.Tg,
            f = d.isBackfill,
            g = d.Ci,
            h = d.rd,
            k = d.Od,
            l = d.Ae,
            m = d.Na,
            n = Array.isArray(a.j) ? new _.oh(Number(a.j[0]), Number(a.j[1])) : 1;
        return new JC({
            uf: d.Wf,
            Vc: a.Vc,
            Wc: a.Wc,
            content: mI(a),
            size: n,
            di: !!g,
            Dg: b,
            Ug: null != e ? e : void 0,
            permissions: {
                Md: null != Gk(c, 1) ? !!_.D(c, 1) : !f,
                Nd: null != Gk(c, 2) ? !!_.D(c, 2) : !1
            },
            Xc: !!Lj().fifWin,
            rj: GF ? GF : GF = wk(),
            Oh: Ak(),
            hostpageLibraryTokens: m.hostpageLibraryTokens,
            bb: function(p, r) {
                return void Fg(a.context, p, r)
            },
            uniqueId: h,
            Sg: gC(),
            Od: null != k ? k : void 0,
            eb: void 0,
            Ae: null != l ? l : void 0
        })
    };
    var oI = function() {
        lI.apply(this, arguments)
    };
    _.S(oI, lI);
    oI.prototype.m = function() {
        var a = this.o,
            b = a.X,
            c = b.ba;
        a = b.Y[a.slotId.getDomId()];
        b = new Bk;
        c = Hk([b, c.Qb(), null == a ? void 0 : a.Qb()]);
        return lI.prototype.J.call(this, c).j
    };
    oI.prototype.B = function() {
        return !1
    };
    var fq = function(a, b, c, d, e, f) {
        Z.call(this, a, 669);
        this.ba = b;
        this.Y = c;
        this.C = V(this);
        this.A = X(this, d);
        this.m = W(this, e);
        f && (this.D = W(this, f))
    };
    _.S(fq, Z);
    fq.prototype.j = function() {
        var a;
        if (null == (a = this.D) ? 0 : a.value) this.C.H(!0);
        else {
            var b;
            a = !(null == (b = this.A.value) || !_.bh(b, 1)) && (_.D(this.Y, 12) || Gk(this.ba, 13)) || this.m.value;
            this.C.H(!!a)
        }
    };
    var pI = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.m = b;
        this.G = c;
        this.C = xB(this);
        zB(this, d)
    };
    _.S(pI, Z);
    pI.prototype.j = function() {
        if (!_.G(iy)) {
            var a = this.m,
                b = this.G,
                c = gC();
            c = {
                version: GF ? GF : GF = wk(),
                ke: c
            };
            c = QC.Ki(c);
            var d = xC(b);
            c = d ? le(c, new _.x.Map([
                ["n", String(d)]
            ])) : c;
            d = sf(yk);
            for (var e = new _.x.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
            c = le(c, e);
            var g;
            a.resources[c.toString()] || (null == (g = Lj()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.Ae("IFRAME"), a.src = _.ib(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)))
        }
        this.C.notify()
    };
    var qI = function(a, b, c) {
        Z.call(this, a, 1135);
        this.A = b;
        this.D = c;
        this.m = V(this)
    };
    _.S(qI, Z);
    qI.prototype.j = function() {
        for (var a = new Xu, b = new _.x.Map, c = new _.x.Set, d = _.y(this.A), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (null != _.bh(f, 1)) {
                e = new _.x.Set;
                b.set(_.R(f, 1).toString(), e);
                f = _.y(Oe(f, Vu, 2));
                for (var g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    var h = _.R(g, 1);
                    e.add(h);
                    c.has(h) || qi(a, 2, Vu, g);
                    c.add(h)
                }
            }
        }
        this.D.H(b);
        this.m.H(a)
    };
    var rI = function(a, b, c) {
        Z.call(this, a, 1051);
        this.A = b;
        this.m = X(this, c)
    };
    _.S(rI, Z);
    rI.prototype.j = function() {
        var a = this;
        this.m.value && Pi(this.m.value, function(b, c) {
            Fg(a.context, b, c);
            var d, e;
            null == (d = a.A) || null == (e = d.error) || e.call(d, c)
        })
    };
    var sI = function(a, b) {
        Z.call(this, a, 1040);
        this.m = V(this);
        this.A = X(this, b)
    };
    _.S(sI, Z);
    sI.prototype.j = function() {
        var a = this.A.value;
        a ? (a = Oe(a, Vu, 2), this.m.H(a.map(function(b) {
            var c = mu(b, Wu);
            b = _.R(b, 1);
            c = c && (_.v(c, "startsWith").call(c, location.protocol) || _.v(c, "startsWith").call(c, "data:") && 80 >= c.length) ? je(null === c ? "null" : void 0 === c ? "undefined" : c) : void 0;
            return {
                Hd: b,
                url: c
            }
        }))) : this.m.H([])
    };
    var tI = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.D = b;
        this.m = d;
        this.jb = e;
        c && (this.I = X(this, c));
        e && (this.A = X(this, e))
    };
    _.S(tI, Z);
    tI.prototype.j = function() {
        var a = this,
            b, c, d = null != (c = this.D) ? c : null == (b = this.I) ? void 0 : b.value,
            e, f;
        b = null != (f = this.m) ? f : null == (e = this.A) ? void 0 : e.value;
        if (null != d && d.length && b)
            for (d = _.y(d), e = d.next(); !e.done; e = d.next()) f = e.value, e = f.Hd, (f = f.url) && _.O(this, Ti(e, f, b, this.jb, function(g, h) {
                Fg(a.context, g, h);
                var k, l;
                null == (l = (k = console).error) || l.call(k, h)
            }))
    };
    var uI = function(a, b, c) {
        Z.call(this, a, 1045);
        this.m = b;
        this.jb = c
    };
    _.S(uI, Z);
    uI.prototype.j = function() {
        var a = new ti;
        _.O(this, a);
        var b = new sI(this.context, this.m);
        K(a, b);
        b = new tI(this.context, void 0, b.m, void 0, this.jb);
        K(a, b);
        Di(a)
    };
    var Xp = function(a, b, c, d) {
        Z.call(this, a, 706);
        this.G = b;
        this.C = null != d ? d : V(this);
        this.m = W(this, c)
    };
    _.S(Xp, Z);
    Xp.prototype.j = function() {
        this.C.Ba(Ze(this.m.value, this.G))
    };
    var vI = function(a, b, c, d) {
        Z.call(this, a, 1154);
        this.Za = c;
        this.m = d;
        this.A = X(this, b)
    };
    _.S(vI, Z);
    vI.prototype.j = function() {
        if (this.A.value) {
            var a = new ti;
            _.O(this, a);
            var b = new Xp(this.context, window, this.Za, this.m.jb);
            K(a, b);
            b = new qI(this.context, this.A.value, this.m.jf);
            K(a, b);
            K(a, new uI(this.context, b.m, this.m.jb));
            b = new rI(this.context, console, this.m.jb);
            K(a, b);
            Di(a)
        } else this.m.jf.ha(), this.m.jb.ha()
    };
    var wI = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.G = b;
        this.ca = c;
        this.m = d;
        this.Sc = e;
        this.A = X(this, f)
    };
    _.S(wI, Z);
    wI.prototype.j = function() {
        var a, b = null == (a = this.A.value) ? void 0 : a.Gh;
        b && b(this.m, this.ca, this.G, this.Sc, this.context.Lb)
    };
    var xI = function(a, b) {
        Z.call(this, a, 1095);
        this.m = b;
        this.C = V(this)
    };
    _.S(xI, Z);
    xI.prototype.j = function() {
        this.C.Oa(this.m.load(_.VH))
    };
    var yI = function(a, b, c, d, e) {
        Z.call(this, a, 1090);
        this.m = b;
        this.Sc = c;
        this.A = W(this, d);
        this.D = X(this, e)
    };
    _.S(yI, Z);
    yI.prototype.j = function() {
        var a = this.D.value,
            b;
        if (a && null != (b = _.Rg(a, _.lv, 1)) && _.mv(b).length) {
            b = new ti;
            _.O(this, b);
            var c = new xI(this.context, this.m);
            K(b, c);
            a = new wI(this.context, window, this.A.value, a, this.Sc, c.C);
            K(b, a);
            Di(b)
        }
    };
    var zI = function(a, b, c, d, e, f) {
        f = void 0 === f ? Wi : f;
        Z.call(this, a, 939);
        this.A = b;
        this.G = c;
        this.ca = d;
        this.m = f;
        this.C = xB(this);
        zB(this, e)
    };
    _.S(zI, Z);
    zI.prototype.j = function() {
        var a = this.m,
            b = this.G,
            c = new go;
        var d = new fo;
        d = _.tg(d, 1, String(this.A));
        c = _.vg(c, 5, d);
        c = _.ld(c, 4, 1, 0);
        c = _.ld(c, 2, 2, 0);
        c = _.tg(c, 3, this.context.wb || this.context.nb);
        c = _.qd(c, 6, _.D(this.ca, 5));
        a.call(this, b, c);
        this.C.notify()
    };
    var AI = function(a, b) {
        Z.call(this, a, 820);
        this.G = b;
        this.C = V(this)
    };
    _.S(AI, Z);
    AI.prototype.j = function() {
        var a = this;
        this.C.Oa($i(this.G).then(function(b) {
            var c = b.Jd,
                d = b.status;
            Qh("gpt_etu", function(e) {
                Wh(e, a.context);
                J(e, "rsn", d)
            }, c ? void 0 : 0);
            return null != c ? c : ""
        }))
    };
    var wq = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.G = b;
        this.C = xB(this);
        this.m = X(this, c);
        this.A = W(this, d);
        e && zB(this, e)
    };
    _.S(wq, Z);
    wq.prototype.j = function() {
        var a = this.m.value;
        if (a && !this.A.value) {
            var b = Yw(this.G);
            CD(new BD(b, a)) || this.V(new dl("Cannot create top window frame"))
        }
        this.C.notify()
    };
    var Np = function(a, b, c, d) {
        Z.call(this, a, 979);
        this.G = b;
        this.m = X(this, d);
        this.C = c
    };
    _.S(Np, Z);
    Np.prototype.j = function() {
        var a = this,
            b;
        dj(this.G, null != (b = this.m.value) ? b : !1).then(function(c) {
            a.C.H(c)
        })
    };
    Np.prototype.o = function() {
        this.C.ha()
    };
    var BI = function(a, b, c) {
        Z.call(this, a, 1123);
        this.m = b;
        this.A = c;
        V(this, b);
        V(this, c)
    };
    _.S(BI, Z);
    BI.prototype.j = function() {
        this.m.H(!0);
        this.A.H(10)
    };
    var CI = function(a, b, c, d, e) {
        Z.call(this, a, 978);
        this.G = b;
        this.D = c;
        this.m = e;
        V(this, e);
        this.A = X(this, d.Zb)
    };
    _.S(CI, Z);
    CI.prototype.j = function() {
        if (this.A.value) {
            var a = kj(this.A.value, this.G, new _.XB(this.context), this.D);
            this.m.Oa(a)
        } else this.m.ha()
    };
    CI.prototype.o = function() {
        this.m.ha()
    };
    var xo = function(a, b, c, d, e) {
        Z.call(this, a, 1164);
        this.A = b;
        this.ne = c;
        this.m = e;
        this.D = W(this, d)
    };
    _.S(xo, Z);
    xo.prototype.j = function() {
        if (this.D.value) {
            var a = new ti;
            _.O(this, a);
            K(a, new CI(this.context, window, this.A, this.ne, this.m.oe));
            var b = new BI(this.context, this.m.Ac, this.m.me);
            K(a, b);
            Di(a)
        } else this.m.oe.H(5), this.m.Ac.H(!1), this.m.me.H(5)
    };
    var Bq = function(a, b, c, d, e) {
        Z.call(this, a, 1101);
        this.G = b;
        this.m = c;
        e && (this.A = X(this, e));
        d && (this.D = X(this, d))
    };
    _.S(Bq, Z);
    Bq.prototype.j = function() {
        if (this.m) sj(this.m, this.G);
        else {
            var a = this.D.value;
            pf("browsing-topics", this.G.document) && this.A.value && a && sj(a, this.G)
        }
    };
    var zo = function(a, b, c, d) {
        Z.call(this, a, 1180);
        this.G = b;
        this.A = X(this, d);
        this.m = X(this, c.Zb)
    };
    _.S(zo, Z);
    zo.prototype.j = function() {
        if (this.A.value && this.m.value) {
            var a = new ti;
            _.O(this, a);
            K(a, new Bq(this.context, this.G, this.m.value));
            Di(a)
        }
    };
    var DI = function(a, b, c) {
        Z.call(this, a, 1171);
        this.m = c;
        V(this, c);
        this.Af = W(this, b)
    };
    _.S(DI, Z);
    DI.prototype.j = function() {
        this.m.H(0 === this.Af.value.kind)
    };
    var EI = function(a, b, c) {
        Z.call(this, a, 1160);
        this.m = c;
        V(this, c);
        this.A = W(this, b)
    };
    _.S(EI, Z);
    EI.prototype.j = function() {
        var a = this;
        if (this.A.value.requestId) {
            var b = this.A.value.request;
            Qh("td_ba", function(d) {
                Wh(d, a.context);
                J(d, "sz", b.byteLength)
            }, 1);
            if (32768 < b.byteLength) this.m.H({
                kind: 1,
                reason: 3
            });
            else {
                var c = Ib(b, 3);
                c.length ? this.m.H({
                    kind: 0,
                    signal: c,
                    requestId: this.A.value.requestId
                }) : this.m.H({
                    kind: 1,
                    reason: 5
                })
            }
        } else this.m.H({
            kind: 1,
            reason: this.A.value
        })
    };
    EI.prototype.o = function() {
        this.m.H({
            kind: 1,
            reason: 4
        })
    };
    var FI = function(a, b) {
        Z.call(this, a, 1159);
        this.C = V(this);
        this.m = b
    };
    _.S(FI, Z);
    FI.prototype.j = function() {
        var a = this;
        this.C.Oa(this.m.getInterestGroupAdAuctionData({
            seller: "https://securepubads.g.doubleclick.net"
        }).catch(function(b) {
            a.V(b);
            return 4
        }))
    };
    FI.prototype.o = function() {
        this.C.H(4)
    };
    var Bo = function(a, b, c, d, e) {
        Z.call(this, a, 1177);
        this.I = b;
        this.m = d;
        this.A = e;
        V(this, d);
        V(this, e);
        this.D = W(this, c)
    };
    _.S(Bo, Z);
    Bo.prototype.j = function() {
        if (this.D.value) {
            var a = new ti;
            _.O(this, a);
            var b = new FI(this.context, this.I);
            K(a, b);
            b = new EI(this.context, b.C, this.m);
            K(a, b);
            b = new DI(this.context, this.m, this.A);
            K(a, b);
            Di(a)
        } else this.m.H({
            kind: 1,
            reason: 2
        }), this.A.H(!1)
    };
    var iq = function(a, b, c, d, e) {
        Z.call(this, a, 881);
        this.Wa = b;
        this.Xa = c;
        this.m = d;
        this.C = V(this);
        e && (this.A = X(this, e))
    };
    _.S(iq, Z);
    iq.prototype.j = function() {
        if (this.Xa) var a = this.Xa;
        else {
            if (_.G(ip) || !this.A.value) {
                this.C.ha();
                return
            }
            a = this.A.value
        }
        var b = _.Rg(a, Ov, 23);
        if (b) {
            var c;
            if (0 !== (null == (c = this.m) ? void 0 : c.kind)) throw new TypeError("Received remote auction config despite " + (this.m ? "invalid" : "absent") + " remarketing input.");
            this.C.H({
                seller: "https://securepubads.g.doubleclick.net",
                interestGroupBuyers: _.Sl(a, 3),
                requestId: this.m.requestId,
                serverResponse: yd(nj(b, 1))
            })
        } else {
            b = this.C;
            c = b.H;
            var d = gl(this.context, this.Wa),
                e = _.G(Po);
            e = !_.D(a, 14) && (void 0 === e ? !1 : e);
            for (var f = {}, g = _.y(Oe(a, Mv, 7)), h = g.next(); !h.done; h = g.next()) h = h.value, f[_.R(h, 1)] = JSON.parse(_.R(h, 2));
            if (g = _.Rg(a, Lv, 6)) f["https://googleads.g.doubleclick.net"] = g.toJSON(), f["https://td.doubleclick.net"] = g.toJSON();
            h = {};
            g = _.y(Oe(a, Nv, 11));
            for (var k = g.next(); !k.done; k = g.next()) k = k.value, h[_.R(k, 1)] = _.Re(k, 2);
            var l = {};
            0 !== _.Re(a, 21) && (l["*"] = _.Re(a, 21));
            var m = {};
            vl(a, 18) && (m["https://googleads.g.doubleclick.net"] = vl(a, 18), m["https://td.doubleclick.net"] = vl(a, 18));
            g = _.y(hd(a, 24, Rv));
            for (k = g.next(); !k.done; k = g.next()) k = k.value, vl(k[1], 4) && (m[k[0]] = vl(k[1], 4));
            g = _.R(a, 1).split("/td/")[0];
            k = _.R(a, 19);
            k = "" !== k ? g + k : void 0;
            var n, p = null == (n = _.Rg(a, Qv, 5)) ? void 0 : n.clone(),
                r;
            null != p && null != (r = _.Rg(p, Pv, 5)) && Cp(r, 2);
            n = _.v(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(a, 1),
                trustedScoringSignalsUrl: _.R(a, 2),
                interestGroupBuyers: _.Sl(a, 3),
                sellerExperimentGroupId: vl(a, 17),
                auctionSignals: JSON.parse(_.R(a, 4) || "{}"),
                sellerSignals: (null == p ? void 0 : p.toJSON()) || [],
                sellerTimeout: _.Re(a, 15) || 50,
                perBuyerExperimentGroupIds: m,
                perBuyerSignals: f,
                perBuyerTimeouts: h,
                perBuyerCumulativeTimeouts: l
            }, k ? {
                directFromSellerSignals: k
            } : {}, e ? {
                resolveToConfig: e
            } : {});
            if (null == a ? 0 : _.D(Fp(a, Qv, 5), 25)) n.sellerCurrency = "USD", n.perBuyerCurrencies = _.v(Object, "fromEntries").call(Object, gd(a, 22));
            r = new Qv;
            "0" !== sd(Xd(Fp(Fp(a, Qv, 5), Pv, 5), 2), "0") && (f = new Pv, h = sd(Xd(Fp(Fp(a, Qv, 5), Pv, 5), 2), "0"), l = f.K, m = Xc(l), qc(m), Sc(l, m, 2, null != h && 0 !== +h ? h : void 0), _.vg(r, 5, f));
            Fp(a, Qv, 5).getEscapedQemQueryId() && (f = Fp(a, Qv, 5).getEscapedQemQueryId(), _.tg(r, 2, f));
            a = _.v(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(a, 1),
                sellerExperimentGroupId: vl(a, 17),
                sellerSignals: r.toJSON(),
                sellerTimeout: _.Re(a, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {},
                perBuyerCumulativeTimeouts: {}
            }, k ? {
                directFromSellerSignals: k
            } : {}, {
                componentAuctions: [n].concat(_.se(null != d ? d : []))
            }, e ? {
                resolveToConfig: e
            } : {});
            c.call(b, a)
        }
    };
    iq.prototype.o = function() {
        this.C.ha()
    };
    var Fo = navigator,
        Go = /(\$\{GDPR})/gi,
        Ho = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        Io = /(\$\{ADDTL_CONSENT})/gi,
        Jo = /(\$\{AD_WIDTH})/gi,
        Ko = /(\$\{AD_HEIGHT})/gi;
    var GI = function() {
            var a = this;
            this.promise = new _.x.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        HI = function() {
            this.auctionSignals = new GI;
            this.topLevelSellerSignals = new GI;
            this.j = new GI;
            this.perBuyerSignals = new GI;
            this.perBuyerTimeouts = new GI;
            this.perBuyerCumulativeTimeouts = new GI;
            this.directFromSellerSignals = new GI;
            this.resolveToConfig = new GI
        },
        II = function(a, b, c) {
            this.j = a;
            this.He = b;
            this.Ab = c
        };
    var JI = navigator,
        jq = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u) {
            Z.call(this, a, 882);
            this.O = b;
            this.ca = c;
            this.da = d;
            this.Xa = e;
            this.T = f;
            this.W = g;
            this.A = l;
            this.D = V(this);
            this.m = V(this);
            p && (this.I = X(this, p));
            this.M = X(this, h);
            r && (this.aa = W(this, r));
            u && (this.ka = W(this, u));
            this.ia = W(this, k);
            this.Da = V(this, m);
            this.Db = V(this, n)
        };
    _.S(jq, Z);
    jq.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F;
        return _.wb(function(B) {
            switch (B.j) {
                case 1:
                    var E;
                    if (E = !a.Xa && !a.T && !a.W) {
                        E = !!JI.runAdAuction && pf("run-ad-auction", document);
                        var N;
                        E = _.G(ip) || !E || !a.Xa && !(null == (N = a.I) ? 0 : N.value) || !a.M.value
                    }
                    if (E || !a.M.value) return null == (b = a.A) || b.Ab.abort(), KI(a), a.m.H(!1), B.return();
                    e = null != (d = a.Xa) ? d : null == (c = a.I) ? void 0 : c.value;
                    f = Fp(e, Qv, 5);
                    g = e.getWidth();
                    h = e.getHeight();
                    if (!g || !h) return Mo(0, 0, f), null == (k = a.A) || k.Ab.abort(), KI(a), a.m.H(!1), B.return();
                    l = _.D(f, 9);
                    if (m = _.D(f, 10))
                        if (KI(a), _.D(f, 17)) return Mo(0, 0, f), null == (n = a.A) || n.Ab.abort(), a.m.H(!1), B.return();
                    Oo(a.context, f);
                    p = performance.now();
                    r = _.Re(e, 8) || 1E3;
                    N = a.M.value;
                    E = _.Re(f, 14) || -1;
                    if (0 < E && a.O.F >= E) N = 1;
                    else if (E = _.Re(f, 13) || -1, 0 < E && a.O.B >= E) N = 1;
                    else if (++a.O.F, ++a.O.B, N.signal = AbortSignal.timeout(r), _.D(f, 15)) --a.O.F, N = No();
                    else {
                        if (a.A && N.serverResponse) throw new TypeError("Attempted to provide a RemoteAuctionConfig in parallelized auction.");
                        N = a.A ? LI(a, N, r, p, a.A, f) : MI(a, N, r, p, f);
                        --a.O.F
                    }
                    return xb(B, N, 2);
                case 2:
                    u = B.o;
                    w = Math.round(performance.now() - p);
                    Ro(a.context, u, w, r, !!a.A, f);
                    A = _.G(Po) ? Qo(u) : "string" === typeof u;
                    if (!A) return F = 2 === u, Mo(w, F ? r : 0, f), m || KI(a), a.m.H(!0), B.return();
                    if (m) return xb(B, JI.deprecatedURNToURL(u, !0), 8);
                    if (!l) {
                        B.j = 4;
                        break
                    }
                    if (_.D(f, 17)) {
                        Mo(0, 0, f);
                        B.j = 6;
                        break
                    }
                    return xb(B, JI.deprecatedURNToURL(u, !0), 6);
                case 6:
                    return a.m.H(!0), KI(a), B.return();
                case 8:
                    return a.m.H(!0), B.return();
                case 4:
                    return a.m.H(!0), xb(B, Lo(u, {
                        gdprApplies: null != Gk(a.ca, 3) ? _.D(a.ca, 3) ? "1" : "0" : null,
                        vi: _.bh(a.ca, 2),
                        Hh: _.bh(a.ca, 4),
                        Fh: g.toString(),
                        Eh: h.toString()
                    }), 9);
                case 9:
                    a.ia.value.style.display = "", a.Da.H({
                        kind: 2,
                        zc: u
                    }), a.Db.H(new _.oh(g, h)), a.D.H(!1), B.j = 0
            }
        })
    };
    jq.prototype.o = function() {
        var a, b, c = null == (b = null != (a = this.Xa) ? a : this.I.value) ? void 0 : Fp(b, Qv, 5);
        c && Mo(0, 0, c);
        var d;
        null == (d = this.A) || d.Ab.abort();
        KI(this)
    };
    var MI = function(a, b, c, d, e) {
            var f;
            return null == (f = JI.runAdAuction) ? void 0 : f.call(JI, b).then(function(g) {
                So(a.context, g, c, d, e);
                return g
            }).catch(function(g) {
                return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
            })
        },
        LI = function(a, b, c, d, e, f) {
            Eo(b, e);
            setTimeout(function() {
                e.Ab.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, c);
            return e.j.then(function(g) {
                (null === g || Qo(g)) && So(a.context, g, c, d, f);
                return g
            })
        },
        KI = function(a) {
            a.D.H(a.da);
            var b;
            a.Da.H(null != (b = a.T) ? b : a.aa.value);
            var c;
            a.Db.H(null != (c = a.W) ? c : a.ka.value)
        };
    var Zo = function(a) {
        this.K = _.z(a)
    };
    _.S(Zo, _.T);
    var Vo = function(a, b) {
        return _.ld(a, 2, b, 0)
    };
    var NI = function(a) {
        this.K = _.z(a)
    };
    _.S(NI, _.T);
    var Yo = ge(NI);
    NI.fa = [1];
    var hq = function(a, b, c, d, e, f) {
        Z.call(this, a, 1105);
        this.adUnitPath = b;
        this.Xa = c;
        this.m = d;
        f && (this.D = X(this, f));
        e && (this.A = X(this, e))
    };
    _.S(hq, Z);
    hq.prototype.j = function() {
        var a, b = null != (a = this.m) ? a : this.A.value,
            c;
        a = null != (c = this.Xa) ? c : this.D.value;
        if (this.m || this.Xa || b && a && 0 !== _.Sl(a, 3).length) {
            var d = _.Sl(a, 3);
            c = To(this.adUnitPath);
            if (_.D(a, 20)) {
                a = ap(d);
                var e = (d = b.getItem(c)) ? Oe(Yo(d), Zo, 1) : [];
                d = new NI;
                a = Wo(e, a);
                a = _.el(d, 1, a);
                b.setItem(c, Le(a))
            } else _.G(qy) && b.removeItem(c)
        }
    };
    var oq = function(a, b, c, d, e) {
        Z.call(this, a, 1174);
        var f = this;
        this.Z = b;
        this.directFromSellerSignals = c;
        this.m = _.js(function() {
            if (f.directFromSellerSignals) var g = f.directFromSellerSignals;
            else {
                var h;
                g = null == (h = f.A.value) ? void 0 : _.R(h, 19);
                var k;
                if (null == (k = g) || !k.length) return
            }
            k = (_.C = [].concat(_.se(f.Z.head.querySelectorAll("script[type=webbundle]"))), _.v(_.C, "find")).call(_.C, function(l) {
                var m;
                return null == (m = l.textContent) ? void 0 : m.match(g)
            });
            null != k && k.textContent && (h = JSON.parse(k.textContent), h.resources = h.resources.filter(function(l) {
                return !l.match(g)
            }), k.remove(), h.resources.length && (k = f.Z.createElement("script"), k.type = "webbundle", hb(k, qe(h)), f.Z.head.appendChild(k)))
        });
        e && (this.A = X(this, e));
        zB(this, d);
        _.zn(this, function() {
            return setTimeout(function() {
                return void f.m()
            }, 5E3)
        })
    };
    _.S(oq, Z);
    oq.prototype.j = function() {
        this.m()
    };
    var nq = function(a, b, c) {
        Z.call(this, a, 1175);
        this.C = xB(this);
        zB(this, b);
        zB(this, c)
    };
    _.S(nq, Z);
    nq.prototype.j = function() {
        rB(this.C, Xw(5E3))
    };
    var lq = function(a, b, c) {
        Z.call(this, a, 1054);
        this.m = b;
        this.C = xB(this);
        this.A = W(this, c)
    };
    _.S(lq, Z);
    lq.prototype.j = function() {
        this.A.value || this.m();
        this.C.notify()
    };
    var kq = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.X = c;
        this.O = d;
        this.m = V(this);
        this.A = W(this, e);
        this.D = W(this, f)
    };
    _.S(kq, Z);
    kq.prototype.j = function() {
        this.D.value ? (gp(this.slotId, this.O, this.X, this.A.value), this.m.H(!1)) : this.m.H(!0)
    };
    var mq = function(a, b, c, d) {
        Z.call(this, a, 1055);
        zB(this, c);
        this.m = W(this, b);
        this.C = xB(this, d)
    };
    _.S(mq, Z);
    mq.prototype.j = function() {
        this.m.value && this.C.notify()
    };
    var kp = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A) {
        Z.call(this, a, 1179);
        this.slotId = b;
        this.Y = d;
        this.O = e;
        this.ca = f;
        this.A = g;
        this.aa = l;
        this.I = m;
        this.X = n;
        this.W = p;
        this.tb = r;
        this.m = w;
        this.ia = A;
        this.da = X(this, u);
        this.M = W(this, h);
        this.T = W(this, k);
        this.D = X(this, c)
    };
    _.S(kp, Z);
    kp.prototype.j = function() {
        var a = new ti;
        _.O(this, a);
        var b = this.da.value,
            c = V(this);
        if (b) {
            2 === _.rf(Sp) && this.D.value && _.D(b, 20) && 0 !== _.Sl(b, 3).length && (c = new hq(this.context, this.slotId.getAdUnitPath(), b, this.D.value), K(a, c));
            c = new iq(this.context, this.Y, b, this.ia);
            K(a, c);
            c = new jq(this.context, this.O, this.ca, this.A, b, this.M.value, this.T.value, c.C, this.aa, this.I, this.m.Da, this.m.Db);
            K(a, c);
            var d = new An(this.context, this.slotId, fp);
            K(a, d);
            d = new nq(this.context, c.m, d.C);
            K(a, d);
            b = _.R(b, 19);
            (null == b ? 0 : b.length) && K(a, new oq(this.context, window.document, b, d.C));
            c = c.D
        } else this.m.Da.H(this.M.value), this.m.Db.H(this.T.value), c.H(this.A), null == (d = this.I) || d.Ab.abort();
        b = new kq(this.context, this.slotId, this.X, this.O, this.tb, c);
        K(a, b);
        c = new lq(this.context, this.W, c);
        K(a, c);
        b = new mq(this.context, b.m, c.C, this.m.xf);
        K(a, b);
        Di(a)
    };
    var hp = navigator;
    var OI = function() {
        lI.apply(this, arguments)
    };
    _.S(OI, lI);
    var PI = function(a, b) {
            var c = _.Ae(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.Vc;
            c.name = a.Vc;
            c.title = a.Wc;
            Array.isArray(a.j) ? null != a.j[0] && null != a.j[1] && (c.width = String(a.j[0]), c.height = String(a.j[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        QI = function(a, b) {
            "string" !== typeof a.j && (b.width = String(a.j[0]), b.height = String(a.j[1]));
            var c = Bg(a.context, 774, function() {
                a.loaded(b);
                _.Be(b, "load", c)
            });
            _.ub(b, "load", c);
            _.zn(a, function() {
                return _.Be(b, "load", c)
            });
            a.o.Wf.appendChild(b)
        };
    var RI = function() {
        OI.apply(this, arguments)
    };
    _.S(RI, OI);
    RI.prototype.m = function() {
        var a = PI(this, !this.o.Ij);
        _.G(Po) ? "string" === typeof this.Ta.zc ? Ui(a, this.Ta.zc) : a.config = this.Ta.zc : Ui(a, this.Ta.zc);
        QI(this, a);
        return a
    };
    RI.prototype.B = function() {
        return !1
    };
    var SI = navigator,
        TI = function(a, b, c, d, e, f) {
            Z.call(this, a, 1089);
            this.Ib = b;
            this.ga = c;
            this.Y = d;
            this.m = f;
            V(this, f);
            e && (this.A = X(this, e))
        };
    _.S(TI, Z);
    TI.prototype.j = function() {
        var a = {};
        if (1 === this.Ib)
            for (var b = _.y(this.ga), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = this.Y[d.getDomId()];
                a[d.getId()] = UI(this, c)
            } else if (2 === this.Ib) {
                b = null == (d = this.A) ? void 0 : d.value;
                if (!b) {
                    this.m.ha();
                    return
                }
                d = _.y(this.ga);
                for (c = d.next(); !c.done; c = d.next()) {
                    c = c.value;
                    var e = b.get(c.getId()),
                        f = void 0;
                    null != (f = e) && f.length && (f = this.Y[c.getDomId()], a[c.getId()] = UI(this, f, e))
                }
            }
        this.m.H(a)
    };
    var UI = function(a, b, c) {
        var d = new HI,
            e = new AbortController;
        a = Do({
            He: d,
            Ab: e,
            Vf: gl(a.context, b),
            interestGroupBuyers: c,
            gj: _.G(ry)
        });
        a = SI.runAdAuction(a).catch(function(f) {
            return f instanceof DOMException && "TimeoutError" === f.name ? 2 : 3
        });
        return new II(a, d, e)
    };
    var VI = function(a, b, c, d, e) {
        Z.call(this, a, 1106);
        this.ca = b;
        this.A = c;
        this.ga = d;
        this.D = e;
        this.m = V(this);
        V(this, e)
    };
    _.S(VI, Z);
    VI.prototype.j = function() {
        for (var a = $o(this.A, this.ca), b = new _.x.Map, c = new _.x.Map, d = _.y(this.ga), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = e.getAdUnitPath(),
                g = void 0,
                h = void 0,
                k = null != (h = null == (g = a.get(To(f))) ? void 0 : Oe(g, Zo, 1).map(function(l) {
                    return _.R(l, 1)
                })) ? h : [];
            b.set(e.getId(), k);
            c.has(f) || c.set(f, k.sort().map(_.Af))
        }
        this.m.H(b);
        this.D.H(c)
    };
    var mp = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1170);
        this.Ib = b;
        this.Y = c;
        this.ca = d;
        this.A = e;
        this.m = {
            tf: V(this)
        };
        2 === b && (this.m.Ze = V(this));
        this.I = W(this, f);
        this.D = W(this, g)
    };
    _.S(mp, Z);
    mp.prototype.j = function() {
        var a = this.I.value;
        if (this.D.value && a.length) {
            var b = new ti;
            _.O(this, b);
            if (2 === this.Ib && this.A) {
                var c = new VI(this.context, this.ca, this.A, a, this.m.Ze);
                K(b, c);
                c = c.m
            }
            a = new TI(this.context, this.Ib, a, this.Y, c, this.m.tf);
            K(b, a);
            Di(b)
        } else this.m.tf.ha(), null == (b = this.m.Ze) || b.ha()
    };
    var WI = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1166);
        this.Mc = b;
        this.Z = c;
        this.I = d;
        var k = void 0 === k ? new mB : k;
        this.B.j.push(k);
        this.m = k;
        this.A = V(this);
        this.D = V(this);
        this.T = W(this, e);
        this.W = W(this, f);
        zB(this, g);
        this.M = W(this, h)
    };
    _.S(WI, Z);
    WI.prototype.j = function() {
        var a = this,
            b = this.T.value;
        if (b) {
            var c = _.Bb(this.W.value, {
                    uuid: this.Mc
                }),
                d = this.Z.createElement("script");
            b = {
                source: b,
                credentials: this.M.value ? "include" : "omit",
                resources: [c.toString()]
            };
            d.setAttribute("type", "webbundle");
            hb(d, qe(b));
            this.Z.head.appendChild(d);
            this.A.H(d);
            this.D.H(b);
            this.m.Oa(XI(c).catch(function(e) {
                e instanceof oA ? a.I(e) : (a.V(e), a.o(e));
                return null
            }))
        } else this.m.ha(), this.A.ha(), this.D.ha()
    };
    var XI = function(a) {
        var b, c;
        return _.wb(function(d) {
            if (1 == d.j) return xb(d, fetch(a.toString()).catch(function() {
                throw new oA("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.j) return b = d.o, xb(d, b.text(), 3);
            c = d.o;
            return d.return(Xv(c))
        })
    };
    var YI = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 1167);
        this.Z = b;
        this.ca = c;
        this.I = d;
        this.m = e;
        this.D = f;
        this.A = W(this, g);
        this.T = X(this, h);
        this.W = X(this, k);
        this.aa = X(this, l);
        m && (this.M = X(this, m))
    };
    _.S(YI, Z);
    YI.prototype.j = function() {
        var a = this.T.value,
            b = this.W.value,
            c = this.aa.value;
        if (a)
            if (b && c) {
                var d = _.Sl(a, 1),
                    e = _.Sl(a, 2);
                a = _.Sl(a, 3);
                if (d.length !== e.length) this.m(new nA("Received " + d.length + " ad URLs but " + e.length + " metadatas"));
                else {
                    c.resources = [].concat(_.se(d.filter(function(f) {
                        return f
                    })), _.se(a.map(function(f) {
                        return "https://securepubads.g.doubleclick.net" + f
                    })));
                    c.resources.length ? (a = _.Ae("SCRIPT"), a.setAttribute("type", "webbundle"), hb(a, qe(c)), this.Z.head.removeChild(b), this.Z.head.appendChild(a)) : this.Z.head.removeChild(b);
                    for (b = 0; b < d.length; b++) c = void 0, this.I(b, e[b], {
                        kind: 1,
                        url: d[b]
                    }, this.A.value, this.ca, null == (c = this.M) ? void 0 : c.value, void 0);
                    this.D(d.length - 1, this.A.value, this.ca)
                }
            } else this.m(Error("Lost bundle script"))
    };
    var ZI = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        ti.call(this);
        e = new WI(a, f, h, c, m, n, p, r);
        K(this, e);
        K(this, new YI(a, h, g, b, c, d, k, e.m, e.A, e.D, l));
        this.j = {
            C: e.m
        }
    };
    _.S(ZI, ti);
    var yp = new _.x.Set,
        $I = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.t.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new dl("Reached Limit for addEventListener");
        }, 3E5),
        aJ = function(a, b, c) {
            _.U.call(this);
            this.context = a;
            this.j = b;
            this.m = c;
            this.B = [];
            this.o = !1;
            this.D = 0;
            this.A = new _.x.Map;
            yp.add(this);
            this.j.info(uE(this.getName()))
        };
    _.S(aJ, _.U);
    var Ap = function(a) {
        a.o || (a.o = !0, rk(6, a.context), a.I())
    };
    aJ.prototype.slotAdded = function(a, b) {
        this.B.push(a);
        var c = new EH(a, this.getName());
        cp(this.m, "slotAdded", 818, c);
        this.j.info(wE(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        md(b, 4, _.Ec(a))
    };
    aJ.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return da(b.B, c)
        })
    };
    aJ.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.D >= _.rf(Hx) && 0 < _.rf(Hx)) return $I(), !1;
        if (!c.IntersectionObserver && (_.C = ["impressionViewable", "slotVisibilityChanged"], _.v(_.C, "includes")).call(_.C, a)) return M(this.j, rF()), !1;
        var e;
        if (null == (e = this.A.get(a)) ? 0 : e.has(b)) return !1;
        this.A.has(a) || this.A.set(a, new _.x.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.j.error(NE(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        this.A.get(a).set(b, c);
        this.m.listen(a, c);
        this.D++;
        return !0
    };
    aJ.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.A.get(a)) ? void 0 : c.get(b);
        if (!d || !GD(this.m, a, d)) return !1;
        this.D--;
        return this.A.get(a).delete(b)
    };
    var qp = function(a) {
        for (var b = _.y(yp), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var up = function(a, b, c, d) {
        aJ.call(this, a, b, d);
        this.J = c;
        this.ads = new _.x.Map;
        this.V = this.Wb = !1
    };
    _.S(up, aJ);
    up.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.Wb = a)
    };
    var yF = function(a, b) {
            b && !a.V && Qh("ima_sdk_v", function(c) {
                a.V = !0;
                J(c, "v", b)
            });
            return String(iu())
        },
        zF = function(a, b) {
            var c;
            return a.J.o && !(null == (c = a.ads.get(b)) || !c.bj)
        },
        AF = function(a, b, c, d) {
            b = new AH(b, a.getName());
            null != c && null != d && b.setSize([c, d]);
            cp(a.m, "slotRenderEnded", 67, b)
        };
    up.prototype.getName = function() {
        return "companion_ads"
    };
    up.prototype.slotAdded = function(a, b) {
        var c = this;
        a.listen(KD, function(d) {
            Gk(d.detail, 11) && (bJ(c, a).bj = !0)
        });
        aJ.prototype.slotAdded.call(this, a, b)
    };
    up.prototype.I = function() {};
    var bJ = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.zn(b, function() {
                return a.ads.delete(b)
            }));
            return c
        },
        wF = function(a, b) {
            var c = Fh().j,
                d = Fh().o;
            if (a.J.o) {
                var e = {
                    Kb: 3
                };
                a.M && (e.Bc = a.M);
                a.T && (e.Cc = a.T);
                b = null != b ? b : a.B;
                c = rh(c, d);
                d = e.Bc;
                var f = e.Cc;
                d && "number" !== typeof d || f && "number" !== typeof f || a.J.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.j.error(CE(b[0].getDomId()))
        },
        xF = function(a, b) {
            return a.B.filter(function(c) {
                return _.v(b, "includes").call(b, c.toString())
            })
        };
    var vp = function(a, b, c) {
        aJ.call(this, a, b, c)
    };
    _.S(vp, aJ);
    vp.prototype.getName = function() {
        return "content"
    };
    vp.prototype.I = function() {};
    var Kp = 0;
    var cJ = _.Ar(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        dJ = _.Ar(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        eJ = _.Ar(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        fJ = _.Ar(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        gJ = new _.x.Map([
            [2, {
                Cg: "page_level_ads"
            }],
            [5, {
                Cg: "shoppit"
            }]
        ]),
        hJ = function(a) {
            var b = void 0 === b ? gJ : b;
            this.context = a;
            this.j = b;
            this.o = new _.x.Map;
            this.loaded = new _.x.Set
        },
        jJ;
    hJ.prototype.load = function(a) {
        var b = _.iJ(this, a),
            c, d = (null != (c = this.j.get(a.module)) ? c : {}).Cg;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            (c = _.fh(172)) && "pagead2.googlesyndication.com" === zw((c.src || "").match(_.yw)[3] || null) ? (c = "", _.G(Zx) && (c = Mm(this.context.mg)), d = this.context.wb ? _.ke(eJ, this.context.wb, d, c) : _.ke(fJ, d, this.context.nb)) : this.context.wb ? (c = "", _.G(Zx) && (c = Mm(this.context.mg)), d = _.ke(cJ, this.context.wb, d, c)) : d = _.ke(dJ, d, this.context.nb);
            c = {};
            var e = _.rf(hy);
            e && (c.cb = e);
            d = _.v(Object, "keys").call(Object, c).length ? ts(d, c) : d;
            jJ(this, a);
            _.Tj(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.iJ = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.Lf);
        return a.o.get(b)
    };
    jJ = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = Bg(a.context, 340, function(e) {
            if (a.j.has(c) && "function" === typeof e) {
                var f = a.j.get(c);
                f = (void 0 === f.Xh ? [] : f.Xh).map(function(g) {
                    return _.iJ(a, g).promise
                });
                _.x.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Lj(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var kJ = function(a, b) {
        Z.call(this, a, 980);
        this.C = new jp;
        this.m = [];
        this.A = W(this, b)
    };
    _.S(kJ, Z);
    kJ.prototype.j = function() {
        for (var a = _.y((_.C = [this.A.value, this.m.map(function(c) {
                return c.value
            })], _.v(_.C, "flat")).call(_.C)), b = a.next(); !b.done; b = a.next()) nf(b.value);
        this.C.notify()
    };
    var lJ = function(a, b) {
        Z.call(this, a, 892, _.rf(dy));
        this.m = V(this);
        this.D = V(this);
        this.A = V(this);
        this.Oc = V(this);
        this.kd = V(this);
        this.I = V(this);
        this.te = V(this);
        this.M = yB(this, b)
    };
    _.S(lJ, Z);
    lJ.prototype.j = function() {
        var a = this.M.value;
        if (!a) throw Error("config timeout");
        this.m.Ba(_.Rg(a, av, 3));
        this.D.Ba(_.Rg(a, cv, 2));
        this.A.H(Yc(a, 4, xc));
        this.Oc.Ba(Oe(a, Xu, 6));
        this.kd.Ba(Oe(a, ov, 5));
        this.I.Ba(_.Rg(a, nv, 7));
        var b;
        this.te.H(new _.x.Set((null == (b = _.Rg(a, Yu, 1)) ? void 0 : _.Sl(b, 6)) || []))
    };
    lJ.prototype.J = function(a) {
        this.o(a)
    };
    lJ.prototype.o = function(a) {
        this.m.Sa(a);
        this.D.Sa(a);
        this.A.H([]);
        this.Oc.H([]);
        this.kd.H([]);
        this.I.ha()
    };
    var mJ = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.m = V(this);
        this.error = void 0;
        var d = V(this);
        this.A = W(this, d);
        b(function(e, f) {
            if (f) c.error = f, d.H([]);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.H(g)
                }
            } catch (h) {} finally {
                d.kb || (c.error = Error("malformed response"), d.H([]))
            }
        })
    };
    _.S(mJ, Z);
    mJ.prototype.j = function() {
        if (this.error) throw this.error;
        this.m.H(Kd(qv, this.A.value))
    };
    var nJ = function(a, b) {
        Z.call(this, a, 1081);
        this.Fb = V(this);
        this.m = X(this, b)
    };
    _.S(nJ, Z);
    nJ.prototype.j = function() {
        this.m.value ? this.Fb.H(this.m.value) : this.Fb.ha()
    };
    var oJ = new _.x.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        pJ = function(a, b, c, d, e, f, g, h, k) {
            Z.call(this, a, 1079);
            this.Z = b;
            this.googletag = c;
            this.ba = d;
            this.M = e;
            this.m = f;
            this.D = g;
            this.A = h;
            this.I = k;
            V(this)
        };
    _.S(pJ, Z);
    pJ.prototype.j = function() {
        var a = this,
            b = this.A.getAdUnitPath(),
            c = oJ.get(_.Qe(this.A, 2, 0));
        if (b && c) {
            var d, e = null != (d = this.ba) ? d : this.m.j;
            b = new uH(this.context, this.Z, b, c, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, e, this.m, this.M, this.D, this.I);
            _.O(this, b);
            Di(b)
        }
    };
    var Oq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.ba = c;
        this.M = d;
        this.A = e;
        this.I = f;
        this.D = V(this);
        this.m = new nJ(this.context, this.D);
        this.Fb = this.m.Fb;
        _.O(this, this.m);
        this.T = W(this, g)
    };
    _.S(Oq, Z);
    Oq.prototype.j = function() {
        if (_.G(gy)) {
            for (var a = [], b = _.y(this.T.value), c = b.next(); !c.done; c = b.next()) switch (c = c.value, mj(c, pv)) {
                case 5:
                    a.push(c);
                    break;
                case 8:
                    var d = c
            }
            this.D.Ba(null == d ? void 0 : _.Rg(d, hv, 4));
            d = new ti;
            _.O(this, d);
            a = _.y(a);
            for (b = a.next(); !b.done; b = a.next()) b = b.value, c = void 0, K(d, new pJ(this.context, document, this.googletag, null != (c = this.ba) ? c : this.A.j, this.M, this.A, this.I, _.Rg(b, jv, oj(b, pv, 5)), _.Rg(b, hv, 4)));
            K(d, this.m);
            Di(d)
        } else this.Fb.ha()
    };
    var qJ = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.context = a;
        this.m = b;
        this.B = c;
        this.j = d;
        this.O = e;
        this.o = f;
        this.J = g;
        this.A = h
    };
    _.S(qJ, _.U);
    var rJ = function(a, b, c) {
        var d = new ti;
        _.O(a, d);
        var e = a.context;
        var f = a.o;
        var g = new ti;
        f = new mJ(e, f);
        K(g, f);
        var h = new lJ(e, f.m);
        K(g, h);
        Di(g);
        var k = h.m;
        var l = h.D;
        var m = h.A;
        e = h.Oc;
        var n = h.kd;
        f = h.I;
        h = h.te;
        _.O(a, g);
        var p;
        g = new wH(a.context, document, Lj(), a.m, a.B, a.j, null != (p = window.location.hash) ? p : "");
        K(d, g);
        p = new Oq(a.context, Lj(), null, a.m, a.B, a.j, n);
        K(d, p);
        g = new kJ(a.context, m);
        K(d, g);
        b = new eH(a.context, window, l, b);
        K(d, b);
        m = a.context;
        n = a.J;
        l = {
            xb: new tm,
            Bb: new tm,
            Ob: new tm,
            Nb: new tm,
            ic: new tm,
            Vb: new tm,
            gd: new tm,
            hd: new tm,
            Be: new tm
        };
        var r = new ti;
        K(r, new HG(m, n, k, window, l));
        Di(r);
        _.O(a, r);
        k = Im(a.context, a.o, b.m);
        n = k.lc;
        r = k.pg;
        _.O(d, k.Ma);
        k = new XG(a.context, r);
        K(d, k);
        m = new YG(a.context, r);
        K(d, m);
        r = ql(a.context, a.j, a.O, window, n, r);
        n = r.Za;
        _.O(a, r.Ma);
        r = a.context;
        if (_.G(yy) || Jk()) r = void 0;
        else {
            var u = {
                    jf: new tm,
                    jb: new tm
                },
                w = new ti;
            K(w, new vI(r, e, n, u));
            Di(w);
            r = {
                ie: u,
                Ma: w
            }
        }
        if (r) {
            var A = r.ie;
            _.O(a, r.Ma)
        }
        u = a.context;
        w = a.A;
        r = new ti;
        c = new yI(u, w, c, n, f);
        K(r, c);
        Di(r);
        _.O(a, r);
        Di(d);
        return {
            hc: l,
            ie: A,
            Ti: b.m,
            Sh: g.C,
            Fb: p.Fb,
            Oc: e,
            Pd: k.Pd,
            ri: m.m,
            te: h
        }
    };
    var sJ = function() {
        OI.apply(this, arguments)
    };
    _.S(sJ, OI);
    sJ.prototype.m = function() {
        var a = this,
            b = this.o,
            c = b.Tg;
        b = b.Od;
        var d = PI(this);
        if (null == c ? 0 : c.length)
            if (_.At) {
                c = _.y(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.se(c));
        b && (d.allow = b);
        QI(this, d);
        Hg(this.context, 653, function() {
            var f;
            if (f = _.at(a.Ta.ob)) {
                var g = f.toString().toLowerCase(); - 1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") ? Up(2) : (Up(3), f = _.G(Cy) ? f : _.at("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>"))
            } else Up(1);
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            Sa() && g.open("text/html", "replace");
            lb(g, f);
            var l, m, n;
            if (xs(null != (n = null == (l = d.contentWindow) ? void 0 : null == (m = l.location) ? void 0 : m.href) ? n : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    sJ.prototype.B = function() {
        return !0
    };
    var Cq = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B, E, N, Q, P, Y, ja, xa) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.O = c;
        this.X = d;
        this.ta = e;
        this.Na = f;
        this.G = g;
        this.m = V(this);
        this.D = V(this);
        this.A = xB(this);
        this.M = W(this, h);
        this.Ga = W(this, k);
        zB(this, l);
        this.ia = W(this, m);
        this.I = W(this, n);
        this.da = W(this, p);
        zB(this, E);
        this.T = W(this, r);
        this.W = X(this, u);
        this.La = X(this, w);
        this.aa = W(this, A);
        this.Ca = X(this, F);
        this.Qa = X(this, B);
        zB(this, N);
        this.za = W(this, Q);
        zB(this, P);
        xa && zB(this, xa);
        this.ka = X(this, Y);
        ja && (this.sa = X(this, ja))
    };
    _.S(Cq, Z);
    Cq.prototype.j = function() {
        var a = this.M.value;
        if (0 === a.kind && null == a.ob) throw new nA("invalid html");
        var b, c;
        a: {
            var d = this.context,
                e = {
                    Z: document,
                    slotId: this.slotId,
                    O: this.O,
                    X: this.X,
                    ta: this.ta,
                    size: this.da.value,
                    Yg: this.ia.value,
                    Wf: this.I.value,
                    Pe: this.T.value,
                    ki: this.W.value,
                    Tg: this.La.value,
                    isBackfill: this.aa.value,
                    Ci: this.Ca.value,
                    rd: this.Qa.value,
                    Od: this.za.value,
                    Ij: null == (b = this.ka.value) ? void 0 : _.D(b, 14),
                    Ae: null == (c = this.sa) ? void 0 : c.value,
                    Na: this.Na
                };b = this.Ga.value;c = a.kind;
            switch (c) {
                case 0:
                    a = new(b ? oI : sJ)(d, a, e);
                    break a;
                case 2:
                    a = new RI(d, a, e);
                    break a;
                default:
                    eb(c)
            }
            a = void 0
        }
        _.O(this, a);
        d = a.render();
        tJ(this, this.G, d);
        this.G.top && this.G.top !== this.G && _.Zi(this.G.top) && tJ(this, this.G.top, d);
        this.A.notify();
        this.m.H(d);
        this.D.H(a.B())
    };
    var tJ = function(a, b, c) {
        eG(a, a.id, b, "message", function(d) {
            c.contentWindow === d.source && cp(a.slotId, ul, 824, d)
        })
    };
    var Yp = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.D = c;
        this.C = V(this);
        this.m = X(this, d);
        this.A = X(this, e)
    };
    _.S(Yp, Z);
    Yp.prototype.j = function() {
        var a = this.A.value;
        if (null == a) this.C.ha();
        else {
            var b = Math.round(.3 * this.D),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.m.value) || !_.D(c, 12, !1) || 0 >= b || a <= b ? this.C.H(a) : this.C.H(b)
        }
    };
    var pq = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.ba = c;
        this.A = d;
        this.Z = f;
        this.O = g;
        this.C = V(this);
        this.T = 2 === e || 3 === e;
        this.m = W(this, h);
        this.M = W(this, k);
        this.I = X(this, l);
        this.D = X(this, m);
        n && zB(this, n)
    };
    _.S(pq, Z);
    pq.prototype.j = function() {
        var a = zm(this.ba, this.A),
            b = uh(this.slotId, this.Z) || Al(this.m.value, Dh(this.slotId), a);
        this.M.value && !a && (b.style.display = "inline-block");
        this.T ? TD(this.O, this.slotId, function() {
            return void _.tw(b)
        }) : _.zn(this, function() {
            return void _.tw(b)
        });
        a = uJ(this);
        0 < a && (b.style.paddingTop = a + "px");
        this.C.H(b)
    };
    var uJ = function(a) {
        var b = a.m.value,
            c, d = null == (c = a.I.value) ? void 0 : c.height;
        if (b && !a.D.value && d) {
            var e;
            c = (null != (e = ym(a.A, 23)) ? e : _.D(a.ba, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Wp = function(a, b) {
        Z.call(this, a, 859);
        this.G = b;
        this.C = V(this)
    };
    _.S(Wp, Z);
    Wp.prototype.j = function() {
        this.C.H(!_.Zi(this.G.top))
    };
    var xq = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.Z = c;
        this.C = V(this)
    };
    _.S(xq, Z);
    xq.prototype.j = function() {
        var a = [],
            b = this.Z;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.C = c.features(), _.v(_.C, "includes")).call(_.C, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.G(xx) || a.push("autoplay");
        a.length ? this.C.H(a.join(";")) : this.C.H("")
    };
    var Jq = function(a, b, c, d, e, f) {
        f = void 0 === f ? Vp : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.Z = d;
        this.ta = e;
        this.M = f;
        this.I = !1;
        this.m = null;
        this.D = this.A = -1;
        this.W = _.js(function() {
            cp(g.ta, "impressionViewable", 715, new BH(g.slotId, "publisher_ads"))
        });
        this.aa = ks(function() {
            cp(g.ta, "slotVisibilityChanged", 716, new CH(g.slotId, "publisher_ads", g.D))
        });
        this.T = W(this, c);
        var h = new jp;
        ID(this.slotId).then(function() {
            return void h.notify()
        });
        zB(this, h)
    };
    _.S(Jq, Z);
    Jq.prototype.j = function() {
        var a = this,
            b = this.M(Bg(this.context, this.id, function(c) {
                c = _.y(c);
                for (var d = c.next(); !d.done; d = c.next()) a.A = 100 * d.value.intersectionRatio, _.v(Number, "isFinite").call(Number, a.A) && vJ(a)
            }));
        b && (b.observe(this.T.value), eG(this, this.id, this.Z, "visibilitychange", function() {
            vJ(a)
        }), _.zn(this, function() {
            b.disconnect()
        }))
    };
    var vJ = function(a) {
            var b = !WA(a.Z);
            wJ(a, 50 <= a.A && b);
            b = Math.floor(b ? a.A : 0);
            if (0 > b || 100 < b || b === a.D ? 0 : -1 !== a.D || 0 !== b) a.D = b, a.aa()
        },
        wJ = function(a, b) {
            a.I || (b ? null === a.m && (a.m = setTimeout(function() {
                WA(a.Z) || (a.W(), a.I = !0);
                a.m = null
            }, 1E3)) : null !== a.m && (clearTimeout(a.m), a.m = null))
        };
    var vq = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.ba = b;
        this.A = c;
        this.C = V(this);
        this.m = W(this, d);
        this.D = W(this, e);
        this.I = X(this, f)
    };
    _.S(vq, Z);
    vq.prototype.j = function() {
        var a = this.m.value.kind;
        switch (a) {
            case 0:
                if (this.m.value.ob)
                    if (this.D.value) {
                        a = this.I.value;
                        var b = new Bk;
                        a = pi(b, 3, a);
                        _.D(Hk([a, this.ba.Qb(), this.A.Qb()]), 3) ? this.C.H(OC) : this.C.ha()
                    } else this.C.ha();
                else this.C.ha();
                break;
            case 2:
                this.C.ha();
                break;
            default:
                eb(a)
        }
    };
    var xJ = function(a, b, c, d, e, f) {
        Z.call(this, a, 1119);
        this.slotId = b;
        this.A = c;
        this.documentElement = d;
        this.O = e;
        this.m = f;
        this.C = wB(this)
    };
    _.S(xJ, Z);
    xJ.prototype.j = function() {
        var a = _.Ae("INS");
        a.id = this.A;
        _.Jh(a, {
            display: "none"
        });
        this.documentElement.appendChild(a);
        var b = function() {
            return void _.tw(a)
        };
        (_.C = [2, 3], _.v(_.C, "includes")).call(_.C, this.m) ? TD(this.O, this.slotId, b) : _.zn(this, b);
        this.C.H(a)
    };
    var yJ = function(a, b, c, d, e) {
        Z.call(this, a, 1120);
        this.I = b;
        this.A = c;
        this.kc = d;
        this.m = e;
        this.C = wB(this);
        a = this.m;
        if (!_.ha(a) || !_.ha(a) || 1 !== a.nodeType || a.namespaceURI && "http://www.w3.org/1999/xhtml" !== a.namespaceURI) this.D = W(this, this.m)
    };
    _.S(yJ, Z);
    yJ.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.D) ? void 0 : a.value) ? b : this.m;
        if (!(_.C = [2, 3], _.v(_.C, "includes")).call(_.C, this.A)) {
            a = _.y(_.v(Array, "from").call(Array, c.childNodes));
            for (b = a.next(); !b.done; b = a.next()) b = b.value, 1 === b.nodeType && b.id !== this.I && _.tw(b);
            this.kc || (c.style.display = "")
        }
        this.C.H(c)
    };
    var Zp = function(a, b, c, d, e, f, g, h, k) {
        ti.call(this);
        c ? (a = new yJ(a, e, g, k, c), K(this, a), a = a.C) : 0 !== g && 1 !== g ? (a = new xJ(a, b, d, f, h, g), K(this, a), a = a.C) : (b = new tl(a, b, JD, function(l) {
            return l.detail
        }), K(this, b), a = new yJ(a, e, g, k, b.C), K(this, a), a = a.C);
        this.j = {
            C: a
        }
    };
    _.S(Zp, ti);
    var zJ = function(a, b) {
            var c = Fh();
            this.context = a;
            this.O = b;
            this.j = c
        },
        AJ = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w) {
            var A = document,
                F = window;
            e || f || bE(a.O, d);
            var B = Pq(a.context, b, a.j, c, d, e, f, g, h, k, l, A, m, n, p, r, u, function() {
                bE(a.O, d);
                aE(a.O, d, B)
            }, w);
            f || aE(a.O, d, B);
            _.zn(d, function() {
                bE(a.O, d)
            });
            F.top !== F && F.addEventListener("pagehide", function(E) {
                E.persisted || bE(a.O, d)
            });
            Di(B)
        };
    var BJ = function(a, b, c, d, e) {
        Z.call(this, a, 884);
        this.ua = b;
        this.A = c;
        this.D = V(this);
        this.I = X(this, d);
        this.m = W(this, e)
    };
    _.S(BJ, Z);
    BJ.prototype.j = function() {
        this.A.storage = this.I.value;
        mG(this.A, _.sk(this.ua, "__gads", this.m.value));
        uk(20, this.context, this.ua, this.m.value);
        uk(2, this.context, this.ua, this.m.value);
        this.D.H(_.of())
    };
    var Rq = 0,
        CJ = new _.jh(-9, -9);
    var Uq = new _.x.Set([function(a, b) {
        var c = a.ma.X.ba;
        b.set("pvsid", {
            value: a.la.context.pvsid
        }).set("correlator", {
            value: Xd(c, 26)
        })
    }, function(a, b) {
        a = a.rh;
        var c = a.Mc;
        "wbn" === a.ce && b.set("wbsu", {
            value: c
        })
    }, function(a, b) {
        var c = a.Ri;
        a = c.Ih;
        var d = c.ij;
        c = c.Li;
        _.G(Rx) || b.set("adsid", {
            value: a
        }).set("pucrd", {
            value: d
        }).set("jar", {
            value: c
        })
    }, function(a, b) {
        var c = a.ma.X.ba,
            d = a.Kj;
        a = d.Cc;
        d = d.Bc;
        var e = _.D(c, 21);
        b = b.set("hxva", {
            value: e ? 1 : null
        }).set("cmsid", {
            value: e ? _.bh(c, 23) : null
        }).set("vid", {
            value: e ? _.bh(c, 22) : null
        }).set("pod", {
            value: d
        }).set("ppos", {
            value: a
        });
        c = Xd(c, 29);
        b.set.call(b, "scor", {
            value: null == c ? void 0 : c
        })
    }, function(a, b) {
        var c = a.ma,
            d = c.ga,
            e = c.X.Y;
        c = a.hj;
        var f = c.yi,
            g = c.si;
        b.set("eid", {
            value: a.la.Se
        }).set("debug_experiment_id", {
            value: fA().split(",")
        }).set("expflags", {
            value: _.fh(253) ? _.lf(qf).j(Lx.j, Lx.defaultValue) || null : null
        }).set("pied", {
            value: function() {
                var h = new EB,
                    k = !1,
                    l = !1;
                f && (k = !0, qi(h, 1, hv, f));
                var m = d.map(function(p) {
                    var r = new CB,
                        u;
                    p = null == (u = e[p.getDomId()]) ? void 0 : Oe(u, hv, 27);
                    if (null == p || !p.length) return r;
                    l = k = !0;
                    u = _.y(p);
                    for (p = u.next(); !p.done; p = u.next()) qi(r, 1, hv, p.value);
                    return r
                });
                l && _.el(h, 2, m);
                m = _.y(null != g ? g : []);
                for (var n = m.next(); !n.done; n = m.next()) qi(h, 1, hv, n.value), k = !0;
                return k ? Ib(h.j(), 3) : null
            }()
        })
    }, function(a, b) {
        var c = a.la,
            d = c.context;
        c = c.Va;
        b.set("output", {
            value: a.rh.ce
        }).set("gdfp_req", {
            value: 1
        }).set("vrg", {
            value: d.Ub ? String(d.Ub) : d.nb
        }).set("ptt", {
            value: 17
        }).set("impl", {
            value: c ? "fifs" : "fif"
        })
    }, function(a, b) {
        var c = a.la.ca;
        a = ar(a.ma.X.ba) || new aC;
        var d = _.Qe(a, 6, 2);
        b.set("rdp", {
            value: _.D(a, 1) ? "1" : null
        }).set("ltd", {
            value: _.D(a, 9) ? "1" : null
        }).set("gdpr_consent", {
            value: ou(c, 2)
        }).set("gdpr", {
            value: null != Gk(c, 3) ? _.D(c, 3) ? "1" : "0" : null,
            options: {
                ya: !0
            }
        }).set("addtl_consent", {
            value: ou(c, 4)
        }).set("tcfe", {
            value: pu(c, 7)
        }).set("us_privacy", {
            value: ou(c, 1)
        }).set("npa", {
            value: _.D(c, 6) || _.D(a, 8) ? 1 : null
        }).set("puo", {
            value: _.G(fy) && _.D(a, 13) ? 1 : null
        }).set("tfua", {
            value: 2 !== d ? d : null,
            options: {
                ya: !0
            }
        }).set("tfcd", {
            value: null != yc(Xd(a, 5)) ? _.Qe(a, 5, 0) : null,
            options: {
                ya: !0
            }
        }).set("trt", {
            value: null != yc(Xd(a, 10)) ? _.Qe(a, 10, 0) : null,
            options: {
                ya: !0
            }
        }).set("tad", {
            value: null != Gk(c, 8) ? _.D(c, 8) ? "1" : "0" : null,
            options: {
                ya: !0
            }
        }).set("gpp", {
            value: ou(c, 11)
        }).set("gpp_sid", {
            value: Yc(c, 10, Bc).join(",") || void 0
        })
    }, function(a, b) {
        var c = a.ma,
            d = c.X,
            e = c.ga,
            f = c.af;
        a = a.la;
        var g = a.G,
            h = a.O,
            k = a.Va;
        a = {
            va: "~"
        };
        var l = e.map(function(n) {
                return d.Y[n.getDomId()]
            }),
            m = [];
        c = e.map(function(n) {
            return n.getAdUnitPath().replace(/,/g, ":").split("/").map(function(p) {
                if (!p) return "";
                var r = _.v(m, "findIndex").call(m, function(u) {
                    return u === p
                });
                return 0 <= r ? r : m.push(p) - 1
            }).join("/")
        });
        b.set("iu_parts", {
            value: m
        }).set("enc_prev_ius", {
            value: c
        }).set("prev_iu_szs", {
            value: l.map(function(n) {
                return ah(n)
            })
        }).set("fluid", {
            value: function() {
                var n = !1,
                    p = l.map(function(r) {
                        r = (_.C = $g(r), _.v(_.C, "includes")).call(_.C, "fluid");
                        n || (n = r);
                        return r ? "height" : "0"
                    });
                return n ? p : null
            }()
        }).set("ifi", {
            value: function() {
                var n = Xh(g);
                if (!f) {
                    n += 1;
                    var p = g,
                        r = e.length;
                    r = void 0 === r ? 1 : r;
                    p = cx(ie(p)) || p;
                    p.google_unique_id = (p.google_unique_id || 0) + r
                }
                return n
            }()
        }).set("adks", {
            value: e.map(function(n) {
                if (k) {
                    var p = d.Y[n.getDomId()];
                    p = ch(p);
                    if (n = h.j.get(n)) n.Lc = p;
                    return p
                }
                p = d.ba;
                var r = d.Y[n.getDomId()],
                    u;
                if (!(u = Kq(h, n))) {
                    p = ch(r, _.D(p, 6) || _.D(r, 17) ? null : vh(n));
                    if (n = h.j.get(n)) n.Lc = p;
                    u = p
                }
                return u
            })
        }).set("didk", {
            value: _.G(ly) ? sm(e, function(n) {
                return _.Af(n.getDomId())
            }, a) : null,
            options: _.v(Object, "assign").call(Object, {}, a, {
                vb: !0
            })
        })
    }, function(a, b) {
        var c = a.ma;
        a = c.ga;
        c = c.X;
        var d = c.ba,
            e = c.Y;
        b.set("sfv", {
            value: GF ? GF : GF = wk()
        }).set("fsfs", {
            value: sm(a, function(f) {
                f = e[f.getDomId()];
                var g;
                return Number(null != (g = null == f ? void 0 : ym(f, 12)) ? g : Gk(d, 13))
            }, {
                Pc: 0
            }),
            options: {
                va: ",",
                Nc: 0,
                vb: !0
            }
        }).set("fsbs", {
            value: sm(a, function(f) {
                f = e[f.getDomId()].Qb();
                var g = d.Qb(),
                    h;
                return (null != (h = null == f ? void 0 : ym(f, 3)) ? h : null == g ? 0 : _.D(g, 3)) ? 1 : 0
            }, {
                Pc: 0
            }),
            options: {
                Nc: 0,
                vb: !0
            }
        })
    }, function(a, b) {
        var c = a.la,
            d = c.O,
            e = c.G;
        a = a.ma;
        c = a.ga;
        var f = a.af;
        b.set("ris", {
            value: sm(c, function(g) {
                var h, k;
                g = null != (k = null == (h = d.j.get(g)) ? void 0 : h.yg) ? k : 0;
                h = _.gf(e);
                return g && h ? Math.round(Math.min((h - g) / 1E3, 1800)) : null
            }, {
                va: "~"
            }),
            options: {
                va: "~",
                vb: !0
            }
        }).set("rcs", {
            value: sm(c, function(g) {
                if (!f) {
                    var h = void 0 === h ? _.t : h;
                    var k = d.j.get(g);
                    k && (k.yg = _.gf(h) || 0, k.Pg++)
                }
                return ZD(d, g)
            }, {
                Pc: 0
            }),
            options: {
                Nc: 0,
                vb: !0
            }
        })
    }, function(a, b) {
        var c = a.ma;
        a = a.la.Va;
        c = c.X.Y[c.ga[0].getDomId()];
        b.set("click", {
            value: !a && c.getClickUrl() ? _.bh(c, 7) : null
        })
    }, function(a, b, c) {
        var d = a.ma,
            e = d.ga,
            f = d.X.Y;
        a = a.la;
        var g = a.ca,
            h = a.G;
        c = void 0 === c ? function(k, l) {
            return Ze(k, l)
        } : c;
        a = e.map(function(k) {
            return f[k.getDomId()]
        });
        b.set("ists", {
            value: pm(a, function(k) {
                return 0 !== on(k)
            }) || null
        }).set("fas", {
            value: sm(a, function(k) {
                return sn(on(k))
            }, {
                Pc: 0
            }),
            options: {
                Nc: 0,
                vb: !0
            }
        }).set("itsi", {
            value: e.some(function(k) {
                var l;
                return !pn(k) && 5 === (null == (l = f[k.getDomId()]) ? void 0 : on(l))
            }) ? function() {
                var k = c(g, h);
                if (!k) return 1;
                var l;
                k = Math.max.apply(Math, _.se(null != (l = _.mn(k, 604800)) ? l : []));
                return isFinite(k) ? Math.floor(Math.max((Date.now() - k) / 6E4, 1)) : null
            }() : null
        })
    }, function(a, b) {
        a = a.ma;
        var c = a.X.Y;
        a = a.ga.map(function(d) {
            return c[d.getDomId()]
        });
        b.set("rbvs", {
            value: pm(a, function(d) {
                return 4 === on(d)
            }) || null
        })
    }, function(a, b) {
        var c = a.ma,
            d = c.X,
            e = c.X.ba,
            f = c.ga;
        c = c.Kb;
        var g = a.la;
        a = g.isSecureContext;
        g = g.G;
        b = b.set("prev_scp", {
            value: Pm(f, d),
            options: {
                vb: !0,
                va: "|"
            }
        });
        var h = b.set,
            k = d.ba,
            l = d.Y,
            m = new Rh;
        m.set(0, 1 !== c);
        l = l[f[0].getDomId()];
        m.set(1, !!_.D(l, 17));
        m.set(2, Vm(f, d));
        m.set(3, _.D(k, 27) || !1);
        m.set(4, 3 === c);
        d = Th(m);
        h.call(b, "eri", {
            value: d
        }).set("cust_params", {
            value: Rm(e),
            options: {
                va: "&"
            }
        }).set("ppid", {
            value: null != _.bh(e, 16) ? _.R(e, 16) : null,
            options: {
                ya: !0
            }
        }).set("gct", {
            value: Km("google_preview", g)
        }).set("sc", {
            value: a ? 1 : 0,
            options: {
                ya: !0
            }
        })
    }, function(a, b) {
        var c = a.la,
            d = c.G,
            e = c.ca;
        c = c.ua;
        var f = Sm(a.ma.X.ba.Ea()),
            g = _.sk(c, "__gads", e);
        a = "1" === _.sk(c, "__gpi_opt_out", e) ? "1" : null;
        b = b.set("cookie", {
            value: g,
            options: {
                ya: !0
            }
        }).set("cookie_enabled", {
            value: !g && uA(c, e) ? "1" : null
        });
        g = d.document;
        var h = g.domain;
        d = b.set.call(b, "cdm", {
            value: (f || hh(d)) === g.URL ? "" : h
        });
        f = d.set;
        e = (e = _.sk(c, "__gpi", e)) && !_.v(e, "includes").call(e, "&") ? e : null;
        f.call(d, "gpic", {
            value: e
        }).set("pdopt", {
            value: a
        })
    }, function(a, b) {
        a = a.la.G;
        b.set("arp", {
            value: zl(a) ? 1 : null
        }).set("abxe", {
            value: _.Zi(a.top) || Lw(a.IntersectionObserver) ? 1 : null
        })
    }, function(a, b) {
        var c = a.la.G;
        a = Sm(a.ma.X.ba.Ea());
        b.set("dt", {
            value: (new Date).getTime()
        });
        if (!a) {
            a = b.set;
            try {
                var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
            } catch (e) {
                d = null
            }
            a.call(b, "lmt", {
                value: d
            })
        }
        d = Kp;
        c = _.jf(c);
        0 < c && d >= c && b.set("dlt", {
            value: c
        }).set("idt", {
            value: d - c
        })
    }, function(a, b) {
        var c = a.ma,
            d = c.X;
        c = c.ga;
        var e = a.la;
        a = e.G;
        var f = e.Va;
        e = Zg(!0, a);
        for (var g = d.ba, h = a.document, k = d.Y, l = [], m = [], n = _.y(c), p = n.next(); !p.done; p = n.next()) {
            p = p.value;
            var r = k[p.getDomId()];
            p = Bh(p, r, h, zm(g, r));
            r = void 0;
            var u = f ? null != (r = p) ? r : CJ : p;
            u && (l.push(Math.round(u.x)), m.push(Math.round(u.y)))
        }
        e && (d.Dc = e);
        f = gh(a) ? null : Zg(!1, a);
        try {
            var w = a.top;
            var A = Qq(w.document, w)
        } catch (F) {
            A = new _.jh(-12245933, -12245933)
        }
        b.set("adxs", {
            value: l,
            options: {
                ya: !0
            }
        }).set("adys", {
            value: m,
            options: {
                ya: !0
            }
        }).set("biw", {
            value: e ? e.width : null
        }).set("bih", {
            value: e ? e.height : null
        }).set("isw", {
            value: e ? null == f ? void 0 : f.width : null
        }).set("ish", {
            value: e ? null == f ? void 0 : f.height : null
        }).set("scr_x", {
            value: Math.round(A.x),
            options: {
                ya: !0
            }
        }).set("scr_y", {
            value: Math.round(A.y),
            options: {
                ya: !0
            }
        }).set("btvi", {
            value: Sq(c, a, d),
            options: {
                ya: !0,
                va: "|"
            }
        })
    }, function(a, b) {
        var c = a.la.O;
        b.set("ucis", {
            value: a.ma.ga.map(function(d) {
                d = c.j.get(d);
                null != d.rd || (d.rd = window === window.top ? (++c.V).toString(36) : ew());
                return d.rd
            }),
            options: {
                va: "|"
            }
        }).set("oid", {
            value: 2
        })
    }, function(a, b) {
        a = a.ma;
        var c = a.ga,
            d = a.X,
            e = d.Y;
        a = new _.x.Map;
        d = _.y(d.ba.Ea());
        for (var f = d.next(); !f.done; f = d.next()) {
            var g = f.value;
            a.set(_.R(g, 1), [_.Sl(g, 2)[0]])
        }
        for (d = 0; d < c.length; d++)
            if (g = e[c[d].getDomId()])
                for (g = _.y(g.Ea()), f = g.next(); !f.done; f = g.next()) {
                    var h = f.value;
                    f = _.R(h, 1);
                    var k = a.get(f) || [];
                    h = _.Sl(h, 2)[0];
                    1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                    a.set(f, k)
                }
        c = [];
        e = _.y(_.v(a, "keys").call(a));
        for (d = e.next(); !d.done; d = e.next()) g = d.value, d = cE()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
            return encodeURIComponent(l || "")
        }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
            value: g[0]
        }));
        c.length && b.set("sps", {
            value: c,
            options: {
                va: "|"
            }
        })
    }, function(a, b) {
        var c = a.ma.X.ba,
            d = a.la;
        a = d.G;
        d = d.ub;
        var e = _.fh(251),
            f, g, h, k, l, m, n;
        var p = a;
        p = void 0 === p ? Yv : p;
        try {
            var r = p.history.length
        } catch (Ua) {
            r = 0
        }
        b = b.set("u_his", {
            value: r
        }).set("u_h", {
            value: null == (f = a.screen) ? void 0 : f.height
        }).set("u_w", {
            value: null == (g = a.screen) ? void 0 : g.width
        }).set("u_ah", {
            value: null == (h = a.screen) ? void 0 : h.availHeight
        }).set("u_aw", {
            value: null == (k = a.screen) ? void 0 : k.availWidth
        }).set("u_cd", {
            value: null == (l = a.screen) ? void 0 : l.colorDepth
        });
        f = b.set;
        g = a;
        g = void 0 === g ? _.t : g;
        g = g.devicePixelRatio;
        f = f.call(b, "u_sd", {
            value: "number" === typeof g ? +g.toFixed(3) : null
        }).set("u_tz", {
            value: -(new Date).getTimezoneOffset()
        });
        g = f.set;
        try {
            var u, w, A, F, B = null != (F = null == (u = a.external) ? void 0 : null == (w = u.getHostEnvironmentValue) ? void 0 : null == (A = w.bind(a.external)) ? void 0 : A("os-mode")) ? F : "",
                E, N = Number(null == (E = JSON.parse(B)) ? void 0 : E["os-mode"]);
            var Q = 0 <= N ? N + 1 : null
        } catch (Ua) {
            Q = null
        }
        Q = g.call(f, "wsm", {
            value: Q
        }).set("dmc", {
            value: null != (n = null == (m = a.navigator) ? void 0 : m.deviceMemory) ? n : null
        });
        m = Q.set;
        (c = _.bh(c, 8)) ? (50 < c.length && (c = c.substring(0, 50)), c = "a " + Rt('role:1 producer:12 loc:"' + c + '"')) : c = "";
        c = m.call(Q, "uule", {
            value: c
        });
        m = c.set;
        n = a;
        n = void 0 === n ? _.t : n;
        Q = new Rh;
        "SVGElement" in n && "createElementNS" in n.document && Q.set(0);
        u = Kw();
        u["allow-top-navigation-by-user-activation"] && Q.set(1);
        u["allow-popups-to-escape-sandbox"] && Q.set(2);
        n.crypto && n.crypto.subtle && Q.set(3);
        "TextDecoder" in n && "TextEncoder" in n && Q.set(4);
        n = Th(Q);
        e = m.call(c, "bc", {
            value: n
        }).set("uach", {
            value: e ? Rt(e, 3) : null
        });
        c = e.set;
        if (d) var P = null;
        else if (d = null == (P = a.navigator) ? void 0 : P.userActivation) {
            P = 0;
            if (null == d ? 0 : d.hasBeenActive) P |= 1;
            if (null == d ? 0 : d.isActive) P |= 2
        } else P = void 0;
        P = c.call(e, "uas", {
            value: P
        });
        d = P.set;
        a: {
            try {
                var Y, ja, xa = null == (Y = a.performance) ? void 0 : null == (ja = Y.getEntriesByType("navigation")) ? void 0 : ja[0];
                if (null == xa ? 0 : xa.type) {
                    var ia;
                    var na = null != (ia = PA.get(xa.type)) ? ia : null;
                    break a
                }
            } catch (Ua) {}
            var ta, Oa, va;na = null != (va = QA.get(null == (ta = a.performance) ? void 0 : null == (Oa = ta.navigation) ? void 0 : Oa.type)) ? va : null
        }
        d.call(P, "nvt", {
            value: na
        })
    }, function(a, b) {
        var c = a.la,
            d = c.G,
            e = c.O;
        c = c.Va;
        a = a.ma;
        var f = a.ga;
        a = a.X;
        var g = a.ba,
            h = a.Y;
        a = Lm("google_preview", d);
        var k = d.document,
            l = a ? Tm(k.URL) : k.URL;
        k = a ? Tm(k.referrer) : k.referrer;
        a = !1;
        if (c) c = Sm(g.Ea());
        else {
            var m;
            c = null != (m = Sm(h[f[0].getDomId()].Ea())) ? m : Sm(g.Ea())
        }
        if (null != c) {
            var n = l;
            gh(d) || (k = "", a = !0)
        } else c = l;
        m = Um(d);
        b.set("nhd", {
            value: m || null
        }).set("url", {
            value: c
        }).set("loc", {
            value: null !== n && n !== c ? n : null
        }).set("ref", {
            value: k
        });
        if (m) {
            n = b.set;
            var p, r;
            m = _.Zi(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
            var u;
            p = null == (u = d.location) ? void 0 : u.ancestorOrigins;
            d = xj(d) || "";
            u = (null == p ? void 0 : p[p.length - 1]) || "";
            d = (d = m || d || u) ? a ? zw(d.match(_.yw)[3] || null) : d : null;
            n.call(b, "top", {
                value: d
            }).set("etu", {
                value: e.Jd
            })
        }
    }, function(a, b) {
        a = a.la.context.pvsid;
        b.set("rumc", {
            value: _.G(By) || _.lf(Dg).j ? a : null
        }).set("rume", {
            value: _.G(Xx) ? 1 : null
        })
    }, function(a, b) {
        a = a.la.G;
        var c = b.set;
        var d = Yw(a);
        var e = Kz(a, a.google_ad_width, a.google_ad_height);
        var f = d.location.href;
        if (d === d.top) f = !0;
        else {
            var g = !1,
                h = d.document;
            h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
            (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1);
            f = g
        }
        g = a.top == a ? 0 : _.Zi(a.top) ? 1 : 2;
        d = 4;
        e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
        f && (d |= 16);
        e = "" + d;
        if (a != a.top)
            for (f = a; f && f != f.top && _.Zi(f) && !f.sf_ && !f.$sf && !f.inGptIF && !f.inDapIF; f = f.parent);
        c.call(b, "frm", {
            value: e || null
        }).set("vis", {
            value: _.UA(a.document)
        })
    }, function(a, b) {
        var c = a.ma.ga;
        a = a.la.G;
        for (var d = [], e = [], f = _.y(c), g = f.next(); !g.done; g = f.next()) {
            var h = void 0,
                k = void 0,
                l = void 0;
            var m = a;
            g = vh(g.value);
            var n = Ow((null == g ? void 0 : g.parentElement) && xh(g.parentElement, m) || null);
            !n || 1 === n[0] && 1 === n[3] ? (n = null != (l = null == g ? void 0 : g.parentElement) ? l : null, l = null != (k = ph(n)) ? k : new _.oh(0, 0), Dl(l, n, m, 100), k = null != (h = ph(g)) ? h : new _.oh(0, 0), Dl(k, g, m, 1), -1 === l.height && (k.height = -1), m = l, k = h = k, h = m.width + "x" + m.height, m = k.width + "x" + k.height) : m = h = "-1x-1";
            d.push(h);
            e.push(m)
        }
        null == rG && (f = Kz(a, 500, 300), m = a.navigator, h = m.userAgent, k = m.platform, m = m.product, !/Win|Mac|Linux|iPad|iPod|iPhone/.test(k) && /^Opera/.test(h) ? h = !1 : /Win/.test(k) && /Trident/.test(h) && 11 <= a.document.documentMode ? h = !0 : (k = (/WebKit\/(\d+)/.exec(h) || [0, 0])[1], g = (/rv:(\d+\.\d+)/.exec(h) || [0, 0])[1], h = !k && "Gecko" === m && 27 <= g && !/ rv: 1\.8([^.] |\.0) /.test(h) || 536 <= k ? !0 : !1), rG = h && !f);
        g = 0 !== (0, _.bn)();
        f = Zg(!0, a, g).width;
        h = [];
        m = [];
        k = [];
        null !== a && a != a.top && (l = Zg(!1, a).width, (-12245933 === f || -12245933 === l || l < f) && k.push(8)); - 12245933 !== f && (1.5 * f < a.document.documentElement.scrollWidth ? k.push(10) : g && 1.5 * a.outerWidth < f && k.push(10));
        c = _.y(c);
        for (l = c.next(); !l.done; l = c.next()) {
            g = new Rh;
            n = vh(l.value);
            l = 0;
            var p = !1,
                r = !1,
                u = !1;
            if (n) {
                for (var w = 0, A = n; A && 100 > w; w++, A = A.parentElement) {
                    var F = xh(A, a);
                    if (F) {
                        var B = F,
                            E = B.display,
                            N = B.overflowX;
                        if ("visible" !== B.overflowY && (g.set(2), (B = ph(A)) && (l = l ? Math.min(l, B.width) : B.width), g.get(9))) break;
                        Bl(F) && g.set(9);
                        "none" === E && g.set(7);
                        "IFRAME" === A.nodeName && (F = parseInt(F.width, 10), F < f && (g.set(8), l = l ? Math.min(F, l) : F));
                        r || (r = "scroll" === N || "auto" === N);
                        p || (p = "flex" === E);
                        u || (u = "listbox" === A.role)
                    } else g.set(3)
                }
                if (!u) {
                    if (p = r && p) n = n.getBoundingClientRect().left, p = n > f || 0 > n;
                    u = p
                }
                u && g.set(11)
            } else g.set(1);
            n = _.y(k);
            for (p = n.next(); !p.done; p = n.next()) g.set(p.value);
            h.push(Th(g));
            m.push(l)
        }
        b.set("psz", {
            value: d,
            options: {
                va: "|"
            }
        }).set("msz", {
            value: e,
            options: {
                va: "|"
            }
        }).set("fws", {
            value: h,
            options: {
                ya: !0
            }
        }).set("ohw", {
            value: m,
            options: {
                ya: !0
            }
        }).set("ea", {
            value: rG ? null : "0",
            options: {
                ya: !0
            }
        }).set("efat", {
            value: a.location && "#flexibleAdSlotTest" === a.location.hash ? "1" : null
        })
    }, function(a, b) {
        b.set("psts", {
            value: YD(a.la.O, a.ma.ga)
        })
    }, function(a, b) {
        var c = a.la;
        a = c.ca;
        c = c.G;
        var d;
        var e = c.document.domain,
            f = null != (d = _.D(a, 5) && $e(c) ? c.document.cookie : null) ? d : "",
            g = c.history.length,
            h = c.screen,
            k = c.document.referrer;
        if (ie()) var l = window.gaGlobal || {};
        else {
            var m = Math.round((new Date).getTime() / 1E3),
                n = c.google_analytics_domain_name;
            e = "undefined" == typeof n ? Gz("auto", e) : Gz(n, e);
            var p = -1 < f.indexOf("__utma=" + e + "."),
                r = -1 < f.indexOf("__utmb=" + e);
            (d = (cx() || window).gaGlobal) || (d = {}, (cx() || window).gaGlobal = d);
            var u = !1;
            if (p) {
                var w = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                r ? d.sid = w[3] : d.sid || (d.sid = m + "");
                d.vid = w[0] + "." + w[1];
                d.from_cookie = !0
            } else {
                d.sid || (d.sid = m + "");
                if (!d.vid) {
                    u = !0;
                    r = Math.round(2147483647 * Math.random());
                    p = Ez.appName;
                    var A = Ez.version,
                        F = Ez.language ? Ez.language : Ez.browserLanguage,
                        B = Ez.platform,
                        E = Ez.userAgent;
                    try {
                        w = Ez.javaEnabled()
                    } catch (N) {
                        w = !1
                    }
                    w = [p, A, F, B, E, w ? 1 : 0].join("");
                    h ? w += h.width + "x" + h.height + h.colorDepth : _.t.java && _.t.java.awt && (h = _.t.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), w += h.screen.width + "x" + h.screen.height);
                    w = w + f + (k || "");
                    for (k = w.length; 0 < g;) w += g-- ^ k++;
                    d.vid = (r ^ Fz(w) & 2147483647) + "." + m
                }
                d.from_cookie || (d.from_cookie = !1)
            }
            if (!d.cid) {
                b: for (m = 999, n && (n = 0 == n.indexOf(".") ? n.substr(1) : n, m = n.split(".").length), n = 999, f = f.split(";"), w = 0; w < f.length; w++)
                    if (k = Hz.exec(f[w]) || Iz.exec(f[w]) || Jz.exec(f[w])) {
                        h = k[1] || 0;
                        if (h == m) {
                            l = k[2];
                            break b
                        }
                        h < n && (n = h, l = k[2])
                    }u && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
            }
            d.dh = e;
            d.hid || (d.hid = Math.round(2147483647 * Math.random()));
            l = d
        }
        e = l.sid;
        d = l.hid;
        u = l.from_cookie;
        f = l.cid;
        u && !_.D(a, 5) || b.set("ga_vid", {
            value: l.vid
        }).set("ga_sid", {
            value: e
        }).set("ga_hid", {
            value: d
        }).set("ga_fc", {
            value: u
        }).set("ga_cid", {
            value: f
        }).set("ga_wpids", {
            value: c.google_analytics_uacct
        })
    }, function(a, b) {
        var c = a.la.G,
            d = c.navigator;
        c = c.document;
        a = a.Hj.Af;
        if (!_.G(Fy) && ("runAdAuction" in d && "joinAdInterestGroup" in d && pf("run-ad-auction", c) && b.set("td", {
                value: 1
            }), a)) switch (a.kind) {
            case 0:
                b.set("eig", {
                    value: a.signal
                });
                break;
            case 1:
                b.set("eigir", {
                    value: a.reason,
                    options: {
                        ya: !0
                    }
                });
                break;
            default:
                eb(a)
        }
    }, function(a, b) {
        var c = a.yj,
            d = c.Bj;
        c = c.zj;
        pf("browsing-topics", a.la.G.document) && (b.set("topics", {
            value: d instanceof Uint8Array ? Ib(d, 3) : d
        }), !d || d instanceof Uint8Array || b.set("tps", {
            value: d
        }), c && b.set("htps", {
            value: c
        }))
    }, function(a, b) {
        var c = a.la,
            d = c.G,
            e = c.ca,
            f = a.ma.ga;
        c = a.tj;
        a = c.fe;
        var g = c.fi,
            h = c.Si;
        if (!_.G(zy)) {
            c = b.set;
            e = Ze(e, d);
            d = rg(f[0].getAdUnitPath());
            f = new Gv;
            ri(f, e, d, h);
            g = null != g ? g : [];
            if (d && a && g && "function" === typeof a.getUserIdsAsEidBySource) {
                if ("function" === typeof a.getUserIdsAsEids) try {
                    for (var k = _.y(a.getUserIdsAsEids()), l = k.next(); !l.done; l = k.next()) {
                        var m = l.value;
                        "string" === typeof m.source && ii(52, m.source)
                    }
                } catch (p) {
                    var n;
                    ii(45, "", null == (n = p) ? void 0 : n.message)
                }
                k = _.y(g);
                for (l = k.next(); !l.done; l = k.next())
                    if (l = l.value, String(_.R(l, 1)) === d)
                        for (l = _.y(Oe(l, Vu, 2)), m = l.next(); !m.done; m = l.next())
                            if (m = m.value, _.D(m, oj(m, Wu, 3)) && (m = _.R(m, 1), !ki(f, m))) {
                                n = null;
                                try {
                                    e = h = g = void 0, n = null == (g = a.getUserIdsAsEidBySource(m)) ? void 0 : null == (h = g.uids) ? void 0 : null == (e = h[0]) ? void 0 : e.id
                                } catch (p) {
                                    g = void 0, ii(45, m, null == (g = p) ? void 0 : g.message)
                                }
                                n && (300 < n.length ? (g = {}, ii(12, m, null, (g.sl = String(n.length), g.fp = "1", g))) : (g = xv(m), g = Ll(g, 2, n), g = pi(g, 11, !0), qi(f, 2, ji, g), g = {}, ii(19, m, null, (g.fp = "1", g.hs = n ? "1" : "0", g))))
                            }
            }
            Oe(f, ji, 2).length ? (ii(50, ""), a = Ib(f.j(), 3)) : a = null;
            c.call(b, "a3p", {
                value: a
            })
        }
    }, function(a, b) {
        var c = a.Ya.zd,
            d = a.ma.ga;
        a = {
            va: "~"
        };
        var e = function() {
            return c ? d.map(function(f) {
                return c.get(f)
            }) : []
        }();
        b.set("cbidsp", {
            value: sm(e, function(f) {
                return Ib(f.j(), 3)
            }, a),
            options: _.v(Object, "assign").call(Object, {}, a, {
                vb: !0
            })
        })
    }, function(a, b) {
        a = a.ma.X.ba;
        var c = a.Qd();
        void 0 !== dm(c, Gp, 1, !1) && (a = Fp(a.Qd(), Gp, 1), b.set("cmrv", {
            value: 1
        }).set("cmrq", {
            value: _.bh(a, 1)
        }).set("cmrc", {
            value: _.Sl(a, 2),
            options: {
                va: ">"
            }
        }).set("cmrids", {
            value: _.Sl(a, 3),
            options: {
                va: "!"
            }
        }).set("cmrf", {
            value: _.bh(a, 4)
        }))
    }, function(a, b) {
        var c = [];
        a = _.y(Oe(Fp(a.ma.X.ba.Qd(), Ip, 2), Nn, 1));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.Sl(d, 2).length && c.push(_.Qe(d, 1, 0) + 2 + "=" + _.Sl(d, 2).join("|"));
        b.set("pps", {
            value: c,
            options: {
                va: "~"
            }
        })
    }, function(a, b) {
        b.set("scar", {
            value: a.Xi.xi
        })
    }, function(a, b) {
        a = a.la.G.document;
        !_.G(Ay) && pf("attribution-reporting", a) && b.set("nt", {
            value: 1
        })
    }, function(a, b) {
        if (a = a.ej.dj) a = Rt(Le(a), 3), b.set("psd", {
            value: a
        })
    }]);
    var DJ = function(a, b, c) {
        Z.call(this, a, 798);
        this.C = V(this);
        this.m = X(this, b);
        this.A = W(this, c)
    };
    _.S(DJ, Z);
    DJ.prototype.j = function() {
        var a = this,
            b = new _.x.Map;
        if (this.m.value) {
            var c = this.m.value,
                d = c.la.Va,
                e = c.Ya.zd;
            c = _.y(c.ma.ga);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? EJ(this, f, h) : function() {
                    return a.A.value
                })
            }
        }
        this.C.H(b)
    };
    var EJ = function(a, b, c) {
        return wh(function() {
            var d = _.v(Object, "assign").call(Object, {}, a.m.value);
            d.ma.af = !0;
            d.ma.ga = [b];
            c && (d.Ya.zd = new _.x.Map, d.Ya.zd.set(b, c));
            return Jm($q(d)).url
        })
    };
    var FJ = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.D = b;
        this.Va = c;
        this.X = d;
        this.A = e;
        this.G = f;
        this.ca = g;
        this.m = V(this)
    };
    _.S(FJ, Z);
    FJ.prototype.j = function() {
        var a = this,
            b = this.D;
        !this.Va && 1 < this.D.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.N) return !1;
            var d = a.X.Y[c.getDomId()],
                e;
            if (e = !(wn(on(d)) && (_.C = sf($x), _.v(_.C, "includes")).call(_.C, String(on(d))))) e = a.A, dg(a.G) && 4 === on(d) ? (M(e, WE("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            return e && !rn(a.context, a.A, c, d, a.G, a.ca)
        });
        30 < b.length && (M(this.A, SE("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        this.m.H(b)
    };
    var GJ = function(a, b, c) {
        Z.call(this, a, 919);
        this.m = b;
        this.ca = c;
        this.C = V(this)
    };
    _.S(GJ, Z);
    GJ.prototype.j = function() {
        var a, b = !(null == (a = this.m) ? 0 : _.D(a, 9)) && !!_.D(this.ca, 5);
        this.C.H(b)
    };
    var HJ = function(a, b, c, d, e, f) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.D = f;
        this.C = xB(this);
        this.A = W(this, c);
        _.G(py) && e && (this.m = W(this, e));
        zB(this, d)
    };
    _.S(HJ, Z);
    var IJ = function(a) {
        return a.m ? a.D.split(",").some(function(b) {
            var c;
            return null == (c = a.m) ? void 0 : c.value.has(b)
        }) : !1
    };
    HJ.prototype.j = function() {
        var a = this.context,
            b = this.requestId,
            c = this.A.value.length,
            d = IJ(this);
        if (a.nd) {
            var e = a.Lb;
            a = wg(a);
            var f = new ox;
            b = _.rd(f, 2, b);
            c = _.ld(b, 1, c, 0);
            d = _.qd(c, 3, d);
            d = _.yg(a, 7, zg, d);
            ue(e, d)
        }
        this.C.notify()
    };
    var JJ = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.ta = b;
        this.X = c;
        this.C = xB(this);
        this.m = W(this, d)
    };
    _.S(JJ, Z);
    JJ.prototype.j = function() {
        for (var a = _.y(this.m.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.y(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = Tg(this.X.Y[b.getDomId()], 20);
            cp(b, LD, 808, {
                Uh: c,
                qj: d
            });
            cp(this.ta, "slotRequested", 705, new FH(b, "publisher_ads"))
        }
        this.C.notify()
    };
    var KJ = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B, E, N, Q, P, Y, ja, xa, ia, na, ta, Oa, va, Ua) {
        Z.call(this, a, 785, _.rf(my));
        this.Va = b;
        this.O = c;
        this.ua = d;
        this.X = e;
        this.ce = f;
        this.Kb = g;
        this.Cc = h;
        this.Bc = k;
        this.Se = l;
        this.Mc = m;
        this.timer = n;
        this.ca = p;
        this.isSecureContext = r;
        this.ub = u;
        this.G = w;
        this.m = V(this);
        this.A = V(this);
        this.W = V(this);
        zB(this, P);
        this.sa = yB(this, A);
        this.I = yB(this, F);
        this.M = W(this, B);
        N && (this.D = yB(this, N.oe), N.me && (this.La = X(this, N.me)));
        Q && (this.T = yB(this, Q.Zb));
        zB(this, P);
        zB(this, Y);
        ja && (this.Ca = W(this, ja));
        xa && (this.aa = new qB(xa));
        ia && (this.za = X(this, ia));
        na && (this.ia = W(this, na));
        ta && zB(this, ta);
        Oa && (this.ka = W(this, Oa));
        E && (this.da = X(this, E));
        va && (this.Ga = X(this, va.wf));
        Ua && (this.Qa = W(this, Ua))
    };
    _.S(KJ, Z);
    KJ.prototype.j = function() {
        if (this.M.value.length) {
            var a = !_.G(Rx);
            if (a) {
                Gf();
                var b = If[1]
            } else b = "";
            if (a) {
                Gf();
                var c = If[4]
            } else c = "";
            a ? (Gf(), a = If[6]) : a = "";
            var d = null;
            this.D && (d = (d = this.D.value) ? d : this.T && !this.T.kb() ? 9 : this.D.kb() ? null : 1);
            this.I.value && (this.O.Jd = this.I.value);
            var e, f, g, h, k, l, m, n, p, r, u;
            b = {
                la: {
                    G: this.G,
                    context: this.context,
                    O: this.O,
                    ua: this.ua,
                    ca: this.ca,
                    Va: this.Va,
                    Se: this.Se,
                    isSecureContext: this.isSecureContext,
                    ub: this.ub
                },
                ma: {
                    ga: this.M.value,
                    X: this.X,
                    Kb: this.Kb,
                    af: !1
                },
                Kj: {
                    Cc: this.Cc,
                    Bc: this.Bc
                },
                Ri: {
                    Ih: b,
                    Li: c,
                    ij: a
                },
                Xi: {
                    xi: null != (r = this.sa.value) ? r : "0"
                },
                rh: {
                    ce: this.ce,
                    Mc: this.Mc
                },
                Ya: {
                    zd: null == (e = this.da) ? void 0 : e.value
                },
                yj: {
                    Bj: d,
                    zj: null == (f = this.La) ? void 0 : f.value
                },
                tj: {
                    Si: null != (u = null == (g = this.Ca) ? void 0 : g.value) ? u : void 0,
                    fe: null == (h = this.aa) ? void 0 : h.value,
                    fi: null == (k = this.ia) ? void 0 : k.value
                },
                hj: {
                    yi: null == (l = this.za) ? void 0 : l.value,
                    si: null == (m = this.ka) ? void 0 : m.value
                },
                ej: {
                    dj: null == (n = this.Ga) ? void 0 : n.value
                },
                Hj: {
                    Af: null == (p = this.Qa) ? void 0 : p.value
                }
            };
            this.A.H(b);
            e = Jm($q(b));
            f = e.url;
            lA(this.timer, (9).toString(), 9, e.Sf);
            this.m.H(f);
            this.W.H(Vq(b) ? _.gs("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : _.gs("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}"))
        } else this.m.H(""), this.A.ha()
    };
    var LJ = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.m = b;
        this.Z = c;
        this.X = d;
        this.G = e;
        this.C = xB(this);
        zB(this, f)
    };
    _.S(LJ, Z);
    LJ.prototype.j = function() {
        for (var a = _.y(this.m), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = vh(b, this.Z);
            if (!uh(b, this.Z) && c) {
                a: {
                    var d = c;
                    var e = this.X.Y[b.getDomId()],
                        f = 0,
                        g = 0;e = _.y($g(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.y(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), Bl(xh(d, this.G)) || !d.parentElement || Bl(xh(d.parentElement, this.G))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.X;f = g.ba;g = g.Y[b.getDomId()];Al(c, Dh(b), zm(f, g), d)
            }
        }
        this.C.notify()
    };
    var MJ = function(a, b, c, d, e, f, g) {
            this.m = a;
            this.A = b;
            this.N = c;
            this.ga = d;
            this.ca = e;
            this.V = f;
            this.J = g;
            this.B = "";
            this.F = -1;
            this.j = 1;
            this.o = ""
        },
        OJ = function(a, b) {
            if (b)
                if (1 !== a.j && 2 !== a.j) NJ(a, new nA("state err: (" + ([a.j, a.o.length].join() + ")")));
                else {
                    a.o && (b = a.o + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.j) f.B = c, ++f.F, f.j = 2;
                        else {
                            try {
                                f.m(f.F, f.B, {
                                    kind: 0,
                                    ob: Uw(c)
                                }, f.ga, f.ca, f.V, f.J), f.B = ""
                            } catch (g) {}
                            f.j = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.o = b.substr(c)
                }
        },
        NJ = function(a, b) {
            a.j = 4;
            try {
                a.A(b)
            } catch (c) {}
        },
        PJ = function(a) {
            1 !== a.j || a.o ? NJ(a, new nA("state err (" + ([a.j, a.o.length].join() + ")"))) : (a.j = 3, a.N(a.F, a.ga, a.ca))
        };
    var QJ = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 788);
        this.T = b;
        this.M = c;
        this.I = d;
        this.ca = e;
        this.C = xB(this);
        this.D = 0;
        this.A = !1;
        this.m = null != n ? n : new XMLHttpRequest;
        this.da = W(this, f);
        g && (this.ia = X(this, g));
        this.ka = W(this, h);
        zB(this, k);
        this.W = W(this, l);
        if (null == m ? 0 : m.Ac) this.aa = X(this, m.Ac)
    };
    _.S(QJ, Z);
    QJ.prototype.j = function() {
        var a = this,
            b = this.ka.value;
        if (b) {
            var c, d = new MJ(this.T, this.M, this.I, this.da.value, this.ca, null == (c = this.ia) ? void 0 : c.value);
            this.m.open("GET", b);
            this.m.withCredentials = this.W.value;
            var e;
            if (null == (e = this.aa) ? 0 : e.value) this.m.deprecatedBrowsingTopics = !0;
            this.m.onreadystatechange = function() {
                RJ(a, d, !1)
            };
            this.m.onload = function() {
                RJ(a, d, !0)
            };
            this.m.onerror = function() {
                NJ(d, new oA("XHR error"))
            };
            this.m.send()
        }
        this.C.notify()
    };
    var RJ = function(a, b, c) {
        try {
            if (3 === a.m.readyState || 4 === a.m.readyState)
                if (300 <= a.m.status) a.A || (NJ(b, new oA("xhr_err-" + a.m.status)), a.A = !0);
                else {
                    var d = a.m.responseText.substr(a.D);
                    d && OJ(b, d);
                    a.D = a.m.responseText.length;
                    c && 4 === a.m.readyState && PJ(b)
                }
        } catch (e) {
            NJ(b, e)
        }
    };
    var SJ = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 1078);
        this.D = b;
        this.A = c;
        this.m = d;
        this.ca = e;
        this.C = xB(this);
        this.T = W(this, f);
        g && (this.W = X(this, g));
        h && (this.aa = W(this, h));
        this.da = W(this, k);
        zB(this, l);
        this.I = W(this, m);
        if (null == n ? 0 : n.Ac) this.M = X(this, n.Ac);
        p && (this.ia = W(this, p))
    };
    _.S(SJ, Z);
    SJ.prototype.j = function() {
        var a = this,
            b = this.da.value;
        if (b) {
            var c, d, e = new MJ(this.D, this.A, this.m, this.T.value, this.ca, null == (c = this.W) ? void 0 : c.value, null == (d = this.aa) ? void 0 : d.value);
            c = this.I.value ? "include" : "omit";
            var f;
            d = null == (f = this.M) ? void 0 : f.value;
            var g;
            f = null == (g = this.ia) ? void 0 : g.value;
            g = _.v(Object, "assign").call(Object, {}, {
                credentials: c
            }, d ? {
                browsingTopics: d
            } : {}, f ? {
                Uk: f
            } : {});
            fetch(b, g).then(function(h) {
                TJ(a, h, e)
            }).catch(function(h) {
                UJ(h, e)
            })
        }
        this.C.notify()
    };
    var TJ = function(a, b, c) {
            if (300 <= b.status) NJ(c, new oA("fetch_status-" + b.status));
            else {
                var d, e = null == (d = b.body) ? void 0 : d.pipeThrough(new TextDecoderStream).getReader();
                e ? e.read().then(function(f) {
                    VJ(a, f, e, c)
                }).catch(function(f) {
                    UJ(f, c)
                }) : NJ(c, new oA("failed_reader"))
            }
        },
        VJ = function(a, b, c, d) {
            var e = b.value;
            b.done ? PJ(d) : (OJ(d, e), c.read().then(function(f) {
                VJ(a, f, c, d)
            }).catch(function(f) {
                UJ(f, d)
            }))
        },
        UJ = function(a, b) {
            NJ(b, new oA("fetch error: " + (a instanceof Error ? a.message : void 0)))
        };
    var WJ = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.X = b;
        this.timer = c;
        this.C = xB(this);
        this.m = W(this, e);
        zB(this, d)
    };
    _.S(WJ, Z);
    WJ.prototype.j = function() {
        var a = this.m.value;
        a.length && bp(this.timer, "3", vl(this.X.Y[a[0].getDomId()], 20));
        this.C.notify()
    };
    var YJ = function(a, b, c) {
        Z.call(this, a, 804);
        this.Ta = c;
        this.C = wB(this);
        this.A = [];
        this.qc = {
            zi: XJ(this, function(d) {
                return nu(d, 6)
            }),
            Lj: XJ(this, function(d) {
                return nu(d, 7)
            }),
            Fi: XJ(this, function(d) {
                return !!Gk(d, 8)
            }),
            li: XJ(this, function(d) {
                return ou(d, 10)
            }),
            tb: XJ(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            Jh: XJ(this, function(d) {
                return _.Rg(d, Iv, 43)
            }),
            Ei: XJ(this, function(d) {
                return !!Gk(d, 9)
            }),
            se: XJ(this, function(d) {
                return !!Gk(d, 12)
            }),
            ti: XJ(this, function(d) {
                return _.Rg(d, tv, oj(d, Uv, 48))
            }),
            Te: XJ(this, function(d) {
                return _.Rg(d, sv, oj(d, Uv, 39))
            }),
            Bd: XJ(this, function(d) {
                return pu(d, 36)
            }),
            Jj: XJ(this, function(d) {
                return !!Gk(d, 13)
            }),
            Di: XJ(this, function(d) {
                return !!Gk(d, 3)
            }),
            Lf: XJ(this, function(d) {
                return ou(d, 49)
            }),
            Ai: XJ(this, function(d) {
                return _.Rg(d, Kv, 51)
            }),
            ei: XJ(this, function(d) {
                return ou(d, 61)
            }),
            Da: V(this),
            ih: XJ(this, function(d) {
                return _.Rg(d, Sv, 58)
            }),
            Mj: XJ(this, function(d) {
                var e, f;
                return null != (f = null == (e = _.Rg(d, Jv, 56)) ? void 0 : ou(e, 1)) ? f : null
            }),
            kd: XJ(this, function(d) {
                return Oe(d, ov, 62)
            }),
            Mi: XJ(this, function(d) {
                return Yc(d, 63, Cc)
            }),
            Ph: XJ(this, function(d) {
                return !!Gk(d, 64)
            })
        };
        this.m = W(this, b)
    };
    _.S(YJ, Z);
    var XJ = function(a, b) {
        var c = V(a);
        a.A.push({
            C: c,
            gi: b
        });
        return c
    };
    YJ.prototype.j = function() {
        for (var a = _.y(this.A), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.gi,
                d = void 0;
            b.C.Ba(null != (d = c(this.m.value)) ? d : null)
        }
        0 === this.Ta.kind ? this.qc.Da.H(this.Ta) : this.qc.Da.H({
            kind: 0,
            ob: _.bh(this.m.value, 4) || ""
        });
        this.C.H(this.qc)
    };
    var ZJ = function(a, b, c, d, e) {
        Z.call(this, a, 803);
        this.m = b;
        this.slotId = c;
        this.ua = d;
        this.ca = e;
        this.C = V(this)
    };
    _.S(ZJ, Z);
    ZJ.prototype.j = function() {
        var a = JSON.parse(this.m),
            b = yl(a, hs);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.m);
        a = Kd(Tv, a);
        b = _.y(Yc(a, 27, xc));
        for (var c = b.next(); !c.done; c = b.next()) c = c.value, _.lf(mf).j(c);
        uk(4, this.context, this.ua, this.ca);
        cp(this.slotId, KD, 800, a);
        this.C.H(a)
    };
    var $J = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.O = c;
        this.m = W(this, d)
    };
    _.S($J, Z);
    $J.prototype.j = function() {
        var a = this;
        Gk(this.m.value, 11) && (_.WD(this.O, this.slotId), TD(this.O, this.slotId, function() {
            _.XD(a.O, a.slotId)
        }))
    };
    var aK = function(a, b, c, d) {
        ti.call(this);
        this.context = a;
        this.slotId = b;
        a = d.O;
        var e = d.ca;
        b = d.Na;
        var f = d.ua;
        d = d.Ta;
        c = new ZJ(this.context, c, this.slotId, f, e);
        K(this, c);
        e = new gH(this.context, e, f, c.C);
        K(this, e);
        b = new kH(this.context, this.slotId, b, c.C);
        K(this, b);
        a = new $J(this.context, this.slotId, a, c.C);
        K(this, a);
        a = new YJ(this.context, c.C, d);
        K(this, a);
        d = a.qc;
        this.j = {
            kc: d.Fi,
            Pe: d.tb,
            Xa: d.ih,
            qc: a.C
        }
    };
    _.S(aK, ti);
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var bK = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        cK = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = bK[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var dK = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B, E, N, Q, P, Y, ja, xa) {
        Z.call(this, a, 973);
        this.za = b;
        this.M = c;
        this.I = d;
        this.da = e;
        this.X = f;
        this.O = g;
        this.ua = h;
        this.ka = k;
        this.W = l;
        this.T = m;
        this.ld = n;
        this.sa = p;
        this.Hb = r;
        this.isSecureContext = u;
        this.ub = w;
        this.Na = A;
        this.G = F;
        this.Z = B;
        this.Ga = P;
        this.m = Y;
        this.aa = ja;
        this.Ca = xa;
        this.D = [];
        this.A = X(this, E);
        this.ia = W(this, N);
        this.La = W(this, Q);
        this.m && zB(this, this.m.Sh)
    };
    _.S(dK, Z);
    dK.prototype.j = function() {
        var a = this,
            b = new ti;
        _.O(this, b);
        var c = this.ia.value,
            d = ar(this.X.ba);
        this.A.value && this.Ca.H(this.A.value);
        var e = new gI(this.context, this.Z);
        K(b, e);
        if (_.G(Qx)) {
            var f = fn(this.context, _.Rg(this.X.ba, cq, 5), this.O, this.I, e.C);
            e = f.Ni;
            f = f.cf;
            e && _.O(b, e)
        } else e = new en(this.context, this.I, this.O, _.Rg(this.X.ba, cq, 5), void 0, e.C), K(b, e), f = e.C;
        var g = new LJ(this.context, this.I, this.Z, this.X, this.G, f);
        K(b, g);
        var h = !!_.D(this.X.ba, 6);
        f = new FJ(this.context, this.I, h, this.X, this.M, this.G, c);
        K(b, f);
        var k = new fG(this.context, d, c);
        K(b, k);
        var l = this.aa,
            m = l.Yi,
            n = l.fj;
        e = l.ne;
        l = l.Cj;
        var p = np(this.context, l, this.X.Y, c, this.A.value, f.m, k.C);
        if (p) {
            var r = p.Ej;
            p = p.Dj;
            var u = r.tf;
            r = r.Ze;
            _.O(b, p)
        }
        if (l = Co(this.context, l, this.G.navigator, k.C)) {
            var w = l.jh;
            l = l.Fj;
            var A = w.Mg;
            w = w.tg;
            l && _.O(b, l)
        }
        l = new AI(this.context, this.G);
        K(b, l);
        var F, B = null != (F = this.m) ? F : {},
            E = B.hc;
        p = B.ie;
        var N = B.Fb,
            Q = B.Oc,
            P = B.Pd,
            Y = B.ri;
        F = B.te;
        B = (null != E ? E : {}).xb;
        m = new fI(this.context, m.Zi);
        K(b, m);
        if (E = vm(this.context, this.M, this.X.Y, this.Hb, f.m, E, N)) {
            var ja = E.Kh;
            _.O(this, E.Ma)
        }
        if (r = Yn(this.context, n, r)) {
            var xa = r.ge;
            _.O(this, r.Ma)
        }
        if (r = yo(this.context, this.A.value, e, k.C)) {
            var ia = r.Aj;
            _.O(this, r.Ma);
            this.D.push(ia.oe.promise)
        }
        r = window.isSecureContext && _.G(sy) ? "wbn" : "ldjh";
        var na = ++this.O.J;
        k = "wbn" === r ? cK().toLowerCase() : void 0;
        n = this.ld;
        var ta;
        ja = new KJ(this.context, h, this.O, this.ua, this.X, r, n.Kb, n.Cc, n.Bc, this.La.value, k, _.lf(Dg), c, this.isSecureContext, this.ub, this.G, m.C, l.C, f.m, null == (ta = ja) ? void 0 : ta.Hf, ia, e, g.C, this.Ga, null == p ? void 0 : p.jf, B, N, Q, P, Y, xa, A);
        K(b, ja);
        xa = new WJ(this.context, this.X, _.lf(Dg), ja.m, f.m);
        K(b, xa);
        d = new GJ(this.context, d, c);
        K(b, d);
        ta = Bg(this.context, 646, function(Oa, va, Ua, Pa, rc, Hd, nh) {
            var $b = function() {
                return void eK(a, rc, Oa, va, Ua, Pa, Hd, nh)
            };
            Oa && _.G(Fx) ? setTimeout(Bg(a.context, 646, $b), 0) : $b()
        });
        g = Bg(this.context, 647, function(Oa, va, Ua) {
            var Pa = function() {
                return void fK(a, na, Ua, va, Oa)
            };
            _.G(Fx) ? setTimeout(Bg(a.context, 646, Pa), 0) : Pa()
        });
        "ldjh" === r ? (h = gK(this, 289, "strm_err"), _.G(Mx) && window.fetch && window.TextDecoderStream || _.G(Nx) && Lw(window.fetch) && Lw(window.TextDecoderStream) ? (u = new SJ(this.context, ta, h, g, c, f.m, u, A, ja.m, xa.C, d.C, ia, w), K(b, u), u = u.C) : (u = new QJ(this.context, ta, h, g, c, f.m, u, ja.m, xa.C, d.C, ia), K(b, u), u = u.C)) : (A = new ZI(this.context, ta, gK(this, 1042, "Unknown web bundle error."), g, r, k, c, this.Z, f.m, u, ja.m, ja.W, xa.C, d.C), $p(b, A), u = new jp, rB(u, Di(A).then(function() {})));
        A = new HJ(this.context, na, f.m, u, F, this.Hb);
        K(b, A);
        ia = new DJ(this.context, ja.A, ja.m);
        K(b, ia);
        ia = new JJ(this.context, this.T.ta, this.X, ia.C);
        K(b, ia);
        ia = new pI(this.context, this.ka, this.G, ia.C);
        K(b, ia);
        ia = new WH(this.context, this.X, this.W, f.m, ia.C);
        K(b, ia);
        f = new VG(this.context, this.O, this.X, this.Z, f.m, ia.C);
        K(b, f);
        ia = new zI(this.context, _.Lg(this.G), this.G, c, u);
        K(b, ia);
        1 === na && (c = new UG(this.context, this.G, c, e, u), K(b, c), this.D.push(c.C.promise));
        this.D.push(A.C.promise, f.C.promise, ia.C.promise);
        Di(b)
    };
    var eK = function(a, b, c, d, e, f, g, h) {
            var k, l, m;
            return _.wb(function(n) {
                k = f[c];
                if (!k) return Fg(a.context, 646, Error("missing slot")), n.return();
                0 === c && (l = vl(a.X.Y[k.getDomId()], 20), bp(_.lf(Dg), "4", l));
                return xb(n, hK(a, k, d, e, b, null == (m = g) ? void 0 : m[k.getId()], h), 0)
            })
        },
        fK = function(a, b, c, d, e) {
            var f, g, h;
            return _.wb(function(k) {
                if (1 == k.j) {
                    var l = a.context,
                        m = e + 1,
                        n = d.length;
                    if (l.nd) {
                        var p = l.Lb;
                        l = wg(l);
                        var r = new px;
                        r = _.rd(r, 3, b);
                        m = _.ld(r, 1, m, 0);
                        n = _.ld(m, 2, n, 0);
                        n = _.yg(l, 8, zg, n);
                        ue(p, n)
                    }
                    f = e + 1
                }
                if (3 != k.j) {
                    if (!(f < d.length)) return xb(k, iK(a), 0);
                    if (!d[f]) {
                        k.j = 3;
                        return
                    }
                    p = new Tv;
                    p = pi(p, 8, !0);
                    g = Le(p);
                    h = '{"empty":' + g + "}";
                    return xb(k, eK(a, c, f, h, {
                        kind: 0,
                        ob: ""
                    }, d), 3)
                }++f;
                k.j = 2
            })
        },
        hK = function(a, b, c, d, e, f, g) {
            var h, k, l, m, n, p, r, u, w, A, F;
            return _.wb(function(B) {
                if (1 == B.j) return h = {
                    ca: e,
                    Na: a.Na,
                    O: a.O,
                    ua: a.ua,
                    Ta: d
                }, k = new aK(a.context, b, c, h), xb(B, Di(k), 2);
                l = B.o;
                m = l.kc;
                n = l.Pe;
                p = l.Xa;
                r = l.qc;
                xm(a.context, null == (u = a.m) ? void 0 : u.hc, r.Mj, r.se, r.tb);
                if (b.N) return B.return();
                (w = !!p) && Qh("gpt_td_init", function(E) {
                    Wh(E, a.context);
                    J(E, "noFill", m ? "1" : "0");
                    J(E, "publisher_tag", "gpt");
                    var N = _.Rg(p, Qv, 5);
                    N && (J(E, "winner_qid", N.getEscapedQemQueryId()), J(E, "xfpQid", _.R(N, 6)))
                }, 1);
                A = on(a.X.Y[b.getDomId()]);
                (F = Lm("google_norender") || 5 === A && _.G(ay)) || m && !w ? gp(b, a.O, a.X, n) : AJ(a.sa, a.za, a.M, b, m || F, w, a.O, a.X, a.Na, r, e, f, g, a.T.ta, a.W, a.aa);
                k.wa();
                B.j = 0
            })
        },
        gK = function(a, b, c) {
            return Bg(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                Fg(a.context, b, d);
                iK(a)
            })
        },
        iK = function(a) {
            return _.wb(function(b) {
                if (1 == b.j) {
                    var c = a.O,
                        d = a.da,
                        e = c.o.get(d) - 1;
                    0 === e ? c.o.delete(d) : c.o.set(d, e);
                    return e ? b.return() : xb(b, _.x.Promise.all(a.D), 2)
                }
                cp(a.T.rg, OD, 965, a.da);
                b.j = 0
            })
        };
    var jK = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B, E, N, Q, P, Y) {
        Z.call(this, a, 885);
        this.ka = b;
        this.D = c;
        this.X = d;
        this.O = e;
        this.ua = f;
        this.ld = g;
        this.da = h;
        this.T = k;
        this.m = l;
        this.I = m;
        this.ia = n;
        this.isSecureContext = p;
        this.M = r;
        this.aa = u;
        this.ub = w;
        this.Na = A;
        this.G = F;
        this.Z = B;
        this.A = Q;
        this.W = P;
        this.sa = Y;
        this.za = W(this, E);
        zB(this, N)
    };
    _.S(jK, Z);
    jK.prototype.j = function() {
        var a = this.za.value;
        if (a.length) {
            var b = this.O,
                c = this.m,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.y(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0;
                b = c.Hb;
                d = c.ga;
                c = new ti;
                _.O(this, c);
                var f = Im(this.context, this.aa, null == (e = this.A) ? void 0 : e.Ti);
                e = f.lc;
                var g = f.pg;
                _.O(c, f.Ma);
                e = ql(this.context, this.D, this.O, this.G, e, g, ar(this.X.ba));
                f = e.Za;
                _.O(c, e.Ma);
                e = new jI(this.context, this.G, f);
                K(c, e);
                e = new fH(this.context, this.G, f);
                K(c, e);
                e = new lH(this.context, f);
                K(c, e);
                g = new Xp(this.context, this.G, f);
                K(c, g);
                var h = new BJ(this.context, this.ua, this.M, g.C, f);
                K(c, h);
                b = new dK(this.context, this.ka, this.D, d, this.m, this.X, this.O, this.ua, this.da, this.T, this.I, this.ld, this.ia, b, this.isSecureContext, this.ub, this.Na, this.G, this.Z, g.C, f, h.D, e.m, this.A, this.W, this.sa);
                K(c, b);
                Di(c)
            }
        } else cp(this.I.rg, OD, 965, this.m)
    };
    var kK = new _.x.Map,
        lK = function(a, b, c, d) {
            d = void 0 === d ? kK : d;
            Z.call(this, a, 834);
            this.D = b;
            this.ga = c;
            this.m = d;
            this.A = V(this);
            this.A.Oa(_.x.Promise.all(this.ga.map(this.I, this)).then(function(e) {
                return e.filter(function(f) {
                    return null != f && !f.N
                })
            }))
        };
    _.S(lK, Z);
    lK.prototype.j = function() {};
    lK.prototype.I = function(a) {
        var b = this,
            c, d;
        return _.wb(function(e) {
            if (1 == e.j) {
                if (a.N) return e.return();
                b.m.has(a) || (b.m.set(a, br(a)), _.zn(a, function() {
                    return void b.m.delete(a)
                }));
                c = b.m.get(a);
                return xb(e, c(), 2)
            }
            d = e.o;
            if (b.N) return e.return();
            if (d) return e.return(a);
            M(b.D, dF(a.getAdUnitPath()));
            return e.return()
        })
    };
    var mK = function(a, b, c, d, e) {
        Z.call(this, a, 847);
        this.O = b;
        this.Va = c;
        this.A = d;
        this.m = V(this);
        this.D = W(this, e)
    };
    _.S(mK, Z);
    mK.prototype.j = function() {
        var a = this.D.value;
        if (a.length) {
            for (var b = _.y(a), c = b.next(); !c.done; c = b.next()) $D(this.O, c.value);
            this.A ? this.m.H([]) : this.Va ? (b = rg(a[0].getAdUnitPath()), a = nK(a, b), this.m.H(a)) : (a = a.map(function(d) {
                return {
                    Hb: rg(d.getAdUnitPath()),
                    ga: [d]
                }
            }), this.m.H(a))
        } else this.m.H([])
    };
    var nK = function(a, b) {
        var c = [];
        a = ya(a, function(f) {
            return rg(f.getAdUnitPath())
        });
        a = _.y(_.v(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.y(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                Hb: d,
                ga: e
            }) : c.push({
                Hb: d,
                ga: e
            })
        }
        return c
    };
    var oK = function(a, b, c) {
        Z.call(this, a, 845);
        this.Y = b;
        this.m = V(this);
        this.A = V(this);
        this.D = W(this, c)
    };
    _.S(oK, Z);
    oK.prototype.j = function() {
        var a = this,
            b = function(d) {
                return !!$g(a.Y[d.getDomId()]).length
            },
            c = this.D.value;
        this.m.H(c.filter(b));
        this.A.H(c.filter(is(b)))
    };
    var pK = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w, A, F, B) {
        _.U.call(this);
        var E = this;
        this.context = a;
        this.T = b;
        this.B = c;
        this.O = d;
        this.ua = e;
        this.ta = f;
        this.I = g;
        this.A = h;
        this.M = k;
        this.isSecureContext = l;
        this.J = m;
        this.D = n;
        this.ub = p;
        this.Na = r;
        this.Z = u;
        this.G = w;
        this.m = A;
        this.V = F;
        this.W = B;
        this.j = new _.x.Map;
        this.o = new FD(a);
        _.O(this, this.o);
        this.o.listen(OD, function(N) {
            N = N.detail;
            var Q = E.j.get(N);
            Q && (E.j.delete(N), Q.wa())
        })
    };
    _.S(pK, _.U);
    var qK = function(a, b, c, d) {
        var e = ++a.O.m;
        a.j.has(e);
        var f = new ti;
        a.j.set(e, f);
        b = new lK(a.context, a.B, b);
        K(f, b);
        var g = new oK(a.context, d.Y, b.A);
        K(f, g);
        b = new mK(a.context, a.O, !!_.D(d.ba, 6), Lm("google_nofetch"), g.m);
        K(f, b);
        g = new WG(a.context, a.O, d, document, g.A);
        K(f, g);
        a = new jK(a.context, a.T, a.B, d, a.O, a.ua, c, a.I, a.A, e, {
            rg: a.o,
            ta: a.ta
        }, a.M, a.isSecureContext, a.J, a.D, a.ub, a.Na, a.G, a.Z, b.m, g.m, a.m, a.V, a.W);
        K(f, a);
        Di(f)
    };
    var rK = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, u, w) {
        aJ.call(this, a, c, h);
        this.context = a;
        this.O = d;
        this.J = new _.x.Set;
        this.V = {};
        this.M = new zJ(a, d);
        this.T = new pK(a, b, c, d, new _.tA(window), this.m, m, e, this.M, f, g, k, l, n, document, window, r, u, w);
        _.O(this, this.T)
    };
    _.S(rK, aJ);
    rK.prototype.getName = function() {
        return "publisher_ads"
    };
    rK.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.ha(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        Ap(this);
        var h = Nk(c, this.context, this.j, a, b, f),
            k = h.slotId;
        h = h.Wa;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            tp(this, null != (l = g) ? l : k.getDomId(), c)
        } else M(this.j, Fj("PubAdsService.display", [a, b, d]))
    };
    var tp = function(a, b, c) {
            var d = sK(b, c);
            c = d.slotId;
            var e = d.Yh;
            d = d.Zh;
            if (c) {
                if (b = Fh(), (d = fC(b, c.getDomId())) && !_.D(d, 19))
                    if (e && b.F.set(c, e), (e = vh(c)) || (e = on(d), e = 0 !== e && 1 !== e), e) {
                        if (pi(d, 19, !0), e = rh(b.j, b.o), a.o) {
                            Ap(a);
                            a.o && VD(a.O, c);
                            a.j.info(yE());
                            b = e.ba;
                            d = e.Y;
                            var f = _.D(b, 6);
                            if (f || !a.O.Rb(c)) f && (f = vh(c)) && cp(c, JD, 778, f), _.D(b, 4) && (d = d[c.getDomId()], Am(d, b) && !a.O.Rb(c) && Bm(c, document, d, b)), tK(a, e, c)
                        }
                    } else M(a.j, nE(String(_.bh(d, 1)), String(_.bh(d, 2))), c)
            } else d ? a.j.error(oE(d)) : a.j.error(Fj("googletag.display", [String(b)]))
        },
        FF = function(a, b, c) {
            var d = void 0 === d ? document : d;
            var e;
            null != (e = c.Y[b.getDomId()]) && pi(e, 19, !0);
            e = {
                id: dw(b.getDomId())
            };
            lb(d, Ff(e));
            vh(b, d) ? (Ap(a), VD(a.O, b), tK(a, c, b)) : Qh("gpt_pb_write", function(f) {
                Wh(f, a.context)
            })
        };
    rK.prototype.slotAdded = function(a, b) {
        var c = this;
        _.D(b, 17) || this.o && VD(this.O, a);
        cp(this.m, MD, 724, {
            Gf: a.getDomId(),
            Y: b
        });
        a.listen(fp, function(d) {
            var e = d.detail,
                f = e.size;
            d = new AH(a, "publisher_ads");
            e.isEmpty && (d.isEmpty = !0);
            e = a.j.getResponseInformation();
            f && e && (f = d.setSize([f.width, f.height]), f.sourceAgnosticCreativeId = e.sourceAgnosticCreativeId, f.sourceAgnosticLineItemId = e.sourceAgnosticLineItemId, f.isBackfill = e.isBackfill, f.creativeId = e.creativeId, f.lineItemId = e.lineItemId, f.creativeTemplateId = e.creativeTemplateId, f.advertiserId = e.advertiserId, f.campaignId = e.campaignId, f.yieldGroupIds = e.yieldGroupIds, f.companyIds = e.companyIds);
            cp(c.m, "slotRenderEnded", 708, d)
        });
        a.listen(KD, function() {
            cp(c.m, "slotResponseReceived", 709, new GH(a, c.getName()))
        });
        4 === on(b) && uK(this, "rewardedSlotClosed", a, b);
        7 === on(b) && uK(this, "gameManualInterstitialSlotClosed", a, b);
        aJ.prototype.slotAdded.call(this, a, b)
    };
    var uK = function(a, b, c, d) {
            _.zn(c, a.m.listen(b, function(e) {
                c.j === e.detail.slot && (e = {}, vK(a, [c], Fh().j, (e[c.getDomId()] = d, e), a.O))
            }))
        },
        tK = function(a, b, c) {
            var d = wK(a, b, c);
            xK(a, d, b, {
                Kb: 1
            });
            b = c.getAdUnitPath();
            if (c = a.V[b]) {
                c = _.y(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, xK(a, d.ga, d.X, d.ld);
                delete a.V[b]
            }
        },
        wK = function(a, b, c) {
            var d = b.ba;
            b = b.Y;
            if (_.D(d, 4)) return [];
            var e;
            return !_.D(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : _.D(e, 17)) ? (a.J.add(c), _.zn(c, function() {
                return void a.J.delete(c)
            }), [c]) : a.B.filter(function(f) {
                if (a.J.has(f)) return !1;
                a.J.add(f);
                _.zn(f, function() {
                    return void a.J.delete(f)
                });
                return !0
            })
        },
        xK = function(a, b, c, d) {
            a.j.info(FE());
            if (yK(a, b, d, c) && 1 !== d.Kb)
                for (b = _.y(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), cp(a.m, ND, 725, {
                    Gf: d,
                    Y: c.Y[d]
                })
        },
        yK = function(a, b, c, d) {
            b = b.filter(function(e) {
                var f = d.Y[e.getDomId()],
                    g = _.ep(a.O, e);
                !1 === g && M(a.j, uF(String(on(f)), e.getAdUnitPath()));
                if (!g) return !1;
                (_.C = [5, 4, 7], _.v(_.C, "includes")).call(_.C, on(f)) && _.WD(a.O, e);
                return !0
            });
            if (!b.length) return null;
            qK(a.T, b, c, d);
            return b
        };
    rK.prototype.refresh = function(a, b, c) {
        c = void 0 === c ? {
            Kb: 2
        } : c;
        b = zK(this, b);
        if (!b.length) return !1;
        AK(this, a, b, c);
        return !0
    };
    var zK = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.N) return !0;
                M(a.j, IE(String(d)));
                return !1
            })
        },
        AK = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.o) {
                var h = _.y(c);
                e = h.next();
                for (f = {}; !e.done; f = {
                        Jc: f.Jc
                    }, e = h.next()) f.Jc = e.value, a.J.add(f.Jc), _.zn(f.Jc, function(k) {
                    return function() {
                        return void a.J.delete(k.Jc)
                    }
                }(f));
                xK(a, c, b, d)
            } else c.length && _.D(b.ba, 6) ? (M(a.j, EE(g), e), e = e.getAdUnitPath(), f = null != (h = a.V[e]) ? h : [], f.push({
                ga: c,
                X: b,
                ld: d
            }), a.V[e] = f) : M(a.j, CE(g), e)
        };
    rK.prototype.I = function() {
        var a = Fh().j;
        if (_.D(a, 6))
            for (var b = _.y(this.B), c = b.next(); !c.done; c = b.next()) this.o && VD(this.O, c.value);
        MF(this, a);
        a = Lj();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    rK.prototype.destroySlots = function(a) {
        a = aJ.prototype.destroySlots.call(this, a);
        if (a.length && this.o) {
            var b = Fh();
            BK(this, a, b.j, b.o)
        }
        return a
    };
    var OF = function(a, b, c, d) {
            if (!a.o) return M(a.j, DE(), d[0]), !1;
            var e = zK(a, d);
            if (!e.length) return M(a.j, Fj("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.j.info(GE());
            BK(a, e, b, c);
            return !0
        },
        BK = function(a, b, c, d) {
            for (var e = _.y(b), f = e.next(); !f.done; f = e.next()) SD(a.O, f.value);
            vK(a, b, c, d, a.O)
        };
    rK.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.lf(mf).j(a)
    };
    var vK = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.y(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                bE(a.M.O, g);
                var h = d[g.getDomId()];
                Am(h, c) && Bm(g, f.document, h, c);
                $D(e, g)
            }
        },
        NF = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) M(a.j, Fj("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = pi(d, 21, !0);
                b = Ll(e, 22, b);
                Ll(b, 23, c);
                MF(a, d)
            }
        },
        PF = function(a, b) {
            if (!a.o) return null;
            var c, d;
            return {
                vid: null != (c = _.R(b, 22)) ? c : "",
                cmsid: null != (d = _.R(b, 23)) ? d : ""
            }
        },
        MF = function(a, b) {
            _.D(b, 21) && a.o && (a = Vw(), _.I(b, 29, a))
        },
        sK = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = bG(b, c);
            else if (_.ha(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = bG(b, c)
            } else b = (_.C = [].concat(_.se(b.ga)), _.v(_.C, "find")).call(_.C, function(e) {
                return e.j === a
            });
            return {
                slotId: b,
                Yh: d,
                Zh: c
            }
        };
    var CK = _.Ar(["https://securepubads.g.doubleclick.net/pagead/js/rum_debug.js"]),
        DK = _.Ar(["https://securepubads.g.doubleclick.net/pagead/js/rum.js"]);
    var EK = Br(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        FK = _.js(function() {
            Rw("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        HK = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.v(String, "raw").call(String, EK) : d;
            this.O = a;
            this.o = d;
            this.j = new _.x.Map;
            this.ga = new _.x.Set;
            b.o = function(e) {
                return GK(c, e)
            }
        };
    HK.prototype.defineSlot = function(a, b, c, d, e) {
        a = Nk(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.j;
        a.Kd || b.error(Fj("googletag.defineSlot", [c, d, e]));
        return null
    };
    var Nk = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            Eb: f,
            Gg: void 0 === g ? !1 : g
        }) : {}
    };
    HK.prototype.add = function(a, b, c, d, e) {
        var f = this,
            g = e.Eb,
            h = void 0 === e.format ? 0 : e.format,
            k = void 0 === e.Gg ? !1 : e.Gg;
        e = void 0 === e.hb ? !1 : e.hb;
        try {
            var l = new RegExp(this.o, "u");
            if (l.test("/1") && !l.test(c)) return b.error(qE(c)), {
                Kd: !0
            }
        } catch (n) {}
        if (l = vn(h, e)) return hn(b, l, h, c), {};
        k && FK();
        h = this.j.get(c) || Number(k);
        b = IK(this, a, b, c, h, d, g || "gpt_unit_" + c + "_" + h);
        a = b.Wa;
        var m = b.slotId;
        b = b.Kd;
        if (!m) return {
            Kd: b
        };
        this.j.set(c, h + 1);
        this.ga.add(m);
        _.zn(m, function() {
            return void f.ga.delete(m)
        });
        TB(c);
        return {
            slotId: m,
            Wa: a
        }
    };
    var bG = function(a, b) {
            a = _.y(a.ga);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        rp = function(a) {
            a = _.y(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.wa()
        },
        IK = function(a, b, c, d, e, f, g) {
            var h = bG(a, g);
            if (h) return c.error(pE(g, d, h.getAdUnitPath())), {
                Kd: !0
            };
            var k = new RF;
            SF(Ll(k, 1, d), g);
            TF(k, Zk(f));
            eC(k);
            var l = new Fe(b, d, e, g);
            HF(l, il(b, c, l));
            _.zn(l, function() {
                var m = Fh(),
                    n = l.getDomId();
                delete m.o[n];
                m.F.delete(l);
                m = l.getAdUnitPath();
                m = rg(m);
                var p;
                n = (null != (p = Pg.get(m)) ? p : 0) - 1;
                0 >= n ? Pg.delete(m) : Pg.set(m, n);
                c.info(PE(l.toString()), l);
                (p = yj.get(l)) && zj.delete(p);
                yj.delete(l)
            });
            c.info(dE(l.toString()), l);
            l.listen(LD, function(m) {
                m = m.detail.qj;
                c.info(eE(l.getAdUnitPath()), l);
                lA(_.lf(Dg), "7", 9, ZD(a.O, l), 0, m)
            });
            l.listen(KD, function(m) {
                var n = m.detail;
                c.info(fE(l.getAdUnitPath()), l);
                var p;
                m = _.lf(Dg);
                var r = vl(k, 20);
                n = null != (p = n.getEscapedQemQueryId()) ? p : "";
                m.j && (_.t.google_timing_params = _.t.google_timing_params || {}, _.t.google_timing_params["qqid." + r] = n)
            });
            l.listen(dp, function() {
                return void c.info(gE(l.getAdUnitPath()), l)
            });
            l.listen(fp, function() {
                return void c.info(hE(l.getAdUnitPath()), l)
            });
            return {
                Wa: k,
                slotId: l
            }
        },
        GK = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.se(a.ga)).some(function(d) {
                return c.test(rg(d.getAdUnitPath()))
            })
        };
    var kr = "1";
    (function(a, b) {
        var c = null != a ? a : {
            pvsid: _.Lg(window),
            nb: lr(),
            wb: "m202307100101",
            Lb: new pr(0),
            Vg: !0,
            jg: 1
        };
        try {
            var d = Lj();
            ce(!_.lf(dh).j);
            _.v(Object, "assign").call(Object, eh, d._vars_);
            d._vars_ = eh;
            if (d.evalScripts) d.evalScripts();
            else {
                DC();
                try {
                    zf()
                } catch (va) {
                    Fg(c, 408, va)
                }
                Lp();
                var e = new lG;
                try {
                    uf(e.J), rk(13, c), rk(3, c)
                } catch (va) {
                    Fg(c, 408, va)
                }
                var f = nr(c, e),
                    g = null != a ? a : qr(f, c),
                    h = null != b ? b : new kG(g);
                Ag(g);
                Qh("gpt_fifwin", function(va) {
                    Wh(va, g)
                }, d.fifWin ? .01 : 0);
                var k = new RD,
                    l = new HK(k, e),
                    m = new hJ(g),
                    n = _.fh(260),
                    p = new qJ(g, l, Fh(), h, k, n, e, m),
                    r = Fw(),
                    u = Tp(g),
                    w = new FD(g),
                    A = new FD(g),
                    F = new FD(g),
                    B = _.fh(150),
                    E;
                n && (E = rJ(p, w, B));
                var N = _.fh(221),
                    Q = new kI,
                    P = new hH,
                    Y, ja, xa, ia = null != (xa = null == (Y = E) ? void 0 : null == (ja = Y.ie) ? void 0 : ja.jb) ? xa : new tm,
                    na = new rK(g, l, h, k, m, r, e, w, n, N, Q, P, B, E, u, ia);
                _.G(By) && new cG(g, w, k, l);
                var ta = Fh().j;
                Jp(g, h, na, ta, l, A, F, e, P, ia);
                var Oa = Bg(g, 77, function() {
                    var va = d.cmd;
                    if (!va || Array.isArray(va)) {
                        var Ua = new dG(h);
                        d.cmd = Cj(g, Ua);
                        null != va && va.length && Ua.push.apply(Ua, va)
                    }
                });
                d.fifWin && "complete" !== document.readyState ? _.ub(window, "load", function() {
                    return window.setTimeout(Oa, 0)
                }) : Oa();
                _.G(Jx) && window.setTimeout(function() {
                    for (var va = window.document.scripts, Ua = 0, Pa = 0, rc = 0; rc < va.length; rc++) va[rc].src.match("securepubads.g.doubleclick.net/tag/js/gpt.js") ? Ua++ : va[rc].src.match("www.googletagservices.com/tag/js/gpt.js") && Pa++;
                    1 < Ua && 0 === Pa || 1 < Pa && 0 === Ua ? M(h, sF(), null) : 0 < Pa && 0 < Ua && h.error(tF(), null)
                }, 1E3);
                op();
                if (_.G(By) || _.lf(Dg).j) jr(), _.Tj(document, _.G(Dy) ? _.ke(CK) : _.ke(DK));
                so(g, h);
                Oj(g)
            }
        } catch (va) {
            Fg(c, 106, va)
        }
    })();
    var LK = function(a, b) {
        var c = this;
        this.F = a;
        this.j = !1;
        this.B = b;
        this.o = this.B.Aa(264, function(d) {
            c.j && (JK || (d = Date.now()), c.F(d), JK ? KK.call(_.t, c.o) : _.t.setTimeout(c.o, 17))
        })
    };
    LK.prototype.start = function() {
        this.j || (this.j = !0, JK ? KK.call(_.t, this.o) : this.o(0))
    };
    var KK = _.t.requestAnimationFrame || _.t.webkitRequestAnimationFrame,
        JK = !!KK && !/'iPhone'/.test(_.t.navigator.userAgent);
    var MK = function(a, b, c, d) {
        this.j = a;
        this.m = b;
        this.pa = c;
        this.progress = 0;
        this.o = null;
        this.D = !1;
        this.F = [];
        this.B = null;
        this.N = new LK((0, _.$r)(this.I, this), d)
    };
    MK.prototype.I = function(a) {
        if (this.D) this.N.j = !1;
        else {
            null === this.o && (this.o = a);
            this.progress = (a - this.o) / this.pa;
            1 <= this.progress && (this.progress = 1);
            a = this.B ? this.B(this.progress) : this.progress;
            this.F = [];
            for (var b = 0; b < this.j.length; b++) this.F.push((this.m[b] - this.j[b]) * a + this.j[b]);
            this.V();
            1 == this.progress && (this.N.j = !1, this.J())
        }
    };
    MK.prototype.J = function() {};
    MK.prototype.V = function() {};
    _.NK = function(a) {
        a.D = !1;
        a.N.start()
    };
    MK.prototype.reset = function(a, b, c) {
        this.o = null;
        this.j = a;
        this.m = b;
        this.pa = c;
        this.progress = 0
    };
    _.OK = function(a) {
        return a * a * a
    };
    _.PK = function(a) {
        a = 1 - a;
        return 1 - a * a * a
    };
    _.QK = function(a, b, c, d, e, f, g, h) {
        MK.call(this, [b], [c], d, f);
        this.M = a;
        this.T = e;
        this.A = g ? g : null;
        this.B = h || null
    };
    _.S(_.QK, MK);
    _.QK.prototype.V = function() {
        var a = {};
        a[this.T] = this.F[0] + "px";
        _.ex(this.M, a)
    };
    _.QK.prototype.J = function() {
        this.A && this.A()
    };
}).call(this, {});