/**
 * @id5io/id5-api.js
 * @version v1.0.36
 * @link https://id5.io/
 * @license Apache-2.0
 */
! function(n) {
    var r = {};

    function i(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return n[e].call(t.exports, t, t.exports, i), t.l = !0, t.exports
    }
    i.m = n, i.c = r, i.d = function(e, t, n) {
        i.o(e, t) || Object.defineProperty(e, t, {
            configurable: !1,
            enumerable: !0,
            get: n
        })
    }, i.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return i.d(t, "a", t), t
    }, i.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, i.p = "", i(i.s = 10)
}([function(e, t, n) {
    "use strict";
    t.c = function(e, t) {
        var n = !0;
        return L(e, function(e) {
            return n = n && t(e)
        }), n
    }, t.v = j, t.w = S, t.u = C, t.z = function(e) {
        I = !!e
    }, t.p = T, t.q = function() {
        return _
    }, n.d(t, "a", function() {
        return D
    }), t.j = E, t.o = A, t.t = N, t.k = R, t.r = function(e) {
        return E(e, y)
    }, t.s = function(e) {
        return E(e, b)
    }, t.l = function(e) {
        return E(e, g)
    }, t.m = function(e) {
        return void 0 !== e
    }, t.n = U, t.i = function(e) {
        e = window.document.cookie.match("(^|;)\\s*" + e + "\\s*=\\s*([^;]*)\\s*(;|$)");
        return e ? decodeURIComponent(e[2]) : null
    }, t.y = function(e, t, n) {
        document.cookie = "".concat(e, "=").concat(encodeURIComponent(t)).concat("" !== n ? "; expires=".concat(n) : "", "; path=/")
    }, t.b = function(e, t, n) {
        var r, i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
        try {
            var o = i.method || (n ? "POST" : "GET");
            document.createElement("a").href = e;
            var a, c = "object" === u(t) && null !== t ? t : {
                success: function() {
                    j("ajax", "xhr success")
                },
                error: function(e) {
                    C("ajax", "xhr error", null, e)
                }
            };
            "function" == typeof t && (c.success = t), (r = new window.XMLHttpRequest).onreadystatechange = function() {
                var e;
                r.readyState === x && (200 <= (e = r.status) && e < 300 || 304 === e ? c.success(r.responseText, r) : c.error(r.statusText, r))
            }, r.ontimeout = function() {
                C("ajax", "xhr timeout after ", r.timeout, "ms")
            }, "GET" === o && n && (s((a = function(e, t) {
                var n = document.createElement("a");
                t && "noDecodeWholeURL" in t && t.noDecodeWholeURL ? n.href = e : n.href = decodeURIComponent(e);
                t = t && "decodeSearchAsString" in t && t.decodeSearchAsString;
                return {
                    href: n.href,
                    protocol: (n.protocol || "").replace(/:$/, ""),
                    hostname: n.hostname,
                    port: +n.port,
                    pathname: n.pathname.replace(/^(?!\/)/, "/"),
                    search: t ? n.search : function(e) {
                        return e ? e.replace(/^\?/, "").split("&").reduce(function(e, t) {
                            var n = t.split("="),
                                n = (t = 2, function(e) {
                                    if (Array.isArray(e)) return e
                                }(n = n) || function(e, t) {
                                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                    if (null != n) {
                                        var r, i, o, a, c = [],
                                            s = !0,
                                            u = !1;
                                        try {
                                            if (o = (n = n.call(e)).next, 0 === t) {
                                                if (Object(n) !== n) return;
                                                s = !1
                                            } else
                                                for (; !(s = (r = o.call(n)).done) && (c.push(r.value), c.length !== t); s = !0);
                                        } catch (e) {
                                            u = !0, i = e
                                        } finally {
                                            try {
                                                if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return
                                            } finally {
                                                if (u) throw i
                                            }
                                        }
                                        return c
                                    }
                                }(n, t) || function(e, t) {
                                    if (e) {
                                        if ("string" == typeof e) return l(e, t);
                                        var n = Object.prototype.toString.call(e).slice(8, -1);
                                        return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0
                                    }
                                }(n, t) || function() {
                                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                }()),
                                t = n[0],
                                n = n[1];
                            return /\[\]$/.test(t) ? (e[t = t.replace("[]", "")] = e[t] || [], e[t].push(n)) : e[t] = n || "", e
                        }, {}) : {}
                    }(n.search || ""),
                    hash: (n.hash || "").replace(/^#/, ""),
                    host: n.host || window.location.host
                }
            }(e, i)).search, n), e = function(e) {
                return (e.protocol || "http") + "://" + (e.host || e.hostname + (e.port ? ":".concat(e.port) : "")) + (e.pathname || "") + (e.search ? "?".concat(function(e) {
                    return Object.keys(e).map(function(t) {
                        return Array.isArray(e[t]) ? e[t].map(function(e) {
                            return "".concat(t, "[]=").concat(e)
                        }).join("&") : "".concat(t, "=").concat(e[t])
                    }).join("&")
                }(e.search || "")) : "") + (e.hash ? "#".concat(e.hash) : "")
            }(a)), r.open(o, e, !0), i.withCredentials && (r.withCredentials = !0), L(i.customHeaders, function(e, t) {
                r.setRequestHeader(t, e)
            }), i.preflight && r.setRequestHeader("X-Requested-With", "XMLHttpRequest"), r.setRequestHeader("Content-Type", i.contentType || "text/plain"), "POST" === o && n ? r.send(n) : r.send()
        } catch (e) {
            C("ajax", "xhr construction", e)
        }
    }, t.f = function(e, t, n) {
        "loading" !== document.readyState ? M(e, t, n) : document.addEventListener("DOMContentLoaded", function() {
            M(e, t, n)
        })
    }, t.d = function(e) {
        for (var t, n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0, r = function(e, t) {
                if (A(Math.imul)) return Math.imul(e, t);
                var n = (4194303 & e) * (t |= 0);
                return 4290772992 & e && (n += (4290772992 & e) * t | 0), 0 | n
            }, i = 3735928559 ^ n, o = 1103547991 ^ n, a = 0; a < e.length; a++) t = e.charCodeAt(a), i = r(i ^ t, 2654435761), o = r(o ^ t, 1597334677);
        return i = r(i ^ i >>> 16, 2246822507) ^ r(o ^ o >>> 13, 3266489909), (4294967296 * (2097151 & (o = r(o ^ o >>> 16, 2246822507) ^ r(i ^ i >>> 13, 3266489909))) + (i >>> 0)).toString()
    }, t.h = function(e) {
        var t = /[()-.:;=?_/]/g;
        R(e.brands) && (e.brands = F(e.brands, function(e) {
            return N(e.brand) && e.brand.search(t) < 0
        }));
        R(e.fullVersionList) && (e.fullVersionList = F(e.fullVersionList, function(e) {
            return N(e.brand) && e.brand.search(t) < 0
        }));
        return e
    }, t.g = function(e, t, n, r, i) {
        for (t = t.split ? t.split(".") : t, r = 0; r < t.length; r++) e = e ? e[t[r]] : i;
        return e === i ? n : e
    }, t.x = function(e) {
        var t = Object.keys(e),
            n = t.length,
            r = new Array(n);
        for (; n--;) r[n] = [t[n], e[t[n]]];
        return r
    }, t.e = function e(t, n) {
        var r = V(t) && V(n);
        if (!r) return t === n;
        var i = Object.keys(t);
        r = Object.keys(n);
        if (i.length !== r.length) return !1;
        for (var o = 0, a = i; o < a.length; o++) {
            var c = a[o];
            if (!e(t[c], n[c])) return !1
        }
        return !0
    };
    var r = n(6);

    function s() {
        return (s = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }

    function u(e) {
        return (u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function l(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, h(r.key), r)
        }
    }

    function c(e, t) {
        return (c = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function f(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = o(n);
            return function(e, t) {
                {
                    if (t && ("object" === u(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return d(e)
            }(this, r ? (e = o(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function d(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function o(e) {
        return (o = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function h(e) {
        e = function(e, t) {
            if ("object" !== u(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== u(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === u(e) ? e : String(e)
    }
    var a = "Array",
        p = "String",
        v = "Function",
        y = "Number",
        b = "Object",
        g = "Boolean",
        m = Object.prototype.toString,
        O = "TRUE" === P("id5_debug").toUpperCase(),
        _ = "TRACE" === P("id5_debug").toUpperCase(),
        w = Boolean(window.console),
        I = !1;

    function j(e) {
        for (var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
        k(console.info, e, "INFO", n)
    }

    function S(e) {
        for (var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
        k(console.warn, e, "WARNING", n)
    }

    function C(e) {
        for (var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
        k(console.error, e, "ERROR", n)
    }

    function k(e, t, n, r) {
        T() && w && e && e.apply(console, ["%cID5 - #".concat(t), "color: #fff; background: #1c307e; padding: 1px 4px; border-radius: 3px;", n].concat(r))
    }

    function T() {
        return O || _ || I
    }
    var D = function() {
        ! function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && c(e, t)
        }(a, r["b"]);
        var e, t, n, o = f(a);

        function a(e) {
            var t, n, r, i;
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, a), t = o.call(this), n = d(t), i = void 0, (r = h(r = "_invocationId")) in n ? Object.defineProperty(n, r, {
                value: i,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : n[r] = i, t._invocationId = e, t
        }
        return e = a, (t = [{
            key: "debug",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                j.apply(void 0, [this._invocationId].concat(t))
            }
        }, {
            key: "info",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                j.apply(void 0, [this._invocationId].concat(t))
            }
        }, {
            key: "warn",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                S.apply(void 0, [this._invocationId].concat(t))
            }
        }, {
            key: "error",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                C.apply(void 0, [this._invocationId].concat(t))
            }
        }]) && i(e.prototype, t), n && i(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), a
    }();

    function P(e) {
        e = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(window.location.search);
        return null === e ? "" : decodeURIComponent(e[1].replace(/\+/g, " "))
    }

    function E(e, t) {
        return m.call(e) === "[object " + t + "]"
    }

    function A(e) {
        return E(e, v)
    }

    function N(e) {
        return E(e, p)
    }

    function R(e) {
        return E(e, a)
    }

    function U(e) {
        if (!e) return !0;
        if (R(e) || N(e)) return !(0 < e.length);
        for (var t in e)
            if (hasOwnProperty.call(e, t)) return !1;
        return !0
    }

    function L(e, t) {
        if (!U(e)) {
            if (A(e.forEach)) return e.forEach(t, this);
            var n = 0,
                r = e.length;
            if (0 < r)
                for (; n < r; n++) t(e[n], n, e);
            else
                for (n in e) hasOwnProperty.call(e, n) && t.call(this, e[n], n)
        }
    }
    var x = 4;

    function M(e, t, n) {
        var r = new Image;
        r.src = e, A(t) && t(), A(n) && (r.complete ? n() : r.addEventListener("load", n))
    }

    function F(e, t) {
        var n = [];
        return L(e, function(e) {
            t(e) && n.push(e)
        }), n
    }
    var V = function(e) {
        return null != e && "object" === u(e)
    }
}, function(e, t) {
    e.exports = {
        STORAGE_CONFIG: {
            ID5: {
                name: "id5id",
                expiresDays: 90
            },
            LAST: {
                name: "id5id_last",
                expiresDays: 90
            },
            CONSENT_DATA: {
                name: "id5id_cached_consent_data",
                expiresDays: 30
            },
            PD: {
                name: "id5id_cached_pd",
                expiresDays: 30
            },
            SEGMENTS: {
                name: "id5id_cached_segments",
                expiresDays: 30
            },
            PRIVACY: {
                name: "id5id_privacy",
                expiresDays: 30
            },
            LIVE_INTENT: {
                name: "id5li",
                expiresDays: 90
            }
        },
        LEGACY_COOKIE_NAMES: ["id5.1st", "id5id.1st"],
        PRIVACY: {
            JURISDICTIONS: {
                gdpr: !0,
                ccpa: !1,
                lgpd: !0,
                other: !1
            }
        },
        ID5_EIDS_SOURCE: "id5-sync.com",
        LIVE_INTENT_POLL_INTERVAL_MS: 500
    }
}, function(e, t) {
    var n = function() {
        return this
    }();
    try {
        n = n || Function("return this")() || (0, eval)("this")
    } catch (e) {
        "object" == typeof window && (n = window)
    }
    e.exports = n
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(e, t) {
        return (o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function a(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = c(n);
            return function(e, t) {
                {
                    if (t && ("object" === i(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = c(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function c(e) {
        return (c = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function s(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, function(e) {
                e = function(e, t) {
                    if ("object" !== i(e) || null === e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 === n) return ("string" === t ? String : Number)(e);
                    t = n.call(e, t || "default");
                    if ("object" !== i(t)) return t;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }(e, "string");
                return "symbol" === i(e) ? e : String(e)
            }(r.key), r)
        }
    }

    function u(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }
    n.d(t, "a", function() {
        return l
    }), n.d(t, "c", function() {
        return f
    }), n.d(t, "b", function() {
        return d
    });
    var l = function() {
            function e() {
                s(this, e)
            }
            return u(e, [{
                key: "debug",
                value: function() {}
            }, {
                key: "info",
                value: function() {}
            }, {
                key: "warn",
                value: function() {}
            }, {
                key: "error",
                value: function() {}
            }]), e
        }(),
        f = new l,
        d = function() {
            ! function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && o(e, t)
            }(i, l);
            var r = a(i);

            function i(e, t) {
                var n;
                return s(this, i), (n = r.call(this))._prefix = e, n._delegate = t, n
            }
            return u(i, [{
                key: "debug",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).debug.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "info",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).info.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "warn",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).warn.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "error",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).error.apply(e, [this._prefix].concat(n))
                }
            }]), i
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return m
    }), n.d(t, "b", function() {
        return O
    });
    var f = n(0),
        r = n(18),
        t = n(1),
        i = n.n(t),
        o = (n(5), ["localStoragePurposeConsent", "ccpaString"]);

    function a(e) {
        return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c() {
        return (c = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }

    function s(e, t) {
        if (null == e) return {};
        var n, r = function(e, t) {
            if (null == e) return {};
            var n, r, i = {},
                o = Object.keys(e);
            for (r = 0; r < o.length; r++) n = o[r], 0 <= t.indexOf(n) || (i[n] = e[n]);
            return i
        }(e, t);
        if (Object.getOwnPropertySymbols)
            for (var i = Object.getOwnPropertySymbols(e), o = 0; o < i.length; o++) n = i[o], 0 <= t.indexOf(n) || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
        return r
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, p(r.key), r)
        }
    }

    function d(e, t, n) {
        return t && l(e.prototype, t), n && l(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function h(e, t, n) {
        return (t = p(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function p(e) {
        e = function(e, t) {
            if ("object" !== a(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== a(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === a(e) ? e : String(e)
    }
    var v = {
            tcfv1: {
                objName: "__cmpCall",
                objKeys: ["command", "parameter"],
                returnObjName: "__cmpReturn"
            },
            tcfv2: {
                objName: "__tcfapiCall",
                objKeys: ["command", "version"],
                returnObjName: "__tcfapiReturn"
            },
            uspv1: {
                objName: "__uspapiCall",
                objKeys: ["command", "version"],
                returnObjName: "__uspapiReturn"
            }
        },
        y = Object.freeze({
            NONE: "none",
            TCF_V1: "TCFv1",
            TCF_V2: "TCFv2",
            USP_V1: "USPv1",
            ID5_ALLOWED_VENDORS: "ID5"
        }),
        b = Object.freeze({
            FORCE_ALLOWED_BY_CONFIG: "force_allowed_by_config",
            ID5_CONSENT: "id5_consent",
            PROVISIONAL: "provisional",
            JURISDICTION: "jurisdiction",
            CONSENT_API: "consent_api"
        }),
        g = function() {
            function r(e, t, n) {
                u(this, r), h(this, "allowed", !1), h(this, "grantType", b.NONE), h(this, "api", y.NONE), this.allowed = e, this.grantType = t, this.api = n
            }
            return d(r, [{
                key: "isDefinitivelyAllowed",
                value: function() {
                    return this.allowed && this.grantType !== b.PROVISIONAL
                }
            }]), r
        }(),
        m = function() {
            function e() {
                u(this, e), h(this, "api", y.NONE), h(this, "consentString", void 0), h(this, "gdprApplies", !1), h(this, "localStoragePurposeConsent", void 0), h(this, "allowedVendors", void 0), h(this, "hasCcpaString", !1), h(this, "ccpaString", "")
            }
            return d(e, [{
                key: "localStorageGrant",
                value: function() {
                    return new g(this.isGranted(), b.CONSENT_API, this.api)
                }
            }, {
                key: "isGranted",
                value: function() {
                    switch (this.api) {
                        case y.NONE:
                            return !0;
                        case y.TCF_V1:
                            return !this.gdprApplies || !0 === this.localStoragePurposeConsent;
                        case y.TCF_V2:
                            return !1 === this.gdprApplies || !0 === this.localStoragePurposeConsent;
                        case y.ID5_ALLOWED_VENDORS:
                            return this.allowedVendors.includes("131");
                        case y.USP_V1:
                            return !0
                    }
                }
            }, {
                key: "hashCode",
                value: function() {
                    this.localStoragePurposeConsent, this.ccpaString;
                    var e = s(this, o);
                    return Object(f.d)(JSON.stringify(e))
                }
            }]), e
        }(),
        O = function() {
            function l(e, t, n) {
                u(this, l), h(this, "invocationId", void 0), h(this, "consentData", void 0), h(this, "storedPrivacyData", void 0), h(this, "localStorage", void 0), h(this, "_consentRequested", !1), this.invocationId = e, this.localStorage = t, this.storageConfig = n, this.resetConsentData()
            }
            return d(l, [{
                key: "requestConsent",
                value: function(e, t, n, r) {
                    if (e) this.consentData = new m, Object(f.w)(this.invocationId, "cmpApi: ID5 is operating in forced consent mode and will not retrieve any consent signals from the CMP"), r(this.consentData);
                    else if (this._consentRequested) r(this.consentData);
                    else switch (this.consentData = new m, this._consentRequested = !0, t) {
                        case "static":
                            this.parseStaticConsentData(n, r);
                            break;
                        case "iab":
                            this.lookupIabConsent(r);
                            break;
                        default:
                            Object(f.u)(this.invocationId, "cmpApi: Unknown consent API: ".concat(t)), this.resetConsentData(), r(this.consentData)
                    }
                }
            }, {
                key: "getOrCreateConsentData",
                value: function() {
                    return this.consentData || (this.consentData = new m), this.consentData
                }
            }, {
                key: "parseStaticConsentData",
                value: function(e, t) {
                    e = e || {};
                    var n = {};
                    Object(f.s)(e.getConsentData) ? n = l.parseTcfData(e, 1) : Object(f.s)(e.getTCData) ? n = l.parseTcfData(e.getTCData, 2) : Object(f.k)(e.allowedVendors) ? n = {
                        api: y.ID5_ALLOWED_VENDORS,
                        allowedVendors: e.allowedVendors.map(function(e) {
                            return String(e)
                        }),
                        gdprApplies: !0
                    } : Object(f.s)(e.getUSPData) ? n = l.parseUspData(e.getUSPData) : Object(f.w)(this.invocationId, "cmpApi: No static consent data detected! Using defaults."), c(this.consentData, n), Object(f.v)(this.invocationId, "cmpApi: Detected API '".concat(this.consentData.api, "' from static consent data"), e), t(this.consentData)
                }
            }, {
                key: "lookupIabConsent",
                value: function(n) {
                    var r = this,
                        i = [],
                        e = function(t) {
                            return i[t] = !1,
                                function(e) {
                                    i[t] || (i[t] = !0, e && c(r.consentData, e), i.every(function(e) {
                                        return e
                                    }) && n(r.consentData))
                                }
                        },
                        t = e(0),
                        e = e(1);
                    this.lookupTcf(t), this.lookupUsp(e)
                }
            }, {
                key: "lookupUsp",
                value: function(n) {
                    var r = this,
                        e = l.findUsp(),
                        t = e.uspapiFrame,
                        e = e.uspapiFunction;
                    if (!t) return Object(f.w)(this.invocationId, "cmpApi: USP not found! Using defaults for CCPA."), void n();
                    (Object(f.o)(e) ? (Object(f.v)(this.invocationId, "cmpApi: Detected USP is directly accessible, calling it now."), e) : (Object(f.v)(this.invocationId, "cmpApi: Detected USP is outside the current iframe. Using message passing."), l.buildCmpSurrogate("uspv1", t)))("getUSPData", 1, function(e, t) {
                        t ? n(l.parseUspData(e)) : (Object(f.u)(r.invocationId, "cmpApi: USP callback not succesful. Using defaults for CCPA."), n())
                    })
                }
            }, {
                key: "lookupTcf",
                value: function(e) {
                    var t = l.findTCF(),
                        n = t.cmpVersion,
                        r = t.cmpFrame,
                        t = t.cmpFunction;
                    if (!r) return Object(f.w)(this.invocationId, "cmpApi: TCF not found! Using defaults for GDPR."), void e();
                    Object(f.o)(t) ? this.lookupDirectTcf(n, t, e) : (Object(f.v)(this.invocationId, "cmpApi: Detected TCF is outside the current iframe. Using message passing."), this.lookupMessageTcf(n, r, e))
                }
            }, {
                key: "lookupMessageTcf",
                value: function(e, t, n) {
                    t = l.buildCmpSurrogate(1 === e ? "tcfv1" : "tcfv2", t);
                    this.lookupDirectTcf(e, t, n)
                }
            }, {
                key: "lookupDirectTcf",
                value: function(e, t, r) {
                    function i(e, t, n) {
                        Object(f.v)(a.invocationId, "cmpApi: TCFv".concat(e, " - Received a call back: ").concat(t), n)
                    }

                    function o(e, t) {
                        Object(f.u)(a.invocationId, "cmpApi: TCFv".concat(e, " - Received insuccess: ").concat(t, ". Please check your CMP setup. Using defaults for GDPR."))
                    }
                    var n, a = this,
                        c = {},
                        s = {},
                        u = function(n) {
                            return s[n] = !1,
                                function(e, t) {
                                    s[n] = !0, t ? (i(1, n, e), c[n] = e) : o(1, n), Object.values(s).every(function(e) {
                                        return e
                                    }) && r(l.parseTcfData(c, 1))
                                }
                        };
                    1 === e ? (n = u("getConsentData"), u = u("getVendorConsents"), t("getConsentData", null, n), t("getVendorConsents", null, u)) : 2 === e && t("addEventListener", e, function(e, t) {
                        if (i(2, "event", e), !t) return o(2, "addEventListener"), void r();
                        !e || !1 !== e.gdprApplies && "tcloaded" !== e.eventStatus && "useractioncomplete" !== e.eventStatus || r(l.parseTcfData(e, 2))
                    })
                }
            }, {
                key: "resetConsentData",
                value: function() {
                    this.consentData = void 0, this.storedPrivacyData = void 0, this._consentRequested = !1
                }
            }, {
                key: "localStorageGrant",
                value: function(e, t) {
                    if (!0 === e || !0 === t) return Object(f.w)(this.invocationId, "cmpApi: Local storage access granted by configuration override, consent will not be checked"), new g(!0, b.FORCE_ALLOWED_BY_CONFIG, y.NONE);
                    if (this.consentData && this.consentData.api !== y.NONE) return this.consentData.localStorageGrant();
                    if (Object(f.s)(this.storedPrivacyData) || (n = this.localStorage.getItemWithExpiration(this.storageConfig.PRIVACY), this.storedPrivacyData = n && JSON.parse(n), Object(f.v)(this.invocationId, "cmpApi: Loaded stored privacy data from local storage", this.storedPrivacyData)), this.storedPrivacyData && !0 === this.storedPrivacyData.id5_consent) return new g(!0, b.ID5_CONSENT, y.NONE);
                    if (!this.storedPrivacyData || !Object(f.m)(this.storedPrivacyData.jurisdiction)) return new g(!0, b.PROVISIONAL, y.NONE);
                    var n = this.storedPrivacyData.jurisdiction,
                        n = n in i.a.PRIVACY.JURISDICTIONS && i.a.PRIVACY.JURISDICTIONS[n];
                    return new g(!1 === n, b.JURISDICTION, y.NONE)
                }
            }, {
                key: "setStoredPrivacy",
                value: function(e) {
                    try {
                        Object(f.s)(e) ? (this.storedPrivacyData = e, this.localStorage.setItemWithExpiration(this.storageConfig.PRIVACY, JSON.stringify(e))) : Object(f.u)(this.invocationId, "cmpApi: Cannot store privacy data if it is not an object", e)
                    } catch (e) {
                        Object(f.u)(this.invocationId, "cmpApi: Error while storing privacy data", e)
                    }
                }
            }], [{
                key: "buildCmpSurrogate",
                value: function(c, s) {
                    return function(e, t, n) {
                        var r = Math.random() + "",
                            i = v[c],
                            o = {},
                            a = {};
                        a[i.objKeys[0]] = e, a[i.objKeys[1]] = t, a.callId = r, o[i.objName] = a;
                        a = function e(t) {
                            t = Object(f.g)(t, "data.".concat(i.returnObjName));
                            t && t.callId === r && (window.removeEventListener("message", e), n(t.returnValue, t.success))
                        };
                        window.addEventListener("message", a, !1), s.postMessage(o, "*")
                    }
                }
            }, {
                key: "parseUspData",
                value: function(e) {
                    if (Object(f.s)(e) && Object(f.t)(e.uspString)) return {
                        api: y.USP_V1,
                        hasCcpaString: !0,
                        ccpaString: e.uspString
                    };
                    Object(f.u)(this.invocationId, "cmpApi: No or malformed USP data. Using defaults for CCPA.")
                }
            }, {
                key: "parseTcfData",
                value: function(e, t) {
                    var n, r;
                    if (1 === t) n = l.isValidV1ConsentObject, r = l.normalizeV1Data;
                    else {
                        if (2 !== t) return void Object(f.u)(this.invocationId, "cmpApi: No or malformed CMP data. Using defaults for GDPR.");
                        n = l.isValidV2ConsentObject, r = l.normalizeV2Data
                    }
                    if (n(e)) return r(e);
                    Object(f.u)(this.invocationId, "cmpApi: Invalid CMP data. Using defaults for GDPR.", e)
                }
            }, {
                key: "isValidV1ConsentObject",
                value: function(e) {
                    var t = Object(f.g)(e, "getConsentData.gdprApplies");
                    return !!Object(f.l)(t) && (!1 === t || Object(f.t)(e.getConsentData.consentData) && Object(f.s)(e.getVendorConsents) && 1 < Object.keys(e.getVendorConsents).length)
                }
            }, {
                key: "isValidV2ConsentObject",
                value: function(e) {
                    var t = e && e.gdprApplies,
                        e = e && e.tcString;
                    return !1 === t || Object(f.t)(e)
                }
            }, {
                key: "normalizeV1Data",
                value: function(e) {
                    return {
                        consentString: e.getConsentData.consentData,
                        localStoragePurposeConsent: Object(f.g)(e, "getVendorConsents.purposeConsents.1"),
                        gdprApplies: e.getConsentData.gdprApplies,
                        api: y.TCF_V1
                    }
                }
            }, {
                key: "normalizeV2Data",
                value: function(e) {
                    var t = Object(f.g)(e, "purpose.consents.1");
                    return Object(f.l)(t) || (t = Object(r.a)(e.tcString, 1)), {
                        consentString: e.tcString,
                        localStoragePurposeConsent: t,
                        gdprApplies: e.gdprApplies,
                        api: y.TCF_V2
                    }
                }
            }, {
                key: "findTCF",
                value: function() {
                    for (var e, t, n = 0, r = window; !e;) {
                        try {
                            if ("function" == typeof r.__tcfapi || "function" == typeof r.__cmp) {
                                t = "function" == typeof r.__tcfapi ? (n = 2, r.__tcfapi) : (n = 1, r.__cmp), e = r;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (r.frames.__tcfapiLocator) {
                                n = 2, e = r;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (r.frames.__cmpLocator) {
                                n = 1, e = r;
                                break
                            }
                        } catch (e) {}
                        if (r === window.top) break;
                        r = r.parent
                    }
                    return {
                        cmpVersion: n,
                        cmpFrame: e,
                        cmpFunction: t
                    }
                }
            }, {
                key: "findUsp",
                value: function() {
                    for (var e, t, n = window; !e;) {
                        try {
                            if ("function" == typeof n.__uspapi) {
                                t = n.__uspapi, e = n;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (n.frames.__uspapiLocator) {
                                e = n;
                                break
                            }
                        } catch (e) {}
                        if (n === window.top) break;
                        n = n.parent
                    }
                    return {
                        uspapiFrame: e,
                        uspapiFunction: t
                    }
                }
            }]), l
        }()
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, a(r.key), r)
        }
    }

    function o(e, t, n) {
        return (t = a(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function a(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    n.d(t, "a", function() {
        return s
    });
    var c = "_exp",
        s = function() {
            function n(e) {
                var t = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1];
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, n), o(this, "available", !1), o(this, "win", void 0), o(this, "writingEnabled", void 0), this.win = e, this.writingEnabled = t;
                t = "__id5test";
                try {
                    this.writingEnabled && this.win.localStorage.setItem(t, t), this.win.localStorage.removeItem(t), this.available = !0
                } catch (e) {}
            }
            var e, t, r;
            return e = n, (t = [{
                key: "isAvailable",
                value: function() {
                    return this.available
                }
            }, {
                key: "getItem",
                value: function(e) {
                    if (this.available) return this.win.localStorage.getItem(e)
                }
            }, {
                key: "setItem",
                value: function(e, t) {
                    this.available && this.writingEnabled && this.win.localStorage.setItem(e, t)
                }
            }, {
                key: "removeItem",
                value: function(e) {
                    this.available && this.win.localStorage.removeItem(e)
                }
            }, {
                key: "getItemWithExpiration",
                value: function(e) {
                    var t = e.name,
                        e = this.getItem(t + c);
                    return !e || new Date(e).getTime() - Date.now() <= 0 ? (this.removeItemWithExpiration({
                        name: t
                    }), null) : this.getItem(t)
                }
            }, {
                key: "setItemWithExpiration",
                value: function(e, t) {
                    var n = e.name,
                        e = e.expiresDays,
                        e = Date.now() + 864e5 * e,
                        e = new Date(e).toUTCString();
                    this.setItem(n + c, e), this.setItem(n, t)
                }
            }, {
                key: "removeItemWithExpiration",
                value: function(e) {
                    e = e.name;
                    this.removeItem(e), this.removeItem(e + c)
                }
            }]) && i(e.prototype, t), r && i(e, r), Object.defineProperty(e, "prototype", {
                writable: !1
            }), n
        }()
}, function(e, t, n) {
    "use strict";
    var r = n(12);
    n.d(t, "a", function() {
        return r
    });
    var i = n(3);
    n.d(t, "b", function() {
        return i.a
    })
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return a
    });
    var t = n(1),
        s = n.n(t),
        u = n(0);
    n(5);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, o(r.key), r)
        }
    }

    function l(e, t, n) {
        return (t = o(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function o(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var a = function() {
        function c(e, t, n, r, i) {
            var o = this;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, c), l(this, "isEnabled", void 0), l(this, "invocationId", void 0), l(this, "localStorage", void 0), l(this, "storageConfig", void 0), l(this, "_windowObj", void 0), l(this, "_handler", void 0), l(this, "_hasLiveIntentId", !1), l(this, "_liveIntentId", void 0), l(this, "_liveIntentIdTimestamp", void 0);
            var a = this;
            this._windowObj = e, this.isEnabled = t, this.invocationId = n, this.localStorage = r, this.storageConfig = i, t && (this._checkLocalStorage(), Object(u.v)(this.invocationId, "Starting polling detection of LiveIntent API"), this._handler = setInterval(function() {
                Object(u.g)(o._windowObj, "liQ.ready") && (Object(u.v)(o.invocationId, "Stopping polling detection of LiveIntent API: found"), clearInterval(a._handler), a._onDetected())
            }, s.a.LIVE_INTENT_POLL_INTERVAL_MS))
        }
        var e, t, n;
        return e = c, (t = [{
            key: "_checkLocalStorage",
            value: function() {
                var e;
                this.localStorage.isAvailable() && (e = this.localStorage.getItemWithExpiration(this.storageConfig.LIVE_INTENT), e = Object(u.t)(e) ? JSON.parse(e) : void 0, Object(u.s)(e) && (Object(u.v)(this.invocationId, "Retrieved LiveIntent ID from local storage"), this._setLiveIntentId(e)))
            }
        }, {
            key: "_onDetected",
            value: function() {
                var t = this;
                Object(u.v)(this.invocationId, "Detected LiveIntent API on the page! Requesting their ID.");
                var e = Object(u.g)(this._windowObj, "liQ.resolve");
                if (Object(u.o)(e)) try {
                    e(function(e) {
                        Object(u.v)(t.invocationId, "Received LiveIntent API `resolve` lookup response", e), e.unifiedId && t._setLiveIntentIdFromResponse(e.unifiedId, Date.now())
                    })
                } catch (e) {
                    Object(u.u)("Error caught while calling resolve() on LiveIntent API", e)
                }
            }
        }, {
            key: "_setLiveIntentIdFromResponse",
            value: function(e, t) {
                t = {
                    liveIntentId: e,
                    timestamp: t
                };
                this.localStorage.setItemWithExpiration(this.storageConfig.LIVE_INTENT, JSON.stringify(t)), this._setLiveIntentId(t)
            }
        }, {
            key: "_setLiveIntentId",
            value: function(e) {
                Object(u.v)(self.invocationId, "Received LiveIntent ID", e), this._liveIntentId = e.liveIntentId, this._liveIntentIdTimestamp = e.timestamp, this._hasLiveIntentId = !0
            }
        }, {
            key: "getLiveIntentId",
            value: function() {
                return this.isEnabled ? this._liveIntentId : void 0
            }
        }, {
            key: "hasLiveIntentId",
            value: function() {
                return this.isEnabled && this._hasLiveIntentId
            }
        }]) && i(e.prototype, t), n && i(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), c
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "d", function() {
        return y
    }), n.d(t, "c", function() {
        return b
    }), n.d(t, "a", function() {
        return g
    }), n.d(t, "b", function() {
        return m
    });
    var i = n(9);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(e, "prototype", {
            writable: !1
        }), t && r(e, t)
    }

    function r(e, t) {
        return (r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function c(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = s(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = s(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function s(e) {
        return (s = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, h(r.key), r)
        }
    }

    function f(e, t, n) {
        return t && l(e.prototype, t), n && l(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function d(e, t, n) {
        return (t = h(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function h(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var p = Object.freeze({
            TIMER: "TIMER",
            SUMMARY: "SUMMARY",
            COUNTER: "COUNTER"
        }),
        v = function() {
            function r(e, t, n) {
                u(this, r), d(this, "name", void 0), d(this, "tags", void 0), d(this, "values", void 0), this.name = e, this.tags = i.a.from(t), this.type = n, this.values = []
            }
            return f(r, [{
                key: "reset",
                value: function() {
                    this.values = []
                }
            }]), r
        }(),
        y = function() {
            a(r, v);
            var n = c(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.TIMER)
            }
            return f(r, [{
                key: "startMeasurement",
                value: function() {
                    try {
                        return new b(this)
                    } catch (e) {
                        return
                    }
                }
            }, {
                key: "record",
                value: function(e) {
                    try {
                        this.values.push({
                            value: e,
                            timestamp: Date.now()
                        })
                    } catch (e) {}
                }
            }, {
                key: "recordNow",
                value: function() {
                    try {
                        var e;
                        this.record(0 | (null === (e = performance) || void 0 === e ? void 0 : e.now()))
                    } catch (e) {}
                }
            }]), r
        }(),
        b = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
                u(this, t), this.timer = e, this.startTime = performance.now()
            }
            return f(t, [{
                key: "record",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
                    try {
                        var t = performance.now() - this.startTime | 0,
                            n = e || this.timer;
                        return n && n.record(t), t
                    } catch (e) {
                        return
                    }
                }
            }]), t
        }(),
        g = function() {
            a(r, v);
            var n = c(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.COUNTER)
            }
            return f(r, [{
                key: "inc",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 1;
                    try {
                        0 === this.values.length ? this.values.push({
                            value: e,
                            timestamp: Date.now()
                        }) : (this.values[0].value += e, this.values[0].timestamp = Date.now())
                    } catch (e) {}
                }
            }]), r
        }(),
        m = function() {
            a(r, v);
            var n = c(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.SUMMARY)
            }
            return f(r, [{
                key: "record",
                value: function(e) {
                    try {
                        this.values.push({
                            value: e,
                            timestamp: Date.now()
                        })
                    } catch (e) {}
                }
            }]), r
        }()
}, function(e, t, n) {
    "use strict";

    function r(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, i, o, a, c = [],
                    s = !0,
                    u = !1;
                try {
                    if (o = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        s = !1
                    } else
                        for (; !(s = (r = o.call(n)).done) && (c.push(r.value), c.length !== t); s = !0);
                } catch (e) {
                    u = !0, i = e
                } finally {
                    try {
                        if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw i
                    }
                }
                return c
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return i(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function i(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }
    var o = Object.freeze({});
    t.a = {
        EMPTY: o,
        from: function(e) {
            return e ? e instanceof Map ? Object.fromEntries(e) : e : o
        },
        toString: function(e) {
            return Array.from(Object.entries(e), function(e) {
                var t = r(e, 2),
                    e = t[0],
                    t = t[1];
                return "".concat(e, "=").concat(t)
            }).sort().toString()
        }
    }
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    n = n(11);
    window.ID5 || (window.ID5 = n.a)
}, function(e, t, n) {
    "use strict";
    var g = n(0),
        i = n(16),
        d = n(17),
        h = n(4),
        p = n(19),
        a = n(20),
        v = n(5),
        y = n(21),
        b = n(7),
        m = n(22),
        s = n(30),
        o = n(6);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function u(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? c(Object(n), !0).forEach(function(e) {
                _(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function l(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, i, o, a, c = [],
                    s = !0,
                    u = !1;
                try {
                    if (o = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        s = !1
                    } else
                        for (; !(s = (r = o.call(n)).done) && (c.push(r.value), c.length !== t); s = !0);
                } catch (e) {
                    u = !0, i = e
                } finally {
                    try {
                        if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw i
                    }
                }
                return c
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return f(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function f(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function O(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, w(r.key), r)
        }
    }

    function _(e, t, n) {
        return (t = w(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function w(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var I = "https://id5-sync.com",
        n = new(function() {
            function e() {
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e), _(this, "loaded", !1), _(this, "_isUsingCdn", !1), _(this, "_referer", !1), _(this, "_version", a.a), _(this, "versions", {}), _(this, "invocationId", 0), this.loaded = !0, this._isUsingCdn = !!(document && document.currentScript && document.currentScript.src && 0 === document.currentScript.src.indexOf("https://cdn.id5-sync.com")), this._referer = Object(i.a)(), this.versions[a.a] = !0
            }
            var t, n, r;
            return t = e, (n = [{
                key: "debug",
                get: function() {
                    return Object(g.p)()
                },
                set: function(e) {
                    Object(g.z)(e)
                }
            }, {
                key: "init",
                value: function(e) {
                    var t = this.invocationId;
                    this.invocationId += 1;
                    try {
                        Object(g.v)(t, "ID5 API version ".concat(this._version, ". Invoking init()"), e);
                        var n = new y.a(t, e),
                            r = n.getOptions(),
                            i = this._configureDiagnostics(r);
                        i && (i.loadDelayTimer().recordNow(), i.invocationCountSummary().record(this.invocationId));
                        var o = new g.a(this.invocationId),
                            a = this._registerIntegration(n, i, o),
                            c = new v.a(window.top, !r.applyCreativeRestrictions),
                            s = new b.a(window, !r.disableLiveIntentIntegration, t, c, n.storageConfig),
                            u = new h.b(t, c, n.storageConfig),
                            l = new d.a(t, function() {
                                return u.localStorageGrant(r.allowLocalStorageWithoutConsentApi, r.debugBypassConsent)
                            }, c, n.storageConfig),
                            f = new p.a(t, n, l, u, s, i);
                        return this.getId(f, !1), Object(g.v)(t, "ID5 initialized for partner ".concat(r.partnerId, " with referer ").concat(this._referer.referer, " and options"), e), f._integrationInstance = a, f
                    } catch (e) {
                        Object(g.u)(t, "Exception caught during init()", e)
                    }
                }
            }, {
                key: "refreshId",
                value: function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                        n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
                    if (!Object(g.l)(e)) throw new Error("Invalid signature for refreshId(): second parameter must be a boolean");
                    try {
                        Object(g.v)(t.invocationId, "Invoking refreshId()", arguments), t.startRefresh(e), t.updateOptions(n), t.consentManagement.resetConsentData(), this.getId(t, e)
                    } catch (e) {
                        Object(g.u)(t.invocationId, "Exception caught from refreshId()", e)
                    }
                    return t
                }
            }, {
                key: "getId",
                value: function(t) {
                    var n = this,
                        r = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
                    Object(g.m)(window.navigator.userAgentData) && !t.getOptions().disableUaHints ? this.gatherUaHints().then(function(e) {
                        return n.getIdWithUaHints(t, Object(g.h)(e), r)
                    }).catch(function(e) {
                        Object(g.u)("Error while calling navigator.userAgentData.getHighEntropyValues()", e), n.getIdWithUaHints(t, void 0, r)
                    }) : this.getIdWithUaHints(t, void 0, r)
                }
            }, {
                key: "getIdWithUaHints",
                value: function(o, a, c) {
                    var s, e, t, u = this,
                        l = o.getOptions(),
                        f = 0,
                        d = !1,
                        h = !1,
                        p = !1,
                        v = !1,
                        y = l.refreshInSeconds,
                        n = o.localStorageGrant();
                    n.isDefinitivelyAllowed() && (Object(g.v)(o.invocationId, "Using local storage for cached ID", n), s = o.clientStore.getResponse(), e = o.clientStore.getDateTime(), Object(g.r)(null === s || void 0 === s || null === (t = s.cache_control) || void 0 === t ? void 0 : t.max_age_sec) && (y = s.cache_control.max_age_sec), d = e <= 0 || Date.now() - e > 1e3 * y, f = o.clientStore.getNb(l.partnerId), h = !o.clientStore.isStoredPdUpToDate(l.partnerId, l.pd), p = !o.clientStore.storedSegmentsMatchesSegments(l.partnerId, l.segments)), s || (Object(g.v)(o.invocationId, "No cached ID found"), s = o.clientStore.getResponseFromLegacyCookie(), d = !0), s && s.universal_uid && !h && !p ? (Object(g.v)(o.invocationId, "ID5 User ID available from cache:", {
                        storedResponse: s,
                        storedDateTime: e,
                        refreshNeeded: d
                    }), e <= 0 || 12096e5 < Date.now() - e || (o.setUserId(s, !0), f = o.clientStore.incNb(l.partnerId, f), v = !0)) : s && s.universal_uid && h ? Object(g.v)(o.invocationId, "PD value has changed, so ignoring User ID from cache") : s && s.universal_uid && p ? Object(g.v)(o.invocationId, "Segments have changed, so ignoring User ID from cache") : s && !s.universal_uid ? Object(g.u)(o.invocationId, "Invalid stored response: ", s) : Object(g.v)(o.invocationId, "No ID5 User ID available from cache");
                    var b = null === (e = o._metrics) || void 0 === e ? void 0 : e.consentRequestTimer(l.debugBypassConsent ? "bypass" : l.cmpApi).startMeasurement();
                    o.consentManagement.requestConsent(l.debugBypassConsent, l.cmpApi, l.consentData, function(t) {
                        b && b.record();
                        var e, n, r, i = o.localStorageGrant();
                        Object(g.v)(o.invocationId, "Local storage grant", i), i.allowed ? (s = o.clientStore.getResponse() || o.clientStore.getResponseFromLegacyCookie(), e = !o.clientStore.storedConsentDataMatchesConsentData(t), o.clientStore.putHashedConsentData(t), o.clientStore.isStoredPdUpToDate(l.partnerId, l.pd) || o.clientStore.putHashedPd(l.partnerId, l.pd), o.clientStore.putHashedSegments(l.partnerId, l.segments), ((i = !s || !s.universal_uid || !s.signature) || d || e || h || p || c) && (Object(g.v)(o.invocationId, "Decided to fetch a fresh ID5 ID", {
                            missingStoredData: i,
                            refreshInSecondsHasElapsed: d,
                            consentHasChanged: e,
                            pdHasChanged: h,
                            segmentsHaveChanged: p,
                            forceFetch: c
                        }), n = null === (e = o._metrics) || void 0 === e ? void 0 : e.extensionsCallTimer().startMeasurement(), r = u.gatherData(l, o, f, t, s, a, y, o.getProvidedOptions()), m.a.gather(o.invocationId).then(function(e) {
                            n && n.record(), r.extensions = e, u.fetchFreshID5ID(r, l, t, o, c, v)
                        }))) : Object(g.v)(o.invocationId, "No legal basis to use ID5", t)
                    })
                }
            }, {
                key: "gatherData",
                value: function(n, e, t, r, i, o, a, c) {
                    var s = {
                            partner: n.partnerId,
                            v: this._version,
                            o: "api",
                            tml: this._referer.topmostLocation,
                            ref: this._referer.ref,
                            cu: this._referer.canonicalUrl,
                            u: this._referer.stack[0] || window.location.href,
                            top: this._referer.reachedTop ? 1 : 0,
                            localStorage: e.clientStore.isLocalStorageAvailable() ? 1 : 0,
                            nbPage: t,
                            id5cdn: this._isUsingCdn,
                            ua: window.navigator.userAgent,
                            att: n.att
                        },
                        t = r.gdprApplies;
                    Object(g.m)(t) && (s.gdpr = t ? 1 : 0);
                    t = r.consentString;
                    Object(g.m)(t) && (s.gdpr_consent = t), Object(g.m)(r.allowedVendors) && (s.allowed_vendors = r.allowedVendors);
                    i = i && i.signature ? i.signature : void 0;
                    return Object(g.m)(i) && (s.s = i), Object(g.m)(o) && (s.ua_hints = o), r.hasCcpaString && (s.us_privacy = r.ccpaString), e.liveIntentApi.hasLiveIntentId() && (s.li = e.liveIntentApi.getLiveIntentId()), Object(g.x)({
                        pd: "pd",
                        partnerUserId: "puid",
                        provider: "provider",
                        segments: "segments"
                    }).forEach(function(e) {
                        var t = l(e, 2),
                            e = t[0],
                            t = t[1];
                        Object(g.m)(n[e]) && (s[t] = n[e])
                    }), !0 === n.abTesting.enabled && (s.ab_testing = {
                        enabled: !0,
                        control_group_pct: e.getOptions().abTesting.controlGroupPct
                    }), 0 < e.getInvalidSegments() && (s._invalid_segments = e.getInvalidSegments()), Object(g.q)() && (s._trace = !0), s.provided_options = {
                        refresh_in_seconds: c.refreshInSeconds
                    }, s.used_refresh_in_seconds = a, s
                }
            }, {
                key: "fetchFreshID5ID",
                value: function(e, t, n, r, i, o) {
                    var a = "".concat(I, "/g/v2/").concat(t.partnerId, ".json"),
                        c = Object(s.d)();
                    Object(g.v)(r.invocationId, "Fetching ID5 ID (forceFetch:".concat(i, ") from:"), a, e), Object(g.b)(a, {
                        success: this.handleSuccessfulFetchResponse(r, t, o, n, c),
                        error: function(e) {
                            Object(g.u)(r.invocationId, "Error during AJAX request to ID5 server", e), c && c.record(null === (e = r._metrics) || void 0 === e ? void 0 : e.fetchFailureCallTimer())
                        }
                    }, JSON.stringify(e), {
                        method: "POST",
                        withCredentials: !0
                    })
                }
            }, {
                key: "handleSuccessfulFetchResponse",
                value: function(o, a, c, s, u) {
                    var l = this;
                    return function(e) {
                        u && u.record(null === (t = o._metrics) || void 0 === t ? void 0 : t.fetchSuccessfulCallTimer());
                        var t = l.validateResponseIsCorrectJson(e, o, "fetch");
                        if (t)
                            if (Object(g.t)(t.universal_uid)) {
                                Object(g.v)(o.invocationId, "Valid json response from ID5 received", t);
                                try {
                                    o.setUserId(t, !1), o.consentManagement.setStoredPrivacy(t.privacy);
                                    var n, r, i = o.localStorageGrant();
                                    i.isDefinitivelyAllowed() ? (Object(g.v)(o.invocationId, "Storing ID in cache"), o.clientStore.putResponse(e), o.clientStore.setDateTime((new Date).toUTCString()), o.clientStore.setNb(a.partnerId, c ? 0 : 1)) : (Object(g.v)(o.invocationId, "Cannot use local storage to cache ID", i), o.clientStore.clearAll(a.partnerId)), o.clientStore.removeLegacyCookies(a.partnerId), !0 === t.cascade_needed && i.isDefinitivelyAllowed() && 0 <= a.maxCascades && !a.applyCreativeRestrictions && (n = a.partnerUserId && 0 < a.partnerUserId.length, r = "".concat(I, "/").concat(n ? "s" : "i", "/").concat(a.partnerId, "/").concat(a.maxCascades, ".gif?id5id=").concat(o._userId, "&o=api&").concat(n ? "puid=" + a.partnerUserId + "&" : "", "gdpr_consent=").concat(s.consentString, "&gdpr=").concat(s.gdprApplies), Object(g.v)(o.invocationId, "Opportunities to cascade available", r), Object(g.f)(r))
                                } catch (e) {
                                    Object(g.u)(o.invocationId, "Error during processing of valid ID5 server response", t, e)
                                }
                            } else Object(g.u)(o.invocationId, "Server response failed to validate", t)
                    }
                }
            }, {
                key: "validateResponseIsCorrectJson",
                value: function(t, n, r) {
                    if (!t || !Object(g.t)(t) || t.length < 1) Object(g.u)(n.invocationId, "Empty ".concat(r, ' response from ID5 servers: "').concat(t, '"'));
                    else try {
                        return JSON.parse(t)
                    } catch (e) {
                        Object(g.u)(n.invocationId, "Cannot parse the JSON server ".concat(r, " response"), t)
                    }
                    return null
                }
            }, {
                key: "gatherUaHints",
                value: function() {
                    return window.navigator.userAgentData.getHighEntropyValues(["architecture", "fullVersionList", "model", "platformVersion"])
                }
            }, {
                key: "_configureDiagnostics",
                value: function(e) {
                    try {
                        var t, n, r, i, o = new s.a("api", a.a);
                        return o.addCommonTags(u(u({}, Object(s.c)(e.partnerId)), {}, {
                            tml: this._referer.topmostLocation
                        })), null !== (t = e.diagnostics) && void 0 !== t && t.publishingDisabled || (i = Object(s.b)(e.diagnostics.publishingSampleRatio), null !== (n = e.diagnostics) && void 0 !== n && n.publishAfterLoadInMsec && 0 < e.diagnostics.publishAfterLoadInMsec && o.schedulePublishAfterMsec(e.diagnostics.publishAfterLoadInMsec, i), null !== (r = e.diagnostics) && void 0 !== r && r.publishBeforeWindowUnload && o.schedulePublishBeforeUnload(i)), o
                    } catch (e) {
                        return void Object(g.u)(this.invocationId, "Failed to configure diagnostics", e)
                    }
                }
            }, {
                key: "_registerIntegration",
                value: function(e, t, n) {
                    try {
                        var r = new o.a.Instance(window, "api", a.a, e, t, n);
                        return r.register(), r
                    } catch (e) {
                        Object(g.u)("Failed to register integration instance", e)
                    }
                }
            }]) && O(t.prototype, n), r && O(t, r), Object.defineProperty(t, "prototype", {
                writable: !1
            }), e
        }());
    t.a = n
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), n.d(t, "Role", function() {
        return h
    }), n.d(t, "Event", function() {
        return p
    }), n.d(t, "Properties", function() {
        return y
    }), n.d(t, "Instance", function() {
        return m
    }), t.electLeader = O;
    var r = n(13),
        s = n(14),
        u = n(15),
        l = n(3);

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function a(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function f(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function d(e, t, n) {
        return (t = c(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var h = Object.freeze({
            UNKNOWN: "unknown",
            LEADER: "leader",
            FOLLOWER: "follower"
        }),
        p = Object.freeze({
            ID5_MESSAGE_RECEIVED: "message",
            ID5_INSTANCE_JOINED: "instance-joined",
            ID5_LEADER_ELECTED: "leader-elected"
        }),
        v = Object.freeze(Object.values(p)),
        y = function e(t, n, r, i, o, a) {
            f(this, e), d(this, "id", void 0), d(this, "version", void 0), d(this, "source", void 0), d(this, "sourceVersion", void 0), d(this, "sourceConfiguration", void 0), d(this, "href", void 0), d(this, "domain", void 0), this.id = t, this.version = n, this.source = r, this.sourceVersion = i, this.sourceConfiguration = o, this.href = null == a ? void 0 : a.href, this.domain = null == a ? void 0 : a.hostname
        },
        b = function() {
            function t(e) {
                f(this, t), d(this, "_knownValues", []), d(this, "_counter", void 0), this._counter = e
            }
            return a(t, [{
                key: "add",
                value: function(e) {
                    e && -1 === this._knownValues.indexOf(e) && (this._counter.inc(), this._knownValues.push(e))
                }
            }]), t
        }(),
        g = function() {
            function r(e, t) {
                f(this, r), d(this, "_instancesCounter", void 0), d(this, "_domainsCounter", void 0), d(this, "_windowsCounter", void 0), d(this, "_partnersCounter", void 0);
                var n = t.id;
                this._instancesCounter = e.instanceCounter(t.id), this._windowsCounter = new b(e.instanceUniqWindowsCounter(n)), this._partnersCounter = new b(e.instanceUniqPartnersCounter(n)), this._domainsCounter = new b(e.instanceUniqueDomainsCounter(n)), this.addInstance(t)
            }
            return a(r, [{
                key: "addInstance",
                value: function(e) {
                    var t, n;
                    this._instancesCounter.inc(), this._partnersCounter.add(null == e || null === (t = e.sourceConfiguration) || void 0 === t || null === (n = t.options) || void 0 === n ? void 0 : n.partnerId), this._domainsCounter.add(null == e ? void 0 : e.domain), this._windowsCounter.add(null == e ? void 0 : e.href)
                }
            }]), r
        }(),
        m = function() {
            function c(e, t, n, r, i) {
                var o = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : l.c;
                f(this, c), d(this, "properties", void 0), d(this, "_messenger", void 0), d(this, "_knownInstances", new Map), d(this, "role", void 0), d(this, "_leader", void 0), d(this, "_metrics", void 0), d(this, "_logger", void 0), d(this, "_callbacks", new Map), d(this, "_instanceCounters", void 0);
                var a = s.a();
                this.properties = new y(a, u.a, t, n, r, e.location), this.role = h.UNKNOWN, this._metrics = i, this._instanceCounters = new g(i, this.properties), this._loadTime = performance.now(), this._logger = void 0 !== o ? new l.b("Instance(id=".concat(a, ")"), o) : l.c, this._logger.debug("Instance created"), this._window = e
            }
            return a(c, [{
                key: "register",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 3e3,
                        n = this,
                        t = n._window;
                    this._messenger = new r.a(n.properties.id, t, n._logger), this._messenger.onMessageReceived(function(e) {
                        var t = performance.now() - e.timestamp | 0;
                        n._metrics.instanceMsgDeliveryTimer().record(t), n._logger.debug("Message received", e), e.type === _.TYPE && (t = e.payload, n._addInstance(t.instance), e.dst === r.b && n._messenger.sendResponseMessage(e, new _(n.properties), _.TYPE)), n._doFireEvent(p.ID5_MESSAGE_RECEIVED, e)
                    }), setTimeout(function() {
                        var e = Array.from(n._knownInstances.values());
                        e.push(n.properties);
                        e = O(e);
                        n._leader = e, n.role = e.id === n.properties.id ? h.LEADER : h.FOLLOWER, n._doFireEvent(p.ID5_LEADER_ELECTED, n.role, n._leader), n._logger.debug("Leader elected", e.id, "my role", n.role)
                    }, e), n._messenger.broadcastMessage(new _(n.properties), _.TYPE), void 0 === t.__id5_instances && (t.__id5_instances = []), t.__id5_instances.push(this)
                }
            }, {
                key: "deregister",
                value: function() {
                    var e = this._window.__id5_instances;
                    void 0 !== e && e.splice(e.indexOf(this), 1), this._messenger && this._messenger.deregister()
                }
            }, {
                key: "getRole",
                value: function() {
                    return this.role
                }
            }, {
                key: "on",
                value: function(e, t) {
                    var n;
                    return void 0 !== e && v.includes(e) && ((n = this._callbacks.get(e)) ? n.push(t) : this._callbacks.set(e, [t])), this
                }
            }, {
                key: "_addInstance",
                value: function(e) {
                    this._knownInstances.get(e.id) || (this._knownInstances.set(e.id, e), this._instanceCounters.addInstance(e), this._metrics.instanceJoinDelayTimer().record(performance.now() - this._loadTime | 0), void 0 !== this._leader && this._metrics.instanceLateJoinCounter(this.properties.id).inc(), this._logger.debug("Instance joined", e.id), this._doFireEvent(p.ID5_INSTANCE_JOINED, e))
                }
            }, {
                key: "_doFireEvent",
                value: function(t) {
                    for (var n = this, e = arguments.length, r = new Array(1 < e ? e - 1 : 0), i = 1; i < e; i++) r[i - 1] = arguments[i];
                    var o = this._callbacks.get(t);
                    o && o.forEach(function(e) {
                        try {
                            e.apply(void 0, r)
                        } catch (e) {
                            n._logger.error("Failed to call event listener", t, e)
                        }
                    })
                }
            }]), c
        }();

    function O(e) {
        if (e && 0 !== e.length) return e.sort(function(e, t) {
            var n = -s.b(e.version, t.version);
            return n = 0 === n && 0 === (n = 0 === (n = e.source.localeCompare(t.source)) ? -s.b(e.sourceVersion, t.sourceVersion) : n) ? e.id.localeCompare(t.id) : n
        })[0]
    }
    var _ = function e(t) {
        f(this, e), d(this, "instance", void 0), this.instance = t
    };
    d(_, "TYPE", "HelloMessage")
}, function(e, t, n) {
    "use strict";
    n.d(t, "b", function() {
        return f
    }), n.d(t, "a", function() {
        return h
    });
    var i = n(3);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, u(r.key), r)
        }
    }

    function a(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function c(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function s(e, t, n) {
        return (t = u(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function u(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }

    function l(e, t, n, r, i, o) {
        var a = 6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : void 0;
        c(this, l), s(this, "_isId5Message", !0), s(this, "id", void 0), s(this, "timestamp", void 0), s(this, "type", void 0), s(this, "src", void 0), s(this, "dst", void 0), s(this, "request", void 0), s(this, "payload", void 0), this.id = r, this.timestamp = e, this.src = t, this.dst = n, this.type = o, this.request = a, this.payload = i
    }
    var f = void 0,
        d = function() {
            function t(e) {
                c(this, t), s(this, "_senderId", void 0), s(this, "_messageSeqNb", 0), this._senderId = e, this._messageSeqNb = 0
            }
            return a(t, [{
                key: "createBroadcastMessage",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : e.constructor.name;
                    return new l(performance.now(), this._senderId, f, ++this._messageSeqNb, e, t || e.constructor.name)
                }
            }, {
                key: "createResponse",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    return new l(performance.now(), this._senderId, e.src, ++this._messageSeqNb, t, n || t.constructor.name, e)
                }
            }, {
                key: "createUnicastMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    return new l(performance.now(), this._senderId, e, ++this._messageSeqNb, t, n || t.constructor.name)
                }
            }]), t
        }(),
        h = function() {
            function r(e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : i.c;
                c(this, r), s(this, "_id", void 0), s(this, "_messageFactory", void 0), s(this, "_log", void 0), s(this, "_onMessageCallBackFunction", void 0), this._id = e, this._messageFactory = new d(this._id), this._log = n, this._window = t, this._register()
            }
            return a(r, [{
                key: "_register",
                value: function() {
                    var n = this;
                    n._abortController = "undefined" != typeof AbortController ? new AbortController : void 0;
                    var e = null === (e = n._abortController) || void 0 === e ? void 0 : e.signal;
                    n._window.addEventListener("message", function(e) {
                        var t = e.data;
                        void 0 !== t && t._isId5Message && (e.data.src !== n._id ? void 0 === e.data.dst || e.data.dst === n._id ? n._onMessageCallBackFunction && "function" == typeof n._onMessageCallBackFunction && n._onMessageCallBackFunction(t) : n._log.debug("Ignore msg not to me") : n._log.debug("Ignore loopback msg"))
                    }, {
                        capture: !1,
                        signal: e
                    })
                }
            }, {
                key: "deregister",
                value: function() {
                    this._abortController && this._abortController.abort()
                }
            }, {
                key: "onMessageReceived",
                value: function(e) {
                    this._onMessageCallBackFunction = e
                }
            }, {
                key: "broadcastMessage",
                value: function(e, t) {
                    this._log.debug("Broadcasting message", t, e), this._postMessage(this._messageFactory.createBroadcastMessage(e, t))
                }
            }, {
                key: "sendResponseMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    this._log.debug("Sending response message", e, n, t), this._postMessage(this._messageFactory.createResponse(e, t, n))
                }
            }, {
                key: "unicastMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    this._log.debug("Sending response to", e, n, t), this._postMessage(this._messageFactory.createUnicastMessage(e, t, n))
                }
            }, {
                key: "_postMessage",
                value: function(i) {
                    var o = this;
                    (function e(t) {
                        try {
                            ! function(e) {
                                try {
                                    e.postMessage(i, "*")
                                } catch (e) {
                                    o._log.error("Could not post message to window", e)
                                }
                            }(t);
                            var n = t.frames;
                            if (n)
                                for (var r = 0; r < n.length; r++) e(n[r])
                        } catch (e) {
                            o._log.error("Could not broadcast message", e)
                        }
                    })(o._window.top)
                }
            }]), r
        }()
}, function(e, t, n) {
    "use strict";
    ! function(e) {
        t.a = function() {
            if (void 0 !== e && void 0 !== e.crypto && void 0 !== e.crypto.randomUUID) return e.crypto.randomUUID();
            return "".concat(1e6 * Math.random() | 0)
        }, t.b = function(e, t) {
            var n = "^\\d+(\\.\\d+(\\.\\d+){0,1}){0,1}$";
            if (!e.match(n) || !t.match(n)) return;
            var r = e.split("."),
                i = t.split("."),
                n = function(e) {
                    return parseInt(e) || 0
                },
                e = function(e, t) {
                    t = e - t;
                    return 0 == t ? 0 : t < 0 ? -1 : 1
                },
                t = e(n(r[0]), n(i[0]));
            if (0 !== t) return t;
            t = e(n(r[1]), n(i[1]));
            return 0 !== t ? t : e(n(r[2]), n(i[2]))
        }
    }.call(t, n(2))
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return r
    });
    var r = "1.0.1"
}, function(e, t, n) {
    "use strict";

    function i() {
        return (i = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }
    n.d(t, "a", function() {
        return r
    });
    var a, r = (a = window, function() {
        try {
            var e, t, n = c(),
                r = n.length - 1,
                i = null !== n[r].location || 0 < r && null !== n[r - 1].referrer,
                o = function(e) {
                    for (var t, n = [], r = null, i = null, o = null, a = null, c = null, s = e.length - 1; 0 <= s; s--) {
                        try {
                            i = e[s].location
                        } catch (e) {}
                        if (i) n.push(i), c = c || i;
                        else if (0 !== s) {
                            t = e[s - 1];
                            try {
                                o = t.referrer, a = t.ancestor
                            } catch (e) {}
                            o ? (n.push(o), c = c || o) : a ? (n.push(a), c = c || a) : n.push(r)
                        } else n.push(r)
                    }
                    return {
                        stack: n,
                        detectedRefererUrl: c
                    }
                }(n);
            n[n.length - 1].canonicalUrl && (e = n[n.length - 1].canonicalUrl);
            try {
                t = a.top.document.referrer
            } catch (e) {}
            return {
                topmostLocation: o.detectedRefererUrl,
                ref: t || null,
                reachedTop: i,
                numIframes: r,
                stack: o.stack,
                canonicalUrl: e
            }
        } catch (e) {}
    });

    function c() {
        var e = function() {
                var t, n = [];
                do {
                    try {
                        t = t ? t.parent : a;
                        try {
                            var e = t === a.top,
                                r = {
                                    referrer: t.document.referrer || null,
                                    location: t.location.href || null,
                                    isTop: e
                                };
                            e && (r = i(r, {
                                canonicalUrl: function(e) {
                                    try {
                                        var t = e.querySelector("link[rel='canonical']");
                                        if (null !== t) return t.href
                                    } catch (e) {}
                                    return null
                                }(t.document)
                            })), n.push(r)
                        } catch (e) {
                            n.push({
                                referrer: null,
                                location: null,
                                isTop: t === a.top
                            })
                        }
                    } catch (e) {
                        return n.push({
                            referrer: null,
                            location: null,
                            isTop: !1
                        }), n
                    }
                } while (t !== a.top);
                return n
            }(),
            t = function() {
                try {
                    return a.location.ancestorOrigins ? a.location.ancestorOrigins : void 0
                } catch (e) {}
            }();
        if (t)
            for (var n = 0, r = t.length; n < r; n++) e[n].ancestor = t[n];
        return e
    }
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return l
    });
    var o = n(0),
        t = n(1),
        r = n.n(t),
        a = n(4);

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, u(r.key), r)
        }
    }

    function s(e, t, n) {
        return (t = u(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function u(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var l = function() {
        function i(e, t, n, r) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, i), s(this, "invocationId", void 0), s(this, "localStorageGrantChecker", void 0), s(this, "localStorage", void 0), this.invocationId = e, this.localStorageGrantChecker = t, this.localStorage = n, this.storageConfig = r
        }
        var e, t, n;
        return e = i, n = [{
            key: "makeStoredHash",
            value: function(e) {
                return Object(o.d)("string" == typeof e ? e : "")
            }
        }, {
            key: "storedDataMatchesCurrentData",
            value: function(e, t) {
                return null == e || e === t
            }
        }], (t = [{
            key: "get",
            value: function(e) {
                try {
                    var t = this.localStorageGrant();
                    if (t.isDefinitivelyAllowed()) {
                        var n = this.localStorage.getItemWithExpiration(e);
                        return Object(o.v)(this.invocationId, "Local storage get key=".concat(e.name, " value=").concat(n)), n
                    }
                    Object(o.w)(this.invocationId, "clientStore.get() has been called without definitive grant", t)
                } catch (e) {
                    Object(o.u)(this.invocationId, e)
                }
            }
        }, {
            key: "clear",
            value: function(e) {
                try {
                    this.localStorage.removeItemWithExpiration(e)
                } catch (e) {
                    Object(o.u)(this.invocationId, e)
                }
            }
        }, {
            key: "put",
            value: function(e, t) {
                try {
                    var n = this.localStorageGrant();
                    n.isDefinitivelyAllowed() ? (Object(o.v)(this.invocationId, "Local storage put key=".concat(e.name, " value=").concat(t)), this.localStorage.setItemWithExpiration(e, t)) : Object(o.w)(this.invocationId, "clientStore.put() has been called without definitive grant", n)
                } catch (e) {
                    Object(o.u)(this.invocationId, e)
                }
            }
        }, {
            key: "localStorageGrant",
            value: function() {
                return this.localStorageGrantChecker()
            }
        }, {
            key: "isLocalStorageAvailable",
            value: function() {
                return this.localStorage.isAvailable()
            }
        }, {
            key: "getResponseFromLegacyCookie",
            value: function() {
                var t;
                return r.a.LEGACY_COOKIE_NAMES.forEach(function(e) {
                    Object(o.i)(e) && (t = Object(o.i)(e))
                }), t ? JSON.parse(t) : null
            }
        }, {
            key: "getResponse",
            value: function() {
                var e = this.get(this.storageConfig.ID5);
                return e && JSON.parse(decodeURIComponent(e))
            }
        }, {
            key: "clearResponse",
            value: function() {
                this.clear(this.storageConfig.ID5)
            }
        }, {
            key: "putResponse",
            value: function(e) {
                this.put(this.storageConfig.ID5, encodeURIComponent(e))
            }
        }, {
            key: "getHashedConsentData",
            value: function() {
                return this.get(this.storageConfig.CONSENT_DATA)
            }
        }, {
            key: "clearHashedConsentData",
            value: function() {
                this.clear(this.storageConfig.CONSENT_DATA)
            }
        }, {
            key: "putHashedConsentData",
            value: function(e) {
                e !== new a.a && this.put(this.storageConfig.CONSENT_DATA, e.hashCode())
            }
        }, {
            key: "getHashedPd",
            value: function(e) {
                return this.get(this.pdCacheConfig(e))
            }
        }, {
            key: "isStoredPdUpToDate",
            value: function(e, t) {
                var n = this.getHashedPd(e),
                    r = Object(o.n)(t) && !Object(o.n)(n),
                    e = Object(o.n)(n) && Object(o.n)(t);
                return r || e || n === i.makeStoredHash(t)
            }
        }, {
            key: "clearHashedPd",
            value: function(e) {
                this.clear(this.pdCacheConfig(e))
            }
        }, {
            key: "putHashedPd",
            value: function(e, t) {
                this.put(this.pdCacheConfig(e), i.makeStoredHash(t))
            }
        }, {
            key: "getHashedSegments",
            value: function(e) {
                return this.get(this.segmentsCacheConfig(e))
            }
        }, {
            key: "putHashedSegments",
            value: function(e, t) {
                this.put(this.segmentsCacheConfig(e), i.makeStoredHash(JSON.stringify(t)))
            }
        }, {
            key: "storedSegmentsMatchesSegments",
            value: function(e, t) {
                return i.storedDataMatchesCurrentData(this.getHashedSegments(e), i.makeStoredHash(JSON.stringify(t)))
            }
        }, {
            key: "clearHashedSegments",
            value: function(e) {
                this.clear(this.segmentsCacheConfig(e))
            }
        }, {
            key: "getDateTime",
            value: function() {
                return new Date(this.get(this.storageConfig.LAST)).getTime()
            }
        }, {
            key: "clearDateTime",
            value: function() {
                this.clear(this.storageConfig.LAST)
            }
        }, {
            key: "setDateTime",
            value: function(e) {
                this.put(this.storageConfig.LAST, e)
            }
        }, {
            key: "getNb",
            value: function(e) {
                e = this.get(this.nbCacheConfig(e));
                return e ? parseInt(e) : 0
            }
        }, {
            key: "clearNb",
            value: function(e) {
                this.clear(this.nbCacheConfig(e))
            }
        }, {
            key: "setNb",
            value: function(e, t) {
                this.put(this.nbCacheConfig(e), t)
            }
        }, {
            key: "incNb",
            value: function(e, t) {
                return t = Math.round(t + 1), this.setNb(e, t), t
            }
        }, {
            key: "pdCacheConfig",
            value: function(e) {
                return this.storageConfig.PD.withNameSuffixed(e)
            }
        }, {
            key: "nbCacheConfig",
            value: function(e) {
                return this.storageConfig.ID5.withNameSuffixed(e, "nb")
            }
        }, {
            key: "segmentsCacheConfig",
            value: function(e) {
                return this.storageConfig.SEGMENTS.withNameSuffixed(e)
            }
        }, {
            key: "clearAll",
            value: function(e) {
                this.clearResponse(), this.clearDateTime(), this.clearNb(e), this.clearHashedPd(e), this.clearHashedSegments(e), this.clearHashedConsentData()
            }
        }, {
            key: "removeLegacyCookies",
            value: function(t) {
                var n = new Date(Date.now() - 1e3).toUTCString();
                r.a.LEGACY_COOKIE_NAMES.forEach(function(e) {
                    Object(o.y)("".concat(e), "", n), Object(o.y)("".concat(e, "_nb"), "", n), Object(o.y)("".concat(e, "_").concat(t, "_nb"), "", n), Object(o.y)("".concat(e, "_last"), "", n), Object(o.y)("".concat(e, ".cached_pd"), "", n), Object(o.y)("".concat(e, ".cached_consent_data"), "", n)
                })
            }
        }, {
            key: "storedConsentDataMatchesConsentData",
            value: function(e) {
                return i.storedDataMatchesCurrentData(this.getHashedConsentData(), e.hashCode())
            }
        }]) && c(e.prototype, t), n && c(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), i
    }()
}, function(e, t, n) {
    "use strict";
    t.a = function(e, t) {
        var n = 152 + t - 1,
            t = ~~(n / i);
        if (!e || "C" !== e.charAt(0) || e.length <= t) return;
        t = e.charAt(t), t = r[t];
        return void 0 !== t ? 0 != (t & 1 << i - n % i - 1) : void 0
    };
    var r = {
            A: 0,
            B: 1,
            C: 2,
            D: 3,
            E: 4,
            F: 5,
            G: 6,
            H: 7,
            I: 8,
            J: 9,
            K: 10,
            L: 11,
            M: 12,
            N: 13,
            O: 14,
            P: 15,
            Q: 16,
            R: 17,
            S: 18,
            T: 19,
            U: 20,
            V: 21,
            W: 22,
            X: 23,
            Y: 24,
            Z: 25,
            a: 26,
            b: 27,
            c: 28,
            d: 29,
            e: 30,
            f: 31,
            g: 32,
            h: 33,
            i: 34,
            j: 35,
            k: 36,
            l: 37,
            m: 38,
            n: 39,
            o: 40,
            p: 41,
            q: 42,
            r: 43,
            s: 44,
            t: 45,
            u: 46,
            v: 47,
            w: 48,
            x: 49,
            y: 50,
            z: 51,
            0: 52,
            1: 53,
            2: 54,
            3: 55,
            4: 56,
            5: 57,
            6: 58,
            7: 59,
            8: 60,
            9: 61,
            "-": 62,
            _: 63,
            "+": 62,
            "/": 63
        },
        i = 6
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return f
    });
    var t = n(1),
        r = n.n(t),
        o = n(0);
    n(4), n(7);

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c() {
        return (c = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, a(r.key), r)
        }
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t, n) {
        return (t = a(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function a(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var f = function() {
        function a(e, t, n, r, i, o) {
            u(this, a), l(this, "_availableCallbackTimerId", void 0), l(this, "_availableCallbackFired", !1), l(this, "_availableCallback", void 0), l(this, "_updateCallback", void 0), l(this, "_refreshCallbackTimerId", void 0), l(this, "_refreshCallbackFired", !1), l(this, "_refreshCallback", void 0), l(this, "_isExposed", void 0), l(this, "_fromCache", void 0), l(this, "_isRefreshing", !1), l(this, "_isRefreshingWithFetch", !1), l(this, "_userId", void 0), l(this, "_ext", void 0), l(this, "_userIdAvailable", !1), l(this, "invocationId", void 0), l(this, "config", void 0), l(this, "clientStore", void 0), l(this, "consentManagement", void 0), l(this, "liveIntentApi", void 0), l(this, "_metrics", void 0), this.invocationId = e, this.config = t, this.clientStore = n, this.consentManagement = r, this.liveIntentApi = i, this._metrics = o
        }
        var e, t, n;
        return e = a, n = [{
            key: "doFireOnAvailableCallBack",
            value: function(e) {
                Object(o.v)(e.invocationId, "Id5Status.doFireOnAvailableCallBack"), e._availableCallbackFired = !0, e._availableCallbackTimerId = void 0, e._availableCallback(e)
            }
        }, {
            key: "doFireOnUpdateCallBack",
            value: function(e) {
                Object(o.v)(e.invocationId, "Id5Status.doFireOnUpdateCallBack"), e._updateCallback(e)
            }
        }, {
            key: "doFireOnRefreshCallBack",
            value: function(e) {
                Object(o.v)(e.invocationId, "Id5Status.doFireOnRefreshCallBack"), e._refreshCallbackFired = !0, e._refreshCallbackTimerId = void 0, e._isRefreshing = !1, e._isRefreshingWithFetch = !1, e._refreshCallback(e)
            }
        }], (t = [{
            key: "getOptions",
            value: function() {
                return this.config.getOptions()
            }
        }, {
            key: "getProvidedOptions",
            value: function() {
                return this.config.getProvidedOptions()
            }
        }, {
            key: "getInvalidSegments",
            value: function() {
                return this.config.getInvalidSegments()
            }
        }, {
            key: "updateOptions",
            value: function(e) {
                return this.config.updOptions(e)
            }
        }, {
            key: "startRefresh",
            value: function(e) {
                this._isRefreshing = !0, this._isRefreshingWithFetch = e
            }
        }, {
            key: "setUserId",
            value: function(e, t) {
                var n = this,
                    r = e.universal_uid;
                if (this._isExposed = !0, Object(o.s)(e.ab_testing)) switch (e.ab_testing.result) {
                    case "normal":
                        break;
                    default:
                    case "error":
                        Object(o.u)(this.invocationId, "Id5Status: There was an error with A/B Testing. Make sure controlGroupRatio is a number >= 0 and <= 1");
                        break;
                    case "control":
                        this._isExposed = !1, this.info("User is in control group!")
                }
                var i = this._userId !== r || !1 === Object(o.e)(this._ext, e.ext);
                this._userIdAvailable = !0, this._userId = r, this._ext = e.ext, this._fromCache = t, this.info("User id updated, hasChanged: ".concat(i, ", fromCache: ").concat(t)), Object(o.o)(this._availableCallback) && !1 === this._availableCallbackFired && (this._availableCallbackTimerId && (this.info("Cancelling pending onAvailableCallback watchdog"), clearTimeout(this._availableCallbackTimerId), this._availableCallbackTimerId = void 0), this._availableCallbackTimerId = setTimeout(function() {
                    return a.doFireOnAvailableCallBack(n)
                }, 0)), this._isRefreshing && Object(o.o)(this._refreshCallback) && !1 === this._refreshCallbackFired && (!1 !== t && !1 !== this._isRefreshingWithFetch || (this._refreshCallbackTimerId && (this.info("Cancelling pending onRefreshCallback watchdog"), clearTimeout(this._refreshCallbackTimerId), this._refreshCallbackTimerId = void 0), this._refreshCallbackTimerId = setTimeout(function() {
                    return a.doFireOnRefreshCallBack(n)
                }, 0))), i && Object(o.o)(this._updateCallback) && setTimeout(function() {
                    return a.doFireOnUpdateCallBack(n)
                }, 0)
            }
        }, {
            key: "getUserId",
            value: function() {
                return !1 === this._isExposed ? "0" : this._userId
            }
        }, {
            key: "getLinkType",
            value: function() {
                return !1 === this._isExposed ? 0 : this.getExt().linkType
            }
        }, {
            key: "getExt",
            value: function() {
                var e = !1 === this._isExposed ? {} : this._ext;
                return c({
                    abTestingControlGroup: !this.exposeUserId()
                }, e)
            }
        }, {
            key: "isFromCache",
            value: function() {
                return this._fromCache
            }
        }, {
            key: "exposeUserId",
            value: function() {
                return this._isExposed
            }
        }, {
            key: "getUserIdAsEid",
            value: function() {
                return {
                    source: r.a.ID5_EIDS_SOURCE,
                    uids: [{
                        atype: 1,
                        id: this.getUserId(),
                        ext: this.getExt()
                    }]
                }
            }
        }, {
            key: "onAvailable",
            value: function(e, t) {
                if (!Object(o.o)(e)) throw new Error("onAvailable expect a function");
                var n;
                return Object(o.o)(this._availableCallback) ? this.info("onAvailable was already called, ignoring") : (this._availableCallback = e, (n = this)._userIdAvailable ? (this.info("User id already available firing callback immediately"), this._availableCallbackTimerId = setTimeout(function() {
                    return a.doFireOnAvailableCallBack(n)
                }, 0)) : 0 < t && (this._availableCallbackTimerId = setTimeout(function() {
                    return a.doFireOnAvailableCallBack(n)
                }, t))), this
            }
        }, {
            key: "onUpdate",
            value: function(e) {
                if (!Object(o.o)(e)) throw new Error("onUpdate expect a function");
                this._updateCallback = e;
                var t = this;
                return this._userIdAvailable && setTimeout(function() {
                    return a.doFireOnUpdateCallBack(t)
                }, 0), this
            }
        }, {
            key: "onRefresh",
            value: function(e, t) {
                if (!Object(o.o)(e)) throw new Error("onRefresh expect a function");
                this._refreshCallbackTimerId && (clearTimeout(this._refreshCallbackTimerId), this._refreshCallbackTimerId = void 0), this._refreshCallback = e;
                var n = this;
                return !0 === this._isRefreshing && !1 === this._isRefreshingWithFetch && this._userIdAvailable ? this._refreshCallbackTimerId = setTimeout(function() {
                    return a.doFireOnRefreshCallBack(n)
                }, 0) : 0 < t && (this._refreshCallbackTimerId = setTimeout(function() {
                    return a.doFireOnRefreshCallBack(n)
                }, t)), this
            }
        }, {
            key: "localStorageGrant",
            value: function() {
                return this.clientStore.localStorageGrant()
            }
        }, {
            key: "info",
            value: function(e) {
                Object(o.v)(this.invocationId, "Id5Status: " + e)
            }
        }]) && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), a
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return r
    });
    var r = "1.0.36"
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return l
    });
    var d = n(0),
        t = n(1),
        i = n.n(t);

    function h(e) {
        return (h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function p(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function v(e, t, n) {
        return (t = c(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function a(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== h(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== h(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === h(e) ? e : String(e)
    }
    var s = function() {
            function c(e, t) {
                o(this, c), this.name = e, this.expiresDays = t
            }
            return a(c, [{
                key: "withNameSuffixed",
                value: function() {
                    for (var e = this.name, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    for (var i = 0, o = n; i < o.length; i++) {
                        var a = o[i];
                        e += "_".concat(a)
                    }
                    return new c(e, this.expiresDays)
                }
            }]), c
        }(),
        u = function e() {
            var n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
            o(this, e);

            function t(e) {
                var t = void 0 !== n ? Math.max(1, n) : e.expiresDays;
                return new s(e.name, t)
            }
            var r = i.a.STORAGE_CONFIG;
            this.ID5 = t(r.ID5), this.LAST = t(r.LAST), this.CONSENT_DATA = t(r.CONSENT_DATA), this.PD = t(r.PD), this.PRIVACY = t(r.PRIVACY), this.SEGMENTS = t(r.SEGMENTS), this.LIVE_INTENT = t(r.LIVE_INTENT)
        },
        l = function() {
            function f(e, t) {
                if (o(this, f), v(this, "invocationId", void 0), v(this, "options", void 0), v(this, "providedOptions", void 0), v(this, "invalidSegments", void 0), this.invocationId = e, this.options = {
                        debugBypassConsent: !1,
                        allowLocalStorageWithoutConsentApi: !1,
                        cmpApi: "iab",
                        consentData: {
                            getConsentData: {
                                consentData: void 0,
                                gdprApplies: void 0
                            },
                            getVendorConsents: {}
                        },
                        refreshInSeconds: 7200,
                        partnerId: void 0,
                        partnerUserId: void 0,
                        callbackOnAvailable: void 0,
                        callbackOnUpdates: void 0,
                        callbackTimeoutInMs: void 0,
                        pd: void 0,
                        abTesting: {
                            enabled: !1,
                            controlGroupPct: 0
                        },
                        provider: void 0,
                        maxCascades: 8,
                        applyCreativeRestrictions: !1,
                        segments: void 0,
                        disableUaHints: !1,
                        disableLiveIntentIntegration: !1,
                        storageExpirationDays: void 0,
                        att: void 0,
                        diagnostics: {
                            publishingDisabled: !1,
                            publishAfterLoadInMsec: 3e4,
                            publishBeforeWindowUnload: !0,
                            publishingSampleRatio: .01
                        }
                    }, this.providedOptions = {}, !Object(d.r)(t.partnerId) && !Object(d.t)(t.partnerId)) throw new Error("partnerId is required and must be a number or a string");
                this.invalidSegments = 0, this.updOptions(t), this.storageConfig = new u(t.storageExpirationDays)
            }
            return a(f, [{
                key: "getOptions",
                value: function() {
                    return this.options
                }
            }, {
                key: "getProvidedOptions",
                value: function() {
                    return this.providedOptions
                }
            }, {
                key: "getInvalidSegments",
                value: function() {
                    return this.invalidSegments
                }
            }, {
                key: "updOptions",
                value: function(c) {
                    var s, u = this,
                        l = this;
                    Object(d.s)(c) ? (this.setPartnerId(c.partnerId), s = function(e, t) {
                        u.options[e] = t, u.providedOptions[e] = t
                    }, Object.keys(c).forEach(function(e) {
                        var n, t, r, i, o, a;
                        "segments" === e ? (a = c[e], n = [], Object(d.k)(a) ? (a.forEach(function(e, t) {
                            t = "segments[".concat(t, "]");
                            return Object(d.k)(e.ids) && Object(d.c)(e.ids, d.t) ? e.ids.length < 1 ? (Object(d.u)(l.invocationId, "Config option ".concat(t, ".ids should contain at least one segment ID")), void(l.invalidSegments += 1)) : Object(d.t)(e.destination) ? void n.push(e) : (y(l.invocationId, "".concat(t, ".destination"), "String", e.destination), void(l.invalidSegments += 1)) : (y(l.invocationId, "".concat(t, ".ids"), "Array of String", e.ids), void(l.invalidSegments += 1))
                        }), s(e, n)) : y(l.invocationId, e, "Array", a)) : "diagnostics" === e ? (t = u.options.diagnostics, r = c.diagnostics, Object(d.j)(r, f.configTypes.diagnostics) && (i = function(t) {
                            for (var e = 1; e < arguments.length; e++) {
                                var n = null != arguments[e] ? arguments[e] : {};
                                e % 2 ? p(Object(n), !0).forEach(function(e) {
                                    v(t, e, n[e])
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach(function(e) {
                                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                                })
                            }
                            return t
                        }({}, t), Object.keys(r).forEach(function(e) {
                            void 0 !== t[e] && h(t[e]) === h(r[e]) && (i[e] = r[e])
                        }), u.options[e] = i), u.providedOptions[e] = c[e]) : "partnerId" !== e && (o = f.configTypes[e], a = c[e], Object(d.j)(a, o) ? s(e, a) : y(l.invocationId, e, o, a))
                    })) : Object(d.u)(this.invocationId, "Config options must be an object")
                }
            }, {
                key: "setPartnerId",
                value: function(e) {
                    var t;
                    if (Object(d.t)(e)) {
                        if (t = parseInt(e), isNaN(t) || t < 0) throw new Error("partnerId is required and must parse to a positive integer")
                    } else Object(d.r)(e) && (t = e);
                    if (Object(d.r)(t)) {
                        if (Object(d.r)(this.options.partnerId) && t !== this.options.partnerId) throw new Error("Cannot update config with a different partnerId");
                        this.options.partnerId = t, this.providedOptions.partnerId = e
                    }
                }
            }]), f
        }();

    function y(e, t, n, r) {
        Object(d.u)(e, "Config option ".concat(t, " must be of type ").concat(n, " but was ").concat(toString.call(r), ". Ignoring..."))
    }
    v(l, "configTypes", {
        debugBypassConsent: "Boolean",
        allowLocalStorageWithoutConsentApi: "Boolean",
        cmpApi: "String",
        consentData: "Object",
        refreshInSeconds: "Number",
        partnerUserId: "String",
        callbackOnAvailable: "Function",
        callbackOnUpdates: "Function",
        callbackTimeoutInMs: "Number",
        pd: "String",
        abTesting: "Object",
        provider: "String",
        maxCascades: "Number",
        applyCreativeRestrictions: "Boolean",
        disableUaHints: "Boolean",
        disableLiveIntentIntegration: "Boolean",
        storageExpirationDays: "Number",
        att: "Number",
        diagnostics: "Object"
    })
}, function(e, t, n) {
    "use strict";
    var a = n(0),
        c = n(23);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function s(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? o(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], (n = u(n)) in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : o(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, u(r.key), r)
        }
    }

    function u(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    n = new(function() {
        function e() {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e)
        }
        var t, n, r;
        return t = e, (n = [{
            key: "gather",
            value: function(r) {
                var n, i, o = {
                    lbCDN: "%%LB_CDN%%"
                };
                return c.a.allSettled([(n = "https://lb.eu-1-id5-sync.com/lb/v1", i = r, new c.a(function(t) {
                    Object(a.b)(n, {
                        success: function(e) {
                            e = function(t, n) {
                                try {
                                    return JSON.parse(n)
                                } catch (e) {
                                    return Object(a.u)(r, "Cannot parse the JSON  response from: ".concat(t), n), o
                                }
                            }(n, e);
                            t(e)
                        },
                        error: function(e) {
                            Object(a.w)(i, "Got error from ".concat(n, " endpoint"), e), t(o)
                        }
                    }, null)
                }))]).then(function(e) {
                    var t = o;
                    return e.forEach(function(e) {
                        e.value && (t = s(s({}, t), e.value))
                    }), t
                }).catch(function(e) {
                    return Object(a.u)(r, "Got error ".concat(e, " when gathering extensions data")), o
                })
            }
        }]) && i(t.prototype, n), r && i(t, r), Object.defineProperty(t, "prototype", {
            writable: !1
        }), e
    }());
    t.a = n
}, function(e, i, o) {
    "use strict";
    ! function(e) {
        var t = o(24);
        var n, r = void 0 !== (n = void 0 !== e ? e : window) && void 0 !== n.Promise ? n.Promise : t.a;
        i.a = r
    }.call(i, o(2))
}, function(e, h, p) {
    "use strict";
    ! function(t) {
        var e = p(28),
            n = p(29),
            r = setTimeout;

        function s(e) {
            return Boolean(e && void 0 !== e.length)
        }

        function i() {}

        function o(e) {
            if (!(this instanceof o)) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("not a function");
            this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], d(e, this)
        }

        function a(n, r) {
            for (; 3 === n._state;) n = n._value;
            0 !== n._state ? (n._handled = !0, o._immediateFn(function() {
                var e, t = 1 === n._state ? r.onFulfilled : r.onRejected;
                if (null !== t) {
                    try {
                        e = t(n._value)
                    } catch (e) {
                        return void u(r.promise, e)
                    }
                    c(r.promise, e)
                } else(1 === n._state ? c : u)(r.promise, n._value)
            })) : n._deferreds.push(r)
        }

        function c(t, e) {
            try {
                if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
                if (e && ("object" == typeof e || "function" == typeof e)) {
                    var n = e.then;
                    if (e instanceof o) return t._state = 3, t._value = e, void l(t);
                    if ("function" == typeof n) return void d((r = n, i = e, function() {
                        r.apply(i, arguments)
                    }), t)
                }
                t._state = 1, t._value = e, l(t)
            } catch (e) {
                u(t, e)
            }
            var r, i
        }

        function u(e, t) {
            e._state = 2, e._value = t, l(e)
        }

        function l(e) {
            2 === e._state && 0 === e._deferreds.length && o._immediateFn(function() {
                e._handled || o._unhandledRejectionFn(e._value)
            });
            for (var t = 0, n = e._deferreds.length; t < n; t++) a(e, e._deferreds[t]);
            e._deferreds = null
        }

        function f(e, t, n) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = n
        }

        function d(e, t) {
            var n = !1;
            try {
                e(function(e) {
                    n || (n = !0, c(t, e))
                }, function(e) {
                    n || (n = !0, u(t, e))
                })
            } catch (e) {
                if (n) return;
                n = !0, u(t, e)
            }
        }
        o.prototype.catch = function(e) {
            return this.then(null, e)
        }, o.prototype.then = function(e, t) {
            var n = new this.constructor(i);
            return a(this, new f(e, t, n)), n
        }, o.prototype.finally = e.a, o.all = function(t) {
            return new o(function(i, o) {
                if (!s(t)) return o(new TypeError("Promise.all accepts an array"));
                var a = Array.prototype.slice.call(t);
                if (0 === a.length) return i([]);
                var c = a.length;
                for (var e = 0; e < a.length; e++) ! function t(n, e) {
                    try {
                        if (e && ("object" == typeof e || "function" == typeof e)) {
                            var r = e.then;
                            if ("function" == typeof r) return void r.call(e, function(e) {
                                t(n, e)
                            }, o)
                        }
                        a[n] = e, 0 == --c && i(a)
                    } catch (e) {
                        o(e)
                    }
                }(e, a[e])
            })
        }, o.allSettled = n.a, o.resolve = function(t) {
            return t && "object" == typeof t && t.constructor === o ? t : new o(function(e) {
                e(t)
            })
        }, o.reject = function(n) {
            return new o(function(e, t) {
                t(n)
            })
        }, o.race = function(i) {
            return new o(function(e, t) {
                if (!s(i)) return t(new TypeError("Promise.race accepts an array"));
                for (var n = 0, r = i.length; n < r; n++) o.resolve(i[n]).then(e, t)
            })
        }, o._immediateFn = "function" == typeof t ? function(e) {
            t(e)
        } : function(e) {
            r(e, 0)
        }, o._unhandledRejectionFn = function(e) {
            "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
        }, h.a = o
    }.call(h, p(25).setImmediate)
}, function(e, i, o) {
    ! function(e) {
        var t = void 0 !== e && e || "undefined" != typeof self && self || window,
            n = Function.prototype.apply;

        function r(e, t) {
            this._id = e, this._clearFn = t
        }
        i.setTimeout = function() {
            return new r(n.call(setTimeout, t, arguments), clearTimeout)
        }, i.setInterval = function() {
            return new r(n.call(setInterval, t, arguments), clearInterval)
        }, i.clearTimeout = i.clearInterval = function(e) {
            e && e.close()
        }, r.prototype.unref = r.prototype.ref = function() {}, r.prototype.close = function() {
            this._clearFn.call(t, this._id)
        }, i.enroll = function(e, t) {
            clearTimeout(e._idleTimeoutId), e._idleTimeout = t
        }, i.unenroll = function(e) {
            clearTimeout(e._idleTimeoutId), e._idleTimeout = -1
        }, i._unrefActive = i.active = function(e) {
            clearTimeout(e._idleTimeoutId);
            var t = e._idleTimeout;
            0 <= t && (e._idleTimeoutId = setTimeout(function() {
                e._onTimeout && e._onTimeout()
            }, t))
        }, o(26), i.setImmediate = "undefined" != typeof self && self.setImmediate || void 0 !== e && e.setImmediate || this && this.setImmediate, i.clearImmediate = "undefined" != typeof self && self.clearImmediate || void 0 !== e && e.clearImmediate || this && this.clearImmediate
    }.call(i, o(2))
}, function(e, t, n) {
    ! function(e, h) {
        ! function(n, r) {
            "use strict";
            var i, o, a, c, s, u, t, e;

            function l(e) {
                delete o[e]
            }

            function f(e) {
                if (a) setTimeout(f, 0, e);
                else {
                    var t = o[e];
                    if (t) {
                        a = !0;
                        try {
                            ! function(e) {
                                var t = e.callback,
                                    n = e.args;
                                switch (n.length) {
                                    case 0:
                                        t();
                                        break;
                                    case 1:
                                        t(n[0]);
                                        break;
                                    case 2:
                                        t(n[0], n[1]);
                                        break;
                                    case 3:
                                        t(n[0], n[1], n[2]);
                                        break;
                                    default:
                                        t.apply(r, n)
                                }
                            }(t)
                        } finally {
                            l(e), a = !1
                        }
                    }
                }
            }

            function d() {
                function e(e) {
                    e.source === n && "string" == typeof e.data && 0 === e.data.indexOf(t) && f(+e.data.slice(t.length))
                }
                var t = "setImmediate$" + Math.random() + "$";
                n.addEventListener ? n.addEventListener("message", e, !1) : n.attachEvent("onmessage", e), s = function(e) {
                    n.postMessage(t + e, "*")
                }
            }
            n.setImmediate || (i = 1, a = !(o = {}), c = n.document, e = (e = Object.getPrototypeOf && Object.getPrototypeOf(n)) && e.setTimeout ? e : n, "[object process]" === {}.toString.call(n.process) ? s = function(e) {
                h.nextTick(function() {
                    f(e)
                })
            } : ! function() {
                if (n.postMessage && !n.importScripts) {
                    var e = !0,
                        t = n.onmessage;
                    return n.onmessage = function() {
                        e = !1
                    }, n.postMessage("", "*"), n.onmessage = t, e
                }
            }() ? s = n.MessageChannel ? ((t = new MessageChannel).port1.onmessage = function(e) {
                f(e.data)
            }, function(e) {
                t.port2.postMessage(e)
            }) : c && "onreadystatechange" in c.createElement("script") ? (u = c.documentElement, function(e) {
                var t = c.createElement("script");
                t.onreadystatechange = function() {
                    f(e), t.onreadystatechange = null, u.removeChild(t), t = null
                }, u.appendChild(t)
            }) : function(e) {
                setTimeout(f, 0, e)
            } : d(), e.setImmediate = function(e) {
                "function" != typeof e && (e = new Function("" + e));
                for (var t = new Array(arguments.length - 1), n = 0; n < t.length; n++) t[n] = arguments[n + 1];
                return o[i] = {
                    callback: e,
                    args: t
                }, s(i), i++
            }, e.clearImmediate = l)
        }("undefined" == typeof self ? void 0 === e ? this : e : self)
    }.call(t, n(2), n(27))
}, function(e, t) {
    var n, r, e = e.exports = {};

    function i() {
        throw new Error("setTimeout has not been defined")
    }

    function o() {
        throw new Error("clearTimeout has not been defined")
    }

    function a(t) {
        if (n === setTimeout) return setTimeout(t, 0);
        if ((n === i || !n) && setTimeout) return n = setTimeout, setTimeout(t, 0);
        try {
            return n(t, 0)
        } catch (e) {
            try {
                return n.call(null, t, 0)
            } catch (e) {
                return n.call(this, t, 0)
            }
        }
    }! function() {
        try {
            n = "function" == typeof setTimeout ? setTimeout : i
        } catch (e) {
            n = i
        }
        try {
            r = "function" == typeof clearTimeout ? clearTimeout : o
        } catch (e) {
            r = o
        }
    }();
    var c, s = [],
        u = !1,
        l = -1;

    function f() {
        u && c && (u = !1, c.length ? s = c.concat(s) : l = -1, s.length && d())
    }

    function d() {
        if (!u) {
            var e = a(f);
            u = !0;
            for (var t = s.length; t;) {
                for (c = s, s = []; ++l < t;) c && c[l].run();
                l = -1, t = s.length
            }
            c = null, u = !1,
                function(t) {
                    if (r === clearTimeout) return clearTimeout(t);
                    if ((r === o || !r) && clearTimeout) return r = clearTimeout, clearTimeout(t);
                    try {
                        r(t)
                    } catch (e) {
                        try {
                            return r.call(null, t)
                        } catch (e) {
                            return r.call(this, t)
                        }
                    }
                }(e)
        }
    }

    function h(e, t) {
        this.fun = e, this.array = t
    }

    function p() {}
    e.nextTick = function(e) {
        var t = new Array(arguments.length - 1);
        if (1 < arguments.length)
            for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
        s.push(new h(e, t)), 1 !== s.length || u || a(d)
    }, h.prototype.run = function() {
        this.fun.apply(null, this.array)
    }, e.title = "browser", e.browser = !0, e.env = {}, e.argv = [], e.version = "", e.versions = {}, e.on = p, e.addListener = p, e.once = p, e.off = p, e.removeListener = p, e.removeAllListeners = p, e.emit = p, e.prependListener = p, e.prependOnceListener = p, e.listeners = function(e) {
        return []
    }, e.binding = function(e) {
        throw new Error("process.binding is not supported")
    }, e.cwd = function() {
        return "/"
    }, e.chdir = function(e) {
        throw new Error("process.chdir is not supported")
    }, e.umask = function() {
        return 0
    }
}, function(e, t, n) {
    "use strict";
    t.a = function(t) {
        var n = this.constructor;
        return this.then(function(e) {
            return n.resolve(t()).then(function() {
                return e
            })
        }, function(e) {
            return n.resolve(t()).then(function() {
                return n.reject(e)
            })
        })
    }
}, function(e, t, n) {
    "use strict";
    t.a = function(n) {
        return new this(function(i, e) {
            if (!n || void 0 === n.length) return e(new TypeError(typeof n + " " + n + " is not iterable(cannot read property Symbol(Symbol.iterator))"));
            var o = Array.prototype.slice.call(n);
            if (0 === o.length) return i([]);
            var a = o.length;
            for (var t = 0; t < o.length; t++) ! function t(n, e) {
                if (e && ("object" == typeof e || "function" == typeof e)) {
                    var r = e.then;
                    if ("function" == typeof r) return void r.call(e, function(e) {
                        t(n, e)
                    }, function(e) {
                        o[n] = {
                            status: "rejected",
                            reason: e
                        }, 0 == --a && i(o)
                    })
                }
                o[n] = {
                    status: "fulfilled",
                    value: e
                }, 0 == --a && i(o)
            }(t, o[t])
        })
    }
}, function(e, t, n) {
    "use strict";
    t.b = function(n, r) {
        if (Math.random() < n && i.a) return function(e, t) {
            return new i.b(r, {
                sampling: n
            }).publish(e, t)
        };
        return function(e) {
            return e
        }
    }, t.d = function() {
        return new o.c
    }, t.c = p, n.d(t, "a", function() {
        return v
    });
    var i = n(31),
        r = n(32),
        o = n(8);

    function a(e) {
        return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function s(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? c(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], (n = l(n)) in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : c(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function u(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, l(r.key), r)
        }
    }

    function l(e) {
        e = function(e, t) {
            if ("object" !== a(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== a(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === a(e) ? e : String(e)
    }

    function f(e, t) {
        return (f = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function d(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = h(n);
            return function(e, t) {
                {
                    if (t && ("object" === a(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = h(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function h(e) {
        return (h = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function p(e) {
        return {
            partner: e
        }
    }
    var v = function() {
        ! function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && f(e, t)
        }(o, r["a"]);
        var e, t, n, i = d(o);

        function o(e, t) {
            var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : void 0,
                r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : void 0;
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, o), i.call(this, s(s({
                source: e,
                version: t
            }, p(n)), r))
        }
        return e = o, (t = [{
            key: "loadDelayTimer",
            value: function() {
                return this.timer("id5.api.instance.load.delay", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "fetchCallTimer",
            value: function(e) {
                return this.timer("id5.api.fetch.call.time", s({
                    status: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "fetchFailureCallTimer",
            value: function() {
                return this.fetchCallTimer("fail", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "fetchSuccessfulCallTimer",
            value: function() {
                return this.fetchCallTimer("success", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "extensionsCallTimer",
            value: function() {
                return this.timer("id5.api.extensions.call.time", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "consentRequestTimer",
            value: function(e) {
                return this.timer("id5.api.consent.request.time", s({
                    requestType: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "invocationCountSummary",
            value: function() {
                return this.summary("id5.api.invocation.count", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "instanceCounter",
            value: function(e) {
                return this.counter("id5.api.instance.count", s({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqueDomainsCounter",
            value: function(e) {
                return this.counter("id5.api.instance.domains.count", s({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqWindowsCounter",
            value: function(e) {
                return this.counter("id5.api.instance.windows.count", s({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqPartnersCounter",
            value: function(e) {
                return this.counter("id5.api.instance.partners.count", s({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceJoinDelayTimer",
            value: function() {
                return this.timer("id5.api.instance.join.delay.time", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "instanceLateJoinCounter",
            value: function(e) {
                return this.counter("id5.api.instance.lateJoin.count", s({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceMsgDeliveryTimer",
            value: function() {
                return this.timer("id5.api.instance.message.delivery.time", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }]) && u(e.prototype, t), n && u(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), o
    }()
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function i(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? o(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], (n = c(n)) in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : o(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    n.d(t, "a", function() {
        return u
    }), n.d(t, "b", function() {
        return l
    });
    var s = "https://diagnostics.id5-sync.com/measurements",
        u = "undefined" != typeof Promise && "undefined" != typeof fetch,
        l = function() {
            function n(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, n), this.url = e || s, this._metadata = t
            }
            var e, t, r;
            return e = n, (t = [{
                key: "publish",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                    return e && 0 < e.length ? (e.forEach(function(e) {
                        var n;
                        n = e.tags, Object.keys(n).forEach(function(e) {
                            var t = n[e];
                            t && (t instanceof Object ? n[e] = JSON.stringify(t) : n[e] = "".concat(t))
                        })
                    }), fetch(this.url, {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/plain"
                        },
                        mode: "no-cors",
                        body: JSON.stringify({
                            metadata: i(i({}, this._metadata), t),
                            measurements: e
                        })
                    })) : Promise.resolve()
                }
            }]) && a(e.prototype, t), r && a(e, r), Object.defineProperty(e, "prototype", {
                writable: !1
            }), n
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return y
    });
    var r = n(8),
        i = n(9);

    function o(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function a(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? o(Object(n), !0).forEach(function(e) {
                c(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function c(e, t, n) {
        return (t = p(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e) {
        return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function u(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, i, o, a, c = [],
                    s = !0,
                    u = !1;
                try {
                    if (o = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        s = !1
                    } else
                        for (; !(s = (r = o.call(n)).done) && (c.push(r.value), c.length !== t); s = !0);
                } catch (e) {
                    u = !0, i = e
                } finally {
                    try {
                        if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw i
                    }
                }
                return c
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return l(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function l(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function f(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function d(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, p(r.key), r)
        }
    }

    function h(e, t, n) {
        return t && d(e.prototype, t), n && d(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function p(e) {
        e = function(e, t) {
            if ("object" !== s(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== s(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === s(e) ? e : String(e)
    }
    var v = function() {
            function e() {
                f(this, e)
            }
            return h(e, [{
                key: "has",
                value: function(e) {
                    return void 0 !== this[e]
                }
            }, {
                key: "set",
                value: function(e, t) {
                    return this[e] = t, this
                }
            }, {
                key: "get",
                value: function(e) {
                    return this[e]
                }
            }, {
                key: "values",
                value: function() {
                    return Object.entries(this).map(function(e) {
                        e = u(e, 2), e[0];
                        return e[1]
                    })
                }
            }]), e
        }(),
        y = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
                f(this, t), c(this, "_registry", void 0), c(this, "commonTags", void 0), c(this, "_scheduled", void 0), this._registry = new v, this.commonTags = i.a.from(e)
            }
            return h(t, [{
                key: "getOrCreate",
                value: function(e, t, n) {
                    var r = a(a({}, t), this.commonTags),
                        t = "".concat(e, "[").concat(i.a.toString(r), "]");
                    return this._registry.has(t) || this._registry.set(t, n(e, r)), this._registry.get(t)
                }
            }, {
                key: "getAllMeasurements",
                value: function() {
                    return this._registry.values().map(function(e) {
                        return {
                            name: e.name,
                            type: e.type,
                            tags: e.tags,
                            values: e.values
                        }
                    }).filter(function(e) {
                        return e.values && 0 < e.values.length
                    })
                }
            }, {
                key: "reset",
                value: function() {
                    Array.from(this._registry.values()).forEach(function(e) {
                        return e.reset()
                    })
                }
            }, {
                key: "addCommonTags",
                value: function(e) {
                    this.commonTags = a(a({}, this.commonTags), i.a.from(e))
                }
            }, {
                key: "timer",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.d(e, t)
                    })
                }
            }, {
                key: "counter",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.a(e, t)
                    })
                }
            }, {
                key: "summary",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.b(e, t)
                    })
                }
            }, {
                key: "publish",
                value: function() {
                    var t = this,
                        n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : function(e) {
                            return e
                        },
                        r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                    return Promise.resolve(this.getAllMeasurements()).then(function(e) {
                        return n(e, r)
                    }).then(function(e) {
                        return t.reset()
                    })
                }
            }, {
                key: "schedulePublishAfterMsec",
                value: function(e, t) {
                    var n;
                    return this._scheduled || (n = this, setTimeout(function() {
                        return n._scheduled = !1, n.publish(t, {
                            trigger: "fixed-time",
                            fixed_time_msec: e
                        })
                    }, e), this._scheduled = !0), this
                }
            }, {
                key: "schedulePublishBeforeUnload",
                value: function(e) {
                    var t = this;
                    return addEventListener("beforeunload", function() {
                        return t.publish(e, {
                            trigger: "beforeunload"
                        })
                    }), this
                }
            }]), t
        }()
}]);