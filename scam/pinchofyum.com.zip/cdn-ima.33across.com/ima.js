var _33AcrossIdMappingsProvider;
(() => {
    var t = {
            928: (t, e) => {
                t.exports = function(t) {
                    return new Promise(((e, n) => {
                        const i = function(t) {
                            let {
                                url: e,
                                params: n = {},
                                win: i = window,
                                options: s = {}
                            } = t;
                            const a = new i.XMLHttpRequest("MSXML2.XMLHTTP.3.0"),
                                r = new URLSearchParams(n);
                            return a.open("GET", "".concat(e, "?").concat(r), 1), a.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), a.withCredentials = s.withCredentials || !0, a.timeout = s.timeout, a
                        }(t);
                        i.onreadystatechange = () => {
                            4 === i.readyState && (i.status >= 200 && i.status < 300 ? e(i.responseText) : n("Ajax: Status code ".concat(i.status)))
                        }, i.onerror = () => n("Ajax: Network error"), i.ontimeout = () => n("Ajax: Timeout"), i.send()
                    }))
                }
            },
            698: (t, e) => {
                function n(t, e) {
                    s(t, e), e.add(t)
                }

                function i(t, e, n) {
                    s(t, e), e.set(t, n)
                }

                function s(t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }

                function a(t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                    return n
                }

                function r(t, e) {
                    return function(t, e) {
                        return e.get ? e.get.call(t) : e.value
                    }(t, c(t, e, "get"))
                }

                function o(t, e, n) {
                    return function(t, e, n) {
                        if (e.set) e.set.call(t, n);
                        else {
                            if (!e.writable) throw new TypeError("attempted to set read only private field");
                            e.value = n
                        }
                    }(t, c(t, e, "set"), n), n
                }

                function c(t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                    return e.get(t)
                }
                const l = "iab",
                    h = {
                        CCPA: "__uspapi",
                        GDPR: "__tcfapi"
                    },
                    u = {
                        GDPR: "__tcfapiLocator",
                        CCPA: "__uspapiLocator"
                    },
                    d = {
                        GDPR: "addEventListener",
                        CCPA: "getUSPData"
                    },
                    p = {
                        GDPR: 2,
                        CCPA: 1
                    };
                var w = new WeakMap,
                    v = new WeakMap,
                    f = new WeakMap,
                    g = new WeakMap,
                    m = new WeakMap,
                    S = new WeakMap,
                    k = new WeakMap,
                    P = new WeakMap,
                    C = new WeakSet,
                    M = new WeakSet,
                    W = new WeakSet,
                    b = new WeakSet,
                    A = new WeakSet,
                    y = new WeakSet,
                    D = new WeakSet,
                    T = new WeakSet,
                    E = new WeakSet,
                    x = new WeakSet;

                function L(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : r(this, m);
                    try {
                        if ("function" == typeof e[r(this, v)]) return {
                            cmpApi: e[r(this, v)],
                            win: e
                        };
                        if (e.frames[t]) return {
                            win: e
                        }
                    } catch (t) {}
                    return e === r(this, m).top ? {} : a(this, C, L).call(this, t, e.parent)
                }

                function _(t) {
                    return !("boolean" == typeof(null == t ? void 0 : t.gdprApplies) ? t.gdprApplies : r(this, k)) || (e = null == t ? void 0 : t.tcString) && "string" == typeof e ? {
                        consentData: a(this, b, I).call(this, {
                            consentString: t.tcString,
                            applies: t.gdprApplies,
                            consentObject: t,
                            additionalFields: { ..."string" == typeof t.addtlConsent ? {
                                    addtlConsent: t.addtlConsent
                                } : {}
                            }
                        })
                    } : {
                        errMsg: "CMP returned unexpected value during lookup process.",
                        errArgs: {
                            consentObject: t
                        }
                    };
                    var e
                }

                function j(t) {
                    return (e = null == t ? void 0 : t.uspString) && "string" == typeof e ? {
                        consentData: a(this, b, I).call(this, {
                            consentString: t.uspString,
                            consentObject: t
                        })
                    } : {
                        errMsg: "CMP returned unexpected value during lookup process.",
                        errArgs: {
                            consentObject: t
                        }
                    };
                    var e
                }

                function I() {
                    let {
                        consentString: t,
                        applies: e,
                        consentObject: n,
                        additionalFields: i
                    } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return {
                        consentString: t,
                        vendorData: n,
                        applies: "boolean" == typeof e ? e : r(this, k),
                        apiVersion: p[r(this, w)],
                        name: r(this, w),
                        ...i
                    }
                }

                function R(t) {
                    var e = this;
                    const n = {
                        GDPR: function() {
                            for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                            return a(e, M, _).call(e, ...n)
                        },
                        CCPA: function() {
                            for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                            return a(e, W, j).call(e, ...n)
                        }
                    };
                    return n[r(this, w)](t)
                }

                function O(t, e) {
                    return e ? {
                        GDPR: t => !1 === t.gdprApplies || "tcloaded" === t.eventStatus || "useractioncomplete" === t.eventStatus,
                        CCPA: () => !0
                    }[r(this, w)](t) ? a(this, A, R).call(this, t) : (o(this, g, t), null) : {
                        errMsg: "CMP unable to register callback function.  Please check CMP setup."
                    }
                }

                function U(t, e) {
                    var n, i, s;
                    const a = "".concat(r(this, v), "Return"),
                        o = (null !== (n = t.data) && void 0 !== n && null !== (i = n.includes) && void 0 !== i && i.call(n, a) ? JSON.parse(t.data) : t.data)[a];
                    null != o && o.callId && (null === (s = e[o.callId]) || void 0 === s || s.call(e, o.returnValue, o.success), delete e[o.callId])
                }

                function G(t) {
                    let {
                        command: e,
                        win: n,
                        eventListener: i
                    } = t;
                    const s = {},
                        o = "".concat(r(this, v), "Call");
                    r(this, m)[r(this, v)] = function(t, e, i) {
                        let a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
                        const r = Math.random().toString(),
                            c = {
                                [o]: {
                                    command: t,
                                    version: e,
                                    parameter: a,
                                    callId: r
                                }
                            };
                        s[r] = i, n.postMessage(c, "*")
                    }, r(this, m).addEventListener("message", (t => a(this, D, U).call(this, t, s)), !1), r(this, m)[r(this, v)](e, p[r(this, w)], i)
                }

                function X() {
                    var t = this;
                    const {
                        cmpApi: e,
                        win: n
                    } = a(this, C, L).call(this, u[r(this, w)]);
                    return new Promise((i => {
                        if (!n) return void i({
                            errMsg: "CMP not found"
                        });
                        const s = function() {
                                for (var e = arguments.length, n = new Array(e), s = 0; s < e; s++) n[s] = arguments[s];
                                const r = a(t, y, O).call(t, ...n);
                                r && i(r)
                            },
                            o = d[r(this, w)];
                        e ? e(o, p[r(this, w)], s) : a(this, T, G).call(this, {
                            command: o,
                            win: n,
                            eventListener: s
                        })
                    }))
                }

                function V() {
                    return a(this, A, R).call(this, r(this, P))
                }
                t.exports = class {
                    constructor(t) {
                        let {
                            name: e,
                            userCmp: s = l,
                            win: a = window,
                            config: r = {}
                        } = t;
                        n(this, x), n(this, E), n(this, T), n(this, D), n(this, y), n(this, A), n(this, b), n(this, W), n(this, M), n(this, C), i(this, w, {
                            writable: !0,
                            value: void 0
                        }), i(this, v, {
                            writable: !0,
                            value: void 0
                        }), i(this, f, {
                            writable: !0,
                            value: void 0
                        }), i(this, g, {
                            writable: !0,
                            value: void 0
                        }), i(this, m, {
                            writable: !0,
                            value: void 0
                        }), i(this, S, {
                            writable: !0,
                            value: void 0
                        }), i(this, k, {
                            writable: !0,
                            value: void 0
                        }), i(this, P, {
                            writable: !0,
                            value: void 0
                        }), o(this, w, e), o(this, v, h[e]), o(this, f, s), o(this, m, a), o(this, k, r.defaultPrivacyScope || !1), o(this, S, r.consentTimeout || 1e4), o(this, P, r.staticConsentData || {})
                    }
                    loadConsentData() {
                        var t = this;
                        const e = {
                            iab: function() {
                                for (var e = arguments.length, n = new Array(e), i = 0; i < e; i++) n[i] = arguments[i];
                                return a(t, E, X).call(t, ...n)
                            },
                            static: () => a(this, x, V).call(this)
                        };
                        let n = null;
                        if (!Object.keys(e).includes(r(this, f))) return Promise.resolve({
                            errMsg: "The indicated CMP (".concat(r(this, f), ") is not a supported")
                        });
                        const i = new Promise((t => {
                            n = r(this, m).setTimeout((() => {
                                const {
                                    consentData: e,
                                    errMsg: n
                                } = a(this, A, R).call(this, r(this, g));
                                t({
                                    consentData: n ? a(this, b, I).call(this) : e,
                                    errMsg: "CMP hasn't been loaded"
                                })
                            }), r(this, S))
                        }));
                        return Promise.race([e[r(this, f)](), i]).finally((() => r(this, m).clearTimeout(n)))
                    }
                }
            },
            440: (t, e, n) => {
                function i(t, e) {
                    a(t, e), e.add(t)
                }

                function s(t, e, n) {
                    a(t, e), e.set(t, n)
                }

                function a(t, e) {
                    if (e.has(t)) throw new TypeError("Cannot initialize the same private elements twice on an object")
                }

                function r(t, e) {
                    return function(t, e) {
                        return e.get ? e.get.call(t) : e.value
                    }(t, l(t, e, "get"))
                }

                function o(t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
                    return n
                }

                function c(t, e, n) {
                    return function(t, e, n) {
                        if (e.set) e.set.call(t, n);
                        else {
                            if (!e.writable) throw new TypeError("attempted to set read only private field");
                            e.value = n
                        }
                    }(t, l(t, e, "set"), n), n
                }

                function l(t, e, n) {
                    if (!e.has(t)) throw new TypeError("attempted to " + n + " private field on non-instance");
                    return e.get(t)
                }
                const h = n(928),
                    u = "https://lexicon.33across.com/v1/envelope",
                    d = "33acrossId",
                    p = "".concat(d, "_last"),
                    w = "".concat(d, "_exp"),
                    v = 1e4,
                    f = 28800,
                    g = 90,
                    m = "ima",
                    S = {
                        GDPR: "gdpr_consent",
                        CCPA: "us_privacy"
                    };
                var k = new WeakMap,
                    P = new WeakMap,
                    C = new WeakMap,
                    M = new WeakMap,
                    W = new WeakMap,
                    b = new WeakMap,
                    A = new WeakMap,
                    y = new WeakMap,
                    D = new WeakMap,
                    T = new WeakMap,
                    E = new WeakMap,
                    x = new WeakSet,
                    L = new WeakSet,
                    _ = new WeakSet,
                    j = new WeakSet,
                    I = new WeakSet,
                    R = new WeakSet,
                    O = new WeakSet,
                    U = new WeakSet,
                    G = new WeakSet,
                    X = new WeakSet,
                    V = new WeakSet;

                function H(t) {
                    const e = JSON.parse(t);
                    return e.succeeded && e.data.envelope ? e.data.envelope : ""
                }

                function N() {
                    const t = new Date(o(this, j, z).call(this, r(this, E).EXP));
                    return !!t && new Date(t).getTime() - Date.now() <= 0
                }

                function q() {
                    const t = new Date(o(this, j, z).call(this, r(this, E).LAST));
                    return Date.now() - t.getTime() > 1e3 * r(this, C)
                }

                function z(t) {
                    return r(this, M).localStorage.getItem(t)
                }

                function F(t, e) {
                    return r(this, M).localStorage.setItem(t, e), this
                }

                function J(t) {
                    var e, n;
                    const i = new Date(Date.now() + 864e5 * r(this, y));
                    return o(n = o(e = o(this, I, F).call(this, r(this, E).VALUE, t), I, F).call(e, r(this, E).EXP, i.toUTCString()), I, F).call(n, r(this, E).LAST, (new Date).toUTCString()), this
                }
                async function B() {
                    const t = await o(this, U, K).call(this);
                    return t ? (o(this, R, J).call(this, t), o(this, X, Y).call(this, t)) : r(this, b)
                }
                async function K() {
                    try {
                        const t = await r(this, W).call(this, {
                            url: r(this, P),
                            params: o(this, G, Q).call(this, {
                                allConsentData: await r(this, D)
                            }),
                            options: {
                                withCredentials: !0,
                                timeout: v
                            }
                        });
                        return o(this, x, H).call(this, t)
                    } catch (t) {
                        throw new Error("_33AcrossIdMappingsProvider: ".concat(t))
                    }
                }

                function Q(t) {
                    let {
                        allConsentData: e
                    } = t;
                    return e.reduce(((t, e) => {
                        let {
                            consentData: n = {}
                        } = e;
                        const i = S[n.name];
                        return n.consentString && i && Object.assign(t, {
                            [i]: n.consentString
                        }), t
                    }), {
                        pid: r(this, k),
                        src: r(this, T),
                        ver: "0.5.0"
                    })
                }

                function Y(t) {
                    const [e] = r(this, A), [n] = e.uids;
                    return Object.assign(n, {
                        id: t,
                        atype: 1
                    }), c(this, b, r(this, A)), r(this, b)
                }

                function Z() {
                    return "esp" === r(this, T) ? {
                        VALUE: "".concat(r(this, T), "_").concat(d),
                        LAST: "".concat(r(this, T), "_").concat(p),
                        EXP: "".concat(r(this, T), "_").concat(w)
                    } : {
                        VALUE: d,
                        LAST: p,
                        EXP: w
                    }
                }
                t.exports = class {
                    constructor(t) {
                        let {
                            pid: e,
                            apiUrl: n = u,
                            expires: a = g,
                            refreshInSeconds: r = f,
                            win: o = window,
                            src: l = m
                        } = t, {
                            ajax: d = h,
                            consentDataPromise: p = Promise.resolve([])
                        } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        i(this, V), i(this, X), i(this, G), i(this, U), i(this, O), i(this, R), i(this, I), i(this, j), i(this, _), i(this, L), i(this, x), s(this, k, {
                            writable: !0,
                            value: void 0
                        }), s(this, P, {
                            writable: !0,
                            value: void 0
                        }), s(this, C, {
                            writable: !0,
                            value: void 0
                        }), s(this, M, {
                            writable: !0,
                            value: void 0
                        }), s(this, W, {
                            writable: !0,
                            value: void 0
                        }), s(this, b, {
                            writable: !0,
                            value: []
                        }), s(this, A, {
                            writable: !0,
                            value: []
                        }), s(this, y, {
                            writable: !0,
                            value: void 0
                        }), s(this, D, {
                            writable: !0,
                            value: void 0
                        }), s(this, T, {
                            writable: !0,
                            value: void 0
                        }), s(this, E, {
                            writable: !0,
                            value: {}
                        }), c(this, k, e), c(this, P, n), c(this, C, r), c(this, M, o), c(this, W, d), c(this, y, a), c(this, D, p), c(this, T, l)
                    }
                    async fetch() {
                        c(this, E, o(this, V, Z).call(this)), c(this, A, [{
                            source: "33across.com",
                            uids: [{}]
                        }]);
                        const t = r(this, M).decodeURIComponent(o(this, j, z).call(this, r(this, E).VALUE));
                        return o(this, L, N).call(this) || !t ? o(this, O, B).call(this) : (o(this, _, q).call(this) && o(this, O, B).call(this), o(this, X, Y).call(this, t))
                    }
                    getIds() {
                        return r(this, b)
                    }
                    getLoadingIds() {
                        return r(this, A)
                    }
                    getPid() {
                        return r(this, k)
                    }
                    getSource() {
                        return r(this, T)
                    }
                }
            },
            966: (t, e, n) => {
                const i = n(698),
                    s = n(440),
                    a = Promise.all(["GDPR", "CCPA"].map((t => new i({
                        name: t
                    }).loadConsentData())));

                function r(t) {
                    const e = new s(t, {
                        consentDataPromise: a
                    });
                    return r.providers[e.getSource()] = e, e
                }
                r.providers = {}, t.exports = r
            }
        },
        e = {},
        n = function n(i) {
            var s = e[i];
            if (void 0 !== s) return s.exports;
            var a = e[i] = {
                exports: {}
            };
            return t[i](a, a.exports, n), a.exports
        }(966);
    _33AcrossIdMappingsProvider = n
})();